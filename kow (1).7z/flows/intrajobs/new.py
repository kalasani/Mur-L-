from datetime import datetime
import time

import sys
from os import path


import datetime
import calendar
sys.path.append(((path.dirname(path.dirname(path.abspath(__file__))))))
import json
#from datetime import datetime, timedelta
import sys, traceback
import os
import datetime;
tmp = '2015-10-28 16:09:59'
dt = datetime.datetime.strptime(tmp,'%Y-%m-%d %H:%M:%S')

date_string = f'{dt:%Y-%m-%d}'
print(type(dt))
print(dt)
dt.date()
print("ds=======>",date_string)


# date_str = "2008-11-10 17:53:59"
# # dt_obj = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
# # #print(dt_obj)
# new_dt_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
# #print(type(dt_obj))
# print(new_dt_obj)
# #print repr(dt_obj)

#date_str = "2008-11-10 17:53:59"
# date_str="2018-09-27 15:12:21.330000"
# newTime = time.strptime(date_str, "%Y-%m-%d %H:%M:%S")
# print(type(newTime))
# #print repr(time_tuple)
#
# newTime=datetime.datetime.strptime(date_str,"%Y-%m-%d")
# #newTime=datetime.strptime(date_str, "%Y-%m-%d").date()
# print("newTime is ====>",newTime)
#end_date_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
#end_date_time = datetime.strptime(date_str, "%Y-%m-%d")
#print(end_date_time)

data = """ {"env.name": "dev", "job.name": "pdp_dclrms_intraday", "high.water.mark.dts": "2018-09-20 04:23:12",
                "job.debug": "0", "etl.load.type": "incremental", "etl.run.bus.prd.start.timestamp": "2018-09-25",
                "etl.run.bus.prd.end.timestamp": "2018-09-25", "etl.run.max_dataload_dt": "2018-09-25",
                "teradata.publish.flag": "True", "etl.load.delta.period": "1", "etl.load.loop.counter": "1",
                "etl.load.post.arrival.day.count": "10"} 
                """
dataOne = {"env.name": "dev", "job.name": "pdp_dclrms_intraday", "high.water.mark.dts": "2018-09-20 04:23:12",
           "job.debug": "0", "etl.load.type": "incremental", "etl.run.bus.prd.start.timestamp": "2018-09-25",
           "etl.run.bus.prd.end.timestamp": "2018-09-25", "etl.run.max_dataload_dt": "2018-09-25",
           "teradata.publish.flag": "True", "etl.load.delta.period": "1", "etl.load.loop.counter": "1",
           "etl.load.post.arrival.day.count": "10"}

data = {"env.name": "stage", "job.name": "pdp_dclrms_intraday",
        "pdp.intraday.high.water.mark.dts": "2018-09-26 04:23:12",
        "price_config.high.water.mark.dts": "2018-09-26 04:23:12",
        "sl_lim_config.high.water.mark.dts": "2018-09-26 04:23:12",
        "sl_lim_rcmd.high.water.mark.dts": "2018-09-26 04:23:12",
        "price_rcmd_dtl.high.water.mark.dts": "2018-09-26 04:23:12",
        "expect_oh_bkng.high.water.mark.dts": "2018-09-26 04:23:12",
        "uncnstrn_bkng.high.water.mark.dts": "2018-09-26 04:23:12",
        "uncnstrn_dmnd_fcs.high.water.mark.dts": "2018-09-26 04:23:12", "job.debug": "0",
        "etl.load.type": "incremental", "etl.run.bus.prd.start.timestamp": "2018-09-26",
        "etl.run.bus.prd.end.timestamp": "2018-09-26", "etl.run.max_dataload_dt": "2018-09-25",
        "teradata.publish.flag": "True", "etl.load.delta.period": "1", "etl.load.loop.counter": "1",
        "etl.load.post.arrival.day.count": "10"}
print(data)
print(type(data))
print(dataOne)
print(type(dataOne))

# tablesNames = ["PRICE_CONFIG", "SL_LIM_CONFIG", "PRICE_RCMD_DTL",
#                "SL_LIM_RCMD", "EXPECT_OH_BKNG", "UNCNSTRN_BKNG",
#                "UNCNSTRN_DMND_FCST"]
# runDTS = ["PRICE_CONFIG_DTS", "SL_LIM_CONFIG_DTS", "PRICE_RCMD_DTL_DTS",
#                "SL_LIM_RCMD_DTS", "EXPECT_OH_BKNG_DTS", "UNCNSTRN_BKNG_DTS",
#                "UNCNSTRN_DMND_FCST_DTS"]
# #
# # runDTS = [self.price_rcmd_dtl_high_water_mark_dts, self.sl_lim_config_high_water_mark_dts,
# #           self.price_rcmd_dtl_high_water_mark_dts,
# #           self.sl_lim_rcmd_high_water_mark_dts, self.expect_oh_bkng_high_water_mark_dts,
# #           self.uncnstrn_bkng_high_water_mark_dts,
# #           self.uncnstrn_dmnd_fcs_high_water_mark_dts]
# # i = 0;
# # while i < len(tablesNames):
# #     tableName = tablesNames[i];
# #     while i<len(runDTS):
# #         runDTS=runDTS[i];
# #         print(tableName+"  "+runDTS)
# #         i+=1
# #     # runDTS = runDTS[i];
# #     # print(tableName)
# #     i+=1
#
# for f, b in zip(tablesNames, runDTS):
#     print(f, b)

# one=["PRICE_CONFIG","SL_LIM_CONFIG","PRICE_RCMD_DTL","SL_LIM_RCMD","EXPECT_OH_BKNG","UNCNSTRN_BKNG","UNCNSTRN_DMND_FCST"]
# two = ["PRICE_CONFIG_0", "SL_LIM_CONFIG_1", "PRICE_RCMD_DTL_2", "SL_LIM_RCMD", "EXPECT_OH_BKNG",  "UNCNSTRN_BKNG", "UNCNSTRN_DMND_FCST"]

# table_dts_names = [self.price_rcmd_dtl_high_water_mark_dts, self.price_rcmd_dtl_high_water_mark_dts,
#                    self.price_rcmd_dtl_high_water_mark_dts]

# price_hig_dts=""
# sl_lim_hi_dts=""
# price_rcmd_dts=""
# sl_lim_rcmd_dts=""
# expect_dts=""
# uncn_dts=""
# un_dmnd_dts=""
# for name in tableNames:
#     if name =="PRICE_CONFIG":
#         price_hig_dts="price_hig_dts_new";
#     if  name =="SL_LIM_CONFIG":
#         sl_lim_hi_dts="sl_lim_hi_dts";
#     if name == "PRICE_RCMD_DTL":
#         price_rcmd_dts = "price_rcmd_dts";
#     if name == "SL_LIM_RCMD":
#         sl_lim_rcmd_dts = "sl_lim_rcmd_dts";
#     if name == "EXPECT_OH_BKNG":
#         expect_dts = "expect_dts";
#     if name == "UNCNSTRN_BKNG":
#         uncn_dts = "uncn_dts";
#     if name == "UNCNSTRN_DMND_FCST":
#         un_dmnd_dts = "un_dmnd_dts";
#
#
#
# print("price_hig_dts===>",price_hig_dts)
# print("sl_lim_hi_dts===>",sl_lim_hi_dts)
# print("price_rcmd_dts===>",price_rcmd_dts)
# print("sl_lim_rcmd_dts===>",sl_lim_rcmd_dts)
# print("expect_dts===>",expect_dts)
# print("uncn_dts===>",uncn_dts)
# print("un_dmnd_dts===>",un_dmnd_dts)

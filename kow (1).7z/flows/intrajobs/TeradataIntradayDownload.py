import sys
from os import path

sys.path.append(((path.dirname(path.dirname(path.abspath(__file__))))))
import json
from datetime import datetime, timedelta
from framework.compression.compresser_new import *
from framework.core.BaseJob import BaseJob, constant
from framework.utils.S3DataLoader import *
import sys, traceback
import os

databasemap = {"dclrm": "sha", "dclrm_dm": "dm", "dcl_rms_app": "app", "date": "dt", "dcl_rms_app_arch": "arch"}


class PartitionMetadata:
    def __init__(self, **entries):
        self.__dict__.update(entries)


class TeradataIntradayDownload(BaseJob):
    """
     spark the spark context
     environment identifies the teradata environment and can have strings like dv, tst etc.
     user identifies the user of teradata
     password identifies the password to authenticate to teradata
     url identifies the teradata jdbc url
     s3_root_bucket identifies the s3 root bucket
     start_dt_str the start date for which the download needs to happen in YYYY-MM-DD format
     end_dt_str the end date for which the download needs to happen in YYYY-MM-DD format
     refresh if set to 1 will overwrite any existing partitions
    """

    # def __init__(self,spark,environment,url,user,password,s3_root_bucket,start_dt_str,end_dt_str,num_days,refresh):
    def __init__(self, name, table, start_dt_time):
        self.table = table
        self.environment = None
        self.user = None
        self.password = None
        self.url = None
        # self.start_date_time = datetime.strptime(str(start_dt_time), "%Y-%m-%d %H:%M:%S")
        # date_str = "%s %s" %(str(self.start_date_time.date()),"23:59:59")
        # self.end_date_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        self.BEGIN_DT = datetime.strptime('1800-01-01', "%Y-%m-%d").date()
        self.BEGIN_DT_TIME = datetime.strptime('1800-01-01 00:00:00', "%Y-%m-%d %H:%M:%S")
        print
        name
        super(TeradataIntradayDownload, self).__init__(name)

    def setUp(self):
        properties = self.env
        self.url = properties.teradata_jdbc_url
        self.environment = properties.teradata_environment
        self.orig_environment = self.environment
        self.user = properties.teradata_uid
        self.password = properties.teradata_pwd

    def loadData(self):
        self.table_info = self.config.getTableConfig(self.table)
        print(self.table_info)

    def preProcess(self):
        pass

    def createDriver(self):
        pass

    def writeToHDFS(self):
        pass

    def tearDown(self):
        pass

    def get_columns(self, df, database_name, table_name):
        """
          Gets the list of columns from a table in teradata
          df: Input dataframe
          database_name the name of the database
          table_name the name of the tables whose columns need to be identified

          returns a list of column strings
        """
        filter_clause = " upper(databaseName) == '%s' and upper(tableName) == '%s' " % (
        database_name.upper(), table_name.upper())
        df_columns = df.select("ColumnName").filter(filter_clause)
        df_columns_list = df_columns.collect()
        columns_list = []
        for row in df_columns_list:
            if row.ColumnName.lower() != "insert_dts" and row.ColumnName.lower().startswith("etl_") == False:
                columns_list.append(str((row.ColumnName).strip()))
        return columns_list

    def get_data_from_teradata(self, columns_df, meta, start_dt_time):
        """
          Gets data from teradata and returns the data frame
        """
        dbtable = "%s_%s_%s.%s" % (self.environment, meta.database_name, "vmdb", meta.table_name)
        database_name = "%s_%s_%s" % (self.environment, meta.database_name, "vmdb")
        # dbtableName = "%s_s" %meta.table_name
        dbtableName = "%s" % meta.table_name
        column_list = self.get_columns(columns_df, database_name, meta.table_name)
        cols_as_string = ",".join(column_list)
        print
        "%s" % cols_as_string
        sql = None
        start_column_present = None
        if hasattr(meta, "start_dt_column"):
            start_column_present = meta.start_dt_column
        if meta.increment == "N" and start_column_present == None:
            sql = "select %s from %s" % (cols_as_string, dbtableName)
        else:
            if meta.increment == "N":
                # get the complete data as increment is set to 'N'
                sql = "select cast(%s as date) as partition_dt,%s \
                   from %s" % (meta.start_dt_column, cols_as_string, dbtableName)
            elif meta.start_dt_column != None and meta.start_dt_column.endswith("dts"):
                sql = "select cast(%s as date) as partition_dt,%s \
                   from %s \
                   where cast(%s as timestamp) > TIMESTAMP'%s' " \
                      % (meta.start_dt_column, cols_as_string, dbtableName, meta.start_dt_column, start_dt_time)
                # and cast(%s as timestamp) <= TIMESTAMP'%s'" \
                # %(meta.start_dt_column,cols_as_string,dbtableName,meta.start_dt_column,start_dt_time,meta.start_dt_column,end_dt_time)
            elif meta.start_dt_column != None:
                sql = "select %s as partition_dt,%s \
                   from %s \
                   where cast(%s as timestamp) > TIMESTAMP'%s' " \
                      % (meta.start_dt_column, cols_as_string, dbtableName, meta.start_dt_column, start_dt_time)
                # and cast(%s as timestamp) <= TIMESTAMP'%s'" \
                # %(meta.start_dt_column,cols_as_string,dbtableName,meta.start_dt_column,start_dt_time,meta.start_dt_column,end_dt_time)
            else:
                print
                " not a valid condition for intraday"
                sys.exit(-1)
        print
        " the value of sql is %s" % sql
        print
        " the value of increment is %s val" % meta.increment
        print
        " the value of refresh is %s" % self.refresh
        print
        " the value of parititonReq is %s val" % meta.partitionReq
        if meta.partitionReq == "N":
            print
            "Partition NOT required for %s" % dbtable
            sql2 = " ( %s ) as t " % sql
            url = "%s/DATABASE=%s" % (self.url, database_name)
            df = self.spark.read.format("jdbc") \
                .option("url", url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", sql2) \
                .option("password", self.password) \
                .load()
            return df
        elif meta.partitionReq == "Y" and meta.increment == 'Y' and self.refresh == 0:
            print
            "Partition used for '%s', partitions: '%s'" % (meta.numPartitions, meta.partitionColumn)
            # find upper and lower bounds
            bound_sql = " (select max(%s) mx, min(%s) mn from  (%s ) A ) as t" % (
            meta.partitionColumn, meta.partitionColumn, sql)
            bound_url = "%s/DATABASE=%s" % (self.url, database_name)

            bound_df = self.spark.read.format("jdbc") \
                .option("url", bound_url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", bound_sql) \
                .option("password", self.password) \
                .load()
            cnt = bound_df.count()
            bound_vals = bound_df.collect()[0]
            print
            bound_vals
            if bound_vals["mn"] == None:
                return None
            lower_bound = long(bound_vals["mn"])
            upper_bound = long(bound_vals["mx"])
            print
            " bounded count should be 1 - count is %s upper:%s lower:%s" % (cnt, upper_bound, lower_bound)
            sql2 = " ( %s ) as t " % sql
            print
            sql2
            df = self.spark.read.format("jdbc") \
                .option("url", bound_url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", sql2) \
                .option("password", self.password) \
                .option("numPartitions", meta.numPartitions) \
                .option("partitionColumn", meta.partitionColumn) \
                .option("lowerBound", lower_bound) \
                .option("upperBound", upper_bound) \
                .load()
            return df
        else:
            print
            "not a valid condition for intraday"
            sys.exi(-1)

    def check_if_parititon_exists(self, partition_path, format="orc"):
        """
          Checks if a partition exists, if it exists returns 1
          else returns 0
        """
        try:
            df = self.spark.read.format(format).load(partition_path)
            return 1
        except:
            the_type, the_value, traceb = sys.exc_info()
            print
            the_type
            print
            the_value
            print
            partition_path
            return 0

    def process(self):
        """
          reads a meta data json file and identifies all
          tables that need to be downloaded

          if refresh is set to 1
             No checks for partitions are done
          if refresh is set to 0
             checks if a partition exists before downloading data
             check is only done for the end date
        """
        partitionMetadataObj = PartitionMetadata(**self.table_info)
        s3loc_dbc = "%s/%s/%s/data" % (self.s3_root_bucket, "dbc", "columnsv")
        columns_df = self.spark.read.format("orc").load(s3loc_dbc)
        columns_df.cache()

        print
        "PERF INFO START: Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())

        intraday = 'N'
        if hasattr(partitionMetadataObj, "intraday"):
            intraday = partitionMetadataObj.intraday

        if intraday == 'N':
            print
            " table not marked for intraday in metadataconfig json.. skippng"
            return

        time_value = self.getMaxTimeOnHdfs(partitionMetadataObj)
        print
        " value of max time is %s" % time_value
        df = self.get_data_from_teradata(columns_df, partitionMetadataObj, time_value)
        if df == None:
            print
            "PERF INFO END: No data to download Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())
            return
        self.persist(df, partitionMetadataObj)
        print
        "PERF INFO END: Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())

    def getMaxTimeOnHdfs(self, meta):
        start_column_present = None
        if hasattr(meta, "start_dt_column"):
            start_column_present = meta.start_dt_column
        if start_column_present == None:
            return self.BEGIN_DT_TIME
        s3loc = "%s/%s/%s/data" % (self.s3_root_bucket, databasemap[meta.database_name], meta.table_name)
        max_data_values = self.spark.read.format("orc").load(s3loc).agg(
            max(meta.start_dt_column).alias("max_time")).collect()
        if max_data_values != None:
            time_val = max_data_values[0]["max_time"]
            time_val = str(time_val).split(".")[0]
            print
            " the max value identified is %s" % time_val
            return datetime.strptime(time_val, "%Y-%m-%d %H:%M:%S")
        return self.BEGIN_DT_TIME

    def persist(self, df, partitionMetadataObj):
        s3loc = None
        if df == None or df.rdd.isEmpty == True:
            return
        if databasemap[partitionMetadataObj.database_name] != "":
            s3loc = "%s/%s/%s/data" % (
            self.s3_root_bucket, databasemap[partitionMetadataObj.database_name], partitionMetadataObj.table_name)
            print
            "looking up database lookup database:%s and table:%s" % (
            partitionMetadataObj.database_name, partitionMetadataObj.table_name)
        else:
            print
            "error in looking up database lookup database:%s and table:%s" % (
            partitionMetadataObj.database_name, partitionMetadataObj.table_name)
            sys.exit(1)
        start_column_present = None
        intraday = 'N'
        if hasattr(partitionMetadataObj, "intraday"):
            intraday = partitionMetadataObj.intraday
        if hasattr(partitionMetadataObj, "start_dt_column"):
            start_column_present = partitionMetadataObj.start_dt_column
        if partitionMetadataObj.increment == "N" and start_column_present == None:
            print
            "increment=N %s" % partitionMetadataObj.increment
            print
            "overwrite mode"
            df.write.mode("overwrite").format("orc").save(s3loc)
        else:
            print
            "increment=Y %s" % partitionMetadataObj.increment
            if partitionMetadataObj.increment == "N":
                print
                "overwrite mode"
                df = df.repartition("partition_dt")
                df.write.partitionBy("partition_dt").mode("overwrite").format("orc").save(s3loc)
            elif (self.refresh == 0):
                print
                "append mode becaue of append or incremental"
                df.write.partitionBy("partition_dt").mode("append").format("orc").save(s3loc)
            else:
                print
                "overwrite mode"
                df = df.repartition("partition_dt")
                df.write.partitionBy("partition_dt").mode("overwrite").format("orc").save(s3loc)


if __name__ == '__main__':

    # t = Test.getJob("trail")
    if __name__ == '__main__':
        """ The main method drives the flow
          python terada_download.py <tablename>
        """
        if len(sys.argv) != 2:
            print
            "error in command line arguments - should be of the form python teradata_downaload.py <tablename>"

        print
        "%s" % sys.argv
        start_date = None
        end_date = None
        try:
            table = sys.argv[1]
            timestr = "2018-09-25 07:20:25"
            appName = "download_intraday_%s" % table.lower()
            downloader = TeradataIntradayDownload(appName, table, timestr)
            downloader.execute()

        except:
            print
            "error in parsing input parameters"
            traceback.print_exc()
            sys.exit(-1)
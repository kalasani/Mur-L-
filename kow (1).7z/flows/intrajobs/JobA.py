class JobA(object):
    def mytest(self):
        print("JobA")

if __name__ == '__main__':

    try:
        print("MyTest")
    except:
        print("new")

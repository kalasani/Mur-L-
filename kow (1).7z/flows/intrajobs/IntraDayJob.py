import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob_old import *;
#from flows.intrajobs.IntraDayBtchRunDTS import *;
class IntraDayJob(BaseJob):
    def __init__(self):
        self.table = "pdp_dclrms_intraday"
        super(IntraDayJob, self).__init__(self.table)

    def setUp(self):
        #properties = self.config.getEnvConfig()
        #print(properties)
        #self.s3_root_bucket = properties.hdfs_root_directory
        #self.data_loader = S3DataLoader(self.spark, self.s3_root_bucket)
        #print("Before Setup Calling Here ")
        #print(self.table)
        #t_properties = self.config.getJobConfig(self.table.lower(), False)
        #print(t_properties)
        #self.start_date = datetime.strptime(t_properties.start_date, "%Y-%m-%d").date()
        #self.end_date = datetime.strptime(t_properties.end_date, "%Y-%m-%d").date()
        #self.refresh = t_properties.data_download_refresh
        #self.runType = t_properties.load_type;
        #self.debug = t_properties.debug
        self.runType = self.load_type
        self.intraday = self.config.getIntradayJonConfig("intraday");
        self.hig_water_mark_dts=self.intraday.high_water_mark_dts;
        print("self.intraday ===>",self.intraday)
        print("hig_water_mark_dt===>",self.hig_water_mark_dts);
        # if self.parameters.max_dataload_dt is None :
        #     self.max_data_load_dt=self.end_date
        # else :
        #     self.max_data_load_dt=datetime.strptime(self.parameters.max_dataload_dt, "%Y-%m-%d").date()


    def loadData(self):
        print("high_water_mark_dts==>", self.high_water_mark_dts)

    def createDriver(self):
        pass;

    def preProcess(self):
        pass

    def process(self):
        #intraRunDTS=IntraDayBtchRunDTS()
        pass;

    def writeToHDFS(self):
        pass;

    def tearDown(self):
        pass



if __name__ == '__main__':

    try:
        print("IntraDayJob BOH JOB start Here  ")
        obj = IntraDayJob()
        obj.execute()
        print("IntraDayJob BOH JOB end Here  ")
    except:
        traceback.print_exc()
        sys.exit(-1)

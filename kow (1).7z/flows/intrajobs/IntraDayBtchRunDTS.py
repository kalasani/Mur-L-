import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
#from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob import *;
class IntraDayBtchRunDTS(BaseJob):

    def __init__(self, name, table):
        self.table = table
        self.environment = None
        self.user = None
        self.password = None
        self.url = None
        self.BEGIN_DT = datetime.strptime('1800-01-01', "%Y-%m-%d").date()
        super(IntraDayBtchRunDTS, self).__init__(name)

    def setUp(self):
        properties = self.env
        self.url = properties.teradata_jdbc_url
        self.environment = properties.teradata_environment
        self.orig_environment = self.environment
        self.user = properties.teradata_uid
        self.password = properties.teradata_pwd

    def loadData(self):
        pass;

    def preProcess(self):
        pass

    def createDriver(self):
        pass

    def readDataTeradata(self,sql):
        df = self.spark.read.format("jdbc") \
            .option("url", self.url) \
            .option("driver", "com.teradata.jdbc.TeraDriver") \
            .option("user", self.user) \
            .option("dbtable", sql) \
            .option("password", self.password) \
            .load();
        df.printSchema()
        df.show(10)
        refValue = df.collect()[0];
        return refValue;


    def process(self):
        print("Process started here ")
        #url = "%s/DATABASE=%s" % (self.url, self.database_name)
        #print(url)
        print("self.user==>",self.user)
        print("self.password==>", self.password)
        print("self.url==>", self.url)
        sql="( select max(btch_end_dts) as btch_end_dts from stg_dcl_rms_app_vmdb.btch  WHERE btch_sts_nm='SUCCESSFUL' AND btch_end_dts >='2018-08-23 00:00:00') as one";
        df=self.readDataTeradata(self.sql);


    def tearDown(self):
        pass


if __name__ == '__main__':

    try:
        print("IntraDayJob BOH JOB start Here  ")
        appName = "download_agecategory"
        obj = IntraDayBtchRunDTS(appName,appName)

        obj.execute()
        print("IntraDayJob BOH JOB end Here  ")
    except:
        traceback.print_exc()
        sys.exit(-1)

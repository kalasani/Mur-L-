from flows.intrajobs.JobA import *;
class JobB(object):
    def classsB(self):
        print("ClassB")

if __name__ == '__main__':

    try:
        obj = JobA()

    except:
        print("Job Error ")




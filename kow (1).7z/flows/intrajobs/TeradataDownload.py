import sys
from os import path

sys.path.append(((path.dirname(path.dirname(path.abspath(__file__))))))
import json
from datetime import datetime, timedelta
from framework.compression.compresser_new import *
from framework.core.BaseJob import BaseJob, constant
from framework.utils.S3DataLoader import *
import sys, traceback
import os

databasemap = {"dclrm": "sha", "dclrm_dm": "dm", "dcl_rms_app": "app", "date": "dt", "dcl_rms_app_arch": "arch"}


class PartitionMetadata:
    def __init__(self, **entries):
        self.__dict__.update(entries)


class TeradataDownload(BaseJob):
    """
     spark the spark context
     environment identifies the teradata environment and can have strings like dv, tst etc.
     user identifies the user of teradata
     password identifies the password to authenticate to teradata
     url identifies the teradata jdbc url
     s3_root_bucket identifies the s3 root bucket
     start_dt_str the start date for which the download needs to happen in YYYY-MM-DD format
     end_dt_str the end date for which the download needs to happen in YYYY-MM-DD format
     refresh if set to 1 will overwrite any existing partitions
    """

    # def __init__(self,spark,environment,url,user,password,s3_root_bucket,start_dt_str,end_dt_str,num_days,refresh):
    def __init__(self, name, table):
        self.table = table
        self.environment = None
        self.user = None
        self.password = None
        self.url = None
        self.BEGIN_DT = datetime.strptime('1800-01-01', "%Y-%m-%d").date()
        super(TeradataDownload, self).__init__(name)

    def setUp(self):
        properties = self.env
        self.url = properties.teradata_jdbc_url
        self.environment = properties.teradata_environment
        self.orig_environment = self.environment
        self.user = properties.teradata_uid
        self.password = properties.teradata_pwd

    def loadData(self):
        self.table_info = self.config.getTableConfig(self.table)
        print(self.table_info)

    def preProcess(self):
        pass

    def createDriver(self):
        pass

    def writeToHDFS(self):
        pass

    def tearDown(self):
        pass

    def get_columns(self, df, database_name, table_name):
        """
          Gets the list of columns from a table in teradata
          df: Input dataframe
          database_name the name of the database
          table_name the name of the tables whose columns need to be identified

          returns a list of column strings
        """
        filter_clause = " upper(databaseName) == '%s' and upper(tableName) == '%s' " % (
        database_name.upper(), table_name.upper())
        df_columns = df.select("ColumnName").filter(filter_clause)
        df_columns_list = df_columns.collect()
        columns_list = []
        for row in df_columns_list:
            if row.ColumnName.lower() != "insert_dts" and row.ColumnName.lower().startswith("etl_") == False:
                columns_list.append(str((row.ColumnName).strip()))
        return columns_list

    def get_data_from_teradata(self, columns_df, meta, start_dt, end_dt):
        """
          Gets data from teradata and returns the data frame
        """
        dbtable = "%s_%s_%s.%s" % (self.environment, meta.database_name, "vmdb", meta.table_name)
        if self.environment=="dev":
            self.environment="dv";
        database_name = "%s_%s_%s" % (self.environment, meta.database_name, "vmdb")
        # dbtableName = "%s_s" %meta.table_name
        dbtableName = "%s" % meta.table_name
        column_list = self.get_columns(columns_df, database_name, meta.table_name)
        cols_as_string = ",".join(column_list)
        print
        "%s" % cols_as_string
        sql = None
        start_column_present = None
        if hasattr(meta, "start_dt_column"):
            start_column_present = meta.start_dt_column
        if meta.increment == "N" and start_column_present == None:
            sql = "select %s from %s" % (cols_as_string, dbtableName)
        else:
            if meta.increment == "N":
                # get the complete data as increment is set to 'N'
                sql = "select cast(%s as date) as partition_dt,%s \
                   from %s" % (meta.start_dt_column, cols_as_string, dbtableName)
            elif meta.start_dt_column != None and meta.start_dt_column.endswith("dts"):
                sql = "select cast(%s as date) as partition_dt,%s \
                   from %s \
                   where cast(%s as date) >= DATE'%s' and cast(%s as date) <= DATE'%s'" \
                      % (meta.start_dt_column, cols_as_string, dbtableName, meta.start_dt_column, start_dt,
                         meta.start_dt_column, end_dt)
            elif meta.start_dt_column != None:
                sql = "select %s as partition_dt,%s \
                   from %s \
                   where cast(%s as date) >= DATE'%s' and cast(%s as date) <= DATE'%s'" \
                      % (meta.start_dt_column, cols_as_string, dbtableName, meta.start_dt_column, start_dt,
                         meta.start_dt_column, end_dt)
            else:
                sql = "select %s,%s \
                   from %s \
                   where %s >= DATE'%s' and %s  <= DATE'%s'" \
                      % (meta.start_dt_column, cols_as_string, dbtableName, meta.start_dt_column, start_dt,
                         meta.start_dt_column, end_dt)
        print
        " the value of sql is %s" % sql
        print
        " the value of increment is %s val" % meta.increment
        print
        " the value of refresh is %s" % self.refresh
        print
        " the value of parititonReq is %s val" % meta.partitionReq
        if meta.partitionReq == "N":
            print
            "Partition NOT required for %s" % dbtable
            sql2 = " ( %s ) as t " % sql
            url = "%s/DATABASE=%s" % (self.url, database_name)
            df = self.spark.read.format("jdbc") \
                .option("url", url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", sql2) \
                .option("password", self.password) \
                .load()
            return df
        elif meta.partitionReq == "Y" and meta.increment == 'Y' and self.refresh == 0:
            print
            "Partition used for '%s', partitions: '%s'" % (meta.numPartitions, meta.partitionColumn)
            # find upper and lower bounds
            bound_sql = " (select max(%s) mx, min(%s) mn from  (%s ) A ) as t" % (
            meta.partitionColumn, meta.partitionColumn, sql)
            bound_url = "%s/DATABASE=%s" % (self.url, database_name)

            bound_df = self.spark.read.format("jdbc") \
                .option("url", bound_url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", bound_sql) \
                .option("password", self.password) \
                .load()
            cnt = bound_df.count()
            bound_vals = bound_df.collect()[0]
            print
            bound_vals
            if bound_vals["mn"] == None:
                return None
            lower_bound = long(bound_vals["mn"])
            upper_bound = long(bound_vals["mx"])
            print
            " bounded count should be 1 - count is %s upper:%s lower:%s" % (cnt, upper_bound, lower_bound)
            sql2 = " ( %s ) as t " % sql
            print
            sql2
            df = self.spark.read.format("jdbc") \
                .option("url", bound_url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", sql2) \
                .option("password", self.password) \
                .option("numPartitions", meta.numPartitions) \
                .option("partitionColumn", meta.partitionColumn) \
                .option("lowerBound", lower_bound) \
                .option("upperBound", upper_bound) \
                .load()
            return df
        else:
            print
            "Partition used for '%s', partitions: '%s'" % (meta.numPartitions, meta.partitionColumn)
            # find upper and lower bounds
            bound_sql = " (select max(%s) mx, min(%s) mn from  %s ) as t" % (
            meta.partitionColumn, meta.partitionColumn, dbtableName)
            bound_url = "%s/DATABASE=%s" % (self.url, database_name)

            bound_df = self.spark.read.format("jdbc") \
                .option("url", bound_url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", bound_sql) \
                .option("password", self.password) \
                .load()
            cnt = bound_df.count()
            bound_vals = bound_df.collect()[0]
            print
            bound_vals
            lower_bound = long(bound_vals["mn"])
            upper_bound = long(bound_vals["mx"])
            print
            " bounded count should be 1 - count is %s upper:%s lower:%s" % (cnt, upper_bound, lower_bound)

            df = self.spark.read.format("jdbc") \
                .option("url", self.url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user) \
                .option("dbtable", dbtable) \
                .option("password", self.password) \
                .option("numPartitions", meta.numPartitions) \
                .option("partitionColumn", meta.partitionColumn) \
                .option("lowerBound", lower_bound) \
                .option("upperBound", upper_bound) \
                .load()
            df.registerTempTable(dbtableName)
            print
            "download from teradata sql %s" % sql
            return self.spark.sql(sql)

    def check_if_parititon_exists(self, partition_path, format="orc"):
        """
          Checks if a partition exists, if it exists returns 1
          else returns 0
        """
        try:
            df = self.spark.read.format(format).load(partition_path)
            return 1
        except:
            the_type, the_value, traceb = sys.exc_info()
            print
            the_type
            print
            the_value
            print
            partition_path
            return 0

    def process(self):
        """
          reads a meta data json file and identifies all
          tables that need to be downloaded

          if refresh is set to 1
             No checks for partitions are done
          if refresh is set to 0
             checks if a partition exists before downloading data
             check is only done for the end date
        """
        partitionMetadataObj = PartitionMetadata(**self.table_info)
        ### SPECIAL HANDLING FOR COLUMNSV
        if partitionMetadataObj.table_name.lower() == "columnsv":
            ### END OF SPECIAL HANDLING FOR COLUMNSV
            s3loc_dbc = "%s/%s/%s/data" % (self.s3_root_bucket, "dbc", "columnsv")
            columns_df = self.spark.read.format("jdbc") \
                .option("url", self.url) \
                .option("driver", "com.teradata.jdbc.TeraDriver") \
                .option("user", self.user).option("dbtable", "DBC.columnsv") \
                .option("password", self.password) \
                .option("numPartitions", 100) \
                .option("partitionColumn", "columnId") \
                .option("lowerBound", 0) \
                .option("upperBound", 3000) \
                .load()
            columns_df = columns_df.repartition(50, "databaseName")
            columns_df.cache()
            columns_df.write.mode("overwrite").format("orc").save(s3loc_dbc)
            return
        else:
            ### END OF SPECIAL HANDLING FOR COLUMNSV
            s3loc_dbc = "%s/%s/%s/data" % (self.s3_root_bucket, "dbc", "columnsv")
            columns_df = self.spark.read.format("orc").load(s3loc_dbc)
            columns_df.cache()
        partition_present = 0

        print
        "PERF INFO START: Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())
        if partitionMetadataObj.table_name == "DT":
            self.environment = "pd"
        else:
            self.environment = self.orig_environment
        if databasemap[partitionMetadataObj.database_name] != "" and partitionMetadataObj.increment == 'Y':
            s3loc = "%s/%s/%s/data/partition_dt=%s/" % (
            self.s3_root_bucket, databasemap[partitionMetadataObj.database_name], partitionMetadataObj.table_name,
            self.end_date)
            if (self.refresh == 0):
                partition_present = self.check_if_parititon_exists(s3loc, "orc")

        intraday = 'N'
        if hasattr(partitionMetadataObj, "intraday"):
            intraday = partitionMetadataObj.intraday
        if partition_present == 1 and intraday == 'N':
            print
            "%s already downloaded " % partitionMetadataObj.table_name
            return
        else:
            print
            "%s not present - so need to to download " % partitionMetadataObj.table_name

        print
        "%s processing  list " % partitionMetadataObj.table_name

        df = self.get_data_from_teradata(columns_df, partitionMetadataObj, self.start_date, self.end_date)
        if df == None:
            print
            "PERF INFO END: No data to download Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())
            return
        self.persist(df, partitionMetadataObj)
        print
        "PERF INFO END: Name:%s time:%s" % (partitionMetadataObj.table_name, datetime.now())

    def persist(self, df, partitionMetadataObj):
        print
        self.end_date
        versioned_end_dt = self.end_date + timedelta(days=-1)
        versioned = 0
        if hasattr(partitionMetadataObj, "versioned"):
            if partitionMetadataObj.versioned == "Y" and self.refresh == 0:
                versioned = 1
                print
                "versioning starting "
                # df.cache()
                # count = df.count()
                # print " count of incremental data is %s" %count
                df = version_data("refresh", self.BEGIN_DT, versioned_end_dt, partitionMetadataObj.table_name,
                                  self.spark, self.s3_root_bucket, df, 0)
                df.cache()
                count = df.count()
                print
                " count after versioning is %s" % count
                # the caches is a must , if not data is not available because of the lazy nature
                # data being read is overwritten
        if df == None or df.rdd.isEmpty == True:
            return
        if databasemap[partitionMetadataObj.database_name] != "":
            s3loc = "%s/%s/%s/data" % (
            self.s3_root_bucket, databasemap[partitionMetadataObj.database_name], partitionMetadataObj.table_name)
            print
            "looking up database lookup database:%s and table:%s" % (
            partitionMetadataObj.database_name, partitionMetadataObj.table_name)
        else:
            print
            "error in looking up database lookup database:%s and table:%s" % (
            partitionMetadataObj.database_name, partitionMetadataObj.table_name)
            sys.exit(1)
        start_column_present = None
        intraday = 'N'
        if hasattr(partitionMetadataObj, "intraday"):
            intraday = partitionMetadataObj.intraday
        if hasattr(partitionMetadataObj, "start_dt_column"):
            start_column_present = partitionMetadataObj.start_dt_column
        if partitionMetadataObj.increment == "N" and start_column_present == None:
            print
            "increment=N %s" % partitionMetadataObj.increment
            print
            "overwrite mode"
            df.write.mode("overwrite").format("orc").save(s3loc)
        else:
            print
            "increment=Y %s" % partitionMetadataObj.increment
            if partitionMetadataObj.increment == "N":
                print
                "overwrite mode"
                df = df.repartition("partition_dt")
                df.write.partitionBy("partition_dt").mode("overwrite").format("orc").save(s3loc)
            elif versioned == 0 and (self.refresh == 0 and intraday == 'Y'):
                # in intraday we write the data to the specific partition directly
                print
                "direct write mode becaue of intraday"
                s3loc = "%s/%s/%s/data/partition_dt=%s" % (
                self.s3_root_bucket, databasemap[partitionMetadataObj.database_name], partitionMetadataObj.table_name,
                self.end_date)
                df.write.mode("overwrite").format("orc").save(s3loc)
            elif versioned == 0 and (self.refresh == 0):
                print
                "append mode becaue of append or incremental"
                df.write.partitionBy("partition_dt").mode("append").format("orc").save(s3loc)
            else:
                print
                "overwrite mode"
                df = df.repartition("partition_dt")
                df.write.partitionBy("partition_dt").mode("overwrite").format("orc").save(s3loc)


if __name__ == '__main__':

    # t = Test.getJob("trail")
    if __name__ == '__main__':
        """ The main method drives the flow
          python terada_download.py <tablename>
        """
        if len(sys.argv) != 2:
            print
            "error in command line arguments - should be of the form python teradata_downaload.py <tablename>"

        print
        "%s" % sys.argv
        start_date = None
        end_date = None
        try:
            table = sys.argv[1]
            appName = "download_%s" % table.lower()
            downloader = TeradataDownload(appName, table)
            downloader.execute()

        except:
            print
            "error in parsing input parameters"
            traceback.print_exc()
            sys.exit(-1)
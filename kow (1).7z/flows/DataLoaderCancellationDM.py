##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : run_data_loader BOH -DataLoading & Driver Prepration              #
# Author            : Nikhila Teki                                                          #
# Date created      : 20180619                                                           #
# Purpose           : To fetch gross per dimension metrices for all VF* inventory levels #
# Revision History  :                                                                    #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                     #
# 20180618     Anjaiah Y   Chris                                                          #
#                                                                                        #
##########################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
#from flows.utils.S3DataLoader import *
#from flows.jobs.con_resbaseln_cancellation_dm import *
#from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
#from flows.utils.DataFrameUtil import *
from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from pyspark.sql.types import *

from time import time
import os, sys

class DataLoaderCancellationDM(object):

    def __init__(self,start_dt,end_dt,sql_context,s3_bucket,data_loader,debug):
        self.start_dt=start_dt
        self.end_dt = end_dt
        self.sql_context = sql_context
        self.s3_bucket = s3_bucket
        self.data_loader=data_loader;
        self.debug = debug


    def run_cancel_data_loader(self):
        """
        Driver program to run cancellation_dm
        Attributes
        start_dt    : the time slice that is being executed
        sql_context : the spark sql context
        s3_bucket   : the s3 bucket that identifies the data source
        debug       :  debug flag
        """

        ##################################################################
        # Driver program to run run_data_loader dm  process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################
        # print "run_cancel_data_loader STARTED"
        t0 = time()

        data_loader = self.data_loader

        ###########################################################################
        # STEP 2:   Loading data from S3 and create corresponding dataframes      #
        ###########################################################################

        #########################################################
        #                         VOYAGE                        #
        #########################################################

        ## Get all voyages and meta information  - TBD needs to go in a common class ##
        vyge_filter_clause = "UPPER(instnc_st_nm)='STANDARD' \
                        and ship_cd != 'XP' "

        ## Applying filter clause while loading data from s3 and populating selected columns ##
        vyge_df = self.data_loader.read_data("dm", "VYGE") \
            .filter(vyge_filter_clause)
        ## All voyages meta informationa collected in voyage_df ##
        vyge_df.createOrReplaceTempView(" vyge ")
        vyge_df.persist();
        t1 = str(time() - t0)
        # print "vyge load completed in "+t1+" seconds"
        if self.debug == 1:
            DebugCount.count_check(vyge_df, "vyge")

        #########################################################
        #                   VOYAGE_ATTR                         #
        #########################################################

        ## Get all voyages and meta information  - TBD needs to go in a common class ##
        vyge_attr_df = None
        if str(self.start_dt) == str('2016-01-11'):
            # print "in if condition data loader"
            # vyge_attr_filter_clause = "UPPER(instnc_st_nm)='STANDARD' \
            #                                             and ship_cd != 'XP' \
            #                                             and date('%s') >= date(vrsn_strt_dts) \
            #                                             and date('%s') < date(vrsn_end_dts)" % (start_dt, start_dt)
            #
            vyge_attr_filter_clause = "UPPER(instnc_st_nm)='STANDARD' \
                                                                and ship_cd != 'XP'"

            vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR") \
                .filter(vyge_attr_filter_clause)

        else:
            # vyge_attr_filter_clause = "invld_vyge_in=0 \
            #                         and UPPER(instnc_st_nm)='STANDARD' \
            #                                             and ship_cd != 'XP' \
            #                                             and date('%s') >= date(vrsn_strt_dts) \
            #                                             and date('%s') < date(vrsn_end_dts)" % (start_dt, start_dt)

            vyge_attr_filter_clause = "invld_vyge_in=0 \
                                            and UPPER(instnc_st_nm)='STANDARD' \
                                                                and ship_cd != 'XP'"

            vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR") \
                .filter(vyge_attr_filter_clause)
        # vyge_attr_nextdays_df=None
        # if (start_dt <> end_dt):
        #
        #     dt = start_dt + timedelta(days=1)
        #     print "hello '%s' and '%s'"%(dt, end_dt)
        #     # vyge_attr_filter_clause = "invld_vyge_in=0 \
        #     #             and UPPER(instnc_st_nm)='STANDARD' \
        #     #             and ship_cd != 'XP' \
        #     #             and date('%s') >= date(vrsn_strt_dts) \
        #     #             and date('%s') < date(vrsn_end_dts)" %(dt, end_dt)
        #     vyge_attr_filter_clause = "invld_vyge_in=0 \
        #                         and UPPER(instnc_st_nm)='STANDARD' \
        #                         and ship_cd != 'XP'"
        #
        #
        #     vyge_attr_nextdays_df = data_loader.read_data("dm", "VYGE_ATTR") \
        #                               .filter(vyge_attr_filter_clause)
        #     vyge_attr_df = vyge_attr_firstday_df.union(vyge_attr_nextdays_df).dropDuplicates()
        #
        # if (start_dt == end_dt):
        #     print("dates are same")
        #     vyge_attr_df = vyge_attr_firstday_df
        vyge_attr_df.createOrReplaceTempView(" vyge_attr ")
        vyge_attr_df.persist();
        # vyge_attr_df.write.mode("overwrite").format("orc").save("/user/mohaw002/vyge_attr_df")
        t2 = str(time() - t0)
        # print "vyge_attr load completed in " + t2 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(vyge_attr_df, "vyge_attr")

        #########################################################
        #                   SHIP_STRM_STRM_TYP                  #
        #########################################################
        """
        ## Get all ship category type code and ship code details from SHIP_STRM_STRM_TYP ##
        ship_strm_strm_typ_filter_clause = " UPPER(strm_typ_cd) NOT IN('IRG','XAM') \
                        and UPPER(instnc_st_nm)='STANDARD' \
                        and date('%s') >= date(vrsn_strt_dts) \
                        and date('%s') < date(vrsn_end_dts) " % (start_dt, start_dt)

        ship_strm_strm_typ_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
            .filter(ship_strm_strm_typ_filter_clause)
        ship_strm_strm_typ_df.createOrReplaceTempView(" ship_strm_strm_typ ")
        ship_strm_strm_typ_df.persist()
        if debug == 1:
            count_check(ship_strm_strm_typ_df, "ship_strm_strm_typ")

        #########################################################
        #                   SHIP_STRM_TYP_EXT                   #
        #########################################################

        ## Get all ship category type extention details along with category names ##
        ship_strm_typ_ext_filter_clause = " UPPER(ship_strm_typ_cd) NOT IN('IRG','XAM') \
                        and UPPER(instnc_st_nm)='STANDARD' \
                        and date('%s') >= date(vrsn_strt_dts) \
                        and date('%s') < date(vrsn_end_dts) " % (start_dt, start_dt)

        ship_strm_typ_ext_df = data_loader.read_data("dm", "SHIP_STRM_TYP_EXT") \
            .filter(ship_strm_typ_ext_filter_clause)
        ship_strm_typ_ext_df.createOrReplaceTempView(" ship_strm_typ_ext ")
        ship_strm_typ_ext_df.persist()
        if debug == 1:
            count_check(ship_strm_typ_ext_df, "ship_strm_typ_ext")

        #########################################################
        #                       SHIP_FEAT                       #
        #########################################################
        """
        ## Load Ship Feat data by checking with start date value on config_start_dts and config_end_dts ##
        ship_feat_filter_clause = "UPPER(lgcl_del_in) = 'N' \
                                   and date('%s') >= date(ship_feat_config_strt_dts) \
                        and date('%s') < date(ship_feat_config_end_dts)" % (self.start_dt, self.end_dt)

        ship_feat_df = data_loader.read_data("app", "SHIP_FEAT") \
            .filter(ship_feat_filter_clause)
        ship_feat_df.createOrReplaceTempView(" ship_feat ")
        ship_feat_df.persist()
        t3 = str(time() - t0)
        # print "ship_feat load completed in " + t3 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(ship_feat_df, "ship_feat")

        #########################################################
        #                       SFB_SEQ                         #
        #########################################################

        ## Get all science fare bucket sequence information and loaded as dataframe ##
        sfb_seq_filter_clause = "UPPER(sfb_nm) != 'OFFICER'"

        sfb_seq_df = self.data_loader.read_data("app", "SFB_SEQ") \
            .filter(sfb_seq_filter_clause)
        sfb_seq_df.createOrReplaceTempView(" sfb_seq ")
        sfb_seq_df.persist();
        t4 = str(time() - t0)
        # print "sfb_seq load completed in " + t4 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(sfb_seq_df, "sfb_seq")

        #########################################################
        #                       RES_BASELN                      #
        #########################################################
        # min(date(res_baseln.vrsn_strt_dts))
        ## Get all resrvation baseln information and loaded entirely as dataframe ##

        min_opening_date_of_vyges = self.sql_context.sql("SELECT \
                                                            MIN(vyge_opn_dt) AS min_vyge_opn_dt \
                                                          FROM \
                                                            vyge_attr").head()[0]
        # print("min vyge open date is %s" %(min_opening_date_of_vyges))
        # print("fetching res_basln using these parameters start_dt: ('%s') end_dt: ('%s')" %(start_dt,end_dt))
        res_baseln_filter = "upper(instnc_st_nm)= 'STANDARD' \
                        AND upper(sfb_nm) <> 'OFFICER' \
                        AND UPPER(price_strm_typ_cd) NOT IN('IRG','XAM') \
                        AND date('%s') >= date('%s') " % (self.start_dt, min_opening_date_of_vyges)
        res_baseln_all_df = data_loader.read_data_with_filter("dm", "RES_BASELN", "partition_dt", \
                                                              str(min_opening_date_of_vyges), str(self.end_dt),
                                                              res_baseln_filter) \
            .select("vyge_id", "sfb_nm", "vrsn_strt_dts", "vrsn_end_dts")

        res_baseln_all_df.createOrReplaceTempView("res_baseln_all")
        res_baseln_formatted_df = self.sql_context.sql(
            " SELECT DISTINCT vyge_id,sfb_nm, date(vrsn_strt_dts) as startdt, date(vrsn_end_dts) as enddt from res_Baseln_all")
        # res_baseln_all_df.write.mode("overwrite").format("orc").save("/user/mohaw002/res_baseln_all_df")

        # res_baseln_sfb_min_df = sql_context.sql("SELECT DISTINCT vyge_id,sfb_nm,MIN(date(vrsn_strt_dts)) \
        #                                     OVER (PARTITION BY vyge_id,sfb_nm) as startdt, date(vrsn_end_dts) as enddt FROM \
        #                                      res_baseln_all")\
        #                 .dropDuplicates()
        #
        # res_baseln_sfb_max_df = sql_context.sql("SELECT DISTINCT vyge_id,sfb_nm,MAX(date(vrsn_end_dts)) \
        #                                         OVER (PARTITION BY vyge_id,sfb_nm) as enddt FROM \
        #                                          res_baseln_all") \
        #     .dropDuplicates()
        # res_baseln_sfb_df = res_baseln_sfb_min_df.join(res_baseln_sfb_max_df,["vyge_id","sfb_nm"]).select(res_baseln_sfb_min_df.vyge_id,res_baseln_sfb_min_df.sfb_nm,res_baseln_sfb_min_df.startdt,res_baseln_sfb_max_df.enddt)
        # res_baseln_all_df.coalesce(1).write.mode("overwrite").format("orc").save("/user/mohaw002/resbaseln_sfb")
        # record_count = res_baseln_sfb_df.count()
        # print "value after res_baseln_sfb is : '%s'" %record_count
        res_baseln_df = res_baseln_formatted_df.join(vyge_attr_df.select("vyge_id"), "vyge_id")

        # res_baseln_df.printSchema()
        res_baseln_df.createOrReplaceTempView("res_baseln")
        res_baseln_df.persist();
        # record_count = res_baseln_df.count()
        # print "res_baseln count is :('%s')" %record_count
        t5 = str(time() - t0)
        # print "res_baseln load completed in " + t5 + " seconds"

        if self.debug == 1:
            DebugCount.count_check(res_baseln_df, "res_baseln")

        #########################################################
        #                    APP_VYGE_XREF                      #
        #########################################################
        """
        ## Get all application voyage information and loaded entirely as dataframe ##
        app_vyge_xref_filter_clause = "UPPER(lgcl_del_in) = 'N'"

        app_vyge_xref_df = data_loader.read_data("app", "APP_VYGE_XREF") \
            .filter(app_vyge_xref_filter_clause)
        app_vyge_xref_df.createOrReplaceTempView("app_vyge_xref")
        app_vyge_xref_df.persist();
        if debug == 1:
            count_check(app_vyge_xref_df, "app_vyge_xref")

        #########################################################
        #                    SFB                                #
        #########################################################
        """
        ## Get all sfb data adn loaded as dataframe ##
        sfb_filter_clause = " lgcl_del_in = 'N' "

        sfb_df = data_loader.read_data("app", "SFB") \
            .filter(sfb_filter_clause)
        sfb_df.createOrReplaceTempView("sfb")
        sfb_df.persist()
        t6 = str(time() - t0)
        # print "sfb load completed in " + t6 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(sfb_df, "sfb")

        #########################################################
        #                  PROMO_ELIG                           #
        #########################################################

        ## Get all promo eligible codes and laoded as dataframe ##
        promo_elig_filter_clause = " UPPER(instnc_st_nm) = 'STANDARD' "

        promo_elig_df = data_loader.read_data("dm", "PROMO_ELIG") \
            .filter(promo_elig_filter_clause)
        promo_elig_df.createOrReplaceTempView("promo_elig")
        promo_elig_df.persist()
        t7 = str(time() - t0)
        # print "promo elig load completed in" + t7 + " seconds"

        if self.debug == 1:
            DebugCount.count_check(promo_elig_df, "promo_elig")

        #########################################################
        #                  SL_LIM_VYGE_SUM                      #
        #########################################################

        ## Get all selling limits of active voyages adn loaded as a dataframe ##
        sl_lim_vyge_sum_filter_clause = " UPPER(instnc_st_nm) = 'STANDARD' \
                        and is_stop_sl_in = 0 \
                        and ocpncy_cn is null \
                        and age_fr_nb is null \
                        and dng_tm is null \
                        and age_ctgy_cd is null \
                        and grp_typ_cd is null \
                        and gst_seq_fr_nb is null \
                        and conditiontext is null \
                        and agcy_id is null \
                        and res_typ_cd is null \
                        and ref_src_nm is null \
                        and pkg_typ_cd is null \
                        "

        sl_lim_vyge_sum_df = data_loader.read_data("dm", "SL_LIM_VYGE_SUM") \
            .filter(sl_lim_vyge_sum_filter_clause)
        sl_lim_vyge_sum_df.createOrReplaceTempView("sl_lim_vyge_sum")
        sl_lim_vyge_sum_df.persist()
        t8 = str(time() - t0)
        # print "sl_lim_vyge_sum load completed in " + t8 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(sl_lim_vyge_sum_df, "sl_lim_vyge_sum")


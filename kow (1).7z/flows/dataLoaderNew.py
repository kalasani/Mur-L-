##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : run_data_loader BOH -DataLoading & Driver Prepration              #
# Author            : Anjaiah M                                                          #
# Date created      : 20180619                                                           #
# Purpose           : To fetch gross per dimension metrices for all VF* inventory levels #
# Revision History  :                                                                    #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                     #
# 20180618     Anjaiah Y   Chris                                                          #
#                                                                                        #
##########################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from flows.utils.S3DataLoader import *
from flows.jobs.con_resbaseln_cancellation_dm import *
from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
from flows.utils.DataFrameUtil import *
from pyspark.sql.types import *
import os, sys


def count_check(dataframe, name):
    print(" Debug start ************************************************************************ %s %s" % (
        name, datetime.now()))
    cnt = dataframe.count()
    # dataframe.show()
    try:
        dataframe.show()
    except:
        print(" exception")
    print(" Debug counts ************************************************************************ %s " % cnt)
    print(" Debug end ************************************************************************ %s %s" % (
        name, datetime.now()))


def run_data_loader_voyage(start_dt, sql_context, s3_bucket, debug):
    """
    Driver program to run cancellation_dm
    Attributes
    start_dt    : the time slice that is being executed
    sql_context : the spark sql context
    s3_bucket   : the s3 bucket that identifies the data source
    debug       :  debug flag
    """

    ##################################################################
    # Driver program to run run_data_loader dm  process method #
    # Attributes                                                     #
    # start_dt    : the time slice that is being executed            #
    # sql_context : the spark sql context                            #
    # s3_bucket   : the s3 bucket that identifies the data source    #
    # debug       :  debugging the counts                            #
    ##################################################################

    data_loader = S3DataLoader(sql_context, s3_bucket)
    converter = DataFrameUtil(sql_context)

    ###########################################################################
    # STEP 2:   Loading data from S3 and create corresponding dataframes      #
    ###########################################################################

    #########################################################
    #                         VOYAGE                        #
    #########################################################

    ## Get all voyages and meta information  - TBD needs to go in a common class ##
    vyge_filter_clause = "UPPER(instnc_st_nm)='STANDARD' and ship_cd <> 'XP' and ship_cd is not null and vyge_dprt_seapt_cd is not null"


    ## Applying filter clause while loading data from s3 and populating selected columns ##
    vyge_df = data_loader.read_data("dm", "VYGE") \
        .filter(vyge_filter_clause)
    ## All voyages meta informationa collected in voyage_df ##
    vyge_df.createOrReplaceTempView(" vyge ")
    vyge_df.cache();
    if debug == 1:
        count_check(vyge_df, "vyge")

    #########################################################
    #                   VOYAGE_ATTR                         #
    #########################################################

    ## Get all voyages and meta information  - TBD needs to go in a common class ##
    # vyge_attr_filter_clause = "invld_vyge_in=0 and vyge_init_bkng_dt < = current_date() and  VYGE_DRTN_NGHT_CN is not null and VYGE_ITNRY_NM is not nul
    # l and VYGE_OPN_DT is not null and " \
    # #                           "vyge_dprt_dt is not null and ORIG_VYGE_ITNRY_NM is not null and " \
    # #                           " UPPER(instnc_st_nm)='STANDARD' AND " \
    # #                           "date(vrsn_end_dts) > vyge_arvl_dt and  datediff(vyge_dprt_dt,date('%s'))<3650" % (start_dt)

    vyge_attr_filter_clause = """ invld_vyge_in=0 and LEAST(vyge_init_bkng_dt,VYGE_OPN_DT)  <= current_date() and  VYGE_DRTN_NGHT_CN is not null and VYGE_ITNRY_NM is not null 
    and (vyge_init_bkng_dt is not null or   VYGE_OPN_DT is not null) and  vyge_dprt_dt is not null and ORIG_VYGE_ITNRY_NM is not null and  UPPER(instnc_st_nm)='STANDARD'
    AND date(vrsn_end_dts) > vyge_arvl_dt """

    vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR") \
        .filter(vyge_attr_filter_clause)
    vyge_attr_df.createOrReplaceTempView(" vyge_attr ")
    vyge_attr_df.cache();
    if debug == 1:
        count_check(vyge_attr_df, "vyge_attr")

    #########################################################
    #                   SHIP_STRM_STRM_TYP                  #
    #########################################################

    ## Get all ship category type code and ship code details from SHIP_STRM_STRM_TYP ##
    ship_strm_strm_typ_filter_clause = " UPPER(strm_typ_cd) NOT IN('IRG','XAM') \
                    and UPPER(instnc_st_nm)='STANDARD' "


    ship_strm_strm_typ_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
        .filter(ship_strm_strm_typ_filter_clause)
    ship_strm_strm_typ_df.createOrReplaceTempView(" ship_strm_strm_typ")
    ship_strm_strm_typ_df.cache()
    if debug == 1:
        count_check(ship_strm_strm_typ_df, "ship_strm_strm_typ")

    #########################################################
    #                   SHIP_STRM_TYP_EXT                   #
    #########################################################



    ship_strm_typ_ext_filter_clause = " ship_ctgy_nm is not null and UPPER(ship_strm_typ_cd) NOT IN('IRG','XAM')  \
                    and UPPER(instnc_st_nm)='STANDARD' "


    ship_strm_typ_ext_df = data_loader.read_data("dm", "SHIP_STRM_TYP_EXT") \
        .filter(ship_strm_typ_ext_filter_clause)
    ship_strm_typ_ext_df.createOrReplaceTempView(" ship_strm_typ_ext ")
    ship_strm_typ_ext_df.cache()
    if debug == 1:
        count_check(ship_strm_typ_ext_df, "ship_strm_typ_ext")




    ##################################################################################################################
    ################### SL_LIM_CONFIG Dataloading start here########
    ######################################################################################################################
    sl_lim_config_attr = "UPPER(lgcl_del_in) = 'N'   AND UPPER(btch_sts_nm) = 'SUCCESSFUL'"
    sl_lim_config_df = data_loader.read_data("sha", "SL_LIM_CONFIG").filter(sl_lim_config_attr).dropDuplicates()
    sl_lim_config_df.createOrReplaceTempView("sl_lim_config");
    sl_lim_config_df.cache()
    if debug == 1:
        count_check(sl_lim_config_df, "sl_lim_confg_max_df count info")

    ##################################################################################################################
    ################### SL_LIM_CONFIG Dataloading end here########
    ######################################################################################################################




    ##################################################################################################################
    ################### price_rcmd_dtl Dataloading start here########
    ######################################################################################################################

    price_rcmd_dtl_attr = "upper(lgcl_del_in)= 'N'"
    price_rcmd_dtl_df = data_loader.read_data("sha", "PRICE_RCMD_DTL").filter(price_rcmd_dtl_attr).dropDuplicates()
    price_rcmd_dtl_df.createOrReplaceTempView("price_rcmd_dtl")
    ##################################################################################################################
    ################### STRM_TYP_NEST_CONFIG Dataloading start here########
    ######################################################################################################################
    strm_typ_nest_config_attr = "upper(lgcl_del_in) = 'N'\
                                     and upper(sci_rcmd_excl_in) = 'N'"
    strm_typ_nest_config_df = data_loader.read_data("app", "STRM_TYP_NEST_CONFIG").filter(
        strm_typ_nest_config_attr).dropDuplicates()
    strm_typ_nest_config_df.createOrReplaceTempView("strm_typ_nest_config")

    strm_typ_nest_config = sql_context.sql(
         """    SELECT     ship_cd,
                            src_sys_strm_typ_nm,
                            max(strm_typ_nest_config_strt_dts) AS   strm_typ_nest_config_strt_dts_max
                     FROM   strm_typ_nest_config
             GROUP BY       ship_cd,
                            src_sys_strm_typ_nm
                  """ ).dropDuplicates();
    strm_typ_nest_config.createOrReplaceTempView("strm_typ_nest_config");
    if debug == 1:
         count_check(strm_typ_nest_config, "strm_typ_nest_config count info")


    ##################################################################################################################
    ################### PRICE_CONFIG Dataloading start here########
    ######################################################################################################################
    price_config_df = data_loader.read_data("sha", "PRICE_CONFIG").dropDuplicates()
    price_config_df.createOrReplaceTempView("price_config")


    ##################################################################################################################
    ################### GAWF_VAR Dataloading start here########
    ######################################################################################################################

    gawf_var_df = data_loader.read_data("app", "GAWF_VAR").dropDuplicates()
    gawf_var_df.createOrReplaceTempView("gawf_var");
    if debug == 1:
        count_check(gawf_var_df, "gawf_var_df execution start here ")

    ##################################################################################################################
    ################### GAWF_VAR Dataloading end here########
    ######################################################################################################################

    ##################################################################################################################
    ################### DFLT_GAWF_VAR Dataloading start here########
    ######################################################################################################################

    dflt_gawf_var_df = data_loader.read_data("app", "DFLT_GAWF_VAR").dropDuplicates()

    dflt_gawf_var_df.createOrReplaceTempView("dflt_gawf_var");



    if debug == 1:
        count_check(dflt_gawf_var_df, "dflt_gawf_var_df execution start here ")

    ##################################################################################################################
    ################### DFLT_GAWF_VAR Dataloading end here########
    ######################################################################################################################

    ##################################################################################################################
    ################### MASTER_SAILING_SCIENCE Dataloading start here########
    ######################################################################################################################
    master_sailing_science_df = data_loader.read_data("arch", "MASTER_SAILING_SCIENCE").dropDuplicates()
    master_sailing_science_df.createOrReplaceTempView("master_sailing_science");
    if debug == 1:
        count_check(master_sailing_science_df, "master_sailing_science_df execution start here ")

    ##################################################################################################################
    ################### MASTER_SAILING_SCIENCE Dataloading start here########
    ######################################################################################################################

    #####################################################################
    #                           DT                                      #
    #####################################################################
    dt_df = data_loader.read_data("dt", "DT")
    dt_df.createOrReplaceTempView("dt")
    dt_df.persist()
    if debug == 1:
        count_check(dt_df, "dt")

    ######################################################################
    #                         RESERVATION                                #
    ######################################################################
    #reservation_df = data_loader.read_data("sha", "RESERVATION")
    #reservation_df.createOrReplaceTempView("reservation")
    #if debug == 1:
    #    count_check(reservation_df, "reservation")

        ##################################################################################################################
        ################### EXPECT_OH_BKNG Dataloading start here########
        ######################################################################################################################

    expect_oh_fliter=" UPPER(instnc_st_nm) = 'STANDARD' AND UPPER(lgcl_del_in) = 'N'";
    expect_oh_max_batch_df = data_loader.read_data("sha", "EXPECT_OH_BKNG").filter(expect_oh_fliter).dropDuplicates()
    expect_oh_max_batch_df.createOrReplaceTempView("expect_oh_bkng");

    if debug == 1:
        count_check(expect_oh_max_batch_df, "expect_oh_max_batch_df execution start here ")

    #########################################################
    #                    PROC_PRICE_PT                      #
    #########################################################

    proc_price_pt_filter_clause = " upper(instnc_st_nm) = 'STANDARD' AND upper(sfb_nm) <> 'OFFICER'"
    proc_price_pt_df = data_loader.read_data("dm", "PROC_PRICE_PT").filter(proc_price_pt_filter_clause);

    proc_price_pt_df.createOrReplaceTempView("proc_price_pt")
    proc_price_pt_df.cache()

    if debug == 1:
        count_check(proc_price_pt_df, "proc_price_pt")


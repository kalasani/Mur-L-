##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : run_data_loader BOH -DataLoading & Driver Prepration               #
# Author            : Anjaiah M                                                        #
# Date created      : 20180619                                                           #
# Purpose           : To fetch gross per dimension metrices for all VF* inventory levels #
# Revision History  :                                                                    #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                     #
# 20180618     Anjaiah Y  Navin Chris                                                    #
#                                                                                        #
##########################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
# from flows.jobs.con_resbaseln_cancellation_dm import *
# from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from pyspark.sql.types import *
from framework.utils.DebugCount import *;
from time import time
import os, sys


class VygeStateRoomDriver(object):
    @staticmethod
    def expand_keys(row):
        """
           Flat map function which takes a row containing voyage id , voyage init booking date and voyage arrival date
           and returns  a rdd containing vyge_id and txn_dt
        """
        # print("expand_keys:::max_data_load_dt  ===>",max_data_load_dt)
        start_dt = row.vyge_init_bkng_dt
        if start_dt > row.vyge_opn_dt:
            start_dt = row.vyge_opn_dt

        end_dt = row.vyge_arvl_dt + timedelta(days=10)

        input_start_dt = "2016-01-11"

        txn_bgn_dt = datetime.strptime(input_start_dt, "%Y-%m-%d").date()
        if (start_dt <= txn_bgn_dt):
            start_dt = txn_bgn_dt

        if (end_dt <= txn_bgn_dt):
            end_dt = txn_bgn_dt
        # if(max_data_load_dt!=None):
        #     if(end_dt > max_data_load_dt):
        #         end_dt=max_data_load_dt

        dt = start_dt

        list_obj = []

        while (dt <= end_dt):
            t = (row.vyge_id, dt, row.app_vyge_id, row.ship_cd)
            list_obj.append(t)
            dt = dt + timedelta(days=1)

        return list_obj

    @staticmethod
    def loadRunDtsIncrementProcess(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug):
        data_loader = S3DataLoader(spark, s3_bucket)
        # start_dt_process_date = datetime.strptime(start_dt, '%Y-%m-%d')

        inc_expect_batch_df = spark.sql(
            "select * from expect_oh_bkng where date(expect_oh_bkng_run_dts) <= date_sub(date('%s'), 1) and date(expect_oh_bkng_run_dts) <= date('%s')" % (
                start_dt, max_data_load_dt)).dropDuplicates()
        inc_price_rcmd_df = spark.sql(
            "select * from price_rcmd_dtl where date(price_rcmd_run_dts) <= date_sub(date('%s'), 1) and date(price_rcmd_run_dts)<=date('%s')" % (
                start_dt, max_data_load_dt)).dropDuplicates()

        inc_uncnstrn_dmnd_fcst_df = data_loader.read_data("sha", "UNCNSTRN_DMND_FCST").select("app_vyge_id",
                                                                                              "uncnstrn_dmnd_fcst_run_dts").filter(
            "date(uncnstrn_dmnd_fcst_run_dts) <= date_sub(date('%s'), 1) and date(uncnstrn_dmnd_fcst_run_dts)<=date('%s')" % (
                start_dt, max_data_load_dt)).dropDuplicates()

        expect_oh_batch_run_dts_df = inc_expect_batch_df.select("app_vyge_id", "expect_oh_bkng_run_dts").distinct()
        expect_oh_max_batch_max_run_dts_df = expect_oh_batch_run_dts_df.select("app_vyge_id",
                                                                               "expect_oh_bkng_run_dts").groupBy(
            "app_vyge_id").agg(max("expect_oh_bkng_run_dts").alias("expect_oh_bkng_run_dts"))

        in_price_df = inc_price_rcmd_df.select("app_vyge_id", "price_rcmd_run_dts").distinct()
        price_max_df = in_price_df.select("app_vyge_id", "price_rcmd_run_dts").groupBy("app_vyge_id").agg(
            max("price_rcmd_run_dts").alias("price_rcmd_run_dts"))

        in_uncnstrn_dmnd_fcst_run_dts_df = inc_uncnstrn_dmnd_fcst_df.select("app_vyge_id",
                                                                            "uncnstrn_dmnd_fcst_run_dts").distinct()
        in_uncnstrn_dmnd_fcst_run_dts_df.printSchema()

        uncnstrn_dmnd_fcst_maxrun_df = in_uncnstrn_dmnd_fcst_run_dts_df.select("app_vyge_id",
                                                                               "uncnstrn_dmnd_fcst_run_dts").groupBy(
            "app_vyge_id").agg(max("uncnstrn_dmnd_fcst_run_dts").alias("uncnstrn_dmnd_fcst_run_dts"))

        join_cond_df = expect_oh_max_batch_max_run_dts_df.join(price_max_df, ["app_vyge_id"], "full_outer").join(
            uncnstrn_dmnd_fcst_maxrun_df, ["app_vyge_id"], "full_outer").select("app_vyge_id",
                                                                                "expect_oh_bkng_run_dts",
                                                                                "price_rcmd_run_dts",
                                                                                "uncnstrn_dmnd_fcst_run_dts")

        maxValue = udf(lambda row: VygeStateRoomDriver.max_values(row))

        join_cond_df_df = join_cond_df.withColumn("batch_run_dts",
                                                  maxValue(struct(
                                                      [join_cond_df[x] for x in
                                                       join_cond_df.columns])).cast(
                                                      "timestamp"))
        join_cond_df_df.printSchema();

        join_cond_df_df.createOrReplaceTempView("inc_prev_start_run_dts_df")
        # folder_name = "%s%s" % ("VYGE_JOIN_Batch_NEW/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, join_cond_df_df)

    @staticmethod
    def buildMinMaxDtsForInc(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug):
        VygeStateRoomDriver.loadRunDtsIncrementProcess(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug)
        inc_prev_start_run_dts_df = spark.sql("select * from inc_prev_start_run_dts_df");

        df_inc_rundts_comp_max = spark.sql(
            """ select
                 vyge_id
                , inc_prev_start_run_dts_df.batch_run_dts as prev_batch_run_dts
                , run_dts_df.max_btch_run_dts as batch_run_dts
                 , CASE WHEN inc_prev_start_run_dts_df.batch_run_dts IS NULL AND inc_prev_start_run_dts_df.app_vyge_id IS NOT NULL THEN NULL
    			        WHEN inc_prev_start_run_dts_df.batch_run_dts IS NULL AND inc_prev_start_run_dts_df.app_vyge_id IS NULL THEN date('%s')						
                        WHEN run_dts_df.max_btch_run_dts ==  inc_prev_start_run_dts_df.batch_run_dts then date('%s')
                        ELSE date(inc_prev_start_run_dts_df.batch_run_dts)
                 END AS start_txn_dt
                 FROM
                    run_dts_df run_dts_df LEFT OUTER JOIN inc_prev_start_run_dts_df as inc_prev_start_run_dts_df
                    on run_dts_df.app_vyge_id= inc_prev_start_run_dts_df.app_vyge_id
                 WHERE
                      run_dts_df.txn_dt = date('%s')
           """ % (start_dt, start_dt, start_dt))

        df_inc_rundts_comp_max.printSchema()
        data_loader = S3DataLoader(spark, s3_bucket)

        # folder_name = "%s%s" % ("VYGE_TXN_RUN_DTS_NEW/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, df_inc_rundts_comp_max)
        vyge_attr_txn_dt_df = spark.sql("select * from vyge_attr_txn_dt_df");
        vyge_attr_txn_dt_df = vyge_attr_txn_dt_df.join(df_inc_rundts_comp_max, ["vyge_id"]).filter(
            "txn_dt >= start_txn_dt ").select("vyge_id", "txn_dt", "app_vyge_id", "ship_cd")
        vyge_attr_txn_dt_df.createOrReplaceTempView("vyge_attr_txn_dt_df")
        vyge_attr_txn_dt_df.printSchema()
        # folder_name = "%s%s" % ("VYGE_TXN_DT_INCREMNT/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, vyge_attr_txn_dt_df)

    @staticmethod
    def max_values(row):
        max_value = None

        if row.expect_oh_bkng_run_dts != None:
            max_value = row.expect_oh_bkng_run_dts

        if row.price_rcmd_run_dts != None:

            if (max_value == None or (max_value != None and row.price_rcmd_run_dts > max_value)):
                max_value = row.price_rcmd_run_dts

        if row.uncnstrn_dmnd_fcst_run_dts != None:

            if (max_value == None or (max_value != None and row.uncnstrn_dmnd_fcst_run_dts > max_value)):
                max_value = row.uncnstrn_dmnd_fcst_run_dts

        return str(max_value)

    @staticmethod
    def maxValueAsOfDt(row):
        as_of_dt = None
        if row.expect_oh_bkng_run_dts != None:
            if row.expect_oh_bkng_run_dts == row.batch_run_dts:
                as_of_dt = row.expect_df_rundts_asofdate

        if row.price_rcmd_run_dts != None:
            if (row.price_rcmd_run_dts == row.batch_run_dts):
                as_of_dt = row.price_rundts_asofdate

        if row.uncnstrn_dmnd_fcst_run_dts != None:
            if row.uncnstrn_dmnd_fcst_run_dts == row.batch_run_dts:
                as_of_dt = row.uncnstrn_dmnd_rundts_asofdate

        return str(as_of_dt)

    @staticmethod
    def loadRunDts(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug):
        expect_batch_df = spark.sql("select * from expect_oh_bkng")
        price_rcmd_df = spark.sql("select * from price_rcmd_dtl");
        price_config_attr_df = spark.sql("SELECT * FROM price_config");
        sl_lim_config_df = spark.sql("select * from sl_lim_config");
        vyge_txn_dt_df = spark.sql("select * from vyge_attr_txn_dt_df")

        min_data_date = spark.sql("SELECT   MIN(txn_dt) AS min_vyge_opn_dt FROM  vyge_attr_txn_dt_df").head()[0]
        max_data_date = spark.sql("SELECT   max(txn_dt) AS min_vyge_opn_dt FROM  vyge_attr_txn_dt_df").head()[0]

        data_loader = S3DataLoader(spark, s3_bucket)
        converter = DataFrameUtil(spark)
        sl_lim_rcmd_attr = "(upper(lgcl_del_in) ='N' or lgcl_del_in is null)   and upper(instnc_st_nm) = 'STANDARD' and  strm_ocpncy_cn is null and date(sl_lim_rcmd_run_dts) <= date('%s') " % (
            max_data_load_dt)
        sl_lim_rcmd_df = data_loader.read_data("sha", "SL_LIM_RCMD").filter(sl_lim_rcmd_attr)

        sl_lim_rcmd_df.createOrReplaceTempView("sl_lim_rcmd")

        sl_lim_rcmd_df.printSchema()
        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_df, "sl_lim_rcmd_df execution start here ")

        sl_lim_config_distinct_df = sl_lim_config_df.select("app_vyge_id", "sl_lim_config_strt_dts").distinct()
        sl_lim_config_start_dts_df = vyge_txn_dt_df.join(sl_lim_config_distinct_df, ["app_vyge_id"]).filter(
            "date(sl_lim_config_strt_dts)<=txn_dt").select("vyge_id", "txn_dt", "sl_lim_config_strt_dts").groupBy(
            "vyge_id", "txn_dt").agg(max("sl_lim_config_strt_dts").alias("sl_lim_config_strt_dts_max"))
        sl_lim_config_start_dts_df.createOrReplaceTempView("sl_lim_config_start_dts_df")

        if debug == 1:
            DebugCount.debug_counts(sl_lim_config_start_dts_df, "sl_lim_config_start_dts_df count info")

        sl_lim_rcmd_df_distinct_df = sl_lim_rcmd_df.select("app_vyge_id", "sl_lim_rcmd_run_dts").distinct()

        sl_lim_rcmd_max_df = sl_lim_rcmd_df_distinct_df.select("app_vyge_id", "sl_lim_rcmd_run_dts").groupBy(
            "app_vyge_id").agg(max("sl_lim_rcmd_run_dts").alias("sl_lim_rcmd_run_dts"))

        sl_lim_rcmd_rcmd_run_dts_df = vyge_txn_dt_df.join(sl_lim_rcmd_max_df, ["app_vyge_id"]).select("app_vyge_id",
                                                                                                      "txn_dt",
                                                                                                      "vyge_id",
                                                                                                      "sl_lim_rcmd_run_dts")
        sl_lim_rcmd_rcmd_run_dts_df.createOrReplaceTempView("sl_lim_rcmd_rcmd_run_dts_df")
        sl_lim_rcmd_rcmd_run_dts_df.printSchema()

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_rcmd_run_dts_df, "sl_lim_rcmd_rcmd_run_dts_df count info")

        # ---------
        uncnstrn_bkng_rcmd_df = data_loader.read_data("sha", "UNCNSTRN_BKNG").filter(
            "date(uncnstrn_bkng_run_dts) <= date('%s')" % (max_data_load_dt))
        # uncnstrn_bkng_rcmd_df1 =data_loader.read_data_from_path("con/uncnstrn_bkng_rcmd").filter("date(uncnstrn_bkng_run_dts) <= date('%s')"% (max_data_load_dt)).dropDuplicates()

        uncnstrn_bkng_rcmd_df.printSchema()
        uncnstrn_bkng_rcmd_max_df = uncnstrn_bkng_rcmd_df.select("app_vyge_id", "uncnstrn_bkng_run_dts").distinct()
        uncnstrn_bkng_rcmd_max_df = uncnstrn_bkng_rcmd_max_df.groupBy(
            "app_vyge_id").agg(max("uncnstrn_bkng_run_dts")
                               .alias("uncnstrn_bkng_run_dts"))

        uncnstrn_bkng_rcmd_max_df.printSchema()
        uncnstrn_bkng_run_dts_df = vyge_txn_dt_df.join(uncnstrn_bkng_rcmd_max_df, ["app_vyge_id"]).select("app_vyge_id",
                                                                                                          "vyge_id",
                                                                                                          "txn_dt",
                                                                                                          "uncnstrn_bkng_run_dts")
        uncnstrn_bkng_run_dts_df.createOrReplaceTempView("uncnstrn_bkng_run_dts_df")

        if debug == 1:
            DebugCount.debug_counts(uncnstrn_bkng_run_dts_df, "uncnstrn_bkng_run_dts_df count info")

        uncnstrn_bkng_rcmd_df.createOrReplaceTempView("uncnstrn_bkng")

        # -----------------

        expect_oh_batch_run_dts_df = expect_batch_df.select("app_vyge_id", "expect_oh_bkng_run_dts", "asofdate").filter(
            "date(expect_oh_bkng_run_dts) <= date('%s')" % (max_data_load_dt)).distinct()
        expect_oh_max_batch_max_run_dts_df = expect_oh_batch_run_dts_df.select("app_vyge_id",
                                                                               "expect_oh_bkng_run_dts").groupBy(
            "app_vyge_id").agg(max("expect_oh_bkng_run_dts").alias("expect_oh_bkng_run_dts"))

        expect_run_dts_df_w_aod = expect_oh_max_batch_max_run_dts_df.join(expect_oh_batch_run_dts_df,
                                                                          ["app_vyge_id",
                                                                           "expect_oh_bkng_run_dts"]).select(
            "app_vyge_id",
            "expect_oh_bkng_run_dts",
            "asofdate").distinct()

        expect_run_dts_df = vyge_txn_dt_df.join(expect_run_dts_df_w_aod, ["app_vyge_id"]).select("app_vyge_id",
                                                                                                 "vyge_id",
                                                                                                 "txn_dt",
                                                                                                 "expect_oh_bkng_run_dts",
                                                                                                 "asofdate")

        # expect_run_dts_df = expect_run_dts_df.join(expect_oh_batch_run_dts_df,
        #                                          ["app_vyge_id", "expect_oh_bkng_run_dts"]).select("app_vyge_id",
        #                                                                                            "txn_dt",
        #                                                                                            "vyge_id",
        #                                                                                            "expect_oh_bkng_run_dts",
        #                                                                                            "asofdate").distinct()
        expect_run_dts_df.createOrReplaceTempView("expect_run_dts_df")

        if debug == 1:
            DebugCount.debug_counts(expect_run_dts_df, "expect_run_dts_df count info")

        # -------------------------------------------------------------------------------------------------------

        price_df = price_rcmd_df.select("app_vyge_id", "price_rcmd_run_dts", "asofdate").filter(
            "date(price_rcmd_run_dts) <= date('%s')" % (max_data_load_dt)).distinct()
        price_df.createOrReplaceTempView("price_df_run_dts_df")

        price_max_df = price_df.select("app_vyge_id", "price_rcmd_run_dts").groupBy("app_vyge_id").agg(
            max("price_rcmd_run_dts").alias("price_rcmd_run_dts"))

        price_rcmd_run_w_aod = price_df.join(price_max_df, ["app_vyge_id", "price_rcmd_run_dts"]).select("app_vyge_id",
                                                                                                         "asofdate",
                                                                                                         "price_rcmd_run_dts")

        price_rcmd_run_dts_df = vyge_txn_dt_df.join(price_rcmd_run_w_aod, ["app_vyge_id"]).select("app_vyge_id",
                                                                                                  "txn_dt",
                                                                                                  "vyge_id",
                                                                                                  "price_rcmd_run_dts",
                                                                                                  "asofdate")

        # price_rcmd_run_dts_df = price_rcmd_run_dts_df.join(price_df,
        #                                                   ["app_vyge_id", "price_rcmd_run_dts"]).select("app_vyge_id",
        #                                                                                                 "vyge_id",
        #                                                                                                 "txn_dt",
        #                                                                                                 "price_rcmd_run_dts",
        #                                                                                                 "asofdate").distinct()

        price_rcmd_run_dts_df.createOrReplaceTempView("price_rcmd_run_dts_df")

        if debug == 1:
            DebugCount.debug_counts(price_rcmd_run_dts_df, "price_rcmd_run_dts_df count info")

        # -------------------------------------------------------------------------------------------------------
        # uncnstrn_dmnd_fcst_df = data_loader.read_data_with_filter("app", "UNCNSTRN_DMND_FCST_NEW", "partition_dt",
        #                                                           str(min_data_date), str(max_data_date),
        #                                                           None).dropDuplicates()

        uncnstrn_dmnd_fcst_df = data_loader.read_data("sha", "UNCNSTRN_DMND_FCST").filter(
            "date(uncnstrn_dmnd_fcst_run_dts) <= date('%s')" % (max_data_load_dt))

        # uncnstrn_dmnd_fcst_df1 = data_loader.read_data_from_path("con/uncnstrn_dmnd_fcst").filter("date(uncnstrn_dmnd_fcst_run_dts) <= date('%s')"% (max_data_load_dt)).distinct()

        # uncnstrn_dmnd_fcst_run_dts_df = uncnstrn_dmnd_fcst_df.select("app_vyge_id", "uncnstrn_dmnd_fcst_run_dts").distinct()
        uncnstrn_dmnd_fcst_run_dts_df = uncnstrn_dmnd_fcst_df.select("app_vyge_id", "uncnstrn_dmnd_fcst_run_dts",
                                                                     "asofdate").distinct()
        uncnstrn_dmnd_fcst_run_dts_df.printSchema()

        uncnstrn_dmnd_fcst_maxrun_df = uncnstrn_dmnd_fcst_run_dts_df.select("app_vyge_id",
                                                                            "uncnstrn_dmnd_fcst_run_dts").groupBy(
            "app_vyge_id").agg(max("uncnstrn_dmnd_fcst_run_dts").alias("uncnstrn_dmnd_fcst_run_dts"))

        uncnstrn_dmnd_fcst_maxrun_w_aod_df = uncnstrn_dmnd_fcst_maxrun_df.join(uncnstrn_dmnd_fcst_run_dts_df,
                                                                               ["app_vyge_id",
                                                                                "uncnstrn_dmnd_fcst_run_dts"]).select(
            "app_vyge_id", "uncnstrn_dmnd_fcst_run_dts", "asofdate").distinct()

        uncnstrn_dmnd_fcst_run_dts_df = vyge_txn_dt_df.join(uncnstrn_dmnd_fcst_maxrun_w_aod_df, ["app_vyge_id"]).select(
            "app_vyge_id", "vyge_id", "txn_dt",
            "asofdate", "uncnstrn_dmnd_fcst_run_dts")

        # uncnstrn_dmnd_fcst_run_dts_df = uncnstrn_dmnd_fcst_maxrun_dts_df.join(uncnstrn_dmnd_fcst_run_dts_df, ["app_vyge_id",
        #                                                                                                      "uncnstrn_dmnd_fcst_run_dts"]).select(
        #    "app_vyge_id", "vyge_id", "txn_dt", "uncnstrn_dmnd_fcst_run_dts", "asofdate").distinct()

        uncnstrn_dmnd_fcst_run_dts_df.createOrReplaceTempView("uncnstrn_dmnd_fcst_run_dts_df")
        if debug == 1:
            DebugCount.debug_counts(uncnstrn_dmnd_fcst_run_dts_df, "uncnstrn_dmnd_fcst_run_dts_df count info")

        # -------------------------------------------------------------------------------------------------------
        price_config_df = price_config_attr_df.select("app_vyge_id", "price_rcmd_txn_dts").distinct()

        # price_config_run_dts_df = vyge_txn_dt_df.join(price_config_df, ["app_vyge_id"]).filter(
        #     "date(price_rcmd_txn_dts)<=txn_dt").select("vyge_id", "txn_dt", "price_rcmd_txn_dts").groupBy("vyge_id",
        #                                                                                                   "txn_dt").agg(
        #     max("price_rcmd_txn_dts").alias("max_price_config_txn_dts"))
        #

        price_config_df = price_config_attr_df.select("app_vyge_id", "price_rcmd_txn_dts").distinct()

        price_config_run_dts_df = vyge_txn_dt_df.join(price_config_df, ["app_vyge_id"]).select("vyge_id",
                                                                                               "price_rcmd_txn_dts") \
            .groupBy("vyge_id").agg(max("price_rcmd_txn_dts").alias("max_price_config_txn_dts"))

        price_config_run_dts_df.createOrReplaceTempView("price_config_txn_dts_df")
        if debug == 1:
            DebugCount.debug_counts(price_config_run_dts_df, "price_config_run_dts_df count info")

        price_dy_bef_vyge_rnge_max_attr_df = spark.sql("""
                                        SELECT
                                            app_vyge_id
                                            ,price_rcmd_run_dts
                                            ,strm_typ_cd
                                            ,max(dy_bef_vyge_rnge_strt_cn) as dy_bef_vyge_rnge_strt_cn_max
                                        FROM
                                        price_rcmd_dtl
                                        group by
                                        app_vyge_id
                                        ,strm_typ_cd
                                        ,price_rcmd_run_dts

            """).dropDuplicates()

        price_dy_bef_vyge_rnge_max_attr_df = price_rcmd_run_dts_df.join(price_dy_bef_vyge_rnge_max_attr_df,
                                                                        ['app_vyge_id', 'price_rcmd_run_dts']) \
            .select("app_vyge_id", "price_rcmd_run_dts", "strm_typ_cd", "txn_dt", "dy_bef_vyge_rnge_strt_cn_max",
                    "vyge_id",
                    "asofdate")
        price_dy_bef_vyge_rnge_max_attr_df.createOrReplaceTempView("price_dy_bef_vyge_rnge_max_attr_df")
        # -------------------------------------------------------------------------------------------------------
        sl_rcmd_dy_bef_vyge_rng_max_df = spark.sql("""
                                            SELECT
                                                app_vyge_id
                                                ,sl_lim_rcmd_run_dts
                                                ,src_sys_strm_typ_nm as strm_typ_cd
                                                ,max(dy_bef_vyge_rnge_strt_cn) as dy_bef_vyge_rnge_strt_cn_max
                                            FROM   sl_lim_rcmd
                                            GROUP BY
                                                    app_vyge_id
                                                    ,src_sys_strm_typ_nm
                                                    ,sl_lim_rcmd_run_dts
            """).dropDuplicates()

        sl_rcmd_dy_bef_vyge_rng_max_df = sl_lim_rcmd_rcmd_run_dts_df.join(sl_rcmd_dy_bef_vyge_rng_max_df,
                                                                          ['app_vyge_id', 'sl_lim_rcmd_run_dts']) \
            .select("app_vyge_id", "sl_lim_rcmd_run_dts", "strm_typ_cd", "txn_dt", "dy_bef_vyge_rnge_strt_cn_max",
                    "vyge_id")
        sl_rcmd_dy_bef_vyge_rng_max_df.createOrReplaceTempView("sl_rcmd_ref")
        sl_rcmd_dy_bef_vyge_rng_max_df.printSchema()

        df_inc_rundts_df = spark.sql(
            """
            select
            vyg_attr.vyge_id
            ,vyg_attr.txn_dt
            ,vyg_attr.app_vyge_id
            ,expect_df.expect_oh_bkng_run_dts as expect_oh_bkng_run_dts
            ,expect_df.asofdate as expect_df_rundts_asofdate
            ,price_df.price_rcmd_run_dts as price_rcmd_run_dts
            ,price_df.asofdate as price_rundts_asofdate
            ,uncnstrn_dmnd_df.uncnstrn_dmnd_fcst_run_dts as uncnstrn_dmnd_fcst_run_dts
            ,uncnstrn_dmnd_df.asofdate as uncnstrn_dmnd_rundts_asofdate

            FROM vyge_attr_txn_dt_df vyg_attr


            LEFT OUTER JOIN  expect_run_dts_df as expect_df
            ON vyg_attr.vyge_id=expect_df.vyge_id
            AND vyg_attr.txn_dt=expect_df.txn_dt

            LEFT OUTER JOIN  uncnstrn_dmnd_fcst_run_dts_df as uncnstrn_dmnd_df
            ON vyg_attr.vyge_id=uncnstrn_dmnd_df.vyge_id
            AND vyg_attr.txn_dt=uncnstrn_dmnd_df.txn_dt


            LEFT OUTER JOIN   price_rcmd_run_dts_df as price_df
            ON  vyg_attr.vyge_id=price_df.vyge_id
            AND vyg_attr.txn_dt=price_df.txn_dt


        """)

        maxValue = udf(lambda row: VygeStateRoomDriver.max_values(row))
        maxValueUDF = udf(lambda row: VygeStateRoomDriver.maxValueAsOfDt(row))

        df_inc_btch_run_dts_df = df_inc_rundts_df.withColumn("batch_run_dts",
                                                             maxValue(struct(
                                                                 [df_inc_rundts_df[x] for x in
                                                                  df_inc_rundts_df.columns])).cast(
                                                                 "timestamp"))
        df_inc_btch_run_dts_df.printSchema();

        df_vyge_max_btch_run_dts = df_inc_btch_run_dts_df.groupBy("vyge_id").agg(
            max("batch_run_dts").alias("max_btch_run_dts"))
        df_vyge_max_btch_run_dts.printSchema();

        df_vyge_run_dts_final_df = df_inc_btch_run_dts_df.join(df_vyge_max_btch_run_dts, "vyge_id");
        df_vyge_run_dts_final_df.createOrReplaceTempView("run_dts_df")
        print("Before dataascience rundts load ===", datetime.now())
        # folder_name = "%s%s" % ("VYGE_STRM_TYP_SFB_BASELN_RUN_DTS_DF/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, df_vyge_run_dts_final_df)
        print("After datasscience rundts load ==>", datetime.now())
        # sys.exit()

    #######################################################################################
    # This function needs to determine all the app_vyge_ids changed from a certain date which is input
    # the input last_fetch_dt will be passed as the start date
    #
    #######################################################################################
    @staticmethod
    def run_app_vyge_max_vrsn(last_fetch_dts, sql_context, s3_bucket, max_data_loaded_dt, debug):
        data_loader = S3DataLoader(sql_context, s3_bucket)
        converter = DataFrameUtil(sql_context)
        # last_fetch_dt = '2018-06-26 21:31:15.88'

        last_fetch_dt = last_fetch_dts

        df_price_rcmd_config = data_loader.read_data("sha", "PRICE_CONFIG")
        df_price_rcmd_config_max = df_price_rcmd_config.select("app_vyge_id", "vrsn_strt_dts") \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s'" % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_sl_lim_rcmd_config = data_loader.read_data("sha", "SL_LIM_CONFIG")
        df_sl_lim_rcmd_config_max = df_sl_lim_rcmd_config.select("app_vyge_id", "vrsn_strt_dts") \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_price_rcmd_dtl = data_loader.read_data("sha", "PRICE_RCMD_DTL")
        df_price_rcmd_dtl_max = df_price_rcmd_dtl.select("app_vyge_id",
                                                         col("price_rcmd_run_dts").alias("vrsn_strt_dts")) \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_sl_lim_rcmd = data_loader.read_data("sha", "SL_LIM_RCMD")
        df_sl_lim_rcmd_max = df_sl_lim_rcmd.select("app_vyge_id", col("sl_lim_rcmd_run_dts").alias("vrsn_strt_dts")) \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_expect_oh_bkng = data_loader.read_data("sha", "EXPECT_OH_BKNG")
        df_expect_oh_bkng_max = df_expect_oh_bkng.select("app_vyge_id",
                                                         col("expect_oh_bkng_run_dts").alias("vrsn_strt_dts")) \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_uncnstrn_bkng = data_loader.read_data("sha", "UNCNSTRN_BKNG")
        df_uncnstrn_bkng_max = df_uncnstrn_bkng.select("app_vyge_id", "vrsn_strt_dts") \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        df_uncnstrn_dmnd_fcst = data_loader.read_data("sha", "UNCNSTRN_DMND_FCST")
        df_uncnstrn_dmnd_fcst_max = df_uncnstrn_dmnd_fcst.select("app_vyge_id", col("uncnstrn_dmnd_fcst_run_dts").alias(
            "vrsn_strt_dts")) \
            .filter(
            "vrsn_strt_dts >= '%s' and date(vrsn_strt_dts) <= '%s' " % (last_fetch_dt, max_data_loaded_dt)).distinct()

        app_vyge_max_vrsn_strt_df = df_price_rcmd_config_max.union(df_sl_lim_rcmd_config_max) \
            .union(df_price_rcmd_dtl_max) \
            .union(df_sl_lim_rcmd_max) \
            .union(df_expect_oh_bkng_max) \
            .union(df_uncnstrn_bkng_max) \
            .union(df_uncnstrn_dmnd_fcst_max) \
            .dropDuplicates()

        # vrsn_strt_dts is kept only for debugging purpose
        # app_vyge_max_vrsn_strt_df.show(100)
        app_vyge_max_vrsn_strt_df = app_vyge_max_vrsn_strt_df.select("app_vyge_id").distinct()

        return app_vyge_max_vrsn_strt_df

    @staticmethod
    def loadVoyages(runType, start_dt, end_dt,last_fetch_dts, spark, s3_bucket, max_data_load_dt, debug):
        noOfDays = "1500"
        filter_clause = " "

        if runType == "I" or runType == "incremental" or runType.upper() == "INTRADAY":
            noOfDays = "10"
        if runType.upper() == "INTRADAY":
            print(" loading intraday voyage ")
            app_vyge_max_vrsn_strt_df = VygeStateRoomDriver.run_app_vyge_max_vrsn(last_fetch_dts, spark, s3_bucket,
                                                                                  max_data_load_dt, debug)
            app_vyge_max_vrsn_strt_df.createOrReplaceTempView("app_vyge_max_vrsn_strt")
            filter_clause = "%s" % ("and vg_attr.app_vyge_id in(select app_vyge_id from app_vyge_max_vrsn_strt)")
        else:
            print("loading voyages")

        print("no of days ", noOfDays)

        vyge_attr_txn_dt_df1 = spark.sql(
            """ SELECT DISTINCT vg_attr.vyge_id,vg_attr.app_vyge_id,vg_attr.ship_cd,
            coalesce(vg_attr.VYGE_OPN_DT,vg_attr.vyge_init_bkng_dt) as vyge_opn_dt ,
            coalesce(vg_attr.vyge_init_bkng_dt,vg_attr.VYGE_OPN_DT) as vyge_init_bkng_dt,vg_attr.vyge_arvl_dt, vg_attr.vrsn_strt_dts, vg_attr.vyge_dprt_dt
            , vg_attr.vyge_drtn_nght_cn, vg_attr.orig_vyge_itnry_nm, vg_attr.vyge_itnry_nm from vyge_attr as vg_attr
            WHERE  date('%s') <= date_add(date(vg_attr.vyge_arvl_dt),%s) %s
            """ % (start_dt, noOfDays, filter_clause)).dropDuplicates()

        vyge_attr_txn_dt_df1.createOrReplaceTempView("vyge_attr_txn_dt_df1")

        vyge_attr_txn_dt_df2 = spark.sql(
            """ SELECT DISTINCT vg_attr.vyge_id,max(vg_attr.vrsn_strt_dts) as max_vrsn_strt_dts
            from vyge_attr as vg_attr
            WHERE  date('%s') <= date_add(date(vg_attr.vyge_arvl_dt),%s) group by vg_attr.vyge_id
            """ % (start_dt, noOfDays)).dropDuplicates()
        vyge_attr_txn_dt_df2.createOrReplaceTempView("vyge_attr_txn_dt_df2")

        vyge_attr_txn_dt_df = spark.sql(
            """ SELECT DISTINCT vg_attr1.vyge_id,vg_attr1.app_vyge_id,vg_attr1.ship_cd, vg_attr1.vyge_opn_dt ,
            vg_attr1.vyge_init_bkng_dt,vg_attr1.vyge_arvl_dt, vg_attr1.vyge_dprt_dt,
            vg_attr1.vyge_drtn_nght_cn, vg_attr1.orig_vyge_itnry_nm, vg_attr1.vyge_itnry_nm
            from vyge_attr_txn_dt_df1 as vg_attr1 join vyge_attr_txn_dt_df2 vg_attr2
            on vg_attr1.vyge_id = vg_attr2.vyge_id
            and date(vg_attr1.vrsn_strt_dts) = date(vg_attr2.max_vrsn_strt_dts) """).dropDuplicates()

        vyge_attr_txn_dt_df.createOrReplaceTempView("vyge_attr_sel_vyges")
        # vyge_attr_txn_dt_df.write.format("orc").mode("overwrite").save("/wdpr-apps-data/dclrms/stg/dm/vyge_attr_txn_dt_df/data")
        print(" vyge_attr_df load is success ")

        keys_df = vyge_attr_txn_dt_df

        f = lambda x: VygeStateRoomDriver.expand_keys(x)

        keys_df = keys_df.rdd.flatMap(f)
        keys_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                  StructField("txn_dt", DateType(), True),
                                  StructField("app_vyge_id", IntegerType(), True),
                                  StructField("ship_cd", StringType(), True)
                                  ])
        vyge_txn_dt_df = spark.createDataFrame(keys_df, keys_schema).dropDuplicates()
        vyge_txn_dt_df.createOrReplaceTempView("vyge_attr_txn_dt_df")
        if debug == 1:
            DebugCount.debug_counts(vyge_txn_dt_df, "vyge_txn_dt_df TraN info")
            # vyge_txn_dt_df.filter("vyge_id = 181000").select("app_vyge_id").show(100)
            # data_loader = S3DataLoader(spark, s3_bucket)
            # print("Before Vyge_attr_txn_dt ===>",datetime.now())
            # folder_name = "%s%s" % ("VYGE_TXN_DT_DF/partition_dt=", start_dt)
            # data_loader.write_data("dm", folder_name, None, vyge_txn_dt_df)
            # print("After Vyge_attr_txn_dt ==>",datetime.now())

    @staticmethod
    def sfbNmCalcuation(start_dt, end_dt, spark, s3_bucket, debug):
        data_loader = S3DataLoader(spark, s3_bucket)
        vyge_attr_df = spark.sql("select * from vyge_attr_sel_vyges");
        # res_baseln_filter = "upper(instnc_st_nm)= 'STANDARD' \
        #                             AND upper(sfb_nm) <> 'OFFICER' \
        #                             AND res_sts_cd in ('OF','BK','CL','TM') \
        #                             AND UPPER(asgn_strm_typ_cd) NOT IN('IRG','XAM') "

        res_baseln_filter = "upper(instnc_st_nm)= 'STANDARD'  AND upper(sfb_nm) <> 'OFFICER' "
        res_baseln_df = data_loader.read_data("dm", "RES_BASELN").filter(res_baseln_filter) \
            .join(vyge_attr_df.select("vyge_id").distinct(), "vyge_id") \
            .dropDuplicates()
        res_baseln_df.createOrReplaceTempView("res_baseln")
        res_baseln_df.cache();

        if debug == 1:
            DebugCount.debug_counts(res_baseln_df, "res_baseln")

        expect_oh_bkng_sfb_df = spark.sql("""
            SELECT DISTINCT app_vyge_id,sfb_nm,strm_typ_cd,vrsn_strt_dts,
            vrsn_end_dts FROM
            expect_oh_bkng    """)
        expect_oh_bkng_sfb_df.createOrReplaceTempView("expect_oh_bkng_sfb_df")

        proc_price_pt_df = spark.sql("""  SELECT DISTINCT vyge_id,sfb_nm,strm_typ_cd ,txn_dt FROM  proc_price_pt
                                  """)
        proc_price_pt_df.createOrReplaceTempView("proc_price_pt_df")

        con_res_base_df = data_loader.read_data("con", "vyge_sfb_strm_res_baseln")
        con_res_base_df.createOrReplaceTempView("oh_paid_res_df")

        vyge_min_txn_dt_df = spark.sql("""  SELECT vyge_id, app_vyge_id, min(txn_dt) as min_txn_dt , max(txn_dt) as max_txn_dt 
                                               FROM  vyge_attr_txn_dt_df group by vyge_id, app_vyge_id """)
        vyge_min_txn_dt_df.createOrReplaceTempView("vyge_min_txn_dt_df")

        sfb_nm_col_df = spark.sql(
            """
            (SELECT DISTINCT res_base.sfb_nm ,
                        vyg_min_txn.vyge_id,
                        strm_typ_cd_df.strm_typ_cd,
                        cast(min(res_base.vrsn_strt_dts) as date) as min_dt
                    FROM   vyge_min_txn_dt_df vyg_min_txn
                    INNER JOIN  strm_typ_cd_df strm_typ_cd_df
                    ON  vyg_min_txn.vyge_id=strm_typ_cd_df.vyge_id

                    INNER JOIN res_baseln res_base
                    ON vyg_min_txn.vyge_id = res_base.vyge_id
                    AND strm_typ_cd_df.strm_typ_cd = res_base.price_strm_typ_cd
                    AND (( res_base.vrsn_strt_dts <= vyg_min_txn.min_txn_dt
                    AND res_base.vrsn_end_dts > vyg_min_txn.min_txn_dt
                    )OR ( res_base.vrsn_strt_dts >= vyg_min_txn.min_txn_dt 
                    AND res_base.vrsn_strt_dts <= vyg_min_txn.max_txn_dt 
                    ))
                    group by vyg_min_txn.vyge_id,strm_typ_cd_df.strm_typ_cd,res_base.sfb_nm 

            )
            UNION
            ( SELECT DISTINCT proc_price_pt.sfb_nm ,
                        vyg_min_txn.vyge_id,
                        strm_typ_cd_df.strm_typ_cd,
                        min(proc_price_pt.txn_dt) as min_dt
                    FROM   vyge_min_txn_dt_df vyg_min_txn
                    INNER JOIN  strm_typ_cd_df strm_typ_cd_df
                    ON  vyg_min_txn.vyge_id=strm_typ_cd_df.vyge_id

                    INNER JOIN proc_price_pt_df AS proc_price_pt
                    ON vyg_min_txn.vyge_id = proc_price_pt.vyge_id
                    AND strm_typ_cd_df.strm_typ_cd = proc_price_pt.strm_typ_cd
                    AND (proc_price_pt.txn_dt >= vyg_min_txn.min_txn_dt 
                    AND proc_price_pt.txn_dt <= vyg_min_txn.max_txn_dt 
                )

                    group by vyg_min_txn.vyge_id,strm_typ_cd_df.strm_typ_cd,proc_price_pt.sfb_nm              
            )
            UNION
            (
                SELECT DISTINCT expect_oh_bkng.sfb_nm ,
                        vyg_min_txn.vyge_id,
                        strm_typ_cd_df.strm_typ_cd,
                        cast(min(expect_oh_bkng.vrsn_strt_dts) as date) as min_dt
                    FROM   vyge_min_txn_dt_df vyg_min_txn
                    INNER JOIN  strm_typ_cd_df strm_typ_cd_df
                    ON  vyg_min_txn.vyge_id=strm_typ_cd_df.vyge_id

                    INNER JOIN expect_oh_bkng_sfb_df AS expect_oh_bkng
                    ON vyg_min_txn.app_vyge_id = expect_oh_bkng.app_vyge_id
                    AND strm_typ_cd_df.strm_typ_cd = expect_oh_bkng.strm_typ_cd
                    AND UPPER(expect_oh_bkng.sfb_nm) ='PREVAIL' 
                    AND (( expect_oh_bkng.vrsn_strt_dts <= vyg_min_txn.min_txn_dt
                    AND expect_oh_bkng.vrsn_end_dts > vyg_min_txn.min_txn_dt
                    )OR ( expect_oh_bkng.vrsn_strt_dts >= vyg_min_txn.min_txn_dt 
                    AND expect_oh_bkng.vrsn_strt_dts <= vyg_min_txn.max_txn_dt 
                    ))
                group by vyg_min_txn.vyge_id,strm_typ_cd_df.strm_typ_cd,expect_oh_bkng.sfb_nm     
            )
                   """).dropDuplicates()

        sfb_nm_col_df_min_dt = sfb_nm_col_df.groupBy("vyge_id", "strm_typ_cd", "sfb_nm").agg(
            min("min_dt").alias("min_txn_dt"))
        sfb_nm_col_df_min_dt.createOrReplaceTempView("sfb_nm_col_df")

        sfb_nm_col_df_min_dt.printSchema()
        print("Before SFB_NM==>", datetime.now())
        # folder_name = "%s%s" % ("VYGE_SFB_NM_DF/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, sfb_nm_col_df)
        print("After SFB_NM===", datetime.now())

        if debug == 1:
            DebugCount.debug_counts(sfb_nm_col_df_min_dt, "sfb_nm_col_df count info")
            # sys.exit()

    @staticmethod
    def run_VoyageStateRoomBOH_Driver(runType, start_dt, end_dt, max_data_load_dt,last_fetch_dts, spark, s3_bucket, debug):
        """
        Driver program to run cancellation_dm
        Attributes
        start_dt    : the time slice that is being executed
        sql_context : the spark sql context
        s3_bucket   : the s3 bucket that identifies the data source
        debug       :  debug flag
        """
        data_loader = S3DataLoader(spark, s3_bucket)
        print(" start_dt ========================>>>  ", start_dt)
        print(" end_dt ========================>>>  ", end_dt)
        print(" max_data_load_dt ========================>>>  ", max_data_load_dt)
        print(" runType ========================>>>  ", runType)
        print(" debug ========================>>>  ", debug)

        converter = DataFrameUtil(spark)
        print("Max_data_load_Dt===>", max_data_load_dt)
        VygeStateRoomDriver.loadVoyages(runType, start_dt, end_dt, last_fetch_dts,spark, s3_bucket, max_data_load_dt, debug);
        VygeStateRoomDriver.loadRunDts(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug);
        if runType == "I" or runType == "incremental" or runType == "i":
            print("Before Calling Increment Cal")
            VygeStateRoomDriver.buildMinMaxDtsForInc(start_dt, end_dt, max_data_load_dt, spark, s3_bucket, debug);
            print("After Calling Increment Cal")

        ship_ctgy_nm_df = spark.sql(
            """
                                            SELECT DISTINCT ship_strm_strm_typ.strm_typ_cd,
                                                            ship_strm_typ_ext.ship_cd,
                                                            ship_strm_typ_ext.ship_ctgy_nm,
                                                            ship_strm_strm_typ.ship_strm_strm_strt_dts,
                                                            ship_strm_strm_typ.instnc_st_nm,
                                                            ship_strm_strm_typ.ship_strm_strm_end_dts,
                                                            ship_strm_strm_typ.vrsn_strt_dts ,
                                                            ship_strm_strm_typ.vrsn_end_dts
                                            FROM ship_strm_typ_ext ship_strm_typ_ext
                                            INNER JOIN ship_strm_strm_typ ship_strm_strm_typ
                                            ON UPPER(ship_strm_strm_typ.ship_cd) = UPPER(ship_strm_typ_ext.ship_cd)
                                            AND UPPER(ship_strm_strm_typ.strm_typ_cd) = UPPER(ship_strm_typ_ext.ship_strm_typ_cd)
            """).dropDuplicates()
        ship_ctgy_nm_df.createOrReplaceTempView("ship_ctgy_nm_df")

        if debug == 1:
            DebugCount.debug_counts(ship_ctgy_nm_df, "ship_ctgy_nm_df execution start here ")

        ship_ctgy_nm_df = spark.sql(
            """
                                           SELECT
                                                   vygeattr.vyge_id as vyge_id,
                                                   strjoin.strm_typ_cd,
                                                   vygeattr.vyge_dprt_dt,
                                                   strjoin.ship_ctgy_nm ,
                                                   strjoin.vrsn_strt_dts,
                                                   strjoin.vrsn_end_dts

                                           FROM   vyge_attr_sel_vyges vygeattr
                                                       INNER JOIN
                                                  ship_ctgy_nm_df strjoin
                                           ON  strjoin.ship_cd = vygeattr.ship_cd
                                                   AND vygeattr.vyge_dprt_dt >= strjoin.ship_strm_strm_strt_dts
                                                   AND vygeattr.vyge_dprt_dt < strjoin.ship_strm_strm_end_dts
                                                   WHERE strjoin.strm_typ_cd not IN ('XAM','IRG')

            """).dropDuplicates()
        ship_ctgy_nm_df.createOrReplaceTempView("strm_typ_cd_df")
        # folder_name = "%s%s" % ("VYGE_STRM_TYP_CD_DF/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, ship_ctgy_nm_df)
        if debug == 1:
            DebugCount.debug_counts(ship_ctgy_nm_df, "strm_typ_cd_df execution start here ")

        VygeStateRoomDriver.sfbNmCalcuation(start_dt, end_dt, spark, s3_bucket, debug);

        df_final_inter = spark.sql("""

    			SELECT  DISTINCT
    			vyge.vyge_id
    			,txn_dt_df.txn_dt as txn_dt
    			,vyg_attr.APP_VYGE_ID
    			,vyge.SHIP_CD
    			,vyg_attr.vyge_drtn_nght_cn
    			,vyg_attr.vyge_arvl_dt
    			,vyg_attr.VYGE_DPRT_DT
    			,vyg_attr.ORIG_VYGE_ITNRY_NM
    			,case when vyg_attr.VYGE_OPN_DT is null then vyg_attr.vyge_init_bkng_dt else vyg_attr.VYGE_OPN_DT end as VYGE_OPN_DT
    			,vyg_attr.VYGE_ITNRY_NM
    			,vyge.vyge_dprt_seapt_cd
    			,datediff(to_date(vyg_attr.VYGE_DPRT_DT),to_date(txn_dt_df.txn_dt)) as dy_bef_vyge_cn
    			,run_dts_df.expect_oh_bkng_run_dts as expect_oh_bkng_run_dts
    			,run_dts_df.expect_df_rundts_asofdate as expect_df_rundts_asofdate
    			,run_dts_df.price_rcmd_run_dts as price_rcmd_run_dts
    			,run_dts_df.price_rundts_asofdate as price_rundts_asofdate
    			,run_dts_df.uncnstrn_dmnd_fcst_run_dts as uncnstrn_dmnd_fcst_run_dts
    			,run_dts_df.uncnstrn_dmnd_rundts_asofdate as uncnstrn_dmnd_rundts_asofdate
    			,run_dts_df.batch_run_dts as batch_run_dts
    			,run_dts_df.max_btch_run_dts as max_btch_run_dts
    			,price_config_txn_dts_df.max_price_config_txn_dts as price_config_txn_dts_max
    			,uncnstrn_bkng_df.uncnstrn_bkng_run_dts as uncnstrn_bkng_run_dts
    			,sl_lim_config_start_dts_df.sl_lim_config_strt_dts_max

    			FROM
    			vyge_attr_sel_vyges as vyg_attr 
    			INNER JOIN vyge as vyge
    			ON  vyg_attr.vyge_id = vyge.vyge_id

    			LEFT OUTER JOIN price_config_txn_dts_df as price_config_txn_dts_df
    			ON vyg_attr.vyge_id=price_config_txn_dts_df.vyge_id

    			INNER JOIN vyge_attr_txn_dt_df txn_dt_df
    			ON vyg_attr.vyge_id = txn_dt_df.vyge_id

    			LEFT OUTER JOIN run_dts_df as run_dts_df
    			ON vyg_attr.vyge_id=run_dts_df.vyge_id
    			AND txn_dt_df.txn_dt=run_dts_df.txn_dt

    			LEFT OUTER JOIN  uncnstrn_bkng_run_dts_df as uncnstrn_bkng_df
    			ON vyg_attr.vyge_id=uncnstrn_bkng_df.vyge_id
    			AND txn_dt_df.txn_dt=uncnstrn_bkng_df.txn_dt



    			LEFT OUTER JOIN  sl_lim_config_start_dts_df as sl_lim_config_start_dts_df
    			ON vyg_attr.vyge_id=sl_lim_config_start_dts_df.vyge_id
    			AND txn_dt_df.txn_dt=sl_lim_config_start_dts_df.txn_dt
    			""").dropDuplicates()

        df_final_inter.createOrReplaceTempView("df_final_inter")

        df_final_inter_temp = spark.sql("""

    			SELECT  DISTINCT
    			df_final_inter.vyge_id
    			,strm_typ_cd_df.strm_typ_cd
    			,df_final_inter.txn_dt as txn_dt
    			,df_final_inter.APP_VYGE_ID
    			,df_final_inter.SHIP_CD
    			,df_final_inter.VYGE_DRTN_NGHT_CN
    			,df_final_inter.VYGE_DPRT_DT
    			,df_final_inter.ORIG_VYGE_ITNRY_NM
    			,df_final_inter.VYGE_OPN_DT
    			,df_final_inter.VYGE_ITNRY_NM
    			,strm_typ_cd_df.ship_ctgy_nm
    			,df_final_inter.vyge_dprt_seapt_cd
    			,df_final_inter.dy_bef_vyge_cn
    			,strm_typ_cd_df.ship_ctgy_nm as strm_ctgy_nm
    			,df_final_inter.expect_oh_bkng_run_dts as expect_oh_bkng_run_dts
    			,df_final_inter.expect_df_rundts_asofdate as expect_df_rundts_asofdate
    			,df_final_inter.price_rcmd_run_dts as price_rcmd_run_dts
    			,df_final_inter.price_rundts_asofdate as price_rundts_asofdate
    			,df_final_inter.uncnstrn_dmnd_fcst_run_dts as uncnstrn_dmnd_fcst_run_dts
    			,df_final_inter.uncnstrn_dmnd_rundts_asofdate as uncnstrn_dmnd_rundts_asofdate
    			,price_df.dy_bef_vyge_rnge_strt_cn_max as dy_bef_vyge_rnge_strt_cn_max
    			,df_final_inter.batch_run_dts as batch_run_dts
    			,df_final_inter.max_btch_run_dts as max_btch_run_dts
    			,df_final_inter.price_config_txn_dts_max
    			,df_final_inter.uncnstrn_bkng_run_dts as uncnstrn_bkng_run_dts
    			,df_final_inter.sl_lim_config_strt_dts_max
    			,sl_rcmd_dy_bef_vyge_rng_df.sl_lim_rcmd_run_dts as sl_lim_rcmd_run_dts_max
    			,sl_rcmd_dy_bef_vyge_rng_df.dy_bef_vyge_rnge_strt_cn_max as sl_rcmd_dy_bef_vyge_rnge_strt_cn_max

    			FROM df_final_inter df_final_inter

    			INNER JOIN strm_typ_cd_df strm_typ_cd_df
    			ON df_final_inter.vyge_id = strm_typ_cd_df.vyge_id
    			AND strm_typ_cd_df.vrsn_strt_dts <= df_final_inter.vyge_arvl_dt
    			AND strm_typ_cd_df.vrsn_end_dts > df_final_inter.vyge_arvl_dt

    			LEFT OUTER JOIN   price_dy_bef_vyge_rnge_max_attr_df as price_df
    			ON  df_final_inter.vyge_id=price_df.vyge_id
    			AND df_final_inter.txn_dt=price_df.txn_dt
    			AND strm_typ_cd_df.strm_typ_cd=price_df.strm_typ_cd

    			LEFT OUTER JOIN   sl_rcmd_ref as sl_rcmd_dy_bef_vyge_rng_df
    			ON  df_final_inter.vyge_id=sl_rcmd_dy_bef_vyge_rng_df.vyge_id
    			AND df_final_inter.txn_dt=sl_rcmd_dy_bef_vyge_rng_df.txn_dt
    			AND strm_typ_cd_df.strm_typ_cd=sl_rcmd_dy_bef_vyge_rng_df.strm_typ_cd
    			""").dropDuplicates()

        df_final_inter_temp.createOrReplaceTempView("df_final_inter_temp")

        df_final = spark.sql("""


    			select distinct 
    			df_final_inter_temp.vyge_id
    			,df_final_inter_temp.strm_typ_cd
    			,sfb_nm_col_df.SFB_NM
    			,df_final_inter_temp.txn_dt as txn_dt
    			,df_final_inter_temp.APP_VYGE_ID
    			,df_final_inter_temp.SHIP_CD
    			,df_final_inter_temp.VYGE_DRTN_NGHT_CN
    			,df_final_inter_temp.VYGE_DPRT_DT
    			,df_final_inter_temp.ORIG_VYGE_ITNRY_NM
    			,df_final_inter_temp.VYGE_OPN_DT
    			,df_final_inter_temp.VYGE_ITNRY_NM
    			,df_final_inter_temp.ship_ctgy_nm
    			,df_final_inter_temp.vyge_dprt_seapt_cd
    			,df_final_inter_temp.dy_bef_vyge_cn
    			,df_final_inter_temp.strm_ctgy_nm
    			,df_final_inter_temp.expect_oh_bkng_run_dts as expect_oh_bkng_run_dts
    			,df_final_inter_temp.expect_df_rundts_asofdate as expect_df_rundts_asofdate
    			,df_final_inter_temp.price_rcmd_run_dts as price_rcmd_run_dts
    			,df_final_inter_temp.price_rundts_asofdate as price_rundts_asofdate
    			,df_final_inter_temp.uncnstrn_dmnd_fcst_run_dts as uncnstrn_dmnd_fcst_run_dts
    			,df_final_inter_temp.uncnstrn_dmnd_rundts_asofdate as uncnstrn_dmnd_rundts_asofdate
    			,df_final_inter_temp.dy_bef_vyge_rnge_strt_cn_max as dy_bef_vyge_rnge_strt_cn_max
    			,df_final_inter_temp.batch_run_dts as batch_run_dts
    			,df_final_inter_temp.max_btch_run_dts as max_btch_run_dts
    			,df_final_inter_temp.price_config_txn_dts_max
    			,df_final_inter_temp.uncnstrn_bkng_run_dts as uncnstrn_bkng_run_dts
    			,df_final_inter_temp.sl_lim_config_strt_dts_max
    			,df_final_inter_temp.sl_lim_rcmd_run_dts_max
    			,df_final_inter_temp.sl_rcmd_dy_bef_vyge_rnge_strt_cn_max

    			FROM df_final_inter_temp  df_final_inter_temp		

    			INNER JOIN sfb_nm_col_df sfb_nm_col_df
    			ON df_final_inter_temp.vyge_id = sfb_nm_col_df.vyge_id
    			AND sfb_nm_col_df.min_txn_dt <= df_final_inter_temp.txn_dt
    			AND sfb_nm_col_df.strm_typ_cd=df_final_inter_temp.strm_typ_cd 

    			""").dropDuplicates()

        print("======================= Driver Final Info Start =================")
        df_final.printSchema()
        print("==============Driver Final Info End Here      ===================")
        maxValue = udf(lambda row: VygeStateRoomDriver.max_values(row))
        maxValueUDF = udf(lambda row: VygeStateRoomDriver.maxValueAsOfDt(row))

        # df_final = df_final.withColumn("batch_run_dts",
        #                                maxValue(struct([df_final[x] for x in df_final.columns])).cast("timestamp"))

        df_final_no_part = df_final.withColumn("as_of_dt",
                                               maxValueUDF(struct([df_final[x] for x in df_final.columns])).cast(
                                                   "date"))
        df_final = df_final_no_part.repartition("vyge_id", "strm_typ_cd", "sfb_nm", "txn_dt")

        if debug == 1:
            DebugCount.debug_counts(df_final, "df_final info ")

        df_final.cache()
        folder_name = "%s%s" % ("VYGE_STRM_TYP_SFB_BASELN_DRIVER/partition_dt=", end_dt)
        data_loader.write_data("dm", folder_name, None, df_final)
        driver_df = df_final

        # driver_df = data_loader.read_data_one_partitionVoygeStateROOM("dm", "VYGE_STRM_TYP_SFB_BASELN_DRIVER",
        #                                                              "partition_dt",
        #                                                              end_dt,
        #                                                              None).dropDuplicates()

        driver_df.createOrReplaceTempView("driver")
        driver_df.printSchema()

        if debug == 1:
            DebugCount.debug_counts(driver_df, "df_final count info");




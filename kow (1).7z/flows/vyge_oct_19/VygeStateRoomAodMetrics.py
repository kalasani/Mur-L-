##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : run_data_loader BOH -DataLoading & Driver Prepration              #
# Author            : Anjaiah M                                                          #
# Date created      : 20180619                                                           #
# Purpose           : To fetch gross per dimension metrices for all VF* inventory levels #
# Revision History  :                                                                    #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                     #
# 20180618     Anjaiah Y  Navin G  Chris                                                          #
#                                                                                        #
##########################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
# from flows.jobs.con_resbaseln_cancellation_dm import *
# from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from pyspark.sql.types import *
from framework.utils.DebugCount import *;
from time import time
import os, sys


class VygeStateRoomAodMetrics(object):
    @staticmethod
    def run_aod_vdd_calc(start_dt, jobRunDate, spark, s3_bucket, debug):
        aod_vdd_vyg_txn_strm_df = spark.sql(
            """ select distinct vyge_id,app_vyge_id,ship_cd,vyge_dprt_dt, price_rcmd_run_dts, strm_typ_cd, txn_dt ,
             max_btch_run_dts , datediff(vyge_dprt_dt,price_rcmd_run_dts) days_pr_to_dp_cn from driver where date(max_btch_run_dts) = date(txn_dt)""")
        aod_vdd_vyg_txn_strm_df.createOrReplaceTempView("aod_vdd_vyg_txn_strm_df")

        aod_grs_pd_am_df = spark.sql(

            """
            SELECT
                    vyge_strm_typ_sfb_baseln.vyge_id
                   , vyge_strm_typ_sfb_baseln.strm_typ_cd 
                   , vyge_strm_typ_sfb_baseln.app_vyge_id
                    , vyge_strm_typ_sfb_baseln.txn_dt

                    , PRICE_RCMD_DTL.VFD_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM AS aod_rcmd_vfd_grs_pd_am
                    , PRICE_RCMD_DTL.VFA_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM AS aod_rcmd_vfa_grs_pd_am
                    , PRICE_RCMD_DTL.VFC_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM AS aod_rcmd_vfc_grs_pd_am
                    , PRICE_RCMD_DTL.VFI_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM AS aod_rcmd_vfi_grs_pd_am

            FROM  aod_vdd_vyg_txn_strm_df as  vyge_strm_typ_sfb_baseln 
            INNER JOIN price_rcmd_dtl as  price_rcmd_dtl 
            ON vyge_strm_typ_sfb_baseln.app_vyge_id = price_rcmd_dtl.app_vyge_id 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = price_rcmd_dtl.strm_typ_cd
    		AND date_format(price_rcmd_dtl.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm')
            AND price_rcmd_dtl.ASOFDATE <= vyge_strm_typ_sfb_baseln.txn_dt
            AND vyge_strm_typ_sfb_baseln.days_pr_to_dp_cn >= price_rcmd_dtl.dy_bef_vyge_rnge_strt_cn
            And  vyge_strm_typ_sfb_baseln.days_pr_to_dp_cn <= price_rcmd_dtl.dy_bef_vyge_rnge_end_cn

            INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
            ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
            AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)                 

            """).dropDuplicates();
        aod_grs_pd_am_df.createOrReplaceTempView("aod_grs_pd_am_df")

        if debug == 1:
            DebugCount.debug_counts(aod_grs_pd_am_df, "aod_grs_pd_am_df count info")

        aod_gawf_am_df = spark.sql(
            """
                    SELECT

                    vyge_strm_typ_sfb_baseln.vyge_id ,
                    vyge_strm_typ_sfb_baseln.app_vyge_id ,
                    vyge_strm_typ_sfb_baseln.strm_typ_cd ,
                    vyge_strm_typ_sfb_baseln.txn_dt ,

                    CASE WHEN date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN null
                         WHEN coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0) =0 then null
                         WHEN vf_cal.AOD_RCMD_VFD_GRS_PD_AM is null then null
             ELSE (((coalesce(vf_cal.AOD_RCMD_VFD_GRS_PD_AM,0) * coalesce((gawf_var.VFD_GST_PER_STRM_CN),(dflt_var.VFD_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.AOD_RCMD_VFA_GRS_PD_AM,0) *coalesce((gawf_var.VFA_GST_PER_STRM_CN),(dflt_var.VFA_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.AOD_RCMD_VFC_GRS_PD_AM,0) * coalesce((gawf_var.VFC_GST_PER_STRM_CN),(dflt_var.VFC_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.AOD_RCMD_VFI_GRS_PD_AM,0) *coalesce((gawf_var.VFI_GST_PER_STRM_CN),(dflt_var.VFI_GST_PER_STRM_CN),0)))/coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0))
                    END as AOD_RCMD_GAWF_AM

                    FROM
                    aod_vdd_vyg_txn_strm_df as vyge_strm_typ_sfb_baseln 

                    INNER JOIN  dflt_gawf_var as dflt_var 
                    ON dflt_var.ship_cd=vyge_strm_typ_sfb_baseln.ship_cd
                    AND dflt_var.lgcl_del_in = 'N'
                    AND dflt_var.dflt_gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND dflt_var.dflt_gawf_var_end_dts  >= vyge_strm_typ_sfb_baseln.txn_dt      

                    LEFT OUTER JOIN   aod_grs_pd_am_df as vf_cal
                    ON  vyge_strm_typ_sfb_baseln.vyge_id = vf_cal.vyge_id
                    AND  vyge_strm_typ_sfb_baseln.strm_typ_cd = vf_cal.strm_typ_cd
                    AND vyge_strm_typ_sfb_baseln.txn_dt = vf_cal.txn_dt

                    LEFT OUTER JOIN  master_science_max_final_df as master_sailing_science
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = master_sailing_science.vyge_id
                    AND date(vyge_strm_typ_sfb_baseln.txn_dt) = date(master_sailing_science.asofdate)


                    LEFT OUTER JOIN gawf_var gawf_var  
                    ON gawf_var.ship_cd = vyge_strm_typ_sfb_baseln.ship_cd
                    and vyge_strm_typ_sfb_baseln.strm_typ_cd = gawf_var.strm_typ_cd
                    AND gawf_var.lgcl_del_in = 'N'
                    AND gawf_var.gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND gawf_var.gawf_var_end_dts  > vyge_strm_typ_sfb_baseln.txn_dt
                    AND master_sailing_science.school_season = gawf_var.schl_seas_nm 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt >= gawf_var.vyge_dprt_rnge_strt_dt 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt < gawf_var.vyge_dprt_rnge_end_dt     

            """ % (jobRunDate)).dropDuplicates();
        aod_gawf_am_df.createOrReplaceTempView("aod_gawf_am_df");
        if debug == 1:
            DebugCount.debug_counts(aod_gawf_am_df, "aod_gawf_am_df count info")

        vdd_grs_pd_am_df = spark.sql(
            """
            SELECT
                    vyge_strm_typ_sfb_baseln.vyge_id
                    ,vyge_strm_typ_sfb_baseln.strm_typ_cd 
                    ,vyge_strm_typ_sfb_baseln.app_vyge_id 
                    ,vyge_strm_typ_sfb_baseln.txn_dt

                    ,PRICE_RCMD_DTL.VFD_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM  as VDD_RCMD_VFD_GRS_PD_AM 
                    ,PRICE_RCMD_DTL.VFA_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM as VDD_RCMD_VFA_GRS_PD_AM
                    ,PRICE_RCMD_DTL.VFC_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM  as VDD_RCMD_VFC_GRS_PD_AM
                    ,PRICE_RCMD_DTL.VFI_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM as VDD_RCMD_VFI_GRS_PD_AM 

            FROM  aod_vdd_vyg_txn_strm_df as  vyge_strm_typ_sfb_baseln 
            INNER JOIN price_rcmd_dtl as  price_rcmd_dtl 
            ON vyge_strm_typ_sfb_baseln.app_vyge_id = price_rcmd_dtl.app_vyge_id 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = price_rcmd_dtl.strm_typ_cd
            AND date_format(price_rcmd_dtl.price_rcmd_run_dts,"y-MM-dd'T'HH:mm")  = date_format(vyge_strm_typ_sfb_baseln.price_rcmd_run_dts,"y-MM-dd'T'HH:mm")
            AND price_rcmd_dtl.ASOFDATE <= vyge_strm_typ_sfb_baseln.txn_dt
            AND price_rcmd_dtl.dy_bef_vyge_rnge_strt_cn = 0

            INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
            ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
            AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)                 

            """).dropDuplicates();
        vdd_grs_pd_am_df.createOrReplaceTempView("vdd_grs_pd_am_df")

        if debug == 1:
            DebugCount.debug_counts(vdd_grs_pd_am_df, "vdd_grs_pd_am_df count info")

        vdd_gawf_am_df = spark.sql(
            """
                    SELECT

                    vyge_strm_typ_sfb_baseln.vyge_id ,
                    vyge_strm_typ_sfb_baseln.app_vyge_id ,
                    vyge_strm_typ_sfb_baseln.strm_typ_cd  ,
                    vyge_strm_typ_sfb_baseln.txn_dt ,

                    CASE WHEN date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN null
                         WHEN coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0) =0 then null
                         WHEN vf_cal.VDD_RCMD_VFD_GRS_PD_AM is null then null
              ELSE (((coalesce(vf_cal.VDD_RCMD_VFD_GRS_PD_AM,0) * coalesce((gawf_var.VFD_GST_PER_STRM_CN),(dflt_var.VFD_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VDD_RCMD_VFA_GRS_PD_AM,0) *coalesce((gawf_var.VFA_GST_PER_STRM_CN),(dflt_var.VFA_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VDD_RCMD_VFC_GRS_PD_AM,0) * coalesce((gawf_var.VFC_GST_PER_STRM_CN),(dflt_var.VFC_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VDD_RCMD_VFI_GRS_PD_AM,0) *coalesce((gawf_var.VFI_GST_PER_STRM_CN),(dflt_var.VFI_GST_PER_STRM_CN),0)))/coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0))
                    END as VDD_RCMD_GAWF_AM

                    FROM
                    aod_vdd_vyg_txn_strm_df as vyge_strm_typ_sfb_baseln 

                    INNER JOIN  dflt_gawf_var as dflt_var 
                    ON dflt_var.ship_cd=vyge_strm_typ_sfb_baseln.ship_cd
                    AND dflt_var.lgcl_del_in = 'N'
                    AND dflt_var.dflt_gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND dflt_var.dflt_gawf_var_end_dts  >= vyge_strm_typ_sfb_baseln.txn_dt      

                    LEFT OUTER JOIN   vdd_grs_pd_am_df as vf_cal
                    ON vyge_strm_typ_sfb_baseln.vyge_id = vf_cal.vyge_id
                    AND  vyge_strm_typ_sfb_baseln.strm_typ_cd = vf_cal.strm_typ_cd
                    AND vyge_strm_typ_sfb_baseln.txn_dt = vf_cal.txn_dt

                    LEFT OUTER JOIN  master_science_max_final_df as master_sailing_science
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = master_sailing_science.vyge_id
                    AND date(vyge_strm_typ_sfb_baseln.txn_dt) = date(master_sailing_science.asofdate)


                    LEFT OUTER JOIN gawf_var gawf_var  
                    ON gawf_var.ship_cd = vyge_strm_typ_sfb_baseln.ship_cd
                    and vyge_strm_typ_sfb_baseln.strm_typ_cd = gawf_var.strm_typ_cd
                    AND gawf_var.lgcl_del_in = 'N'
                    AND gawf_var.gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND gawf_var.gawf_var_end_dts  > vyge_strm_typ_sfb_baseln.txn_dt
                    AND master_sailing_science.school_season = gawf_var.schl_seas_nm 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt >= gawf_var.vyge_dprt_rnge_strt_dt 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt < gawf_var.vyge_dprt_rnge_end_dt


            """ % (jobRunDate)).dropDuplicates();
        vdd_gawf_am_df.createOrReplaceTempView("vdd_gawf_am_df");
        if debug == 1:
            DebugCount.debug_counts(vdd_gawf_am_df, "vdd_gawf_am_df count info")

    @staticmethod
    def run_VoyageStateRoomBOH_Calculations(start_dt, jobRunDate, spark, s3_bucket,data_loader, debug):
        """ reads proc price pt from S3 and identfies if there is a change
        Attributes:
          start_dt : The start date for which price changes need to be detected
          end_dt :
          sql_context:  spark sql_context
          s3_bucket: s3 bucket where the data resides
          debug
        """
        converter = DataFrameUtil(spark)

        print("start_dt===>", start_dt)
        print("jobrun_date===>", jobRunDate)

        ship_filter = " strm_typ_cd NOT IN ( 'IGT', 'OGT', 'VGT', 'XAM','GTY', 'IRG' ) and UPPER(instnc_st_nm) = 'STANDARD' "
        print("ship_strm_typ_filter", ship_filter)
        ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP").filter(ship_filter)
        ship_strm_strm_df.printSchema();

        ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")
        print("Done Before ops")

        phys_invtry_strm_cn_df = spark.sql("""
         				select driver.vyge_id,driver.sfb_nm,driver.strm_typ_cd,driver.txn_dt,count(*) as phys_invtry_strm_cn 
        				from ship_strm_strm_typ as ship INNER JOIN driver as driver ON driver.ship_cd=ship.ship_cd 
        				AND driver.strm_typ_cd=ship.strm_typ_cd
        				AND driver.vyge_dprt_dt >= date(ship.ship_strm_strm_strt_dts)
        				AND driver.vyge_dprt_dt < date(ship.ship_strm_strm_end_dts)
        				AND driver.txn_dt >= date(ship.vrsn_strt_dts)
        				AND driver.txn_dt < date(ship.vrsn_end_dts)
       				 group by driver.vyge_id,driver.sfb_nm,driver.strm_typ_cd,driver.txn_dt """)

        phys_invtry_strm_cn_df.printSchema()
        phys_invtry_strm_cn_df.createOrReplaceTempView("phys_invtry_strm_cn_df");
        if debug == 1:
            DebugCount.debug_counts(phys_invtry_strm_cn_df, "phys_invtry_strm_cn_df")

        ooo_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "
        ooo_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_filter)
        ooo_consolidated_df.createOrReplaceTempView("ooo_consoloidated")

        ooo_consolidated_sql = """
                                  select 
                                  sum(vyge_strm_ooo_strm_cn) as ooo_strm_cn
                                  ,sum(vyge_strm_phys_invtry_strm_cn) as phys_invtry_strm_cn 
                                  ,ooo.src_sys_strm_typ_cd as strm_typ_cd
                                  ,ooo.txn_dt as txn_dt
                                  ,ooo.vyge_id as vyge_id 
                                  from ooo_consoloidated ooo 
                                  group by 
                                    ooo.vyge_id
                                   , ooo.src_sys_strm_typ_cd
                                   ,ooo.txn_dt
                                """
        ooo_inventory_cnt_driver_df = spark.sql(ooo_consolidated_sql).dropDuplicates()
        ooo_inventory_cnt_driver_df.createOrReplaceTempView("ooo_strm_cn_df");
        if debug == 1:
            DebugCount.debug_counts(ooo_inventory_cnt_driver_df, "ooo_inventory_cnt_driver_df")

        master_science_max_df = spark.sql("""
         select max(asofdate) as max_as_of_date,vyge_id from master_sailing_science group by vyge_id
            """)
        master_science_max_df.createOrReplaceTempView("master_science_max_df")
        master_science_max_final_df = spark.sql("""
             select mss.vyge_id,mss.asofdate,mss.school_season from master_sailing_science as mss inner join master_science_max_df master_max 
             ON mss.vyge_id=master_max.vyge_id
             AND mss.asofdate=master_max.max_as_of_date
                """)
        master_science_max_final_df.createOrReplaceTempView("master_science_max_final_df")

        oh_paid_bkng_cn_df = spark.sql(
            """         
              SELECT  vyge_strm_typ_sfb_baseln.vyge_id,
                           vyge_strm_typ_sfb_baseln.strm_typ_cd as  strm_typ_cd,
                           vyge_strm_typ_sfb_baseln.sfb_nm,
                           vyge_strm_typ_sfb_baseln.txn_dt,

                          oh_ref.oh_paid_bkng_cn  as oh_paid_bkng_cn
                    FROM   driver as  vyge_strm_typ_sfb_baseln
                           INNER JOIN oh_paid_res_df as oh_ref
                           ON vyge_strm_typ_sfb_baseln.vyge_id = oh_ref.vyge_id
                           AND vyge_strm_typ_sfb_baseln.sfb_nm = oh_ref.sfb_nm
                           AND vyge_strm_typ_sfb_baseln.strm_typ_cd = oh_ref.strm_typ_cd
                           AND vyge_strm_typ_sfb_baseln.txn_dt = oh_ref.txn_dt

                           """)

        oh_paid_bkng_cn_df.createOrReplaceTempView("oh_paid_bkng_cn_df");

        if debug == 3:
            DebugCount.debug_counts(oh_paid_bkng_cn_df, "oh_paid_bkng_cn_df count info")

        expect_oh_bkng_cn_df = spark.sql(
            """
                    SELECT
                            vyge_sfb_baseln.vyge_id,
                            vyge_sfb_baseln.strm_typ_cd,
                            vyge_sfb_baseln.txn_dt ,
                            vyge_sfb_baseln.sfb_nm,
                            expect_oh_bkng.expect_oh_bkng_cn as  EXPECT_OH_BKNG_CN

                    FROM   driver as vyge_sfb_baseln
                    INNER JOIN
                    expect_oh_bkng  as expect_oh_bkng
                    ON vyge_sfb_baseln.app_vyge_id = expect_oh_bkng.app_vyge_id
                    AND expect_oh_bkng.sfb_nm = vyge_sfb_baseln.sfb_nm
                    AND  expect_oh_bkng.dy_bef_vyge_cn = vyge_sfb_baseln.dy_bef_vyge_cn
                    AND date_format(expect_oh_bkng.expect_oh_bkng_run_dts, 'YYYY-MM-dd HH:mm')= date_format(vyge_sfb_baseln.expect_oh_bkng_run_dts , 'YYYY-MM-dd HH:mm')
                    AND  vyge_sfb_baseln.strm_typ_cd=expect_oh_bkng.strm_typ_cd
                    AND  date(vyge_sfb_baseln.max_btch_run_dts) <= date(vyge_sfb_baseln.txn_dt)

                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
                    ON vyge_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
                    AND vyge_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
                    AND date(vyge_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)                 

             """).dropDuplicates()

        expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_df");

        if debug == 1:
            DebugCount.debug_counts(expect_oh_bkng_cn_df, "expect_oh_bkng_cn_df count info")

        vdd_expect_oh_bkng_cn_df = spark.sql(
            """
                    SELECT
                            vyge_sfb_baseln.vyge_id,
                            vyge_sfb_baseln.strm_typ_cd,
                            vyge_sfb_baseln.txn_dt ,
                            vyge_sfb_baseln.sfb_nm,
                            expect_oh_bkng.expect_oh_bkng_cn as  vdd_expect_oh_bkng_cn


                    FROM   driver as vyge_sfb_baseln
                    INNER JOIN
                    expect_oh_bkng  as expect_oh_bkng
                    ON vyge_sfb_baseln.app_vyge_id = expect_oh_bkng.app_vyge_id
                    AND expect_oh_bkng.sfb_nm = vyge_sfb_baseln.sfb_nm
                    AND  expect_oh_bkng.dy_bef_vyge_cn = 1
                    AND date_format(expect_oh_bkng.expect_oh_bkng_run_dts, 'YYYY-MM-dd HH:mm')= date_format(vyge_sfb_baseln.expect_oh_bkng_run_dts , 'YYYY-MM-dd HH:mm')					
                    AND  vyge_sfb_baseln.strm_typ_cd=expect_oh_bkng.strm_typ_cd
                    AND  date(vyge_sfb_baseln.batch_run_dts) = date(vyge_sfb_baseln.txn_dt)

                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
                    ON vyge_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
                    AND vyge_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
                    AND date(vyge_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)                 

             """).dropDuplicates()

        vdd_expect_oh_bkng_cn_df.createOrReplaceTempView("vdd_expect_oh_bkng_cn_df");

        if debug == 1:
            DebugCount.debug_counts(vdd_expect_oh_bkng_cn_df, "vdd_expect_oh_bkng_cn_df count info")

        price_rcmd_call_df = spark.sql(
            """  
            SELECT 
             vyge_strm_typ_sfb_baseln.app_vyge_id
            ,vyge_strm_typ_sfb_baseln.vyge_id
            ,vyge_strm_typ_sfb_baseln.strm_typ_cd AS strm_typ_cd
            ,vyge_strm_typ_sfb_baseln.sfb_nm AS sfb_nm
            ,vyge_strm_typ_sfb_baseln.txn_dt 

            ,CASE     WHEN price_rcmd_dtl.plan_cfdnc_lvl_am = '-99999' then null 
                      WHEN vyge_strm_typ_sfb_baseln.sfb_nm != 'PREVAIL'then null
                      ELSE price_rcmd_dtl.plan_cfdnc_lvl_am  
            END as plan_cfdnc_lvl_am
            ,
            CASE    WHEN vyge_strm_typ_sfb_baseln.sfb_nm != 'PREVAIL' then null
                        ELSE price_rcmd_dtl.price_impct_lvl_am
               END AS price_impct_lvl_am

            , case when PRICE_RCMD_DTL.VFD_PD_AM is null and PRICE_RCMD_DTL.NON_COMM_FARE_AM is null
                 then  price_rcmd_dtl_max.VFD_PD_AM + price_rcmd_dtl_max.NON_COMM_FARE_AM 
                 else PRICE_RCMD_DTL.VFD_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM
                 end  as rcmd_vfd_grs_pd_am

            ,case when PRICE_RCMD_DTL.VFA_PD_AM is null and PRICE_RCMD_DTL.NON_COMM_FARE_AM is null
                 then  price_rcmd_dtl_max.VFA_PD_AM + price_rcmd_dtl_max.NON_COMM_FARE_AM 
                 else PRICE_RCMD_DTL.VFA_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM
                 end  as rcmd_vfa_grs_pd_am

            ,case when PRICE_RCMD_DTL.VFC_PD_AM is null and PRICE_RCMD_DTL.NON_COMM_FARE_AM is null
                 then  price_rcmd_dtl_max.VFC_PD_AM + price_rcmd_dtl_max.NON_COMM_FARE_AM 
                 else PRICE_RCMD_DTL.VFC_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM
                 end  as rcmd_vfc_grs_pd_am

            ,case when PRICE_RCMD_DTL.VFI_PD_AM is null and PRICE_RCMD_DTL.NON_COMM_FARE_AM is null
                 then  price_rcmd_dtl_max.VFI_PD_AM + price_rcmd_dtl_max.NON_COMM_FARE_AM 
                 else PRICE_RCMD_DTL.VFI_PD_AM + PRICE_RCMD_DTL.NON_COMM_FARE_AM
                 end  as rcmd_vfi_grs_pd_am

            FROM  driver as  vyge_strm_typ_sfb_baseln 

            LEFT OUTER JOIN price_rcmd_dtl as  price_rcmd_dtl 
            ON vyge_strm_typ_sfb_baseln.app_vyge_id = price_rcmd_dtl.app_vyge_id 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = price_rcmd_dtl.strm_typ_cd 
            AND date_format(price_rcmd_dtl.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm')
            AND date(vyge_strm_typ_sfb_baseln.max_btch_run_dts) <= date(vyge_strm_typ_sfb_baseln.txn_dt)
            AND ( 
            vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn >= price_rcmd_dtl.dy_bef_vyge_rnge_strt_cn 
            AND vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn  <= price_rcmd_dtl.dy_bef_vyge_rnge_end_cn
            )


            LEFT OUTER JOIN price_rcmd_dtl as  price_rcmd_dtl_max 
            ON vyge_strm_typ_sfb_baseln.app_vyge_id = price_rcmd_dtl_max.app_vyge_id 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = price_rcmd_dtl_max.strm_typ_cd 
            AND date_format(price_rcmd_dtl_max.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.price_rcmd_run_dts, 'YYYY-MM-dd HH:mm')
            AND date(vyge_strm_typ_sfb_baseln.max_btch_run_dts) <= date(vyge_strm_typ_sfb_baseln.txn_dt)
            AND  price_rcmd_dtl_max.dy_bef_vyge_rnge_strt_cn = vyge_strm_typ_sfb_baseln.dy_bef_vyge_rnge_strt_cn_max


            INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
            ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
            AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)                 
            """).dropDuplicates()

        price_rcmd_call_df.createOrReplaceTempView("price_rcmd_run_dts_df");
        if debug == 1:
            DebugCount.debug_counts(price_rcmd_call_df, "price_rcmd_call_df count info")

        vf_grs_pd_am_cal_df = spark.sql(
            """
            SELECT
            vyge_strm_typ_sfb_baseln.vyge_id
            , vyge_strm_typ_sfb_baseln.strm_typ_cd
            , vyge_strm_typ_sfb_baseln.SFB_NM  as sfb_nm
            , vyge_strm_typ_sfb_baseln.txn_dt
            , vyge_strm_typ_sfb_baseln.app_vyge_id
            , 

            CASE WHEN   vyge_strm_typ_sfb_baseln.txn_dt >  date('%s') THEN  NULL 
               WHEN date(price_config_txn_dts_max) >= date(vyge_strm_typ_sfb_baseln.txn_dt) and proc_price_pt.txn_dt is null
                     THEN   "PRICE_CONFIG"
                    ELSE "PROC_PRICE_PT"
            END as price_src_nm
            ,


            CASE WHEN   date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN  NULL 
                 WHEN date(price_config_txn_dts_max) >= date(vyge_strm_typ_sfb_baseln.txn_dt) and proc_price_pt.txn_dt is null
                 THEN (price_config.vfd_apprv_price_am + price_config.non_comm_fare_am) 
                ELSE (proc_price_pt.VFD_AM + proc_price_pt.NON_COMM_AM)/proc_price_pt.VYGE_DRTN_NGHT_CN END as VFD_GRS_PD_AM
            ,
            CASE WHEN date(vyge_strm_typ_sfb_baseln.txn_dt) > date('%s') THEN   NULL  
                WHEN date(price_config_txn_dts_max) >= date(vyge_strm_typ_sfb_baseln.txn_dt) and proc_price_pt.txn_dt is null  
                THEN  price_config.vfa_apprv_price_am + price_config.non_comm_fare_am 
              ELSE  (proc_price_pt.VFA_EXTRA_AM + proc_price_pt.NON_COMM_AM) / proc_price_pt.VYGE_DRTN_NGHT_CN  END as VFA_GRS_PD_AM
            ,
            CASE WHEN  date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN  NULL   
            WHEN date(price_config_txn_dts_max) >= date(vyge_strm_typ_sfb_baseln.txn_dt) and proc_price_pt.txn_dt is null
            THEN price_config.vfc_apprv_price_am + price_config.non_comm_fare_am
            ELSE  (proc_price_pt.VFC_EXTRA_AM + proc_price_pt.NON_COMM_AM) / proc_price_pt.VYGE_DRTN_NGHT_CN END as VFC_GRS_PD_AM
            ,

            CASE  WHEN  date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN   NULL
             WHEN date(price_config_txn_dts_max) >= date(vyge_strm_typ_sfb_baseln.txn_dt) and proc_price_pt.txn_dt is null 
            THEN  price_config.vfi_apprv_price_am + price_config.non_comm_fare_am
            ELSE (proc_price_pt.VFI_EXTRA_AM + proc_price_pt.NON_COMM_AM) / proc_price_pt.VYGE_DRTN_NGHT_CN END as VFI_GRS_PD_AM

            FROM
            driver as vyge_strm_typ_sfb_baseln
            LEFT OUTER JOIN  proc_price_pt as proc_price_pt
            ON  vyge_strm_typ_sfb_baseln.vyge_id = proc_price_pt.vyge_id
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = proc_price_pt.strm_typ_cd
            AND UPPER(proc_price_pt.sfb_nm) = 'PREVAIL'
            AND UPPER(proc_price_pt.proc_price_src_sys_nm) = 'PRICING EXTRACT'
            AND upper(proc_price_pt.instnc_st_nm) = 'STANDARD'
            AND date(proc_price_pt.txn_dt) =date(vyge_strm_typ_sfb_baseln.txn_dt)

            LEFT OUTER JOIN price_config
            ON vyge_strm_typ_sfb_baseln.app_vyge_id = price_config.app_vyge_id
            AND vyge_strm_typ_sfb_baseln.strm_typ_cd = price_config.strm_typ_cd
            AND date(price_config.price_rcmd_txn_dts) >=    date(vyge_strm_typ_sfb_baseln.txn_dt)
            AND UPPER(price_config.btch_sts_nm) = 'SUCCESSFUL'
            AND price_config.price_rcmd_txn_dts = vyge_strm_typ_sfb_baseln.price_config_txn_dts_max
            AND date(price_config.price_rcmd_txn_dts) >= (vyge_strm_typ_sfb_baseln.txn_dt)

            """ % (jobRunDate, jobRunDate, jobRunDate, jobRunDate, jobRunDate)).dropDuplicates();

        vf_grs_pd_am_cal_df.createOrReplaceTempView("vf_grs_pd_am_df");

        if debug == 1:
            DebugCount.debug_counts(vf_grs_pd_am_cal_df, "vf_grs_pd_am_cal_df count info")

        gawf_am_df = spark.sql(
            """
                    SELECT
                    vyge_strm_typ_sfb_baseln.vyge_id ,
                    vyge_strm_typ_sfb_baseln.app_vyge_id ,
                    vyge_strm_typ_sfb_baseln.strm_typ_cd as strm_typ_cd ,
                    vyge_strm_typ_sfb_baseln.SFB_NM as sfb_nm,
                    vyge_strm_typ_sfb_baseln.txn_dt ,

                    CASE WHEN date(vyge_strm_typ_sfb_baseln.txn_dt) >  date('%s') THEN null
                         WHEN coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0) =0 then null
                         WHEN vf_cal.VFD_GRS_PD_AM is null then null
                 ELSE (
                       ((coalesce(vf_cal.VFD_GRS_PD_AM,0) * coalesce((gawf_var.VFD_GST_PER_STRM_CN),(dflt_var.VFD_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VFA_GRS_PD_AM,0) *coalesce((gawf_var.VFA_GST_PER_STRM_CN),(dflt_var.VFA_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VFC_GRS_PD_AM,0) * coalesce((gawf_var.VFC_GST_PER_STRM_CN),(dflt_var.VFC_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.VFI_GRS_PD_AM,0) *coalesce((gawf_var.VFI_GST_PER_STRM_CN),(dflt_var.VFI_GST_PER_STRM_CN),0)) )/coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0))

                    END as gawf_am

                    FROM
                    driver as vyge_strm_typ_sfb_baseln 

                     INNER JOIN  dflt_gawf_var as dflt_var 
                    ON dflt_var.ship_cd=vyge_strm_typ_sfb_baseln.ship_cd
                    AND dflt_var.lgcl_del_in = 'N'
                    AND dflt_var.dflt_gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND dflt_var.dflt_gawf_var_end_dts  >= vyge_strm_typ_sfb_baseln.txn_dt  


                    LEFT OUTER JOIN   vf_grs_pd_am_df as vf_cal
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = vf_cal.app_vyge_id
                    AND  vyge_strm_typ_sfb_baseln.vyge_id = vf_cal.vyge_id
                    AND  vyge_strm_typ_sfb_baseln.strm_typ_cd = vf_cal.strm_typ_cd
                    AND vyge_strm_typ_sfb_baseln.SFB_NM = vf_cal.SFB_NM
                    AND vyge_strm_typ_sfb_baseln.txn_dt = vf_cal.txn_dt

                    LEFT OUTER JOIN  master_science_max_final_df as master_sailing_science
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = master_sailing_science.vyge_id
                    AND date(vyge_strm_typ_sfb_baseln.txn_dt) = date(master_sailing_science.asofdate)


                    LEFT OUTER JOIN gawf_var gawf_var  
                    ON gawf_var.ship_cd = vyge_strm_typ_sfb_baseln.ship_cd
                    and vyge_strm_typ_sfb_baseln.strm_typ_cd = gawf_var.strm_typ_cd
                    AND gawf_var.lgcl_del_in = 'N'
                    AND gawf_var.gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND gawf_var.gawf_var_end_dts  >= vyge_strm_typ_sfb_baseln.txn_dt
                    AND master_sailing_science.school_season = gawf_var.schl_seas_nm 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt >= gawf_var.vyge_dprt_rnge_strt_dt 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt < gawf_var.vyge_dprt_rnge_end_dt



            """ % (jobRunDate)).dropDuplicates();
        gawf_am_df.createOrReplaceTempView("gawf_am_df");

        if debug == 1:
            DebugCount.debug_counts(gawf_am_df, "gawf_am_df count info")

        rcmd_gawf_am_df = spark.sql(
            """
                    SELECT

                    vyge_strm_typ_sfb_baseln.vyge_id ,
                    vyge_strm_typ_sfb_baseln.app_vyge_id ,
                    vyge_strm_typ_sfb_baseln.strm_typ_cd as strm_typ_cd ,
                    vyge_strm_typ_sfb_baseln.SFB_NM as sfb_nm,
                    vyge_strm_typ_sfb_baseln.txn_dt ,

                    CASE WHEN date(vyge_strm_typ_sfb_baseln.max_btch_run_dts) > date(vyge_strm_typ_sfb_baseln.txn_dt) THEN null
                         WHEN coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0) =0 then null
                         WHEN vf_cal.RCMD_VFD_GRS_PD_AM is null then null
                    ELSE (((coalesce(vf_cal.RCMD_VFD_GRS_PD_AM,0) * coalesce((gawf_var.VFD_GST_PER_STRM_CN),(dflt_var.VFD_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.RCMD_VFA_GRS_PD_AM,0) *coalesce((gawf_var.VFA_GST_PER_STRM_CN),(dflt_var.VFA_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.RCMD_VFC_GRS_PD_AM,0) * coalesce((gawf_var.VFC_GST_PER_STRM_CN),(dflt_var.VFC_GST_PER_STRM_CN),0)) +
                       (coalesce(vf_cal.RCMD_VFI_GRS_PD_AM,0) *coalesce((gawf_var.VFI_GST_PER_STRM_CN),(dflt_var.VFI_GST_PER_STRM_CN),0)))/coalesce((gawf_var.vyge_gst_per_strm_cn),(dflt_var.vyge_gst_per_strm_cn),0))
                    END as RCMD_GAWF_AM

                    FROM
                    driver as vyge_strm_typ_sfb_baseln 

                    INNER JOIN  dflt_gawf_var as dflt_var 
                    ON dflt_var.ship_cd=vyge_strm_typ_sfb_baseln.ship_cd
                    AND dflt_var.lgcl_del_in = 'N'
                    AND dflt_var.dflt_gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND dflt_var.dflt_gawf_var_end_dts  >= vyge_strm_typ_sfb_baseln.txn_dt      

                     LEFT OUTER JOIN  master_science_max_final_df as master_sailing_science
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = master_sailing_science.vyge_id
                    AND vyge_strm_typ_sfb_baseln.txn_dt = master_sailing_science.asofdate


                    LEFT OUTER JOIN   price_rcmd_run_dts_df as vf_cal
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = vf_cal.app_vyge_id
                    AND  vyge_strm_typ_sfb_baseln.vyge_id = vf_cal.vyge_id
                    AND  vyge_strm_typ_sfb_baseln.strm_typ_cd = vf_cal.strm_typ_cd
                    AND vyge_strm_typ_sfb_baseln.SFB_NM = vf_cal.SFB_NM
                    AND vyge_strm_typ_sfb_baseln.txn_dt = vf_cal.txn_dt



                    LEFT OUTER JOIN gawf_var gawf_var  
                    ON gawf_var.ship_cd = vyge_strm_typ_sfb_baseln.ship_cd
                    and vyge_strm_typ_sfb_baseln.strm_typ_cd = gawf_var.strm_typ_cd
                    AND gawf_var.lgcl_del_in = 'N'
                    AND gawf_var.gawf_var_strt_dts <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND master_sailing_science.school_season = gawf_var.schl_seas_nm
                    AND gawf_var.gawf_var_end_dts  > vyge_strm_typ_sfb_baseln.txn_dt
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt >= gawf_var.vyge_dprt_rnge_strt_dt 
                    AND vyge_strm_typ_sfb_baseln.vyge_dprt_dt < gawf_var.vyge_dprt_rnge_end_dt     
            """).dropDuplicates();

        rcmd_gawf_am_df.createOrReplaceTempView("rcmd_gawf_am_df");
        if debug == 1:
            DebugCount.debug_counts(rcmd_gawf_am_df, "rcmd_gawf_am_df count info")

        # compute aod and vdd calcs
        VygeStateRoomAodMetrics.run_aod_vdd_calc(start_dt, jobRunDate, spark, s3_bucket, debug)

        udf_uncnstrndmnd_expect_oh_bkng_run_dts_df = spark.sql(
            """
                    SELECT
                     vyge_strm_typ_sfb_baseln.vyge_id
                    ,vyge_strm_typ_sfb_baseln.strm_typ_cd as strm_typ_cd
                    ,vyge_strm_typ_sfb_baseln.sfb_nm
                    ,vyge_strm_typ_sfb_baseln.txn_dt

                    ,uncnstrn_bkng.udf_as_of_dt_rcmd_price_am AS  udf_as_of_dt_rcmd_price_am
                    ,uncnstrn_bkng.udf_curr_price_am as udf_curr_price_am
                    ,uncnstrn_bkng.udf_rcmd_price_am as udf_rcmd_price_am

                    FROM

                    driver as vyge_strm_typ_sfb_baseln
                    INNER JOIN uncnstrn_bkng as uncnstrn_bkng
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = uncnstrn_bkng.app_vyge_id 
    				AND date_format(uncnstrn_bkng.uncnstrn_bkng_run_dts, 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.uncnstrn_bkng_run_dts , 'YYYY-MM-dd HH:mm')
    	            AND uncnstrn_bkng.partition_dt = date(vyge_strm_typ_sfb_baseln.uncnstrn_bkng_run_dts)
                    AND vyge_strm_typ_sfb_baseln.sfb_nm = uncnstrn_bkng.sfb_nm
                    AND vyge_strm_typ_sfb_baseln.strm_typ_cd = uncnstrn_bkng.strm_typ_cd
                    AND uncnstrn_bkng.dy_bef_vyge_cn = vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn
                    AND  date(vyge_strm_typ_sfb_baseln.max_btch_run_dts) <= date(vyge_strm_typ_sfb_baseln.txn_dt)


                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
                    ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
                    AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
                    AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max) 
                """).dropDuplicates()

        udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.createOrReplaceTempView("udf_uncnstrndmnd_expect_oh_bkng_run_dts_df")
        if debug == 1:
            DebugCount.debug_counts(udf_uncnstrndmnd_expect_oh_bkng_run_dts_df,
                                    "udf_uncnstrndmnd_expect_oh_bkng_run_dts_df count info")

        sl_lim_vyge_sum_df = data_loader.read_data("dm", "SL_LIM_VYGE_SUM")
        sl_lim_vyge_sum_df.createOrReplaceTempView("sl_lim_vyge_sum_df")

        sl_lim_vyge_sum_fil = spark.sql("""select * from sl_lim_vyge_sum_df where 
                                                            instnc_st_nm = 'Standard'
                                                            and AGE_CTGY_CD is null
                                                            and OCPNCY_CN is null
                                                            and PROMO_CD is null
                                                            and REF_SRC_NM is null
                                                            and RES_TYP_CD is null
                                                            and AGCY_ID is null
                                                            and GRP_TYP_CD is null
                                                            and DNG_TM is null
                                                            and AGE_FR_NB is null
                                                            and AGE_TO_NB is null
                                                            and GST_SEQ_FR_NB is null
                                                            and GST_SEQ_TO_NB is null
                                                            and CONDITIONTEXT is null
                                                            and AUTH_CD is null
                                                           """).dropDuplicates()
        # sl_lim_debug.show(10)
        sl_lim_vyge_sum_fil.createOrReplaceTempView("sl_lim_vyge_sum")

        sl_lim_vyge_sum_max_abs_lm_df = spark.sql(
            """
                SELECT vyge_id,
                       txn_dt,
                       strm_typ_cd,
                       sfb_nm,
                       max(sl_lim_vyge_sum.absolute_lim_nb) as absolute_lim_nb
                FROM   driver as vyge_strm_typ_sfb_baseln
                        INNER JOIN sl_lim_vyge_sum as sl_lim_vyge_sum
                ON    vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_vyge_sum.cbn_ctgy_cd
                AND   vyge_strm_typ_sfb_baseln.vyge_id = sl_lim_vyge_sum.sail_id
                AND   vyge_strm_typ_sfb_baseln.ship_cd = sl_lim_vyge_sum.ship_cd
                AND   date(sl_lim_vyge_sum.vrsn_strt_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                AND   date(sl_lim_vyge_sum.vrsn_end_dts) > vyge_strm_typ_sfb_baseln.txn_dt
                group by vyge_id, strm_typ_cd, sfb_nm, txn_dt
                   """).dropDuplicates()

        sl_lim_vyge_sum_max_abs_lm_df.createOrReplaceTempView("sl_lim_vyge_sum_max_abs_lm_df");

        sl_lim_strm_typ_cn_df = spark.sql(
            """
                SELECT
                        vyge_strm_typ_sfb_baseln.vyge_id,
                        vyge_strm_typ_sfb_baseln.app_vyge_id,
                        vyge_strm_typ_sfb_baseln.strm_typ_cd AS strm_typ_cd,
                        vyge_strm_typ_sfb_baseln.sfb_nm AS sfb_nm,
                        vyge_strm_typ_sfb_baseln.txn_dt,
                CASE
                                WHEN      date('%s') < vyge_strm_typ_sfb_baseln.txn_dt THEN NULL
                                WHEN coalesce(sl_lim_config.apprv_sl_lim_strm_typ_cn,0) >0  THEN sl_lim_config.apprv_sl_lim_strm_typ_cn 
                                ELSE cast(coalesce((sl_lim_vyge_sum_max_abs_lm_df.absolute_lim_nb),0) as int)
                end AS sl_lim_strm_typ_cn
                        ,
                CASE 
                    WHEN     date('%s') <  vyge_strm_typ_sfb_baseln.txn_dt THEN NULL
                    WHEN coalesce(sl_lim_config.apprv_sl_lim_strm_typ_cn,0)>0  THEN "SL_LIM_CONFIG"
                    ELSE "SL_LIM_VYGE_SUM"
                END as sl_lim_src_nm

                FROM   driver as vyge_strm_typ_sfb_baseln

                LEFT OUTER JOIN sl_lim_config as sl_lim_config
                ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_config.app_vyge_id
                and vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_config.src_sys_strm_typ_nm
                and UPPER(sl_lim_config.lgcl_del_in) = 'N' 
    			AND date_format(sl_lim_config.sl_lim_config_strt_dts , 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.sl_lim_config_strt_dts_max , 'YYYY-MM-dd HH:mm')
                AND date(sl_lim_config.sl_lim_config_strt_dts)= vyge_strm_typ_sfb_baseln.txn_dt
                AND upper(sl_lim_config.btch_sts_nm) = 'SUCCESSFUL'
                AND   date(sl_lim_config.vrsn_strt_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                AND   date(sl_lim_config.vrsn_end_dts) > vyge_strm_typ_sfb_baseln.txn_dt


                INNER JOIN sl_lim_vyge_sum_max_abs_lm_df as sl_lim_vyge_sum_max_abs_lm_df
                ON    vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_vyge_sum_max_abs_lm_df.strm_typ_cd
                AND   vyge_strm_typ_sfb_baseln.vyge_id = sl_lim_vyge_sum_max_abs_lm_df.vyge_id
                AND   vyge_strm_typ_sfb_baseln.sfb_nm = sl_lim_vyge_sum_max_abs_lm_df.sfb_nm
                AND  vyge_strm_typ_sfb_baseln.txn_dt = sl_lim_vyge_sum_max_abs_lm_df.txn_dt
                  """ % (jobRunDate, jobRunDate)).dropDuplicates()
        sl_lim_strm_typ_cn_df.createOrReplaceTempView("sl_lim_strm_typ_cn_df")
        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_cn_df, "sl_lim_strm_typ_cn_df count info")

        sl_lim_rcmd_attr = "upper(lgcl_del_in) = 'N' and instnc_st_nm = 'STANDARD' and strm_ocpncy_cn is null"

        sl_lim_rcmd_strm_typ_cn_df = spark.sql("""
                      SELECT
                        vyge_strm_typ_sfb_baseln.app_vyge_id
                        , vyge_strm_typ_sfb_baseln.vyge_id
                       , vyge_strm_typ_sfb_baseln.strm_typ_cd AS strm_typ_cd
                       , vyge_strm_typ_sfb_baseln.sfb_nm AS sfb_nm
                       , vyge_strm_typ_sfb_baseln.txn_dt AS txn_dt
                       ,coalesce((sl_lim_rcmd.rcmd_sl_lim_strm_typ_cn),sl_lim_rcmd_by_max_cnt.rcmd_sl_lim_strm_typ_cn,null)  AS rcmd_sl_lim_strm_typ_cn
                    FROM   driver as vyge_strm_typ_sfb_baseln
                    LEFT OUTER JOIN sl_lim_rcmd as sl_lim_rcmd
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_rcmd.app_vyge_id
                    AND vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_rcmd.src_sys_strm_typ_nm 
    				AND date_format(sl_lim_rcmd.sl_lim_rcmd_run_dts, 'YYYY-MM-dd HH:mm')  = date_format(vyge_strm_typ_sfb_baseln.sl_lim_rcmd_run_dts_max, 'YYYY-MM-dd HH:mm')
                    And date( vyge_strm_typ_sfb_baseln.max_btch_run_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND
                    (
                        vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn >= sl_lim_rcmd.dy_bef_vyge_rnge_strt_cn
                        AND vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn <= sl_lim_rcmd.dy_bef_vyge_rnge_end_cn

                    )


                    LEFT OUTER JOIN  sl_lim_rcmd as sl_lim_rcmd_by_max_cnt
                    ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_rcmd_by_max_cnt.app_vyge_id
                    AND vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_rcmd_by_max_cnt.src_sys_strm_typ_nm
    				AND date_format(sl_lim_rcmd_by_max_cnt.sl_lim_rcmd_run_dts , 'YYYY-MM-dd HH:mm') = date_format(vyge_strm_typ_sfb_baseln.sl_lim_rcmd_run_dts_max, 'YYYY-MM-dd HH:mm') 
                    And date( vyge_strm_typ_sfb_baseln.max_btch_run_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                    AND
                    (
                             sl_lim_rcmd_by_max_cnt.dy_bef_vyge_rnge_strt_cn = vyge_strm_typ_sfb_baseln.sl_rcmd_dy_bef_vyge_rnge_strt_cn_max
                    )


                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config
                    ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd
                    AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm
                    AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)
                  """).dropDuplicates()

        # sl_lim_rcmd_strm_typ_cn_df=spark.sql("""
        #       SELECT
        #         vyge_strm_typ_sfb_baseln.app_vyge_id
        #         , vyge_strm_typ_sfb_baseln.vyge_id
        #        , vyge_strm_typ_sfb_baseln.strm_typ_cd AS strm_typ_cd
        #        , vyge_strm_typ_sfb_baseln.sfb_nm AS sfb_nm
        #        , vyge_strm_typ_sfb_baseln.txn_dt AS txn_dt
        #        , cast(coalesce((sl_lim_rcmd.rcmd_sl_lim_strm_typ_cn),sl_lim_rcmd_by_max_cnt.rcmd_sl_lim_strm_typ_cn,0) as int) AS rcmd_sl_lim_strm_typ_cn
        #
        #     FROM   driver as vyge_strm_typ_sfb_baseln
        #     LEFT OUTER JOIN sl_lim_rcmd as sl_lim_rcmd
        #     ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_rcmd.app_vyge_id
        #     AND vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_rcmd.src_sys_strm_typ_nm
        #     AND sl_lim_rcmd.sl_lim_rcmd_run_dts = vyge_strm_typ_sfb_baseln.sl_lim_rcmd_run_dts_max
        #     And date( vyge_strm_typ_sfb_baseln.batch_run_dts ) >= vyge_strm_typ_sfb_baseln.txn_dt
        #     AND
        #     (
        #         vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn >= sl_lim_rcmd.dy_bef_vyge_rnge_strt_cn
        #         AND vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn <= sl_lim_rcmd.dy_bef_vyge_rnge_end_cn
        #
        #     )
        #     LEFT OUTER JOIN  sl_lim_rcmd as sl_lim_rcmd_by_max_cnt
        #     ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_rcmd_by_max_cnt.app_vyge_id
        #     AND vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_rcmd_by_max_cnt.src_sys_strm_typ_nm
        #     AND sl_lim_rcmd_by_max_cnt.sl_lim_rcmd_run_dts = vyge_strm_typ_sfb_baseln.sl_lim_rcmd_run_dts_max
        #     And date( vyge_strm_typ_sfb_baseln.batch_run_dts ) >= vyge_strm_typ_sfb_baseln.txn_dt
        #     AND
        #      (
        #              sl_lim_rcmd_by_max_cnt.dy_bef_vyge_rnge_strt_cn = vyge_strm_typ_sfb_baseln.sl_rcmd_dy_bef_vyge_rnge_strt_cn_max
        #     )
        #
        #
        #     INNER JOIN strm_typ_nest_config as strm_typ_nest_config
        #     ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd
        #     AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm
        #     AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)
        #
        #   """).dropDuplicates()
        # # sl_lim_rcmd_strm_typ_cn_df = spark.sql("""
        #           SELECT
        #             vyge_strm_typ_sfb_baseln.app_vyge_id
        #             , vyge_strm_typ_sfb_baseln.vyge_id
        #            , vyge_strm_typ_sfb_baseln.strm_typ_cd AS strm_typ_cd
        #            , vyge_strm_typ_sfb_baseln.sfb_nm AS sfb_nm
        #            , vyge_strm_typ_sfb_baseln.txn_dt AS txn_dt
        #            , cast(coalesce((sl_lim_rcmd.rcmd_sl_lim_strm_typ_cn),0) as int) AS rcmd_sl_lim_strm_typ_cn
        #
        #         FROM   driver as vyge_strm_typ_sfb_baseln
        #         LEFT OUTER JOIN sl_lim_rcmd as sl_lim_rcmd
        #         ON vyge_strm_typ_sfb_baseln.app_vyge_id = sl_lim_rcmd.app_vyge_id
        #         AND vyge_strm_typ_sfb_baseln.strm_typ_cd = sl_lim_rcmd.src_sys_strm_typ_nm
        #         AND sl_lim_rcmd.sl_lim_rcmd_run_dts = vyge_strm_typ_sfb_baseln.sl_lim_rcmd_run_dts_max
        #         And date( vyge_strm_typ_sfb_baseln.batch_run_dts ) >= vyge_strm_typ_sfb_baseln.txn_dt
        #         AND
        #         (
        #             vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn >= sl_lim_rcmd.dy_bef_vyge_rnge_strt_cn
        #             AND vyge_strm_typ_sfb_baseln.dy_bef_vyge_cn <= sl_lim_rcmd.dy_bef_vyge_rnge_end_cn
        #
        #         )
        #
        #
        #         INNER JOIN strm_typ_nest_config as strm_typ_nest_config
        #         ON vyge_strm_typ_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd
        #         AND vyge_strm_typ_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm
        #         AND date(vyge_strm_typ_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)
        #       """).dropDuplicates()

        # sl_lim_rcmd_strm_typ_cn_df.select("rcmd_sl_lim_strm_typ_cn").distinct().show(100)
        sl_lim_rcmd_strm_typ_cn_df.createOrReplaceTempView("sl_lim_rcmd_strm_typ_cn_df")

        # folder_name = "%s%s" % ("VYGE_STRM_TYP_SFB_BASELN_DRIVER_SL_LIM_RCMD/partition_dt=", start_dt)
        # data_loader.write_data("dm", folder_name, None, sl_lim_rcmd_strm_typ_cn_df)

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_strm_typ_cn_df, "sl_lim_rcmd_strm_typ_cn_df count info")


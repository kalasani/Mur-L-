import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
# from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob import *;
from VygeStrmSfbBaseln import *;
from TeradataIntradayDownload import *;


class DclrmsPdpIntraDayJob(BaseJob):

    def __init__(self):
        self.table = "pdp_dclrms_intraday"
        self.environment = None
        self.user = None
        self.password = None
        self.url = None
        super(DclrmsPdpIntraDayJob, self).__init__(self.table)

    def setUp(self):
        properties = self.env
        self.table = "pdp_dclrms_intraday"
        self.intradayConfig = self.config.readData(self.table);
        print("self.intradayConfig ====>", self.intradayConfig)
        intradayConfig = self.intradayConfig
        self.url = properties.teradata_jdbc_url
        self.environment = properties.teradata_environment
        self.orig_environment = self.environment
        self.user = properties.teradata_uid
        self.password = properties.teradata_pwd
        self.databaseName = properties.env_name + "_dcl_rms_app_vmdb"
        print("DatabaseName ===>", self.databaseName);
        self.sql = "( SELECT max(btch_end_dts) as btch_end_dts from " + self.databaseName + ".btch  WHERE btch_sts_nm='SUCCESSFUL' AND btch_end_dts >'" +\
                   self.intradayConfig.high_water_mark_dts + "') as one";
        print("Spark SQL QUery ===>",self.sql)
    def loadData(self):
        pass;

    def preProcess(self):
        pass

    def createDriver(self):
        pass

    def readDataTeradata(self):
        print("Before readDataTeradata Method ===================>>>")
        df = self.spark.read.format("jdbc") \
            .option("url", self.url) \
            .option("driver", "com.teradata.jdbc.TeraDriver") \
            .option("user", self.user) \
            .option("dbtable", self.sql) \
            .option("password", self.password) \
            .load();
        df.createOrReplaceTempView("Driver")
        df.printSchema()
        df.show()

        df2 = self.spark.sql(
            "select from_unixtime(unix_timestamp(btch_end_dts,'yyyy-MM-dd hh:mm:ss')) as  dts from Driver")
        df2.printSchema()
        df2.show(10)
        dtsValue = df2.collect()[0][0]
        maxDTS = str(dtsValue);
        return maxDTS;
    def readDataTeradataForFullLoadOrIncrementLoad(self):
        print("Before readDataTeradata Method ===================>>>")
        df = self.spark.read.format("jdbc") \
            .option("url", self.url) \
            .option("driver", "com.teradata.jdbc.TeraDriver") \
            .option("user", self.user) \
            .option("dbtable", self.sqlForFullLoadOrIncrementLoad) \
            .option("password", self.password) \
            .load();
        df.createOrReplaceTempView("Driver")
        df.printSchema()
        df.show()

        df2 = self.spark.sql(
            "select from_unixtime(unix_timestamp(btch_end_dts,'yyyy-MM-dd hh:mm:ss')) as  dts from Driver")
        df2.printSchema()
        df2.show(10)
        dtsValue = df2.collect()[0][0]
        maxDTS = str(dtsValue);
        return maxDTS;

    def getMaxBatchEndDTS(self):
        maxbatchEndDTS = self.readDataTeradata();
        return maxbatchEndDTS;

    def process(self):
        print("Process started here ")
        print("self.user==>", self.user)
        print("self.password==>", self.password)
        print("self.url==>", self.url)
        maxBatchEndDTS = self.getMaxBatchEndDTS();
        print("maxBatchEndDTS====>>",maxBatchEndDTS)
        if maxBatchEndDTS is None:
            print("No New Data ")
            return;

        tablesNames = ["PRICE_CONFIG", "SL_LIM_CONFIG", "PRICE_RCMD_DTL",
                       "SL_LIM_RCMD", "EXPECT_OH_BKNG", "UNCNSTRN_BKNG",
                       "UNCNSTRN_DMND_FCST"]

        runDTS = [self.intradayConfig.price_config_high_water_mark_dts,
                  self.intradayConfig.sl_lim_config_high_water_mark_dts,
                  self.intradayConfig.price_rcmd_dtl_high_water_mark_dts,
                  self.intradayConfig.sl_lim_rcmd_high_water_mark_dts,
                  self.intradayConfig.expect_oh_bkng_high_water_mark_dts,
                  self.intradayConfig.uncnstrn_bkng_high_water_mark_dts,
                  self.intradayConfig.uncnstrn_dmnd_fcs_high_water_mark_dts]

        # for tableName, runDTSValue in zip(tablesNames, runDTS):
        #     print("Intradaty Download Job is running here")
        #     downloadRes = self.downloadIncrementalData(runDTSValue, tableName)
        #     if downloadRes is not None and downloadRes == "-1":
        #         print("Exit from Download Job due to failed")
        #         return ;
        #
        # voyageRes = self.voyageIntradayProcess();
        # if voyageRes is not None and voyageRes == "-1":
        #     print("Exit from voyageIntradayProcess due to Job Failed")
        #     return;

        self.updateHighWaterMark(maxBatchEndDTS);

    def tearDown(self):
        pass

    def writeToHDFS(self):
        pass;

    def downloadIncrementalData(self, timeStr, tableName):
        print("table Name is ===>",tableName)
        print("runDTS  value ===>",timeStr)
        appName = "download_%s" % tableName.lower()
        print("download table name key for match check in Hbase(appname)===>",appName)
        downloader = TeradataIntradayDownload(appName, tableName, timeStr)
        downloader.execute()
        return 0;

    def voyageIntradayProcess(self):
        print("hig_water_mark_dts ===>>", self.intradayConfig.high_water_mark_dts)
        vygesfbReference = VygeStrmSfbBaseln("Intraday",self.intradayConfig.high_water_mark_dts);
        vygesfbReference.execute();

        vygesfbReference = VoyagePriceBOHDMJob("Intraday", self.intradayConfig.high_water_mark_dts);
        vygesfbReference.execute();

        return 0;


    def updateHighWaterMark(self, maxRunDTS):
        print("updateHighWaterMark ===>",maxRunDTS)
        data = {"env.name": self.env.env_name,
                "job.name": "pdp_dclrms_intraday",
                "pdp.intraday.high.water.mark.dts": maxRunDTS,
                "price_config.high.water.mark.dts": maxRunDTS,
                "sl_lim_config.high.water.mark.dts": maxRunDTS,
                "sl_lim_rcmd.high.water.mark.dts": maxRunDTS,
                "price_rcmd_dtl.high.water.mark.dts": maxRunDTS,
                "expect_oh_bkng.high.water.mark.dts": maxRunDTS,
                "uncnstrn_bkng.high.water.mark.dts": maxRunDTS,
                "uncnstrn_dmnd_fcs.high.water.mark.dts": maxRunDTS,

                "job.debug": self.intradayConfig.debug,
                "etl.load.type": self.intradayConfig.load_type,
                "etl.run.bus.prd.start.timestamp":  self.intradayConfig.start_date,
                "etl.run.bus.prd.end.timestamp":  self.intradayConfig.end_date,
                "etl.run.max_dataload_dt": self.intradayConfig.max_dataload_dt,
                "teradata.publish.flag":self.intradayConfig.td_publish_flag,
                "etl.load.delta.period": self.intradayConfig.load_delta_period,
                "etl.load.loop.counter": self.intradayConfig.load_loop_counter,
                "etl.load.post.arrival.day.count": self.intradayConfig.load_post_arrival_day_count

                }
        self.jobName = "pdp_dclrms_intraday"
        self.intradayConfig = self.config.writeData(self.jobName, data);


if __name__ == '__main__':

    try:
        print("IntraDayJob BOH JOB start Here  ")
        obj = DclrmsPdpIntraDayJob()
        obj.execute()
        print("IntraDayJob BOH JOB end Here  ")
    except:
        traceback.print_exc()
        sys.exit(-1)
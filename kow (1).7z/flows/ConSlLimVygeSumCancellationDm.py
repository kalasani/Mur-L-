##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : run_data_loader BOH -DataLoading & Driver Prepration              #
# Author            : Nikhila Teki                                                          #
# Date created      : 20180619                                                           #
# Purpose           : To fetch gross per dimension metrices for all VF* inventory levels #
# Revision History  :                                                                    #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                     #
# 20180618     Anjaiah Y   Chris                                                          #
#                                                                                        #
##########################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
#from flows.jobs.con_resbaseln_cancellation_dm import *
#from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from pyspark.sql.types import *
from framework.utils.DebugCount import *;
from time import time
import os, sys

class ConSlLimVygeSumCancellationDm(object):


    @staticmethod
    def run_con_sl_lim_vyge_sum(start_dt, sql_context, s3_bucket, data_loader,debug):
        """
        Attributes:
         start_dt : The start date for which selling limit counts need to be computed
         end_dt :
         sql_context:  spark sql_context
         s3_bucket: s3 bucket where the data resides
         debug
        """
        """
        COMPUTING THE SELLING LIMITS COUNTS AT MULTIPLE LEVELS BY FINDING OUT THE VALID PROMO CODES
        WHICH ARE AVAILABLE FOR SELLING ON VYGE_ID AND SFB_NM 
        """
        sl_sfb_df = sql_context.sql("""
                                select crus_promo_cd , sfb_nm,
                                sfb_config_strt_dts as vrsn_strt_dts,
                                coalesce(max(sfb_config_strt_dts)
                                over(partition by crus_promo_cd order by sfb_config_strt_dts ROWS BETWEEN 1 FOLLOWING AND 1 FOLLOWING)
                                ,cast('9999-12-31 00:00:00' as timestamp))as vrsn_end_dts
                                from sfb
                                """).distinct()

        sl_sfb_df.createOrReplaceTempView("sl_sfb")
        if debug == 1:
            DebugCount.count_check(sl_sfb_df, " sl_sfb_df")

        valid_promos_df = sql_context.sql("""
                                    select 
                                     sub.vyge_id 
                                    ,sl.cbn_ctgy_cd as strm_typ_cd 
                                    ,sub.crus_promo_cd 
                                    ,sub.sfb_nm 
                                    ,sub.txn_dt 
                                from 
                                ( 
                                    select 
                                        elig_sfb.vyge_id 
                                        ,elig_sfb.sfb_nm 
                                        ,elig_sfb.txn_dt 
                                        ,sfb.crus_promo_cd 
                                    from 
                                    ( 
                                    select 
                                        drvr.vyge_id 
                                        ,drvr.sfb_nm 
                                        ,drvr.txn_dt 
                                    from vyge_sfb_bkng_dly drvr 
                                    inner join sl_sfb sfb 
                                        on drvr.sfb_nm = sfb.sfb_nm 
                                        and drvr.txn_dt >= to_date(sfb.vrsn_strt_dts) 
                                        and drvr.txn_dt < to_date(sfb.vrsn_end_dts) 
                                    left join ( 
                                            select 
                                                sail_id, 
                                                promo_cd, 
                                                vrsn_strt_dts, 
                                                vrsn_end_dts, 
                                                dflt_val, 
                                                instnc_st_nm 
                                            from promo_elig 
                                            group by sail_id, 
                                                promo_cd, 
                                                vrsn_strt_dts, 
                                                vrsn_end_dts, 
                                                dflt_val, 
                                                instnc_st_nm 
                                          )elig 
                                        on drvr.vyge_id = elig.sail_id
                                        and sfb.crus_promo_cd = elig.promo_cd    
                                        and drvr.txn_dt >= to_date(elig.vrsn_strt_dts)
                                        and drvr.txn_dt < to_date(elig.vrsn_end_dts)

                                    where (elig.dflt_val = 'ON' or elig.sail_id is null)
                                    group by drvr.vyge_id 
                                        ,drvr.sfb_nm 
                                        ,drvr.txn_dt 
                                ) elig_sfb
                                inner join sl_sfb sfb    
                                    on elig_sfb.sfb_nm = sfb.sfb_nm
                                    and elig_sfb.txn_dt >= to_date(sfb.vrsn_strt_dts)
                                    and elig_sfb.txn_dt < to_date(sfb.vrsn_end_dts)
                                )sub
                                inner join sl_lim_vyge_sum sl 
                                    on sl.sail_id = sub.vyge_id
                                    and sl.promo_cd like concat('%',sub.crus_promo_cd,'%')
                                    and sub.txn_dt >= to_date(sl.vrsn_strt_dts)
                                    and sub.txn_dt < to_date(sl.vrsn_end_dts)
                                    and coalesce(sl.cbn_ctgy_cd,'') not in ('IRG','XAM') 
                                group by sub.vyge_id 
                                        ,sl.cbn_ctgy_cd
                                        ,sub.crus_promo_cd 
                                        ,sub.sfb_nm 
                                        ,sub.txn_dt 
                            """).distinct()

        valid_promos_df.createOrReplaceTempView("valid_promos")
        if debug == 1:
            DebugCount.count_check(valid_promos_df, " valid_promos_df")

        # LIMIT AT VYGE,PROMO CODE LEVEL

        vyge_promo_lvl_df = sql_context.sql("""
                                        select
                                        vyge_id,
                                        sfb_nm,
                                        txn_dt,
                                        sum(absolute_lim_nb_max) as absolute_lim_nb
                                        from
                                        (
                                        select 
                                              distinct
                                              sl.sail_id as vyge_id
                                              ,sl.promo_cd
                                              ,valid_promos.sfb_nm
                                              ,drvr.txn_dt    
                                              ,max(sl.absolute_lim_nb) as absolute_lim_nb_max
                                        from vyge_sfb_bkng_dly drvr
                                        inner join sl_lim_vyge_sum sl
                                                 on drvr.vyge_id=sl.sail_id
                                                 and drvr.txn_dt >= to_date(sl.vrsn_strt_dts)
                                                 and drvr.txn_dt < to_date(sl.vrsn_end_dts)
                                        inner join valid_promos valid_promos 
                                                 on sl.sail_id = valid_promos.vyge_id
                                                 and sl.promo_cd like concat('%',valid_promos.crus_promo_cd, '%') 
                                                 and drvr.txn_dt = valid_promos.txn_dt
                                        where sl.cbn_ctgy_cd is null
                                                 and sl.promo_cd is not null
                                        group by sl.sail_id
                                                      ,sl.promo_cd
                                                      ,valid_promos.sfb_nm
                                                      ,drvr.txn_dt
                                        )promo_lvl_max
                                        group by vyge_id,
                                                sfb_nm,
                                                txn_dt
                                """)
        vyge_promo_lvl_df.createOrReplaceTempView("vyge_promo_lvl")
        if debug == 1:
            DebugCount.count_check(vyge_promo_lvl_df, " vyge_promo_lvl_df")

        # LIMIT AT VYGE,CABIN CATEGORY,PROMO CODE LEVEL

        vyge_ctgy_promo_lvl_df = sql_context.sql("""
                                        select 
                                            vyge_id,
                                            strm_typ_cd,
                                            sfb_nm,
                                            txn_dt,
                                            sum(absolute_lim_nb_max) as absolute_lim_nb
                                        from
                                            (
                                            select 
                                                  distinct
                                                  sl.sail_id as vyge_id
                                                  ,sl.cbn_ctgy_cd as strm_typ_cd
                                                  ,sl.promo_cd
                                                  ,valid_promos.sfb_nm
                                                  ,drvr.txn_dt    
                                                  ,max(sl.absolute_lim_nb) as absolute_lim_nb_max
                                            from vyge_sfb_bkng_dly drvr 
                                            inner join sl_lim_vyge_sum sl
                                                     on drvr.vyge_id = sl.sail_id
                                                     and drvr.txn_dt >= to_date(sl.vrsn_strt_dts)
                                                     and drvr.txn_dt < to_date(sl.vrsn_end_dts)
                                            inner join valid_promos valid_promos 
                                                     on sl.sail_id = valid_promos.vyge_id
                                                     and sl.cbn_ctgy_cd = valid_promos.strm_typ_cd
                                                     and sl.promo_cd like concat('%',valid_promos.crus_promo_cd, '%' )
                                                     and drvr.txn_dt = valid_promos.txn_dt
                                            where sl.cbn_ctgy_cd is not null
                                                     and sl.promo_cd is not null
                                            group by sl.sail_id
                                                          ,sl.cbn_ctgy_cd
                                                          ,sl.promo_cd
                                                          ,valid_promos.sfb_nm
                                                          ,drvr.txn_dt    
                                            )strm_with_promo_lvl
                                            group by vyge_id,
                                            strm_typ_cd,
                                            sfb_nm,
                                            txn_dt
                                    """)
        vyge_ctgy_promo_lvl_df.createOrReplaceTempView("vyge_ctgy_promo_lvl")
        if debug == 1:
            DebugCount.count_check(vyge_ctgy_promo_lvl_df, " vyge_ctgy_promo_lvl_df")

        # LIMIT AT VYGE,CABIN CATEGORY LEVEL

        vyge_ctgy_lvl_df = sql_context.sql("""
                                            select 
                                                  distinct
                                                  sl.sail_id as vyge_id
                                                  ,sl.cbn_ctgy_cd as strm_typ_cd
                                                  ,valid_promos.sfb_nm
                                                  ,drvr.txn_dt    
                                                  ,max(sl.absolute_lim_nb) as absolute_lim_nb
                                            from vyge_sfb_bkng_dly drvr 
                                            inner join sl_lim_vyge_sum sl
                                                     on drvr.vyge_id = sl.sail_id
                                                     and drvr.txn_dt >= to_date(sl.vrsn_strt_dts)
                                                     and drvr.txn_dt < to_date(sl.vrsn_end_dts)
                                            inner join valid_promos valid_promos 
                                                     on sl.sail_id = valid_promos.vyge_id
                                                     and sl.cbn_ctgy_cd = valid_promos.strm_typ_cd
                                                     and drvr.txn_dt = valid_promos.txn_dt
                                            where sl.cbn_ctgy_cd is not null
                                                     and sl.promo_cd is null
                                            group by sl.sail_id
                                                          ,sl.cbn_ctgy_cd
                                                          ,valid_promos.sfb_nm
                                                          ,drvr.txn_dt    
                                            """)

        vyge_ctgy_lvl_df.createOrReplaceTempView("vyge_ctgy_lvl")
        if debug == 1:
            DebugCount.count_check(vyge_ctgy_lvl_df, " vyge_ctgy_lvl_df")

        # LIMIT AT VYGE, SFB, CABIN CATEGORY LEVEL

        vyge_sfb_ctgy_lvl_df = sql_context.sql("""
                                select 
                                    sfb.vyge_id,
                                    sfb.sfb_nm,
                                    sfb.txn_dt,
                                    sum(
                                    case when coalesce(vyge_ctgy_promo_lvl.absolute_lim_nb,vyge_ctgy_lvl.absolute_lim_nb,0) 
                                    <= coalesce(vyge_ctgy_lvl.absolute_lim_nb,vyge_ctgy_promo_lvl.absolute_lim_nb,0)
                                    then coalesce(vyge_ctgy_promo_lvl.absolute_lim_nb,vyge_ctgy_lvl.absolute_lim_nb)
                                    else coalesce(vyge_ctgy_lvl.absolute_lim_nb,vyge_ctgy_promo_lvl.absolute_lim_nb)
                                    end
                                        ) as absolute_lim_nb
                                from 
                                    (
                                    select
                                        vyge_id,
                                        strm_typ_cd,
                                        sfb_nm,
                                        txn_dt
                                    from valid_promos 
                                    group by vyge_id,
                                                strm_typ_cd,
                                                sfb_nm,
                                                txn_dt
                                    )sfb
                                left outer join vyge_ctgy_promo_lvl  vyge_ctgy_promo_lvl
                                    on sfb.vyge_id = vyge_ctgy_promo_lvl.vyge_id
                                    and coalesce(sfb.strm_typ_cd,-1) = coalesce(vyge_ctgy_promo_lvl.strm_typ_cd,-1)
                                    and sfb.sfb_nm = vyge_ctgy_promo_lvl.sfb_nm
                                    and sfb.txn_dt = vyge_ctgy_promo_lvl.txn_dt
                                left outer join vyge_ctgy_lvl vyge_ctgy_lvl
                                    on sfb.vyge_id = vyge_ctgy_lvl.vyge_id
                                    and coalesce(sfb.strm_typ_cd,-1) = coalesce(vyge_ctgy_lvl.strm_typ_cd,-1)
                                    and sfb.sfb_nm = vyge_ctgy_lvl.sfb_nm
                                    and sfb.txn_dt = vyge_ctgy_lvl.txn_dt
                                group by sfb.vyge_id,
                                            sfb.sfb_nm,
                                            sfb.txn_dt
                                        """)
        vyge_sfb_ctgy_lvl_df.createOrReplaceTempView("vyge_sfb_ctgy_lvl")
        if debug == 1:
            DebugCount.count_check(vyge_sfb_ctgy_lvl_df, " vyge_sfb_ctgy_lvl_df")

        # FINAL LIMIT AT VYGE,SFB LEVEL

        sl_lim_sfb_bkng_cn_df = sql_context.sql("""
                                        select
                                            distinct
                                            drvr.vyge_id,
                                            drvr.sfb_nm,
                                            drvr.txn_dt,
                                            case when coalesce(vyge_promo_lvl.absolute_lim_nb,vyge_sfb_ctgy_lvl.absolute_lim_nb,0) 
                                            <= coalesce(vyge_sfb_ctgy_lvl.absolute_lim_nb,vyge_promo_lvl.absolute_lim_nb,0)
                                                then coalesce(vyge_promo_lvl.absolute_lim_nb,vyge_sfb_ctgy_lvl.absolute_lim_nb)
                                                else coalesce(vyge_sfb_ctgy_lvl.absolute_lim_nb,vyge_promo_lvl.absolute_lim_nb)
                                            end as sl_lim_sfb_bkng_cn
                                        from vyge_sfb_bkng_dly drvr
                                        left outer join vyge_promo_lvl vyge_promo_lvl
                                            on drvr.vyge_id = vyge_promo_lvl.vyge_id
                                            and drvr.sfb_nm = vyge_promo_lvl.sfb_nm
                                            and drvr.txn_dt =  vyge_promo_lvl.txn_dt
                                        left outer join vyge_sfb_ctgy_lvl vyge_sfb_ctgy_lvl
                                            on drvr.vyge_id = vyge_sfb_ctgy_lvl.vyge_id
                                            and drvr.sfb_nm = vyge_sfb_ctgy_lvl.sfb_nm
                                            and drvr.txn_dt = vyge_sfb_ctgy_lvl.txn_dt
                                      """)
        sl_lim_sfb_bkng_cn_df.createOrReplaceTempView("sl_lim_sfb_bkng")
        if debug == 1:
            DebugCount.count_check(sl_lim_sfb_bkng_cn_df, "sl_lim_sfb_bkng_cn_df")
        # sl_lim_sfb_bkng_cn_df.unpersist()
        # print "selling limit here"
        # sl_lim_sfb_bkng_cn_df.write.mode("overwrite").format("orc").save("/wdpr-apps-data/dclrms/stg/dm/sl_lim_cancellation")
        # print "writing selling limit"

        # sl_df=sql_context.sql("""select vyge_id,sfb_nm,txn_dt,sl_lim_sfb_bkng_cn
        #		from sl_lim_sfb_bkng where sl_lim_sfb_bkng_cn is not null""")
        # sl_df.show()
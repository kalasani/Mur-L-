import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.core.BaseJob_old import *;

INIT_DT = '1800-01-01'
FOLDER = "con"
DATA_REF = "vyge_sfb_res_baseln_cncl"
PARTITION_COL = "run_dt"


def summarize_weekly_reservations(rows, txn_dt_start, txn_dt_end):
    res_summary_list = []
    # a map for metrics
    # a map between vyge_id and metrics
    # blocks of weeks
    accum_map = {}
    cumul_flag = 0
    last_res_id = -1
    for row in rows:
        cumul_flag = 0
        txn_dt = txn_dt_start
        while (txn_dt <= txn_dt_end):
            key = "%s,%s,%s" % (row.vyge_id, row.sfb_nm, txn_dt)
            if key not in accum_map:
                accum_map[key] = {}
                accum_map[key]["vyge_id"] = row.vyge_id
                accum_map[key]["sfb_nm"] = row.sfb_nm
                accum_map[key]["txn_dt"] = txn_dt
                accum_map[key]["pu_bkng_cn"] = 0
                accum_map[key]["oh_paid_bkng_cn"] = 0
                accum_map[key]["cncl_bkng_cn"] = 0
                # accum_map[key]["curr_wk_oh_sfb_bkng_cn"] = 0
                accum_map[key]["res_ids"] = {}

            if cumul_flag == 1:
                # and (row.prev_res_sts_cd == None or row.prev_res_sts_cd in ('CX','CT') or row.vyge_id != row.prev_vyge_id or row.sfb_nm != row.prev_sfb_nm):
                accum_map[key]["res_ids"][row.res_id] = 1
            if cumul_flag == 2:
                accum_map[key]["res_ids"][row.res_id] = 1
                tkey = "%s,%s,%s" % (row.prev_vyge_id, row.prev_sfb_nm, txn_dt)
                if tkey in accum_map and row.res_id in accum_map[tkey]["res_ids"]:
                    accum_map[tkey]["res_ids"].pop(row.res_id)

            if cumul_flag == -1:
                if row.res_id in accum_map[key]["res_ids"]:
                    accum_map[key]["res_ids"].pop(row.res_id)
                if row.prev_vyge_id != None and row.prev_sfb_nm != None and (
                        row.vyge_id != row.prev_vyge_id or row.sfb_nm != row.prev_sfb_nm):
                    tkey = "%s,%s,%s" % (row.prev_vyge_id, row.prev_sfb_nm, txn_dt)
                    if tkey in accum_map and row.res_id in accum_map[tkey]["res_ids"]:
                        accum_map[tkey]["res_ids"].pop(row.res_id)

            # if txn_dt == row.vrsn_strt_dts and row.res_sts_cd in ('CX','CT'):
            #   # this is a cancellation
            #   # is this a cancellation on an exising pickup
            #   # also the reservation could have had a chnage in sfb name or voyage id
            #   if row.res_id in accum_map[key]["res_ids"]:
            #      accum_map[key]["res_ids"].pop(row.res_id)
            #      cumul_flag=-1
            #   elif row.prev_vyge_id != None and row.prev_sfb_nm!= None and (row.vyge_id != row.prev_vyge_id or row.sfb_nm!=row.prev_sfb_nm):
            #      tkey="%s,%s,%s" %(row.prev_vyge_id,row.prev_sfb_nm,txn_dt)
            #      if tkey in accum_map and row.res_id in accum_map[tkey]["res_ids"]:
            #         accum_map[tkey]["res_ids"].pop(row.res_id)
            #         cumul_flag=-1

            if row.res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
                comp_dt = row.vrsn_strt_dts
                if str(comp_dt) == '1800-01-01':
                    comp_dt = row.res_init_bkng_dt
                if txn_dt >= comp_dt and txn_dt < row.vrsn_end_dts:
                    # most current record as it matches the current date
                    # indicates active
                    if row.sfb_nm != 'OFFICER' and row.price_strm_typ_cd != 'IRG' and row.price_strm_typ_cd != 'XAM':
                        accum_map[key]["oh_paid_bkng_cn"] = accum_map[key]["oh_paid_bkng_cn"] + 1
                    # indicates a reservation was active in this period  add it so other days in the week can add this reservation
                # if txn_dt == row.vrsn_strt_dts:
                if (txn_dt == row.vrsn_strt_dts or (
                        str(row.vrsn_strt_dts) == '1800-01-01' and row.res_init_bkng_dt == txn_dt)) and (
                        row.prev_res_sts_cd == None or row.prev_res_sts_cd in (
                'CX', 'CT', 'WL') or row.vyge_id != row.prev_vyge_id or row.sfb_nm != row.prev_sfb_nm or (
                                row.price_strm_typ_cd in ('XAM', 'IRG') or (row.prev_strm_typ_cd in (
                        'XAM', 'IRG') and row.price_strm_typ_cd != 'XAM' and row.price_strm_typ_cd != 'IRG'))):
                    if row.sfb_nm != 'OFFICER' and row.price_strm_typ_cd != 'IRG' and row.price_strm_typ_cd != 'XAM':
                        cumul_flag = 1
                        accum_map[key]["res_ids"][row.res_id] = 1
                        accum_map[key]["pu_bkng_cn"] = accum_map[key]["pu_bkng_cn"] + 1
                    # check for fake cancels on the business date
                    if row.prev_res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
                        # if  (row.vyge_id != row.prev_vyge_id or row.sfb_nm!=row.prev_sfb_nm) and row.prev_res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
                        # there is a chnage in vyge id or sfb_nm ..in the same reservation so the prev combo is a fake cancelation
                        if row.prev_sfb_nm != 'OFFICER' and row.prev_strm_typ_cd != 'IRG' and row.prev_strm_typ_cd != 'XAM':
                            temp_key = "%s,%s,%s" % (row.prev_vyge_id, row.prev_sfb_nm, txn_dt)
                            if temp_key not in accum_map:
                                accum_map[temp_key] = {}
                                accum_map[temp_key]["vyge_id"] = row.prev_vyge_id
                                accum_map[temp_key]["sfb_nm"] = row.prev_sfb_nm
                                accum_map[temp_key]["txn_dt"] = txn_dt
                                accum_map[temp_key]["pu_bkng_cn"] = 0
                                accum_map[temp_key]["oh_paid_bkng_cn"] = 0
                                accum_map[temp_key]["cncl_bkng_cn"] = 0
                                accum_map[temp_key]["res_ids"] = {}
                            accum_map[temp_key]["cncl_bkng_cn"] = accum_map[temp_key]["cncl_bkng_cn"] + 1
                            # this needs to show up as a cumul_flag of 2 with increase in pk and decreases in previous
                            accum_map[key]["res_ids"][row.res_id] = 1
                            if row.res_id in accum_map[temp_key]["res_ids"]:
                                accum_map[temp_key]["res_ids"].pop(row.res_id)
                                cumul_flag = 2

            if row.res_sts_cd in ('CX', 'CT', 'WL'):
                if txn_dt == row.vrsn_strt_dts and row.prev_res_sts_cd != 'WL' and row.prev_res_sts_cd in (
                'OF', 'BK', 'CL', 'TM'):
                    # regular cancellation
                    # cx from bk on a different product would mean same day fake cancellation which should be disregarded
                    if row.prev_vyge_id == row.vyge_id and row.sfb_nm == row.prev_sfb_nm:
                        if row.sfb_nm != 'OFFICER' and row.price_strm_typ_cd != 'IRG' and row.price_strm_typ_cd != 'XAM':
                            accum_map[key]["cncl_bkng_cn"] = accum_map[key]["cncl_bkng_cn"] + 1
                            if row.res_id in accum_map[key]["res_ids"]:
                                accum_map[key]["res_ids"].pop(row.res_id)
                                cumul_flag = -1
                    else:
                        # same day cancellation - so we need to apply a cancellation on the previous pk
                        if row.prev_sfb_nm != 'OFFICER' and row.prev_strm_typ_cd != 'IRG' and row.prev_strm_typ_cd != 'XAM':
                            temp_key = "%s,%s,%s" % (row.prev_vyge_id, row.prev_sfb_nm, txn_dt)
                            if temp_key not in accum_map:
                                accum_map[temp_key] = {}
                                accum_map[temp_key]["vyge_id"] = row.prev_vyge_id
                                accum_map[temp_key]["sfb_nm"] = row.prev_sfb_nm
                                accum_map[temp_key]["txn_dt"] = txn_dt
                                accum_map[temp_key]["pu_bkng_cn"] = 0
                                accum_map[temp_key]["oh_paid_bkng_cn"] = 0
                                accum_map[temp_key]["res_ids"] = {}
                            accum_map[temp_key]["cncl_bkng_cn"] = accum_map[temp_key]["cncl_bkng_cn"] + 1
                            if row.res_id in accum_map[temp_key]["res_ids"]:
                                accum_map[temp_key]["res_ids"].pop(row.res_id)
                                cumul_flag = -1

            txn_dt = txn_dt + timedelta(days=1)
        last_res_id = row.res_id
    for key, value in accum_map.iteritems():
        # key is vyge_id
        # value is metric
        total_cumulative_oh_sfb_bkng_cn = len(value["res_ids"])
        res_summary_list.append(Row(value["vyge_id"], value["sfb_nm"], value["txn_dt"], \
                                    value["cncl_bkng_cn"], value["oh_paid_bkng_cn"], \
                                    total_cumulative_oh_sfb_bkng_cn, value["pu_bkng_cn"]))
    return iter(res_summary_list)


class ConVygeSfbDly(BaseJob):
    def __init__(self):
        self.name = "ConVygeSfbDly"
        super(ConVygeSfbDly, self).__init__(self.name)

    def setUp(self):
        properties = self.config.getEnvConfig()
        print(properties)
        self.s3_root_bucket = properties.hdfs_root_directory
        self.data_loader = S3DataLoader(self.spark, self.s3_root_bucket)
        t_properties = self.config.getJobConfig(self.name.lower(), False)
        self.start_date = datetime.strptime(t_properties.start_date, "%Y-%m-%d").date()
        self.end_date = datetime.strptime(t_properties.end_date, "%Y-%m-%d").date()
        self.refresh = int(t_properties.data_download_refresh)
        self.runType = t_properties.load_type;
        self.debug = t_properties.debug

    def loadData(self):
        pass

    def createDriver(self):
        pass

    def preProcess(self):
        pass

    def process(self):
        self.run_con_res_baseln_weekly(self.start_date, self.end_date, self.spark, self.data_loader)

    def writeToHDFS(self):
        pass

    def tearDown(self):
        pass

    def run_con_res_baseln_weekly(self, txn_dt_start, txn_dt_end, sql_context, data_loader):
        """ reads resbaseln and processes it on a sunday-saturday basis persists it on a weekly basis and puts a date in yyyy-mm-dd format for that saturday
        Attributes:
          txn_dt_start : The date for which bookings need to be summarized
          txn_dt_end: the date until which we need to summarize bookings
          data_loader : utility class to load data
          converter: a converter to convert data from rdd to dataframe givein a schema
          sql_context:  spark sql_context
        """
        converter = DataFrameUtil(sql_context)
        # read the dt data set and identify the start and end date boundaries - sundaty to saturday
        # if the input txn_dt_start falls on a monday we will roll it back one day to make it sunday and add 6 days and keep going until we hit the end_dt. End date is fixed
        # python weekday function gives 0 for Monday and 6 for Sunday
        if (data_loader.check_parition_if_date_exists(FOLDER, DATA_REF, "txn_dt", str(txn_dt_start))):
            # data exists already print a message and exit
            print
            " Data for the period starting from %s already exists, consider running a full data load or adjust your dates " % txn_dt_start
            sys.exit(-1)

        # if a weekday is 6 for txn_dt_start we keep it as is, else we add 1 to it and subtract that many days to form our sunday start date
        week_day = txn_dt_start.weekday()
        print
        " the value of weekday is  %s" % week_day
        if week_day != 6:
            subtract_days = -1 * (week_day + 1)
            txn_dt_start = txn_dt_start + timedelta(days=(subtract_days))

        initial_partition = 1
        print
        " the values of revised start and end date are %s %s " % (txn_dt_start, txn_dt_end)
        # extract res baseline and cache it
        res_baseln_sum_df = data_loader.read_data_with_filter("dm", "RES_BASELN", "partition_dt", INIT_DT,
                                                              str(txn_dt_end), None) \
            .select("res_id", col("vrsn_strt_dts").cast("date"), col("vrsn_end_dts").cast("date"), "res_cncl_dt",
                    "sfb_nm", \
                    "res_sts_cd", "vyge_id", "prev_vyge_id", "prev_res_sts_cd", "prev_sfb_nm", "res_init_bkng_dt" \
                    , "price_strm_typ_cd", "prev_strm_typ_cd") \
            .repartition(20, "res_id") \
            .sortWithinPartitions("res_id", asc("vrsn_strt_dts"))
        # .filter("price_strm_typ_cd != 'IRG' and price_strm_typ_cd != 'XAM' and sfb_nm!='OFFICER'")\
        res_baseln_sum_df.cache()

        # iterate in 7 days combo
        dt = txn_dt_start
        final_data = None
        counter = 0
        last_batch = 0
        last_batch_dt = None
        while (dt <= txn_dt_end):
            end_dt = dt + timedelta(days=6)
            if txn_dt_end < end_dt:
                end_dt = txn_dt_end
                last_batch = 1
                last_batch_dt = str(dt)

            f = lambda x: summarize_weekly_reservations(x, dt, end_dt)
            filter = " vrsn_strt_dts >= date('%s') and vrsn_strt_dts <= date('%s')" % (INIT_DT, end_dt)

            print
            " the map partition block is the following %s %s " % (dt, end_dt)
            summary_reservation_by_week_df = res_baseln_sum_df.filter(filter).rdd.mapPartitions(f,
                                                                                                preservesPartitioning=True)
            res_baseln_sum_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                                StructField("sfb_nm", StringType(), True),
                                                StructField("txn_dt", DateType(), True),
                                                StructField("cncl_bkng_cn", IntegerType(), True),
                                                StructField("oh_paid_bkng_cn", IntegerType(), True),
                                                StructField("curr_wk_oh_sfb_bkng_cn", IntegerType(), True),
                                                StructField("pu_bkng_cn", IntegerType(), True)
                                                ])
            res_baseln_week_df = converter.convertRddToDataFrame(summary_reservation_by_week_df, res_baseln_sum_schema)
            res_baseln_agg_df = res_baseln_week_df.groupBy("vyge_id", "sfb_nm", "txn_dt").agg(
                sum("cncl_bkng_cn").alias("cncl_bkng_cn"), sum("oh_paid_bkng_cn").alias("oh_paid_bkng_cn"),
                sum("curr_wk_oh_sfb_bkng_cn").alias("curr_wk_oh_sfb_bkng_cn") \
                , sum("pu_bkng_cn").alias("pu_bkng_cn"))
            # .(filter("date(txn_dt) == date'2016-01-13'  and  vyge_id = 143003").show(50)
            # res_baseln_agg_df.filter("date(txn_dt) == date'2016-01-13'  and  vyge_id = 143003").show(50)

            # print " the value of count is %s" %count
            if str(dt) == "2016-01-10":
                res_baseln_agg_df = res_baseln_agg_df.filter(" txn_dt >= date'2016-01-11' ")

                # the last batch will have its own partition
            if last_batch == 0:
                if final_data != None:
                    final_data = final_data.union(res_baseln_agg_df)
                else:
                    final_data = res_baseln_agg_df

            counter = counter + 1
            if counter == 10:
                counter = 0
                if initial_partition == 1:
                    print
                    " writing in overwrite mode"
                    if final_data != None:
                        data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(txn_dt_start),
                                                            final_data.coalesce(2), "overwrite")
                    if last_batch == 1:
                        data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(last_batch_dt),
                                                            res_baseln_agg_df.coalesce(2), "overwrite")
                    initial_partition = 0
                    final_data = None
                else:
                    print
                    " writing in append mode"
                    if final_data != None:
                        data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(txn_dt_start),
                                                            final_data.coalesce(2), "append")
                    if last_batch == 1:
                        data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(last_batch_dt),
                                                            res_baseln_agg_df.coalesce(2), "overwrite")
                    final_data = None

            dt = dt + timedelta(days=7)
        res_baseln_sum_df.unpersist()

        if initial_partition == 1 and (final_data != None or last_batch == 1):
            print
            " writing in overwrite mode"
            if final_data != None:
                data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(txn_dt_start),
                                                    final_data.coalesce(2), "overwrite")
            if last_batch == 1:
                data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(last_batch_dt),
                                                    res_baseln_agg_df.coalesce(2), "overwrite")
            initial_partition = 0
        elif final_data != None or last_batch == 1:
            print
            " writing in append mode"
            if final_data != None:
                data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(txn_dt_start),
                                                    final_data.coalesce(2), "append")
            if last_batch == 1:
                data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(last_batch_dt),
                                                    res_baseln_agg_df.coalesce(2), "overwrite")


if __name__ == '__main__':
    try:
        obj = ConVygeSfbDly()
        obj.execute()
    except:
        traceback.print_exc()
        sys.exit(-1)
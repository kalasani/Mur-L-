import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob_old import *;
from cancellation.DataLoaderCancellationDM import *;
from cancellation.ConSlLimVygeSumCancellationDm import *;
class VygeSfbBkngDly(BaseJob):
    def __init__(self):
        self.table="cancellation"
        super(VygeSfbBkngDly, self).__init__(self.table)



    def setUp(self):
        properties = self.config.getEnvConfig()
        print(properties)
        self.s3_root_bucket = properties.hdfs_root_directory
        self.data_loader = S3DataLoader(self.spark, self.s3_root_bucket)
        print("Before Setup Calling Here ")
        print(self.table)
        t_properties = self.config.getJobConfig(self.table.lower(), False)
        print(t_properties)
        self.start_date = datetime.strptime(t_properties.start_date, "%Y-%m-%d").date()
        self.end_date = datetime.strptime(t_properties.end_date, "%Y-%m-%d").date()
        self.refresh = t_properties.data_download_refresh
        self.runType=t_properties.load_type ;
        self.debug=t_properties.debug

    def loadData(self):
        print("start_date==>",self.start_date)
        print("end_date==>", self.end_date)
        print("spark==>", self.spark)
        print("s3_root_bucket==>", self.s3_root_bucket)
        print("data_loader==>", self.data_loader)
        print("debug==>", self.debug)
        dataLoader= DataLoaderCancellationDM(self.start_date, self.end_date, self.spark, self.s3_root_bucket,self.data_loader,self.debug)
        print("Data Loader Completed ===>",dataLoader)
        dataLoader.run_cancel_data_loader();

    def createDriver(self):
        pass

    def preProcess(self):
        pass

    def process(self):
        print("DataLoaderCancellationDM Calling End Here  ")
        """
                Driver program to run cancellation_dm
                Attributes
                start_dt    : the time slice that is being executed
                self.spark : the spark sql context
                s3_bucket   : the s3 bucket that identifies the data source
                debug       :  debug flag
                """
        data_loader = self.data_loader

        vyge_df = self.spark.sql("select * from  vyge")
        # vyge_attr_df = self.spark.sql("select * from  vyge_attr")


        self.calcDriverForCancellation()

        # Read the driver table which was persisted in the above function and use it in the downstream

        # driver_vyge_sfb_df = data_loader.read_data("con", "vyge_sfb_bkng_dly")
        output_location = """driver_cancellation/partition_dt=%s""" % self.end_date
        driver_vyge_sfb_df = data_loader.read_data("dm", output_location)
        driver_vyge_sfb_df.createOrReplaceTempView("vyge_sfb_bkng_dly")
        # driver_vyge_sfb_df.filter("vyge_id in ('139003','148016','154049')").show()
        # Driver generation completed
        t0 = time()
        t2 = str(time() - t0)
        # print "vyge_sfb_bkng_dly load completed in " + t2 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(driver_vyge_sfb_df, "driver_vyge_sfb_df")

            #################### DRIVER VOYAGE MERGE ###################
        voyage_driver_df = driver_vyge_sfb_df.join(vyge_df, (driver_vyge_sfb_df.vyge_id == vyge_df.vyge_id) & \
                                                   (driver_vyge_sfb_df.txn_dt >= vyge_df.vrsn_strt_dts.cast("date")) & \
                                                   (driver_vyge_sfb_df.txn_dt < vyge_df.vrsn_end_dts.cast("date"))
                                                   , "left_outer") \
            .select(driver_vyge_sfb_df.vyge_id, "ship_cd", "txn_dt", "vyge_arvl_dt", "vyge_dprt_dt",
                    "vyge_drtn_nght_cn", \
                    "vyge_dprt_seapt_cd", "vyge_itnry_nm", "orig_vyge_itnry_nm", "app_vyge_id").distinct()

        voyage_driver_df.createOrReplaceTempView("vyge_driver")
        t3 = str(time() - t0)
        # print "vyge_driver load completed in " + t3 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(voyage_driver_df, "voyage_driver_df")

            #################### DRIVER RES_BASELN MERGE ###################

        # Calling the run_con_res_baseln(consolidated res_baseln) to compute all res_baseln metrics

        # res_baseln_metrics_df = run_con_res_baseln(start_dt,self.spark,s3_bucket,debug)
        res_baseln_metrics_df = data_loader.read_data("con", "vyge_sfb_res_baseln_cncl")

        res_baseln_metrics_df.createOrReplaceTempView("res_baseln_metrics")

        t4 = str(time() - t0)
        # print "res_baseln_metrics load completed in " + t4 + " seconds"
        # Merging res_baseln with driver on vyge_id and sfb_nm for gathering information on
        # transaction date, ON_HAND,CANCELLATION PICK UP and CURRENT WEEK ON_HAND SFB counts based on Reservation id and transaction date

        res_baseln_driver_df = driver_vyge_sfb_df.join(res_baseln_metrics_df, ["vyge_id", "sfb_nm", "txn_dt"],
                                                       "left_outer") \
            .select("vyge_id", "sfb_nm", "txn_dt", "oh_paid_bkng_cn", "cncl_bkng_cn", "pu_bkng_cn",
                    "curr_wk_oh_sfb_bkng_cn") \
            .distinct()

        # all res_baseln attributes are collected in res_baseln_driver_df
        res_baseln_driver_df.createOrReplaceTempView("res_baseln_driver")

        t5 = str(time() - t0)
        # print "res_baseln_driver load completed in " + t5 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(res_baseln_driver_df, "res_baseln_driver_df")

        ################### SHIP_FEAT #########################
        ### Fetch the ship_feat data from the s3 bucket

        ship_feat_df = data_loader.read_data("app", "SHIP_FEAT") \
            .join(vyge_df, "ship_cd") \
            .distinct()

        ship_feat_df.createOrReplaceTempView("ship_feat")

        t6 = str(time() - t0)
        # print "ship_feat load completed in " + t6 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(ship_feat_df, "ship_feat_df")

        #################### DRIVER SHIP_FEAT MERGE ###################
        # Merging ship_feat with driver on vyge_id for gathering all ship related attributes
        ship_feat_driver_df = driver_vyge_sfb_df.join(ship_feat_df, "vyge_id", "left_outer") \
            .select('vyge_id', 'ship_cd', 'ship_nm', 'ship_short_nm', 'ship_cls_nm') \
            .distinct()

        # all ship_feat attributes are collected in ship_feat_driver_df
        ship_feat_driver_df.createOrReplaceTempView("ship_feat_driver")

        t7 = str(time() - t0)
        # print "ship_feat_driver load completed in " + t7 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(ship_feat_driver_df, "ship_feat_driver_df")

        #################### DRIVER SL_LIM_VYGE_SUM MERGE ###################

        # Calling the run_con_sl_lim_vyge_sum(consolidated sl_lim_vyge_sum) that identifies each promo_cd
        # that is available for sales and computes selling limit counts at multiple levels
        # to get the number of rooms that are available for the promotion to sell

        ConSlLimVygeSumCancellationDm.run_con_sl_lim_vyge_sum(self.start_date, self.spark, self.s3_root_bucket,self.data_loader, self.debug)

        t8 = str(time() - t0)
        # print "run_con_sl_lim_vyge_sum completed in " + t8 + " seconds"
        ################ SFB_SEQ #########################
        ### Fetch sfb_seq data from S3 bucket

        sfb_seq_df = data_loader.read_data("app", "SFB_SEQ") \
            .distinct()

        sfb_seq_df.createOrReplaceTempView("sfb_seq")
        t9 = str(time() - t0)
        # print "sfb_seq load completed in " + t9 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(sfb_seq_df, "sfb_seq_df")

        #################### DRIVER SFB_SEQ MERGE ###################
        # Merging sfb_seq with driver on sfb_nm to populate vyge_rduc_price_promo_in target column
        sfb_seq_driver_df = self.spark.sql("\
                                                SELECT sq.sfb_nm,CASE WHEN sq.rduc_rev_in = 1 AND sq.lgcl_del_in ='N' THEN 1 \
                                                WHEN sq.sfb_nm = 'GTY' THEN 1 ELSE 0 \
                                                END AS vyge_rduc_price_promo_in \
                                                FROM vyge_sfb_bkng_dly vsbd \
                                                LEFT JOIN sfb_seq sq \
                                                ON vsbd.sfb_nm = sq.sfb_nm").distinct()

        # all sfb_seq attributes are collected in sfb_seq_driver_df
        sfb_seq_driver_df.createOrReplaceTempView("sfb_seq_driver")
        t10 = str(time() - t0)
        # print "sfb_seq_driver load completed in " + t10 + " seconds"
        if self.debug == 1:
            DebugCount.count_check(sfb_seq_driver_df, "sfb_seq_driver_df")
        # voyage_driver_df.unpersist()
        # ship_feat_driver_df.unpersist()
        # res_baseln_driver_df.unpersist()
        # sfb_seq_driver_df.unpersist()
        ####### final merge to create cancellation data mart data set.
        ####### vyge_sfb_bkng_dly is the target table that gets generated for cancellation data mart
        output_location = """voyage_cancellation/partition_dt=%s""" % self.end_date
        data_loader.write_data("dm", output_location, None, voyage_driver_df)
        output_location = """ship_feat_cancellation/partition_dt=%s""" % self.end_date
        data_loader.write_data("dm", output_location, None, ship_feat_driver_df)
        output_location = """resbaseln_cancellation/partition_dt=%s""" % self.end_date
        data_loader.write_data("dm", output_location, None, res_baseln_driver_df)
        output_location = """sfb_cancellation/partition_dt=%s""" % self.end_date
        data_loader.write_data("dm", output_location, None, sfb_seq_driver_df)




    def writeToHDFS(self):
        ####### final merge to create cancellation data mart data set.
        ####### vyge_sfb_bkng_dly is the target table that gets generated for cancellation data mart
        data_loader =  self.data_loader
        output_location = """voyage_cancellation/partition_dt=%s""" % self.end_date
        voyage_driver_df = data_loader.read_data("dm", output_location)
        output_location = """ship_feat_cancellation/partition_dt=%s""" % self.end_date
        ship_feat_driver_df = data_loader.read_data("dm", output_location)
        output_location = """resbaseln_cancellation/partition_dt=%s""" % self.end_date
        res_baseln_driver_df = data_loader.read_data("dm", output_location)
        output_location = """sfb_cancellation/partition_dt=%s""" % self.end_date
        sfb_seq_driver_df = data_loader.read_data("dm", output_location)

        # sl_lim_sfb_bkng_cn_df = sql_context.read.format("orc").load("/wdpr-apps-data/dclrms/stg/dm/sl_lim_cancellation")
        voyage_driver_df.createOrReplaceTempView("vyge_driver_nik")
        res_baseln_driver_df.createOrReplaceTempView("res_baseln_driver_nik")
        ship_feat_driver_df.createOrReplaceTempView("ship_feat_driver_nik")
        sfb_seq_driver_df.createOrReplaceTempView("sfb_seq_driver_nik")
        # sl_lim_sfb_bkng_cn_df.createOrReplaceTempView("sl_lim_driver_nik")
        # print "display count of drivers here: voyage_driver_df: '%s', ship_feat_driver_df: '%s',res_baseln_driver_df: '%s', sfb_seq_driver: '%s'" %(c1,c2,c3,c4)
        final_merge_sql = """
                                SELECT vd.vyge_id,
                                        rbd.sfb_nm,
                                        vd.txn_dt,
                                        sfd.ship_cd,
                                        sfd.ship_nm,
                                        sfd.ship_short_nm,
                                        sfd.ship_cls_nm,
                                        vd.vyge_dprt_dt,
                                        vd.vyge_arvl_dt,
                                        vd.vyge_drtn_nght_cn,
                                        vd.vyge_dprt_seapt_cd,
                                        vd.vyge_itnry_nm,
                                        vd.orig_vyge_itnry_nm,
                                        datediff(vd.vyge_dprt_dt,vd.txn_dt) AS dy_bef_vyge_cn,
                                        vd.app_vyge_id,
                                        coalesce(rbd.oh_paid_bkng_cn,0) AS oh_paid_bkng_cn,
                                        coalesce(rbd.cncl_bkng_cn,0) AS cncl_bkng_cn,
                                        coalesce(rbd.pu_bkng_cn,0) AS pu_bkng_cn,
                                        sqd.vyge_rduc_price_promo_in,
                                        sld.sl_lim_sfb_bkng_cn,
                                        coalesce(sld.sl_lim_sfb_bkng_cn,0) - coalesce(rbd.oh_paid_bkng_cn,0) AS sl_sfb_bkng_cn,
                                        coalesce(rbd.curr_wk_oh_sfb_bkng_cn,0) AS curr_wk_oh_sfb_bkng_cn
                                    FROM vyge_driver_nik vd, 
                                        res_baseln_driver_nik rbd,
                                        ship_feat_driver_nik sfd, 
                                        sl_lim_sfb_bkng sld, 
                                        sfb_seq_driver_nik sqd
                                    WHERE vd.vyge_id = rbd.vyge_id AND 
                                        vd.vyge_id = sfd.vyge_id AND 
                                        rbd.sfb_nm = sqd.sfb_nm AND
                                        vd.txn_dt = rbd.txn_dt AND 
                                        vd.vyge_id = sld.vyge_id AND 
                                        rbd.sfb_nm = sld.sfb_nm AND 
                                        vd.txn_dt = sld.txn_dt AND 
                                        rbd.txn_dt = sld.txn_dt AND 
                                        sfd.vyge_id = rbd.vyge_id AND
                                        sqd.sfb_nm = sld.sfb_nm AND
                                        rbd.vyge_id = sld.vyge_id
                               """

        final_data_df = self.spark.sql(final_merge_sql).distinct()
        # t11 = str(time() - t0)
        # record_count = final_data_df.count()
        # print
        # "final data count is %s" % record_count
        # print "final_data_df running before writing to HDFS in " + t11 + " seconds"
        output_location = """vyge_sfb_bkng_dly/partition_dt=%s""" % self.end_date
        print
        "output getting created at: %s " % output_location
        data_loader.write_data("dm", output_location, None, final_data_df)

    def calcDriverForCancellation(self):
        # print "started calcDriverForCancellation"
        data_loader =self.data_loader;
        list_obj = []
        # below code is required to handle special condition when start date is 2016-01-11
        if str(self.start_date) == str('2016-01-11'):
            vyge_attr_txn_dt_df = self.spark.sql(" SELECT distinct vyge_id, \
                                                                   '2016-01-11' as txn_dt \
                                    from vyge_attr WHERE date('2016-01-11') <= date_add(vyge_arvl_dt,1500)")
            # print "2016-01-11 schema "
            # vyge_attr_txn_dt_df.printSchema()
            vyge_attr_txn_dt_df.createOrReplaceTempView("vyge_attr_txn_dt")

            if self.debug == 1:
                DebugCount.count_check(vyge_attr_txn_dt_df, "vyge_attr_txn_dt_df")
        else:
            # print "in else condition for startdt: ('%s')" %start_dt
            vyge_attr_txn_dt_df = self.spark.sql(" SELECT distinct vyge_id, \
                                    '%s' as txn_dt \
                                    from vyge_attr WHERE invld_vyge_in=0 and date('%s') >= date(vyge_init_bkng_dt) and date('%s') <= date_add(date(vyge_arvl_dt),10) and date('%s') >= date(vrsn_strt_dts) and date('%s') < date(vrsn_end_dts)" % (
                self.start_date, self.start_date, self.start_date, self.start_date, self.start_date))

            vyge_attr_txn_dt_df.createOrReplaceTempView("vyge_attr_txn_dt")
            # vyge_record_count = vyge_attr_txn_dt_df.count()
            # print "records fetched are : ('%s')" %vyge_record_count
            if self.debug == 1:
                DebugCount.count_check(vyge_attr_txn_dt_df, "vyge_attr_txn_dt_df")

        driver_vyge_sfb_sql = """ select vyge_attr_txn_dt.vyge_id,sfb_nm,txn_dt
                    from vyge_attr_txn_dt vyge_attr_txn_dt
                    inner join res_baseln res_baseln
                    on vyge_attr_txn_dt.vyge_id = res_baseln.vyge_id and res_baseln.startdt <= date('%s') and res_baseln.enddt >= date('%s')""" % (
            self.start_date, self.start_date)

        # check if below distinct is required or not
        driver_vyge_sfb_df = self.spark.sql(driver_vyge_sfb_sql).distinct()
        # record_count = driver_vyge_sfb_df.count()
        # print "for first day record count is ('%s')" %record_count
        # data_loader.write_data_with_mode("con", "vyge_sfb_bkng_dly", None, driver_vyge_sfb_df.coalesce(2), "overwrite")
        # print "we are using list instead of df"
        firstdata = driver_vyge_sfb_df.rdd.map(list).collect()
        # print "using dataframe write"
        # newdf = sql_context.createDataFrame(firstdata, driver_vyge_sfb_df.schema)
        # record_count = driver_vyge_sfb_df.count()
        # print "first date count is '%s' and '%s'" %(start_dt,record_count)
        ##destination_location = """/wdpr-apps-data/dclrms/stg/dm/driver_cancellation/partition_dt=%s""" % end_dt
        ##driver_vyge_sfb_df.coalesce(2).write.mode("overwrite").format("orc").save(destination_location)
        # list_obj = driver_vyge_sfb_df.select("vyge_id","sfb_nm","txn_dt").rdd.flatMap(lambda x:x).collect()
        dt = self.start_date
        final_data = None
        counter = 0
        more_list = []
        while (dt < self.end_date):
            # print "started creating data for ('%s')" %dt
            dt = dt + timedelta(days=1)
            print
            "we started creating data for ('%s')" % dt
            vyge_attr_txn_dt_df = self.spark.sql(" SELECT distinct vyge_id, \
                                '%s' as txn_dt \
                                    from vyge_attr WHERE invld_vyge_in=0 and date('%s') >= date(vyge_init_bkng_dt) and date('%s') <= date_add(date(vyge_arvl_dt),10) and date('%s') >= date(vrsn_strt_dts) and date('%s') < date(vrsn_end_dts) " % (
                dt, dt, dt, dt, dt))
            vyge_attr_txn_dt_df.createOrReplaceTempView("vyge_attr_txn_dt")
            # vyge_attr_txn_dt_df.write.mode("append").format("orc").save("/user/mohaw002/vyge_attr_txn_dt_df")

            driver_vyge_sfb_sql = """ select vyge_attr_txn_dt.vyge_id,sfb_nm,txn_dt
                    from vyge_attr_txn_dt vyge_attr_txn_dt
                    inner join res_baseln res_baseln
                    on vyge_attr_txn_dt.vyge_id = res_baseln.vyge_id and res_baseln.startdt <= date('%s') and res_baseln.enddt >= date('%s')""" % (
                dt, dt)

            # check if below distinct is required or not
            driver_vyge_sfb_df = self.spark.sql(driver_vyge_sfb_sql).distinct()
            # record_count = driver_vyge_sfb_df.count()
            # print "below records created here: ('%s')" %record_count
            ## I am not able to write to below location, so modifying to my hdfs location
            # data_loader.write_data_with_mode("con", "vyge_sfb_bkng_dly", None, driver_vyge_sfb_df.coalesce(2), "append")
            extra_list = driver_vyge_sfb_df.rdd.map(list).collect()
            more_list += extra_list
            # record_count = driver_vyge_sfb_df.count()
            # print "driver : for '%s' we created '%s' records" %(dt,record_count)
            # destination_location = """/wdpr-apps-data/dclrms/stg/dm/driver_cancellation/partition_dt=%s""" %end_dt
            # driver_vyge_sfb_df.coalesce(2).write.mode("append").format("orc").save(destination_location)
        finallist = firstdata + more_list
        # print("created list")
        # print(finallist)
        driver_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                    StructField("sfb_nm", StringType(), True),
                                    StructField("txn_dt", StringType(), True)])
        newdf = self.spark.createDataFrame(finallist, driver_schema)
        output_location = """driver_cancellation/partition_dt=%s""" % self.end_date
        # print "output getting created at: %s " % output_location
        data_loader.write_data("dm", output_location, None, newdf)
        # newdf.coalesce(2).write.mode("overwrite").format("orc").save(destination_location)

    def tearDown(self):
        pass




if __name__ == '__main__':

    try:
        obj = VygeSfbBkngDly()
        obj.execute()

    except:
        traceback.print_exc()
        sys.exit(-1)


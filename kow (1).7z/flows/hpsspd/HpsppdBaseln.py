import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob_old import *;
from Hpsppd import *;
from HpsppdSnapshot import *;



class HpsppdBaseln(BaseJob):
    def __init__(self):
        self.table="Hpsppd"
        super(HpsppdBaseln, self).__init__(self.table)


    def setUp(self):
        properties = self.config.getEnvConfig()
        print(properties)
        self.s3_root_bucket = properties.hdfs_root_directory
        self.data_loader = S3DataLoader(self.spark, self.s3_root_bucket)
        print("Before Setup Calling Here ")
        print(self.table)
        t_properties = self.config.getJobConfig(self.table.lower(), False)
        print(t_properties)
        self.start_date = datetime.strptime(t_properties.start_date, "%Y-%m-%d").date()
        self.end_date = datetime.strptime(t_properties.end_date, "%Y-%m-%d").date()
        self.refresh = t_properties.data_download_refresh
        self.runType=t_properties.load_type ;
        self.debug=t_properties.debug

    def loadData(self):
        pass

    def createDriver(self):
        pass

    def preProcess(self):
        pass

    def process(self):
        ref=Hpsppd(self.spark,self.start_date,self.end_date,self.data_loader,self.debug);
        ref.run_hpsppd_main()
        pass;

    def writeToHDFS(self):
        #HpsppdComp.run_compression(sys.argv[1],self.start_dt, self.end_dt, sys.argv[2], self.spark, self.s3_root_bucket)
        #HpsppdSnapshot.run_hpsppd_snapshot(self.end_dt, self.spark, self.s3_root_bucket, self.debug)
        pass

    def tearDown(self):
        pass



if __name__ == '__main__':

    try:
        obj = HpsppdBaseln()
        obj.execute()

    except:
        traceback.print_exc()
        sys.exit(-1)



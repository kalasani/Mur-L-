from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from flows.utils.S3DataLoader import *
from flows.jobs.proc_price_pt_diff import *
from flows.jobs.con_resbaseln import *
from flows.utils.DataFrameUtil import *
from pyspark.sql.types import *

import os

FLOOR_DT = '2016-01-11'


def expand_keys(row, start_dt, end_dt):
    """
       Flat map function which takes a row containing voyage id , voyage init booking date and voyage arrival date
       and returns  a rdd containing vyge_id and txn_dt
    """
    dt = start_dt
    list_obj = []
    counter = 0
    while (dt <= end_dt):
        counter = counter + 1
        t = (counter, dt)
        list_obj.append(t)
        dt = dt + timedelta(days=1)
    return list_obj


def debug_counts(dataframe, name):
    print
    " Debug start ************************************************************************ %s %s" % (
    name, datetime.now())
    # cnt = dataframe.count()
    # dataframe.show()
    cnt = 0
    try:
        dataframe.filter("vyge_id = 131004 ").show()
        dataframe.filter("vyge_id = 131004 and version_start_date = date('2016-09-29')").show()
        cnt = dataframe.filter("vyge_id = 131004 and version_start_date = date('2016-09-29')").count()
        # dataframe.filter("vyge_id=137002 and strm_typ_cd = '09B'").show()
    #      dataframe.filter("vyge_id=186037 and price_mod_dt = date'2018-06-22'").show()
    except:
        print
        " exception"
    print
    " Debug counts ************************************************************************ %s " % cnt
    print
    " Debug end ************************************************************************ %s %s" % (name, datetime.now())


def populate_prev_ppm(rows):
    """
     map partition method to compute the previous price per diem metric
    """
    last_vyge_id = -1
    last_version_start_date = None
    last_metric = -1.0
    ppm_metric_list = []
    for row in rows:
        if last_vyge_id != row.vyge_id or last_version_start_date != row.version_start_date:
            # this is the first one
            last_metric = None
        metric = row.gtr_price_pd_am
        if row.gtr_price_pd_am == None:
            metric = last_metric
        ppm_metric_list.append(Row(row.vyge_id, row.version_start_date, row.price_mod_dt, last_metric, metric))
        last_metric = row.gtr_price_pd_am
        last_vyge_id = row.vyge_id
        last_version_start_date = row.version_start_date
    return iter(ppm_metric_list)


def modify_proc_price_end_dt(rows):
    """
      mapPartition method to compute proc_price_end_dt for all
      the entries in the driver table
    """
    last_vyge_id = -1
    price_mod_dt_end_lst = []
    last_version_start_date = -1
    for row in rows:
        if last_vyge_id != row.vyge_id or last_version_start_date != row.version_start_date:
            count = 0
        else:
            count = count + 1
        if count >= 1:
            price_mod_dt_end_lst.append(
                Row(row.price_mod_dt, row.version_start_date, row.vyge_id, row.ship_cd, row.vyge_opn_dt,
                    row.vyge_dprt_dt, row.all_price_mod_dt_flag, row.vyge_drtn_nght_cn, row.rank, last_mod_dt))
        else:
            price_mod_dt_end_lst.append(
                Row(row.price_mod_dt, row.version_start_date, row.vyge_id, row.ship_cd, row.vyge_opn_dt,
                    row.vyge_dprt_dt, row.all_price_mod_dt_flag, row.vyge_drtn_nght_cn, row.rank, row.price_mod_dt_end))
        last_mod_dt = row.price_mod_dt
        last_vyge_id = row.vyge_id
        last_version_start_date = row.version_start_date
    return iter(price_mod_dt_end_lst)


def identify_voyages_with_version_changes(data_loader, valid_voyages_df, start_dt, end_dt, debug,
                                          proc_price_pt_diff_cache_df):
    """
     Identify if any of the voyages have version changes

    """
    version_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % (
    "vrsn_strt_dts", start_dt, "vrsn_end_dts", end_dt)
    load_dts_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % (
    "data_ld_dts", start_dt, "data_ld_dts", end_dt)
    ship_feat_tm_dts = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % (
    "ship_feat_config_strt_dts", start_dt, "ship_feat_config_strt_dts", end_dt)
    ship_strm_typ_dts = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % (
    "ship_strm_strm_strt_dts", start_dt, "ship_strm_strm_strt_dts", end_dt)
    proc_price_pt_filter = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % ("txn_dt", start_dt, "txn_dt", end_dt)

    if debug == 1:
        debug_counts(valid_voyages_df, "valid voyages")

    version_change_vyge_attr_df = valid_voyages_df.join((data_loader.read_data("dm", "VYGE_ATTR") \
                                                         .select("vyge_id",
                                                                 col("vrsn_strt_dts").alias("version_start_date").cast(
                                                                     "date"))) \
                                                        , ["vyge_id", "version_start_date"]) \
        .select("vyge_id", valid_voyages_df.version_start_date)
    if debug == 1:
        debug_counts(version_change_vyge_attr_df, "versioned_vyge_attr")

    version_change_vyge_df = valid_voyages_df.join((data_loader.read_data("dm", "VYGE") \
                                                    .select("vyge_id",
                                                            col("vrsn_strt_dts").alias("version_start_date").cast(
                                                                "date"))) \
                                                   , ["vyge_id", "version_start_date"]) \
        .select("vyge_id", valid_voyages_df.version_start_date)
    if debug == 1:
        debug_counts(version_change_vyge_df, "versioned_vyge")
    version_change_ship_feat_df = data_loader.read_data("app", "SHIP_FEAT") \
        .filter(ship_feat_tm_dts) \
        .select("ship_cd", col("ship_feat_config_strt_dts").alias("version_start_date").cast("date"))
    version_change_ship_feat_df = valid_voyages_df.join(version_change_ship_feat_df, ["ship_cd", "version_start_date"]) \
        .select("vyge_id", valid_voyages_df.version_start_date)
    if debug == 1:
        debug_counts(version_change_ship_feat_df, "versioned_ship_feat")

    version_change_ship_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
        .filter(ship_strm_typ_dts) \
        .select("ship_cd", col("ship_strm_strm_strt_dts").alias("version_start_date").cast("date"))
    version_change_ship_strm_df = valid_voyages_df.join(version_change_ship_strm_df, ["ship_cd", "version_start_date"]) \
        .select("vyge_id", valid_voyages_df.version_start_date)

    union_df = version_change_vyge_df.union(version_change_ship_feat_df) \
        .union(version_change_ship_strm_df) \
        .union(version_change_vyge_attr_df)

    if debug == 1:
        debug_counts(version_change_ship_strm_df, "versioned_ship_strm_strm")

    version_change_ship_cabin_p_df = data_loader.read_data("sha", "SHIPCABINRESERVED").filter(version_filter_clause)
    if version_change_ship_cabin_p_df != None:
        version_change_ship_cabin_df = version_change_ship_cabin_p_df \
            .select(col("code").alias("ship_cd"), "SailDateTo", "SailDateFrom",
                    col("vrsn_strt_dts").alias("version_start_date"))
        version_change_ship_cabin_df = valid_voyages_df.join(version_change_ship_cabin_df,
                                                             ["ship_cd", "version_start_date"]) \
            .where("vyge_dprt_dt >=SailDateFrom and vyge_dprt_dt< SailDateTo") \
            .select("vyge_id", "version_start_date")
        union_df = union_df.union(version_change_ship_cabin_df)

    if debug == 1:
        debug_counts(union_df, "versioned_ship_cabin")

    version_change_ship_inventory_p_df = data_loader.read_data("sha", "SHIPINVENTORYALLOC").filter(
        version_filter_clause)
    if version_change_ship_inventory_p_df != None:
        version_change_ship_inventory_df = version_change_ship_inventory_p_df \
            .select(col("ship_code").alias("ship_cd"), "SAIL_DATE_FROM",
                    col("vrsn_strt_dts").alias("version_start_date"))

        version_change_ship_inventory_df = valid_voyages_df.join(version_change_ship_inventory_df,
                                                                 ["ship_cd", "version_start_date"]) \
            .where("vyge_dprt_dt == SAIL_DATE_FROM") \
            .select("vyge_id", "version_start_date")
        union_df = union_df.union(version_change_ship_inventory_df)

    version_change_proc_price_pt_p_df = data_loader.read_data_with_filter("dm", "PROC_PRICE_PT", "partition_dt",
                                                                          start_dt, end_dt, None)
    if version_change_proc_price_pt_p_df != None:
        version_change_proc_price_pt_df = version_change_proc_price_pt_p_df \
            .filter(proc_price_pt_filter) \
            .select("vyge_id", col("txn_dt").alias("version_start_date"))
        version_change_proc_price_pt_df = valid_voyages_df.join(version_change_proc_price_pt_df,
                                                                ["vyge_id", "version_start_date"]) \
            .select("vyge_id", "version_start_date")
        union_df = union_df.union(version_change_proc_price_pt_df)
        if debug == 1:
            debug_counts(version_change_proc_price_pt_df, "versioned_proc_price")

    version_change_proc_price_pt_p_diff_df = proc_price_pt_diff_cache_df
    if version_change_proc_price_pt_p_diff_df != None:
        version_change_proc_price_pt_diff_df = version_change_proc_price_pt_p_diff_df \
            .filter(proc_price_pt_filter) \
            .select("vyge_id", col("txn_dt").alias("version_start_date"))
        version_change_proc_price_pt_diff_df = valid_voyages_df.join(version_change_proc_price_pt_diff_df,
                                                                     ["vyge_id", "version_start_date"]) \
            .select("vyge_id", "version_start_date")

        if debug == 1:
            debug_counts(version_change_proc_price_pt_diff_df, "proc_price_pt_diff")
        union_df = union_df.union(version_change_proc_price_pt_diff_df)

    return union_df.dropDuplicates()


def run_hpsppd_main(start_dt, end_dt, sql_context, s3_bucket, debug):
    dt = start_dt
    data_loader = S3DataLoader(sql_context, s3_bucket)
    converter = DataFrameUtil(sql_context)
    proc_price_pt_diff_cache_df = data_loader.read_data("con", "PROC_PRICE_PT_DIFF")
    # proc_price_pt_diff_cache_df.cache()
    # partition_filter = " txn_dt >= date('%s')  and  txn_dt <= date('%s')" %(str(start_dt),str(end_dt))
    res_baseln_cache_df = data_loader.read_data("con", "vyge_price_eff_dt_res_baseln")
    # res_baseln_cache_df.cache()
    multi_day_driver_df = None
    keys_df = sql_context.range(1)
    f = lambda x: expand_keys(x, start_dt, end_dt)
    keys_df = keys_df.rdd.flatMap(f)
    keys_schema = StructType(
        [StructField("counter", IntegerType(), True), StructField("version_start_date", DateType(), True)])
    version_df = sql_context.createDataFrame(keys_df, keys_schema).dropDuplicates().drop("counter")
    if debug == 1:
        debug_counts(version_df, "version_table")
    multi_day_driver_df = get_driver_for_days(version_df, start_dt, end_dt, sql_context, s3_bucket, debug,
                                              proc_price_pt_diff_cache_df, res_baseln_cache_df, data_loader, converter)
    # multi_day_driver_df.show()
    get_data_and_compute_metrics(multi_day_driver_df, sql_context, s3_bucket, debug, proc_price_pt_diff_cache_df,
                                 res_baseln_cache_df, data_loader, converter, end_dt)


def get_driver_for_days(version_df, start_dt, end_dt, sql_context, s3_bucket, debug, proc_price_pt_diff_cache_df,
                        res_baseln_cache_df, data_loader, converter):
    """
     Driver program to run hpsppd
     Attributes
     start_dt -> the time slice that is being executed
     sql_context : the spark sql context
     s3_bucket the s3 bucket that identifies the data source
     debug debug flag
    """
    print
    datetime.now()

    all_vyge_attr_valid_df = data_loader.read_data("dm", "VYGE_ATTR") \
        .filter(
        "invld_vyge_in = 0 and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null) and upper(instnc_st_nm)='STANDARD'") \
        .select("vyge_id").distinct()
    all_voyage_attr_filter_clause = " vyge_opn_dt <= version_start_date"
    all_vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR").filter(
        "invld_vyge_in = 0 and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null)") \
        .groupBy("vyge_id").agg(min("vyge_opn_dt").alias("vyge_opn_dt"),
                                min("vyge_init_bkng_dt").alias("vyge_init_bkng_dt"),
                                min("vyge_arvl_dt").alias("vyge_arvl_dt")) \
        .select("vyge_id", "vyge_arvl_dt", "vyge_opn_dt", "vyge_init_bkng_dt").join(all_vyge_attr_valid_df, ["vyge_id"]) \
        .select("vyge_id", least("vyge_opn_dt", "vyge_init_bkng_dt").alias("vyge_opn_dt")).join(version_df).filter(
        all_voyage_attr_filter_clause)
    all_vyge_attr_df.createOrReplaceTempView("vyge_attr_df")
    if debug == 1:
        debug_counts(all_vyge_attr_df, "all_vyge_attr_df")

        ## Get all voyages and meta information  - TBD needs to go in a common class

    voyage_attr_filter_clause = "version_start_date >= date(vrsn_strt_dts) \
                               and  version_start_date < date(vrsn_end_dts)"
    voyage_attr_temp_df = data_loader.read_data("dm", "VYGE_ATTR").join(version_df).where(voyage_attr_filter_clause) \
        .select("vyge_id", "ship_cd", "vyge_dprt_dt", "version_start_date", \
                "vyge_arvl_dt", "vyge_drtn_nght_cn", "vyge_itnry_nm", "orig_vyge_itnry_nm", "app_vyge_id") \
        .join(all_vyge_attr_df, ["vyge_id", "version_start_date"])
    voyage_attr_temp_df.cache()
    if debug == 1:
        debug_counts(voyage_attr_temp_df, "voyage_attr_temp_df")

        # read ship_feat
    ship_feat_filter_clause = "upper(lgcl_del_in) = 'N' and \
                              version_start_date >= date(ship_feat_config_strt_dts) and \
                              version_start_date < date(ship_feat_config_end_dts)"
    ship_feat_df = data_loader.read_data("app", "SHIP_FEAT").join(version_df).filter(ship_feat_filter_clause).select(
        "ship_cd", "ship_nm", "ship_short_nm", "ship_cls_nm", "version_start_date")
    ship_feat_df.createOrReplaceTempView("ship_feat")
    if debug == 1:
        debug_counts(ship_feat_df, "ship_feat_df")

    voyage_filter_clause = "upper(instnc_st_nm)='STANDARD' \
                           and  version_start_date >= date(vrsn_strt_dts) \
                           and  version_start_date < date(vrsn_end_dts) "
    voyage_df = data_loader.read_data("dm", "VYGE").join(version_df) \
        .filter(voyage_filter_clause) \
        .select("vyge_id", "vyge_dprt_seapt_cd", "version_start_date")
    # all voyages meta informationa collected in voyage_df
    voyage_df.createOrReplaceTempView("voyage")
    if debug == 1:
        debug_counts(voyage_df, "voyage_df")

        # create voyage attribute
    voyage_attr_df = voyage_attr_temp_df.join(ship_feat_df, ["ship_cd", "version_start_date"]).join(voyage_df,
                                                                                                    ["vyge_id",
                                                                                                     "version_start_date"]).dropDuplicates()
    # voyage_attr_df = voyage_attr_temp_df
    # persist the voyage attr in memory
    voyage_attr_df.createOrReplaceTempView("voyage_attr")
    if debug == 1:
        debug_counts(voyage_attr_df, "voyage_attr_df")

        # min_opening_date_of_vyges = sql_context.sql("select min(vyge_opn_dt) as min_vyge_opn_dt from voyage_attr").head()[0]

    ### identifying if any changes for proc_price_pt and opn_vyg_config vyg_fnc_fcst_var this goes by ship code
    ## if anything here - need to pick all price_mod_dts
    opn_vyge_strm_typ_filter_clause = " version_start_date = date(vyge_strm_typ_config_strt_dts) \
                                       and upper(lgcl_del_in)= 'N'"
    opn_vyge_strm_version_change_voyages_df = data_loader.read_data("app", "OPN_VYGE_STRM_TYP_CONFIG").join(version_df) \
        .filter(opn_vyge_strm_typ_filter_clause)

    opn_vyge_strm_version_change_voyages_df.createOrReplaceTempView("opn_vyge_strm_typ_config")
    opn_vyge_strm_voyages_df = sql_context.sql(" select vyge_id,version_start_date \
                                                from \
                                                   (select ship_cd,version_start_date,\
                                                           strm_typ_cd,\
                                                           vyge_strm_typ_config_strt_dts,\
                                                           ooo_strm_cn,vyge_dprt_dt,\
                                                           vyge_arvl_dt \
                                                   from opn_vyge_strm_typ_config) cfg  inner join \
                                                  ( select  vyge_id,\
                                                            vyge_dprt_dt,\
                                                            ship_cd \
                                                    from voyage_attr) vyge_attr \
                                                    on vyge_attr.ship_cd = cfg.ship_cd \
                                                    where vyge_attr.vyge_dprt_dt >= cfg.vyge_dprt_dt \
                                                          and  vyge_attr.vyge_dprt_dt < cfg.vyge_arvl_dt  ")
    # will have all valid opn_vyge_strm_version_change_voyages
    if debug == 1:
        debug_counts(opn_vyge_strm_voyages_df, "open voyages")

        ### identify if any changes to vyge_fnc_fcst_var
    ## if anything here - need to pick all price_mod_dts
    vyge_fnc_fcst_var_filter_clause = "version_start_date = date(data_ld_dts) and lgcl_del_in= 'N'"
    vyge_fnc_fcst_var_version_change_voyages_df = data_loader.read_data("app", "VYGE_FNC_FCST_VAR").join(version_df) \
        .filter(vyge_fnc_fcst_var_filter_clause) \
        .select("ship_cd", "vyge_strt_dt", "fcst_ship_ocpncy_pc", \
                "fcst_gst_per_strm_cn", "fcst_ooo_gst_per_strm_cn", "version_start_date")

    vyge_fnc_fcst_var_version_change_voyages_df.createOrReplaceTempView("vyge_fnc_fcst_var")
    vyge_fnc_valid_voyages_df = sql_context.sql(" select vyge_id,version_start_date \
                                                 from \
                                                   (select ship_cd,version_start_date,\
                                                           vyge_strt_dt \
                                                    from vyge_fnc_fcst_var \
                                                   ) vyg_fnc inner join \
                                                   (select ship_cd,vyge_id,\
                                                           vyge_dprt_dt from voyage_attr)  vyg_attr \
                                                    on vyg_attr.ship_cd = vyg_fnc.ship_cd \
                                                       and vyg_attr.vyge_dprt_dt = vyg_fnc.vyge_strt_dt")
    if debug == 1:
        debug_counts(vyge_fnc_valid_voyages_df, "vyge_fnc_valid_voyages_df")

        # these reservations can have an impact across all the price_mod_dts so we identify them as potential to impact all
    # price effective dates so mark res valid voyages belonging to the baseline chnages for these voyages to a new version
    res_baseln_partition_df = data_loader.read_data_with_filter("dm", "RES_BASELN", "partition_dt", start_dt, end_dt,
                                                                None)
    if debug == 1 and res_baseln_partition_df != None:
        debug_counts(res_baseln_partition_df, "reservation baseline change voyages")

    # all the price modified dates need to be reported for these voyages
    all_price_mods_df = None
    floor_filter = "version_start_date = date('%s') " % FLOOR_DT
    all_price_mods_df_on_floor = voyage_attr_df.select("vyge_id", "version_start_date").filter(
        floor_filter).dropDuplicates() \
        .withColumn("all_price_mod_dt_flag", lit(1))
    if res_baseln_partition_df != None:
        res_baseln_partition_df = res_baseln_partition_df.select("vyge_id", "prev_vyge_id",
                                                                 col("vrsn_strt_dts").alias("version_start_date").cast(
                                                                     "date"))
        res_baseln_partition_df = res_baseln_partition_df.select("vyge_id", "version_start_date").union(
            res_baseln_partition_df.filter("prev_vyge_id is not null"). \
            select(col("prev_vyge_id").alias("vyge_id"), "version_start_date")) \
            .dropDuplicates()
        res_baseln_partition_df = voyage_attr_df.join(res_baseln_partition_df, ["vyge_id", "version_start_date"]) \
            .select("vyge_id", "version_start_date")
        all_price_mods_df = vyge_fnc_valid_voyages_df.union(opn_vyge_strm_voyages_df) \
            .union(res_baseln_partition_df) \
            .dropDuplicates() \
            .withColumn("all_price_mod_dt_flag", lit(1))
    else:
        all_price_mods_df = vyge_fnc_valid_voyages_df.union(opn_vyge_strm_voyages_df) \
            .dropDuplicates() \
            .withColumn("all_price_mod_dt_flag", lit(1))

    all_price_mods_df = all_price_mods_df.union(all_price_mods_df_on_floor).dropDuplicates()
    if debug == 1:
        debug_counts(all_price_mods_df, "all price mod dfvoyages")

    # voyages which have a version change and need to restate for current price mod dt  only

    version_change_voyages_df = identify_voyages_with_version_changes(data_loader, voyage_attr_temp_df, start_dt,
                                                                      end_dt, debug, proc_price_pt_diff_cache_df)
    if debug == 1:
        debug_counts(version_change_voyages_df, "versioned voyages")
    versioned_voyages_not_all_price_mods = version_change_voyages_df.subtract(
        all_price_mods_df.select("vyge_id", "version_start_date")) \
        .withColumn("all_price_mod_dt_flag", lit(0))

    # union of all voyages with all price mod dts and ones with just current price mod dt restatement
    driver_voyages_df = versioned_voyages_not_all_price_mods.union(all_price_mods_df)
    if debug == 1:
        debug_counts(driver_voyages_df, "driver_voyages_df")

        # identify the price mod dt for voyages which need to be analyzed
    proc_price_pt_diff_filter = "txn_dt <= date('%s')" % end_dt
    # proc_price_pt_df=data_loader.read_data("con","PROC_PRICE_PT_DIFF")
    driver_df = proc_price_pt_diff_cache_df.filter(proc_price_pt_diff_filter) \
        .select("txn_dt", "vyge_id") \
        .dropDuplicates() \
        .join(driver_voyages_df, "vyge_id").filter("version_start_date >= txn_dt")
    if debug == 1:
        debug_counts(driver_df, "driver_df")

        # approach is : to sort to partition driver_df by voyage and sort by txn_dt descending and rank them.
    #               for ones with all_price_mod_dt_flag set to 1 we need all ranks and for ones set to 0 we need
    #               the ones with rank one
    window = Window.partitionBy(driver_df.vyge_id, driver_df.version_start_date).orderBy(driver_df.txn_dt.desc())
    rank_driver_df = driver_df.select("vyge_id", "version_start_date", col("txn_dt") \
                                      .alias("price_mod_dt"), "all_price_mod_dt_flag", \
                                      rank().over(window).alias('rank')) \
        .filter("all_price_mod_dt_flag=1 or (rank < 3 )") \
        .join(voyage_attr_df, ["vyge_id", "version_start_date"]) \
        .select("price_mod_dt", "version_start_date", "vyge_id", "ship_cd", "vyge_opn_dt", "vyge_dprt_dt",
                "all_price_mod_dt_flag", "vyge_drtn_nght_cn", "rank") \
        .dropDuplicates()

    if debug == 1:
        debug_counts(rank_driver_df, "rank_driver_df")
        # generate driver  completed need to add price_mod_dt_end for identifying the range to complete the driver

    final_driver_rdd = rank_driver_df.withColumn("price_mod_dt_end",
                                                 lit(date_add(rank_driver_df.version_start_date, 1)).cast("date")) \
        .repartition("vyge_id", "version_start_date") \
        .sortWithinPartitions("vyge_id", desc("version_start_date"), desc("price_mod_dt")) \
        .rdd.mapPartitions(modify_proc_price_end_dt, preservesPartitioning=True)

    driver_schema = StructType([
        StructField("price_mod_dt", DateType(), True),
        StructField("version_start_date", DateType(), True),
        StructField("vyge_id", IntegerType(), True),
        StructField("ship_cd", StringType(), True),
        StructField("vyge_opn_dt", DateType(), True),
        StructField("vyge_dprt_dt", DateType(), True),
        StructField("all_price_mod_dt_flag", IntegerType(), True),
        StructField("vyge_drtn_nght_cn", IntegerType(), True),
        StructField("rank", IntegerType(), True),
        StructField("price_mod_dt_end", DateType(), True)
    ])
    final_driver_df = converter.convertRddToDataFrame(final_driver_rdd, driver_schema)
    final_driver_df.createOrReplaceTempView("final_driver")
    if debug == 1:
        debug_counts(final_driver_df, "final driver after map partition")

    final_driver_sql = """      
                     select E.*,
                             A.vyge_arvl_dt,
                             A.vyge_itnry_nm,
                             A.orig_vyge_itnry_nm,
                             A.app_vyge_id,
                             I.vyge_dprt_seapt_cd,
                             B.ship_nm,
                             B.ship_short_nm,
                             B.ship_cls_nm
                        from  final_driver E
                        inner join voyage_attr A on  E.vyge_id = A.vyge_id and E.version_start_date = A.version_start_date
                        inner join voyage I on E.vyge_id = I.vyge_id  and I.version_start_date = E.version_start_date
                        inner join ship_feat B on E.ship_cd = B.ship_cd  and B.version_start_date = E.version_start_date                        
                     """
    final_driver_meta_info_df = sql_context.sql(final_driver_sql)
    if debug == 1:
        debug_counts(final_driver_meta_info_df, "final_driver")
        cnt1 = final_driver_meta_info_df.count()
        cnt2 = final_driver_meta_info_df.dropDuplicates().count()
        print
        "*************************************** %s " % cnt1
        print
        "*************************************** %s " % cnt2
    return final_driver_meta_info_df


def get_data_and_compute_metrics(final_driver_df, sql_context, s3_bucket, debug, proc_price_pt_diff_cache_df,
                                 res_baseln_cache_df, data_loader, converter, end_dt):
    final_driver_df.cache()
    print
    " the count for final driver is ********************************%s " % final_driver_df.count()
    final_driver_df.createOrReplaceTempView("final_driver")
    if debug == 1:
        debug_counts(final_driver_df, "final driver_df")
    # min_opening_date_of_vyges = sql_context.sql("select min(vyge_opn_dt) as min_vyge_opn_dt from final_driver").head()[0]
    # res_baseln_metrics_df = run_con_res_baseln(start_dt,data_loader,converter,sql_context,final_driver_df,res_baseln_cache_df)
    # res_baseln_metrics_df.persist()
    res_baseln_cache_df.createOrReplaceTempView("res_baseln_metrics")

    res_baseln_metric_sql = """
                             select sum(grs_paid_bkng_cn) as grs_paid_bkng_cn,
                                    sum(oh_paid_bkng_cn) as oh_paid_bkng_cn,
                                    sum(grs_prevl_paid_bkng_cn) as grs_prevl_paid_bkng_cn,
                                    sum(oh_prevl_paid_bkng_cn) as oh_prevl_paid_bkng_cn,
                                    sum(tot_gst_cn) as tot_gst_cn,
                                    B.vyge_id, B.price_mod_dt,B.version_start_date
                             from final_driver B
                             left join res_baseln_metrics A on A.vyge_id = B.vyge_id and A.txn_dt = B.version_start_date
                             where B.price_mod_dt <= A.price_eff_dt and B.price_mod_dt_end >  A.price_eff_dt
                             group by B.price_mod_dt,B.vyge_id ,B.version_start_date
                          """
    res_baseln_metrics_driver_df = sql_context.sql(res_baseln_metric_sql)
    res_baseln_metrics_driver_df.createOrReplaceTempView("driver_res_baseln_metrics")

    res_baseln_paid_bkng_sql = """
                             select sum(paid_bkng_cn) as paid_bkng_cn,
                                    B.vyge_id, B.price_mod_dt,B.version_start_date
                             from final_driver B
                             left join res_baseln_metrics A on A.vyge_id = B.vyge_id and A.txn_dt = B.price_mod_dt
                             group by B.price_mod_dt,B.vyge_id ,B.version_start_date
                          """
    res_baseln_paid_bkng_df = sql_context.sql(res_baseln_paid_bkng_sql)
    # res_baseln_metrics_driver_df = res_baseln_metrics_df.join(broadcast(final_driver_df),["vyge_id","price_mod_dt"],"right_outer")
    res_baseln_paid_bkng_df.createOrReplaceTempView("driver_res_paid_booking_cnt")
    # res_baseln_metrics_driver_df.persist()

    if debug == 1:
        debug_counts(res_baseln_metrics_driver_df, "res_baseln_metrics_driver_df")
        debug_counts(res_baseln_paid_bkng_df, "res_baseln_paid_booking_df")

    # res_baseln_paid_booking_metrics_df.persist()
    # res_baseln_metrics_df.unpersist()

    ## get inventory information

    ### get physical inventory informaiton
    ship_strm_typ_filter = "upper(instnc_st_nm)='STANDARD' \
                         and strm_typ_cd not in ('IRG','IGT','OGT','VGT','XAM','GTY') "
    ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
        .filter(ship_strm_typ_filter) \
        .join(final_driver_df, "ship_cd") \
        .filter("vyge_dprt_dt >= date(ship_strm_strm_strt_dts) \
                                          and vyge_dprt_dt < date(ship_strm_strm_end_dts)\
                                          and version_start_date >= date(vrsn_strt_dts) \
                                          and version_start_date < date(vrsn_end_dts)") \
        .select("vyge_id", "vyge_dprt_dt", "ship_strm_strm_strt_dts", "strm_typ_cd", "ship_strm_nb", "price_mod_dt",
                "version_start_date")
    ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")
    ship_strm_strm_sql = """
                       select count(*) as phys_invtry_strm_cn,vyge_id ,price_mod_dt,version_start_date 
                       from ship_strm_strm_typ 
                       group by vyge_id,price_mod_dt,version_start_date
                      """

    ship_strm_strm_category_sql = """
                       select count(*) as phys_invtry_strm_ctgy_cn,vyge_id,strm_typ_cd,price_mod_dt,version_start_date
                       from ship_strm_strm_typ 
                       group by vyge_id,strm_typ_cd,price_mod_dt,version_start_date
                      """
    physical_inventory_cnt_df = sql_context.sql(ship_strm_strm_sql)
    physical_inventory_cnt_df.createOrReplaceTempView("physical_inventory_cnt")
    category_inventory_cnt_df = sql_context.sql(ship_strm_strm_category_sql)
    category_inventory_cnt_df.createOrReplaceTempView("category_inventory_cnt")
    if debug == 1:
        debug_counts(category_inventory_cnt_df, "category_inventory_cnt_df")

        ### get variables for ppm computations

    ship_cd_version_start_df = final_driver_df.select("version_start_date", "ship_cd").distinct()
    vyge_ship_cd_version_start_df = final_driver_df.select("vyge_id", "version_start_date", "ship_cd", "vyge_dprt_dt") \
        .groupBy("vyge_id", "ship_cd", "version_start_date").agg(max("vyge_dprt_dt").alias("vyge_dprt_dt"))
    # .distinct()
    voyage_ship_cd_df = final_driver_df.select("vyge_id", "ship_cd", "vyge_dprt_dt") \
        .groupBy("vyge_id", "ship_cd").agg(max("vyge_dprt_dt").alias("vyge_dprt_dt"))
    # .distinct()
    voyage_ship_cd_df.createOrReplaceTempView("voyage_ship_cd")
    vyge_ship_cd_version_start_df.createOrReplaceTempView("voyage_version_ship_cd")

    # Get opn_vyge_fnc_fcst_var variables
    dflt_vyge_fnc_fcst_var_filter = "%s >= date(dflt_ship_fnc_fcst_strt_dts) and \
                                 %s < date(dflt_ship_fnc_fcst_end_dts)" % ("version_start_date", "version_start_date")
    dflt_vyge_fnc_fcst_var_df = data_loader.read_data("app", "DFLT_SHIP_FNC_FCST") \
        .join(final_driver_df, ["ship_cd"]) \
        .filter(dflt_vyge_fnc_fcst_var_filter) \
        .select("price_mod_dt", "vyge_id", "ship_cd", "version_start_date", "fcst_ship_ocpncy_pc",
                "fcst_gst_per_strm_cn", "fcst_ooo_gst_per_strm_cn", "vyge_adlt_split_pc", "vyge_chld_split_pc")
    dflt_vyge_fnc_fcst_var_df.createOrReplaceTempView("dflt_vyge_fnc_fcst_var")
    if debug == 1:
        debug_counts(dflt_vyge_fnc_fcst_var_df, "vyge_default")

    opn_vyge_fnc_fcst_var_df = data_loader.read_data("app", "VYGE_FNC_FCST_VAR")
    vyge_fnc_fcst_var_filter_clause = " upper(lgcl_del_in)= 'N'"
    vyge_fnc_fcst_var_version_change_voyages_df = data_loader.read_data("app", "VYGE_FNC_FCST_VAR") \
        .filter(vyge_fnc_fcst_var_filter_clause) \
        .select("ship_cd", "vyge_strt_dt", "data_ld_dts", "fcst_ship_ocpncy_pc", \
                "fcst_gst_per_strm_cn", "fcst_ooo_gst_per_strm_cn", "vyge_adlt_split_pc", "vyge_chld_split_pc")

    vyge_fnc_fcst_var_version_change_voyages_df.createOrReplaceTempView("vyge_fnc_fcst_var")
    vyge_fnc_fcst_var_max_sql = """
                           select C.vyge_id,C.price_mod_dt,C.version_start_date,V.fcst_ship_ocpncy_pc,
                                  V.fcst_gst_per_strm_cn,V.fcst_ooo_gst_per_strm_cn,V.vyge_chld_split_pc,
                                  V.vyge_adlt_split_pc from
                           (select A.ship_cd,A.vyge_strt_dt,B.max_data_ld_dt,
                                  A.fcst_ship_ocpncy_pc,A.fcst_gst_per_strm_cn,
                                  A.fcst_ooo_gst_per_strm_cn, A.vyge_chld_split_pc, A.vyge_adlt_split_pc from 
                                  ( select max(date(data_ld_dts)) as max_data_ld_dt,ship_cd,vyge_strt_dt
                                    from vyge_fnc_fcst_var 
                                    group by ship_cd,vyge_strt_dt 
                                  ) B,
                                  vyge_fnc_fcst_var A 
                            where B.max_data_ld_dt = date(A.data_ld_dts) and
                                  A.ship_cd = B.ship_cd and  
                                  A.vyge_strt_dt = B.vyge_strt_dt
                           ) V
                           join final_driver C on C.ship_cd = V.ship_cd and C.vyge_dprt_dt = V.vyge_strt_dt 
                           """
    vyge_fnc_fcst_var_max_df = sql_context.sql(vyge_fnc_fcst_var_max_sql)
    vyge_fnc_fcst_var_max_df.createOrReplaceTempView("vyge_fnc_fcst_var_max")
    if debug == 1:
        debug_counts(vyge_fnc_fcst_var_max_df, "vyge_fnc_fcst_var_max_df")
    vyge_fnc_fcst_var_voyage_sql = """
                             select  B.vyge_id,B.version_start_date,B.price_mod_dt,
                                     coalesce(A.fcst_ship_ocpncy_pc,C.fcst_ship_ocpncy_pc) as  fcst_ship_ocpncy_pc,
                                     coalesce(A.fcst_gst_per_strm_cn,C.fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn,
                                     coalesce(A.fcst_ooo_gst_per_strm_cn,C.fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn, 
                                     coalesce(A.vyge_adlt_split_pc,C.vyge_adlt_split_pc) as vyge_adlt_split_pc, 
                                     coalesce(A.vyge_chld_split_pc,C.vyge_chld_split_pc) as vyge_chld_split_pc
                             FROM final_driver B 
                             inner join dflt_vyge_fnc_fcst_var C on B.vyge_id = C.vyge_id and B.version_start_date = C.version_start_date and C.price_mod_dt = B.price_mod_dt
                             left join vyge_fnc_fcst_var_max A on A.vyge_id = B.vyge_id and A.version_start_date = B.version_start_date and A.price_mod_dt = B.price_mod_dt
                               """
    vyge_fnc_fcst_var_voyage_final_df = sql_context.sql(vyge_fnc_fcst_var_voyage_sql)
    vyge_fnc_fcst_var_voyage_final_df.createOrReplaceTempView("vyge_fnc_fcst_var")
    if debug == 1:
        debug_counts(vyge_fnc_fcst_var_voyage_final_df, "vyge_fnc_fcst_var_voyage_final_df")
        ### completed merge of vyge_fnc_fcst_var with voyge
    ### start generation of opn_vyge_strm_typ_config

    ############################################################################

    opn_vyge_strm_typ_filter_clause = " upper(lgcl_del_in)= 'N'"
    opn_vyge_strm_version_change_voyages_df = data_loader.read_data("app", "OPN_VYGE_STRM_TYP_CONFIG") \
        .filter(opn_vyge_strm_typ_filter_clause)
    opn_vyge_strm_version_change_voyages_df.createOrReplaceTempView("opn_vyge_strm_typ_config")
    opn_vyge_strm_typ_config_sql = """
                             select  B.vyge_id,A.strm_typ_cd,B.version_start_date,B.price_mod_dt,
                                     A.ooo_strm_cn
                             from   opn_vyge_strm_typ_config A,
                                    final_driver B
                             where A.ship_cd = B.ship_cd and 
                                   B.vyge_dprt_dt >= A.vyge_dprt_dt and 
                                   B.vyge_dprt_dt < A.vyge_arvl_dt and
                                   B.version_start_date >= date(A.vyge_strm_typ_config_strt_dts) and 
                                   B.version_start_date <  date(A.vyge_strm_typ_config_end_dts)
                             """
    opn_vyge_strm_typ_voyage_df = sql_context.sql(opn_vyge_strm_typ_config_sql)
    opn_vyge_strm_typ_voyage_df.createOrReplaceTempView("opn_vyge_strm_typ")
    if debug == 1:
        debug_counts(opn_vyge_strm_typ_voyage_df, "opn_vyge_strm_typ_voyage_df")

    ###############################################################################
    ##### merge with proc price pt to compute ppm metrics #########################
    ###############################################################################
    voyages_only_df = final_driver_df.select("vyge_id", col("price_mod_dt").alias("txn_dt")).distinct()
    # read proc_price_pt from opening date of voyage to transaction date
    proc_price_pt_filter = "strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') and sfb_nm = 'PREVAIL' and proc_price_src_sys_nm = 'Pricing Extract'"
    proc_price_pt_df = data_loader.read_data("dm", "PROC_PRICE_PT").filter(proc_price_pt_filter) \
        .join(voyages_only_df, ["vyge_id", "txn_dt"]) \
        .select("vyge_id", "vyge_drtn_nght_cn", col("txn_dt").alias("price_mod_dt"), "strm_typ_cd", "vfd_am",
                "vfa_extra_am", "vfc_extra_am", "vfi_extra_am", "non_comm_am")
    proc_price_pt_df.createOrReplaceTempView("proc_price_pt")
    if debug == 1:
        debug_counts(proc_price_pt_df, "proc_price_pt")
    proc_price_pt_sql = """
                       select ppm.vyge_id,
                              ppm.price_mod_dt,
                              ppm.vyge_drtn_nght_cn,
                              ppm.strm_typ_cd,
                              ppm.vfd_am,
                              ppm.vfa_extra_am,
                              ppm.vfc_extra_am,
                              ppm.vfi_extra_am,
                              ppm.non_comm_am ,
                              ppm.version_start_date,
                              coalesce(C.ooo_strm_cn,0) as ooo_strm_cn,
                              D.fcst_ship_ocpncy_pc,
                              D.fcst_gst_per_strm_cn,
                              D.fcst_ooo_gst_per_strm_cn,
                              D.vyge_chld_split_pc, 
                              D.vyge_adlt_split_pc,
                              E.phys_invtry_strm_ctgy_cn 
                        from
                       (select A.vyge_id,
                              A.price_mod_dt,
                              A.vyge_drtn_nght_cn,
                              B.strm_typ_cd,
                              B.vfd_am,
                              B.vfa_extra_am,
                              B.vfc_extra_am,
                              B.vfi_extra_am,
                              B.non_comm_am ,
                              A.version_start_date
                       from  final_driver A
                       inner join proc_price_pt B on A.vyge_id = B.vyge_id  and A.price_mod_dt = B.price_mod_dt ) ppm
                       left join opn_vyge_strm_typ C on ppm.vyge_id = C.vyge_id and ppm.version_start_date = C.version_start_date 
                                 and ppm.strm_typ_cd = C.strm_typ_cd and ppm.price_mod_dt = C.price_mod_dt
                       left join vyge_fnc_fcst_var D on ppm.vyge_id = D.vyge_id and ppm.version_start_date = D.version_start_date 
                                 and ppm.price_mod_dt = D.price_mod_dt
                       left join category_inventory_cnt E on ppm.vyge_id = E.vyge_id and ppm.price_mod_dt = E.price_mod_dt and 
                                                             ppm.version_start_date = E.version_start_date and ppm.strm_typ_cd = E.strm_typ_cd
                      """

    proc_price_pt_df = sql_context.sql(proc_price_pt_sql)
    proc_price_pt_df.createOrReplaceTempView("compute_ppm_view")
    if debug == 1:
        # debug_counts(proc_price_pt_df,"proc_price_pt_df")
        debug_counts(proc_price_pt_df, "compute_ppm_view")
    merge_join_sql_proc_price = """
                               select A.vyge_id, 
                                      A.vyge_drtn_nght_cn,
                                      A.price_mod_dt,
                                      A.version_start_date,
                                      P.strm_typ_cd,
                                      P.vfd_am,
                                      P.vfa_extra_am,
                                      P.vfc_extra_am,
                                      P.vfi_extra_am,
                                      P.non_comm_am,
                                      coalesce(B.ooo_strm_cn, 0) ooo_strm_cn,
                                      C.fcst_ship_ocpncy_pc,
                                      C.fcst_gst_per_strm_cn,
                                      C.fcst_ooo_gst_per_strm_cn,
                                      C.vyge_chld_split_pc, 
                                      C.vyge_adlt_split_pc,
                                      D.phys_invtry_strm_ctgy_cn 
                               from final_driver A
                               inner join proc_price_pt P  on A.vyge_id = P.vyge_id 
                               left join opn_vyge_strm_typ B on A.vyge_id = B.vyge_id and A.strm_typ_cd = B.strm_typ_cd and A.version_start_date = B.version_start_date
                               left join vyge_fnc_fcst_var C on A.vyge_id = C.vyge_id
                               left join category_inventory_cnt D on A.vyge_id = D.vyge_id and A.strm_typ_cd = D.strm_typ_cd and A.version_start_date = D.version_start_date
                             """

    # proc_price_fnc_var_opn_vyge_category_inv_df=sql_context.sql(merge_join_sql_proc_price)
    # if debug ==1:
    #  debug_counts(proc_price_fnc_var_opn_vyge_category_inv_df,"proc_price_fnc_var_opn_vyge_category_inv_df")

    # proc_price_fnc_var_opn_vyge_category_inv_df.createOrReplaceTempView("compute_ppm_view")

    vdf_sql = """
               select vyge_id, price_mod_dt,strm_typ_cd,version_start_date,
               min(fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc,
               min(fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn,
               min(fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn,                      
               sum((((vfd_am+non_comm_am)*2)*((phys_invtry_strm_ctgy_cn*fcst_ship_ocpncy_pc)-ooo_strm_cn)) +
               (((vfa_extra_am+non_comm_am)*vyge_adlt_split_pc)*((phys_invtry_strm_ctgy_cn*fcst_ship_ocpncy_pc)-ooo_strm_cn) *(fcst_gst_per_strm_cn - 2))+
               (((vfc_extra_am+non_comm_am)*vyge_chld_split_pc)*((phys_invtry_strm_ctgy_cn*fcst_ship_ocpncy_pc)-ooo_strm_cn) *(fcst_gst_per_strm_cn - 2))) as gross_revenue,
               sum((phys_invtry_strm_ctgy_cn*vyge_drtn_nght_cn*fcst_ship_ocpncy_pc-vyge_drtn_nght_cn*ooo_strm_cn)*fcst_gst_per_strm_cn +
                                       (ooo_strm_cn*vyge_drtn_nght_cn*fcst_ooo_gst_per_strm_cn)) as gross_price_pd
               from compute_ppm_view 
               group by vyge_id,price_mod_dt,strm_typ_cd,version_start_date
             """
    voyage_price_mod_vdf_cat_df = sql_context.sql(vdf_sql)
    if debug == 1:
        debug_counts(voyage_price_mod_vdf_cat_df, "voyage_price_mod_vdf_cat_df")
    voyage_price_mod_vdf_cat_df.createOrReplaceTempView("compute_ppm_voyage")
    vdf_ppm_voyage_sql = """
                          select vyge_id,price_mod_dt,version_start_date,
                                  (sum(gross_revenue)/sum(gross_price_pd)) as gtr_price_pd_am 
                          from compute_ppm_voyage group by vyge_id, price_mod_dt,version_start_date
                        """
    voyage_price_mod_vdf_summary = sql_context.sql(vdf_ppm_voyage_sql)
    voyage_price_mod_vdf_summary = voyage_price_mod_vdf_summary.withColumn("version_start_date_a", lit(
        voyage_price_mod_vdf_summary.version_start_date).cast("date")).drop("version_start_date")
    voyage_price_mod_vdf_summary.createOrReplaceTempView("voyage_price_mod_vdf_summary")
    if debug == 1:
        debug_counts(voyage_price_mod_vdf_summary, "voyage_price_mod_vdf_summary")

        # because the last price value is vyge_arvl date +10 we need to fix the price
    price_mod_with_driver_df = sql_context.sql("""select A.vyge_id,
                                                      A.price_mod_dt,
                                                      A.version_start_date,
                                                      B.gtr_price_pd_am 
                                                from  final_driver A
                                                left join voyage_price_mod_vdf_summary B on A.vyge_id= B.vyge_id and A.price_mod_dt = B.price_mod_dt
                                                          and A.version_start_date = B.version_start_date_a
                                              """)

    # compute prev_ppm_metric
    prev_ppm_metric_rdd = price_mod_with_driver_df \
        .repartition("vyge_id", "version_start_date") \
        .sortWithinPartitions("vyge_id", "version_start_date", asc("price_mod_dt")) \
        .rdd.mapPartitions(populate_prev_ppm, preservesPartitioning=True)

    if debug == 1:
        debug_counts(voyage_price_mod_vdf_summary, "ppm summary")

    ppm_schema = StructType([
        StructField("vyge_id", IntegerType(), True),
        StructField("version_start_date", DateType(), True),
        StructField("price_mod_dt", DateType(), True),
        StructField("prev_gtr_price_pd_am", DecimalType(10, 2), True),
        StructField("gtr_price_pd_am", DecimalType(10, 2), True)
    ])

    ppm_metrics_df = converter.convertRddToDataFrame(prev_ppm_metric_rdd, ppm_schema)
    voyage_ppm_metrics_df = ppm_metrics_df.join(broadcast(final_driver_df),
                                                ["vyge_id", "price_mod_dt", "version_start_date"], "right_outer") \
        .filter("all_price_mod_dt_flag == 1 or rank < 2")
    voyage_ppm_metrics_df.createOrReplaceTempView("ppm_metric")
    if debug == 1:
        debug_counts(voyage_ppm_metrics_df, "ppm metrics")

        ####################################################3

    ### get strm ooo
    # ship_cabin_reserved_filter="date('%s') >= date(%s) and date('%s') < date(%s) \
    #                            and upper(instnc_st_nm)='STANDARD' \
    #                            and upper(reservetype) = 'OUT OF ORDER'" %(start_dt,"vrsn_strt_dts",start_dt,"vrsn_end_dts")

    # ship_cabin_reserved1_df= data_loader.read_data("sha","SHIPCABINRESERVED")\
    # .filter(ship_cabin_reserved_filter)
    # ship_cabin_reserved_df = ship_cabin_reserved1_df.join(voyage_attr_df,\
    #             (voyage_attr_df.ship_cd == ship_cabin_reserved1_df.Code))\
    #           .filter("vyge_dprt_dt >=SailDateFrom and vyge_dprt_dt< SailDateTo")\
    #           .select("vyge_id","vyge_dprt_dt","SailDateFrom","SailDateTo","CabinNumber","ship_cd","vrsn_strt_dts","vrsn_end_dts")
    # if debug == 1:
    #   debug_counts(ship_cabin_reserved1_df,"base_ship_cabin")
    #   debug_counts(ship_cabin_reserved_df,"base_ship_cabin_voyage")

    ooo_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY')"
    ooo_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_filter)
    ooo_consolidated_df.createOrReplaceTempView("ooo_consoloidated")
    # ship_cabin_reserved_df.createOrReplaceTempView("ship_cabin_reserved")
    ooo_consolidated_sql = """
                          select sum(vyge_strm_ooo_strm_cn) as ooo_strm_cn,ooo.vyge_id,ooo.txn_dt
                          from ooo_consoloidated ooo 
                          group by ooo.vyge_id,ooo.txn_dt
                        """
    ooo_inventory_cnt_driver_df = sql_context.sql(ooo_consolidated_sql)
    ooo_inventory_cnt_driver_df.createOrReplaceTempView("ooo_counts")
    if debug == 1:
        debug_counts(ooo_inventory_cnt_driver_df, "ooo_inventory_cnt_driver_df")

        ## get alloc information
    ship_inventory_alloc_filter = "upper(instnc_st_nm)='STANDARD' and upper(allocation_owner_type)='GROUP'"
    ship_inventory_alloc_df = data_loader.read_data("sha", "SHIPINVENTORYALLOC") \
        .filter(ship_inventory_alloc_filter)
    ship_inventory_alloc_merge_driver_df = final_driver_df.join(ship_inventory_alloc_df, \
                                                                ((
                                                                             final_driver_df.ship_cd == ship_inventory_alloc_df.SHIP_CODE) & \
                                                                 (
                                                                             final_driver_df.vyge_dprt_dt == ship_inventory_alloc_df.SAIL_DATE_FROM))) \
        .filter("price_mod_dt >= date(vrsn_strt_dts) \
                                                                  and price_mod_dt < date(vrsn_end_dts) \
                                                                  and date(vrsn_strt_dts) >= date('2016-10-18') and dlgt_res_id is null") \
        .select("vyge_id", "version_start_date", "ship_cd", "price_mod_dt", "allocation_owner_type", "cabin_number")
    ship_inventory_alloc_merge_driver_df.createOrReplaceTempView("ship_inventory_alloc")
    alloc_sql = """
                 select vyge_id,price_mod_dt,version_start_date,count(*) as alloc_grp_bkng_cn 
                 from ship_inventory_alloc 
                 where cabin_number is not null 
                 group by vyge_id,price_mod_dt,version_start_date
               """
    unalloc_sql = """
                 select vyge_id,price_mod_dt,version_start_date,count(*) as unalloc_grp_bkng_cn
                 from ship_inventory_alloc 
                 where cabin_number is null 
                 group by vyge_id,price_mod_dt,version_start_date
               """
    ship_inventory_alloc_df = sql_context.sql(alloc_sql)
    ship_inventory_unalloc_df = sql_context.sql(unalloc_sql)

    merged_group_alloc_unalloc_counts = final_driver_df.join(ship_inventory_alloc_df,
                                                             ["vyge_id", "price_mod_dt", "version_start_date"],
                                                             "left_outer") \
        .join(broadcast(ship_inventory_unalloc_df), ["vyge_id", "price_mod_dt", "version_start_date"], "left_outer")
    merged_group_alloc_unalloc_counts.createOrReplaceTempView("alloc_counts")

    if debug == 1:
        debug_counts(merged_group_alloc_unalloc_counts, "merged_group_alloc_unalloc_counts")

        # coalesce(((alloc_grp_bkng_cn+unalloc_grp_bkng_cn+oh_paid_bkng_cn,cast(ooo_strm_cn as 'int')*100/cast(phys_invtry_strm_cn as 'int'),0) as strm_utlz_pc,
    ### final merge to create hpsppd data set
    final_merge_sql = """
                        select A.vyge_id,
                               A.version_start_date,
                             A.ship_cd,
                             A.vyge_dprt_dt,
                             B.ship_nm,
                             B.ship_short_nm,
                             B.ship_cls_nm,
                             A.vyge_arvl_dt,
                             A.vyge_drtn_nght_cn,
                             A.vyge_itnry_nm,
                             A.orig_vyge_itnry_nm,
                             A.app_vyge_id,
                             A.vyge_dprt_seapt_cd,
                             A.price_mod_dt,
                             datediff(A.vyge_dprt_dt,A.version_start_date) as dy_bef_vyge_cn, 
                             case when A.rank = 1 
                                  then 1 
                                  else 0 
                             end as rcnt_price_mod_in,
                             case when A.rank = 1 
                                  then  
                                      case when datediff(A.vyge_dprt_dt,A.version_start_date) < 0 then datediff(A.vyge_dprt_dt,A.price_mod_dt) else datediff(A.version_start_date,A.price_mod_dt) end 
                                  else datediff(A.price_mod_dt_end,A.price_mod_dt) 
                             end as prev_rt_dy_cn,
                             coalesce(grs_paid_bkng_cn,0) as grs_paid_bkng_cn,
                             coalesce(oh_paid_bkng_cn,0) as oh_paid_bkng_cn,
                             coalesce(paid_bkng_cn,0) as paid_bkng_cn,
                             coalesce(grs_prevl_paid_bkng_cn,0) as grs_prevl_paid_bkng_cn,
                             coalesce(oh_prevl_paid_bkng_cn,0) as oh_prevl_paid_bkng_cn,
                             coalesce(tot_gst_cn/oh_paid_bkng_cn,0) as oh_bkng_avg_gps_vl,
                             coalesce(alloc_grp_bkng_cn,0) as alloc_grp_bkng_cn,
                             coalesce(unalloc_grp_bkng_cn,0) as unalloc_grp_bkng_cn,
                             cast(D.prev_gtr_price_pd_am as decimal(9,2)) as prev_gtr_price_pd_am,
                             cast(coalesce(D.gtr_price_pd_am,0.0) as decimal(9,2)) as gtr_price_pd_am,
                             coalesce(C.ooo_strm_cn,0) as ooo_strm_cn,
                             coalesce(G.phys_invtry_strm_cn,0) as phys_invtry_strm_cn 
                        from  final_driver A 
                        inner join ppm_metric D on A.vyge_id = D.vyge_id and A.price_mod_dt = D.price_mod_dt and A.version_start_date = D.version_start_date
                        left join alloc_counts B on  A.vyge_id = B.vyge_id and A.price_mod_dt = B.price_mod_dt and A.version_start_date = B.version_start_date
                        left join driver_res_baseln_metrics F on A.vyge_id = F.vyge_id and A.price_mod_dt = F.price_mod_dt and A.version_start_date = F.version_start_date                        
                        left join driver_res_paid_booking_cnt H on A.vyge_id = H.vyge_id and A.price_mod_dt = H.price_mod_dt and A.version_start_date = H.version_start_date                        
                        left join physical_inventory_cnt G on A.vyge_id = G.vyge_id and A.price_mod_dt = g.price_mod_dt and A.version_start_date = G.version_start_date
                        left join ooo_counts C on A.vyge_id = C.vyge_id  and A.version_start_date = C.txn_dt
                     """

    final_data_df = sql_context.sql(final_merge_sql)
    final_data_df.createOrReplaceTempView("final_data")
    final_data_with_ship_info_sql = \
        """
     select A.vyge_id,
            A.ship_cd,
            A.version_start_date,
            A.vyge_dprt_dt,
            A.vyge_arvl_dt,
            A.vyge_drtn_nght_cn,
            A.vyge_itnry_nm,
            A.orig_vyge_itnry_nm,
            A.app_vyge_id,
            A.vyge_dprt_seapt_cd,
            A.price_mod_dt,
            A.dy_bef_vyge_cn, 
            A.rcnt_price_mod_in,
            A.prev_rt_dy_cn,
            A.grs_paid_bkng_cn,
            A.oh_paid_bkng_cn,
            A.grs_prevl_paid_bkng_cn,
            A.oh_prevl_paid_bkng_cn,
            A.oh_bkng_avg_gps_vl,
            A.alloc_grp_bkng_cn,
            A.unalloc_grp_bkng_cn,
            A.ooo_strm_cn,
            A.prev_gtr_price_pd_am,
            A.gtr_price_pd_am,
            A.phys_invtry_strm_cn,
            coalesce((grs_paid_bkng_cn-oh_paid_bkng_cn),0) as cncl_paid_bkng_cn,
            coalesce((alloc_grp_bkng_cn+unalloc_grp_bkng_cn+paid_bkng_cn),0) as strm_utlz_cn,
            coalesce((alloc_grp_bkng_cn+unalloc_grp_bkng_cn+paid_bkng_cn+ooo_strm_cn)*100/phys_invtry_strm_cn,0) as strm_utlz_pc,
            coalesce((grs_prevl_paid_bkng_cn-oh_prevl_paid_bkng_cn),0) as cncl_prevl_paid_bkng_cn, 
            A.ship_nm,
            A.ship_short_nm,
            A.ship_cls_nm
        from final_data A
        """
    hpsppd_df = sql_context.sql(final_data_with_ship_info_sql)
    if debug == 1:
        debug_counts(hpsppd_df, "final_data")

    hpsppd_df = hpsppd_df.withColumn("vrsn_strt_dts",
                                     lit(concat(hpsppd_df.version_start_date, lit(" 04:00:00"))).cast("timestamp")) \
        .withColumn("vrsn_end_dts", lit('9999-12-31 00:00:00').cast("timestamp")).drop("version_start_date")
    folder_name = "%s%s" % ("hist_price_vyge_price_pd_baseln/run_dt=", str(end_dt))
    data_loader.write_data("dm", folder_name, None, hpsppd_df)
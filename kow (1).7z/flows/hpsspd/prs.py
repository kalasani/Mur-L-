name="Anji"
ps={"mynma e"+name+""}
# from datetime import datetime, timedelta
# tmp = '2015-10-28 16:09:59'
# start_date_time = datetime.strptime(str(tmp), "%Y-%m-%d %H:%M:%S")
# print(start_date_time.date())
# # date_str = "%s %s" % (str(self.start_date_time.date()), "23:59:59")
# # self.end_date_time = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
# # self.BEGIN_DT = datetime.strptime('1800-01-01', "%Y-%m-%d").date()
#
# #import datetime
# # datetime.datetime.now().date()
# # datetime.date(2015, 10, 28)
# # tmp = '2015-10-28 16:09:59'
# # dt = datetime.datetime.strptime(tmp,'%Y-%m-%d %H:%M:%S')
# # print(type(dt.date()))
# # ref= dt.strftime("%Y-%m-%d").date()
# # start_dt = datetime.strptime(sys.argv[2], "%Y-%m-%d").date()
# # print(type(ref))
# # print(ref)
# # date_string = f'\{dt:%Y-%m-%d}'
# # print(date_string)
# #date_string = f'{dt:%Y-%m-%d}'
# # print(type(dt))
# # print(dt)
# # dt.date()
# # print("ds=======>",date_string)

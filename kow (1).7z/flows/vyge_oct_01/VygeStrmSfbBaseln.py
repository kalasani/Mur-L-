import sys, os
from os import path
from datetime import timedelta
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *
from datetime import datetime, timedelta
sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob import *;
from voyagestateroompriceboh.DataLoaderVoyageStateRoomPriceDM import *;
from voyagestateroompriceboh.VygeStateRoomAodMetrics import *;
from voyagestateroompriceboh.VoyagePriceBOHDMJob import *;
from voyagestateroompriceboh.VygeStateRoomDriver import *;
from DclrmsPdpIntraDayJob import *;
class VygeStrmSfbBaseln(BaseJob):
    #def __init__(self):
    #   self.table = "VygeStrmSfbBaseln"
    #    super(VygeStrmSfbBaseln, self).__init__(self.table)

    def __init__(self,runMode=None,last_fetch_dts=None):
        print("Init_Process ===>>From Intraday Constructor  ")
        self.table = "VygeStrmSfbBaseln"

        self.last_fetch_dts = None
        self.runMode="Normal"
        if runMode != None and runMode == "Intraday":
                        self.runMode="Intraday";
                        self.last_fetch_dts = last_fetch_dts;
                        print("last_fetch_dts===>>",self.last_fetch_dts)
                        #dt = datetime.datetime.strptime(self.last_fetch_dts, '%Y-%m-%d %H:%M:%S')
                        start_date_time = datetime.strptime(str(self.last_fetch_dts), "%Y-%m-%d %H:%M:%S")
                        self.last_fetch_date =start_date_time.date();
        super(VygeStrmSfbBaseln, self).__init__(self.table)


    def setUp(self):
        self.runType = self.load_type
        self.intradayConfig = self.config.readData("pdp_dclrms_intraday");
        if self.parameters.max_dataload_dt is None :
                self.max_data_load_dt=self.end_date + timedelta(days=1)
        else :
           self.max_data_load_dt=datetime.strptime(self.parameters.max_dataload_dt, "%Y-%m-%d").date()

        if self.runMode=="Intraday":
            self.runType="Intraday"
            self.start_date = self.last_fetch_date
            self.end_date = self.last_fetch_date
            self.max_data_load_dt = self.last_fetch_date + timedelta(days=1)
        else:
            self.last_fetch_dts=None




    def loadData(self):
        print "loadData"
        print("start_date==>", self.start_date)
        print("end_date==>", self.end_date)
        print("max_data_load_dt==>", self.max_data_load_dt)
        print("last_fetch_dts==>", self.last_fetch_dts)
        print("spark==>", self.spark)
        print("s3_root_bucket==>", self.s3_root_bucket)
        print("data_loader==>", self.data_loader)
        print("debug==>", self.debug)
        dataLoader = DataLoaderVoyageStateRoomPriceDM(self.start_date, self.end_date, self.spark, self.s3_root_bucket,self.data_loader,self.runType, self.debug)
        print("Data Loader Completed ===>", dataLoader)
        dataLoader.run_data_loader_voyage();

    def createDriver(self):
        VygeStateRoomDriver.run_VoyageStateRoomBOH_Driver(self.runType, self.start_date, self.end_date,self.max_data_load_dt,self.last_fetch_dts, self.spark, self.s3_root_bucket,self.data_loader,self.debug)

    def preProcess(self):
        pass

    def process(self):
        VygeStateRoomAodMetrics.run_VoyageStateRoomBOH_Calculations(self.start_date,self.end_date,self.spark,self.s3_root_bucket,self.data_loader,self.debug)

    def writeToHDFS(self):
        self.run_VoyageStateRoomBOH_FinalMerge();

    def tearDown(self):
        pass


    def run_VoyageStateRoomBOH_FinalMerge(self):
        """ reads proc price pt from S3 and identfies if there is a change
        Attributes:
          start_dt : The start date for which price changes need to be detected
          end_dt :
          sql_context:  spark sql_context
          s3_bucket: s3 bucket where the data resides
          debug
        """
        final_voyagestate_room_df = self.spark.sql(
            """
            SELECT
                 driver.vyge_id
                ,driver.strm_typ_cd
                ,driver.sfb_nm
                ,driver.txn_dt
                ,driver.app_vyge_id
                ,coalesce(driver.ship_cd,0) as ship_cd
                ,driver.vyge_dprt_dt as vyge_dprt_dt
                ,cast(coalesce(driver.vyge_drtn_nght_cn,0) as int) as vyge_drtn_nght_cn
                ,cast(coalesce(driver.dy_bef_vyge_cn,0) as int) as dy_bef_vyge_cn
                ,coalesce(driver.vyge_dprt_seapt_cd,0) as vyge_dprt_seapt_cd
                ,coalesce(driver.vyge_itnry_nm,0) as vyge_itnry_nm
                ,driver.orig_vyge_itnry_nm
                ,driver.vyge_opn_dt as vyge_opn_dt
                ,coalesce(driver.strm_ctgy_nm,0) as strm_ctgy_nm

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                   THEN driver.batch_run_dts ELSE NULL
                 END AS batch_run_dts

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                   THEN driver.as_of_dt ELSE NULL
                 END AS as_of_dt

                ,cast(coalesce((phys_invtry_strm_cn_df.phys_invtry_strm_cn),0) as int) as phys_invtry_strm_cn
                ,cast(coalesce((ooo_strm_cn_df.ooo_strm_cn),0) as int) as ooo_strm_cn
                ,sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn as sl_lim_strm_typ_cn
                ,sl_lim_rcmd_strm_typ_cn_df.rcmd_sl_lim_strm_typ_cn as rcmd_sl_lim_strm_typ_cn
                ,oh_paid_bkng_cn_df.oh_paid_bkng_cn as oh_paid_bkng_cn
                ,expect_oh_bkng_cn_df.EXPECT_OH_BKNG_CN as expect_oh_bkng_cn

                ,price_rcmd_run_dts_df.price_impct_lvl_am as price_impct_lvl_am
                ,price_rcmd_run_dts_df.plan_cfdnc_lvl_am  as plan_cfdnc_lvl_am

                ,udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.udf_as_of_dt_rcmd_price_am as udf_as_of_dt_rcmd_price_am
                ,udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.udf_curr_price_am as udf_curr_price_am
                ,udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.udf_rcmd_price_am as udf_rcmd_price_am

                ,vf_grs_pd_am_df.vfd_grs_pd_am as vfd_grs_pd_am
                ,vf_grs_pd_am_df.vfa_grs_pd_am as vfa_grs_pd_am
                ,vf_grs_pd_am_df.vfc_grs_pd_am as vfc_grs_pd_am
                ,vf_grs_pd_am_df.vfi_grs_pd_am  as vfi_grs_pd_am
                ,gawf_am_df.gawf_am as gawf_am

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                          THEN price_rcmd_run_dts_df.rcmd_vfd_grs_pd_am
                    ELSE NULL
                 END as rcmd_vfd_grs_pd_am

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                          THEN price_rcmd_run_dts_df.rcmd_vfa_grs_pd_am
                    ELSE NULL
                 END as rcmd_vfa_grs_pd_am

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                          THEN price_rcmd_run_dts_df.rcmd_vfc_grs_pd_am
                    ELSE NULL
                 END as rcmd_vfc_grs_pd_am

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                          THEN price_rcmd_run_dts_df.rcmd_vfi_grs_pd_am
                    ELSE NULL
                 END as rcmd_vfi_grs_pd_am

               ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                          THEN rcmd_gawf_am_df.rcmd_gawf_am
                    ELSE NULL
                 END as rcmd_gawf_am
                ,
                CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                    THEN driver.price_rcmd_run_dts  ELSE NULL
                 END as price_rcmd_run_dts

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                    THEN driver.expect_oh_bkng_run_dts  ELSE NULL
                 END as expect_oh_bkng_run_dts

                 ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                    THEN driver.uncnstrn_dmnd_fcst_run_dts  ELSE NULL
                 END as uncnstrn_dmnd_fcst_run_dts


                ,vf_grs_pd_am_df.price_src_nm as price_src_nm
                ,sl_lim_strm_typ_cn_df.sl_lim_src_nm as sl_lim_src_nm

                ,aod_grs_pd_am_df.aod_rcmd_vfd_grs_pd_am as aod_rcmd_vfd_grs_pd_am
                ,aod_grs_pd_am_df.aod_rcmd_vfa_grs_pd_am as aod_rcmd_vfa_grs_pd_am
                ,aod_grs_pd_am_df.aod_rcmd_vfc_grs_pd_am as aod_rcmd_vfc_grs_pd_am
                ,aod_grs_pd_am_df.aod_rcmd_vfi_grs_pd_am as aod_rcmd_vfi_grs_pd_am
                ,aod_gawf_am_df.AOD_RCMD_GAWF_AM as aod_rcmd_gawf_am

                ,vdd_grs_pd_am_df.VDD_RCMD_VFD_GRS_PD_AM as vdd_rcmd_vfd_grs_pd_am
                ,vdd_grs_pd_am_df.VDD_RCMD_VFA_GRS_PD_AM as vdd_rcmd_vfa_grs_pd_am
                ,vdd_grs_pd_am_df.VDD_RCMD_VFC_GRS_PD_AM as vdd_rcmd_vfc_grs_pd_am
                ,vdd_grs_pd_am_df.VDD_RCMD_VFI_GRS_PD_AM as vdd_rcmd_vfi_grs_pd_am
                ,vdd_gawf_am_df.VDD_RCMD_GAWF_AM as vdd_rcmd_gawf_am

                ,cast(coalesce((vdd_expect_oh_bkng_cn_df.vdd_expect_oh_bkng_cn),0) as int ) as vdd_expect_oh_bkng_cn

                ,CASE WHEN  driver.txn_dt >= date(driver.max_btch_run_dts)
                   THEN cast(coalesce((datediff(driver.vyge_dprt_dt,date(driver.as_of_dt))),0) as int)  ELSE NULL
                 END AS aod_dy_bef_vyge_cn

                FROM driver as driver

                LEFT OUTER JOIN ooo_strm_cn_df as ooo_strm_cn_df
                ON driver.vyge_id=ooo_strm_cn_df.vyge_id
                AND driver.strm_typ_cd = ooo_strm_cn_df.strm_typ_cd
                AND driver.txn_dt = ooo_strm_cn_df.txn_dt


                LEFT OUTER JOIN phys_invtry_strm_cn_df as phys_invtry_strm_cn_df
                ON driver.vyge_id=phys_invtry_strm_cn_df.vyge_id
                AND driver.strm_typ_cd = phys_invtry_strm_cn_df.strm_typ_cd
                AND driver.txn_dt = phys_invtry_strm_cn_df.txn_dt
                AND driver.sfb_nm = phys_invtry_strm_cn_df.sfb_nm


                LEFT OUTER JOIN oh_paid_bkng_cn_df as oh_paid_bkng_cn_df
                ON driver.vyge_id=oh_paid_bkng_cn_df.vyge_id
                AND driver.strm_typ_cd = oh_paid_bkng_cn_df.strm_typ_cd
                AND driver.sfb_nm = oh_paid_bkng_cn_df.sfb_nm
                AND driver.txn_dt = oh_paid_bkng_cn_df.txn_dt




                LEFT OUTER JOIN expect_oh_bkng_cn_df as expect_oh_bkng_cn_df
                ON driver.vyge_id=expect_oh_bkng_cn_df.vyge_id
                AND driver.strm_typ_cd = expect_oh_bkng_cn_df.strm_typ_cd
                AND driver.sfb_nm = expect_oh_bkng_cn_df.sfb_nm
                AND driver.txn_dt = expect_oh_bkng_cn_df.txn_dt

                LEFT OUTER JOIN vdd_expect_oh_bkng_cn_df as vdd_expect_oh_bkng_cn_df
                ON driver.vyge_id=vdd_expect_oh_bkng_cn_df.vyge_id
                AND driver.strm_typ_cd = vdd_expect_oh_bkng_cn_df.strm_typ_cd
                AND driver.sfb_nm = vdd_expect_oh_bkng_cn_df.sfb_nm
                AND driver.txn_dt = vdd_expect_oh_bkng_cn_df.txn_dt

                LEFT OUTER JOIN price_rcmd_run_dts_df as price_rcmd_run_dts_df
                ON driver.vyge_id=price_rcmd_run_dts_df.vyge_id
                AND driver.strm_typ_cd = price_rcmd_run_dts_df.strm_typ_cd
                AND driver.sfb_nm = price_rcmd_run_dts_df.sfb_nm
                AND driver.txn_dt = price_rcmd_run_dts_df.txn_dt

                LEFT OUTER JOIN aod_grs_pd_am_df as aod_grs_pd_am_df
                ON driver.vyge_id=aod_grs_pd_am_df.vyge_id
                AND driver.strm_typ_cd = aod_grs_pd_am_df.strm_typ_cd
                AND driver.txn_dt = aod_grs_pd_am_df.txn_dt

                LEFT OUTER JOIN vdd_grs_pd_am_df as vdd_grs_pd_am_df
                ON driver.vyge_id=vdd_grs_pd_am_df.vyge_id
                AND driver.strm_typ_cd =vdd_grs_pd_am_df.strm_typ_cd
                AND driver.txn_dt = vdd_grs_pd_am_df.txn_dt

                LEFT OUTER JOIN udf_uncnstrndmnd_expect_oh_bkng_run_dts_df as udf_uncnstrndmnd_expect_oh_bkng_run_dts_df
                ON driver.vyge_id = udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.vyge_id
                AND driver.strm_typ_cd = udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.strm_typ_cd
                AND driver.sfb_nm = udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.sfb_nm
                AND driver.txn_dt = udf_uncnstrndmnd_expect_oh_bkng_run_dts_df.txn_dt

                LEFT OUTER JOIN   vf_grs_pd_am_df as vf_grs_pd_am_df
                ON driver.vyge_id=vf_grs_pd_am_df.vyge_id
                AND driver.strm_typ_cd=vf_grs_pd_am_df.strm_typ_cd
                AND driver.sfb_nm = vf_grs_pd_am_df.sfb_nm
                AND driver.txn_dt = vf_grs_pd_am_df.txn_dt

                LEFT OUTER JOIN gawf_am_df as gawf_am_df
                ON driver.vyge_id=gawf_am_df.vyge_id
                AND driver.strm_typ_cd =gawf_am_df.strm_typ_cd
                AND driver.sfb_nm = gawf_am_df.sfb_nm
                AND driver.txn_dt = gawf_am_df.txn_dt

                LEFT OUTER JOIN rcmd_gawf_am_df as rcmd_gawf_am_df
                ON driver.vyge_id=rcmd_gawf_am_df.vyge_id
                AND driver.strm_typ_cd =rcmd_gawf_am_df.strm_typ_cd
                AND driver.sfb_nm = rcmd_gawf_am_df.sfb_nm
                AND driver.txn_dt = rcmd_gawf_am_df.txn_dt

                LEFT OUTER JOIN aod_gawf_am_df as aod_gawf_am_df
                ON driver.vyge_id=aod_gawf_am_df.vyge_id
                AND driver.strm_typ_cd =aod_gawf_am_df.strm_typ_cd
                AND driver.txn_dt = aod_gawf_am_df.txn_dt

                LEFT OUTER JOIN vdd_gawf_am_df as vdd_gawf_am_df
                ON driver.vyge_id=vdd_gawf_am_df.vyge_id
                AND driver.strm_typ_cd =vdd_gawf_am_df.strm_typ_cd
                AND driver.txn_dt = vdd_gawf_am_df.txn_dt

                LEFT OUTER JOIN  sl_lim_rcmd_strm_typ_cn_df as sl_lim_rcmd_strm_typ_cn_df
                ON driver.vyge_id=sl_lim_rcmd_strm_typ_cn_df.vyge_id
                AND driver.strm_typ_cd =sl_lim_rcmd_strm_typ_cn_df.strm_typ_cd
                AND driver.sfb_nm = sl_lim_rcmd_strm_typ_cn_df.sfb_nm
                AND driver.txn_dt = sl_lim_rcmd_strm_typ_cn_df.txn_dt

                LEFT OUTER JOIN  sl_lim_strm_typ_cn_df as sl_lim_strm_typ_cn_df
                ON driver.vyge_id=sl_lim_strm_typ_cn_df.vyge_id
                AND driver.strm_typ_cd =sl_lim_strm_typ_cn_df.strm_typ_cd
                AND driver.sfb_nm = sl_lim_strm_typ_cn_df.sfb_nm
                AND driver.txn_dt = sl_lim_strm_typ_cn_df.txn_dt

            """)

        final_voyagestate_room_df = final_voyagestate_room_df.dropDuplicates();
        final_voyagestate_room_df.createOrReplaceTempView("final_driver")
        if self.debug == 1:
            DebugCount.count_check(final_voyagestate_room_df, "final_voyagestate_room_df info ")
        folder_name = "%s%s" % ("vyge_strm_typ_sfb_baseln/partition_dt=", self.end_date)
        #self.data_loader.write_data("dm", folder_name, None, final_voyagestate_room_df.coalesce(10))
        self.data_loader.write_data_by_run_dts("dm", folder_name, self.start_date, self.end_date, self.load_type,
                                               final_voyagestate_room_df.coalesce(10))

    def updateHighWaterMark(self, maxRunDTS):
        print(" For updateHighWaterMark (Increment /Full Load operation ")
        data = {

                "env.name": self.env.env_name,
                "job.name": "pdp_dclrms_intraday",
                "pdp.intraday.high.water.mark.dts": maxRunDTS,
                "price_config.high.water.mark.dts": maxRunDTS,
                "sl_lim_config.high.water.mark.dts": maxRunDTS,
                "sl_lim_rcmd.high.water.mark.dts": maxRunDTS,
                "price_rcmd_dtl.high.water.mark.dts": maxRunDTS,
                "expect_oh_bkng.high.water.mark.dts": maxRunDTS,
                "uncnstrn_bkng.high.water.mark.dts": maxRunDTS,
                "uncnstrn_dmnd_fcs.high.water.mark.dts": maxRunDTS,
                "job.debug": self.intradayConfig.debug,
                "etl.load.type": self.intradayConfig.load_type,
                "etl.run.bus.prd.start.timestamp":  self.intradayConfig.start_date,
                "etl.run.bus.prd.end.timestamp":  self.intradayConfig.end_date,
                "etl.run.max_dataload_dt": self.intradayConfig.max_dataload_dt,
                "teradata.publish.flag":self.intradayConfig.td_publish_flag,
                "etl.load.delta.period": self.intradayConfig.load_delta_period,
                "etl.load.loop.counter": self.intradayConfig.load_loop_counter,
                "etl.load.post.arrival.day.count": self.intradayConfig.load_post_arrival_day_count
                }
        self.intradayConfig = self.config.writeData("pdp_dclrms_intraday", data);


if __name__ == '__main__':

    try:
        print("VoyageStateROOM BOH JOB starts Here  ")
        obj = VygeStrmSfbBaseln()
        obj.execute()
        print("VoyageStateROOM BOH JOB ends Here  ")

        print("VoyagePriceBOHDMJob  JOB starts Here  ")
        obj_voyageprice=VoyagePriceBOHDMJob();
        obj_voyageprice.execute()
        print("VoyagePriceBOHDMJob  JOB ends Here  ")

        print("DclrmsPdpIntraDayJob  JOB starts Here  ")
        ref = DclrmsPdpIntraDayJob()
        response = ref.readDataTeradataForFullLoadOrIncrementLoad()
        print("max(btch_run_dts value is ====>", response)
        print("Before calling Hbase update operation")
        obj.updateHighWaterMark(response);
        print(" Hbase update operation completed")
        print("DclrmsPdpIntraDayJob  JOB End Here  ")



    except:
        traceback.print_exc()
        sys.exit(-1)

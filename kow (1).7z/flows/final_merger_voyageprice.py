#####################################################################################

# Project           : DCL RM - Disney Cruise Line Revenue Management                #
# Program name      : VoyagePrice-BOH - write_to_s3                             #
# Author            : Anjaiah M                                                     #
# Date created      : 20180616                                                      #
# Purpose           : write data into s3 as a daily partition                       #
# Revision History  :                                                               #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                #
# 20180618    Anjaiah M   Chris                                                     #
#                                                                                   #

#####################################################################################


#################################################################################

# STEP 1: Initializing SPARK variable and importing dependent functions/objects #

#################################################################################


from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from flows.utils.S3DataLoader import *
from flows.jobs.proc_price_pt_diff import *
from flows.jobs.con_resbaseln import *
from flows.utils.DataFrameUtil import *

from pyspark.sql.types import *


def debug_counts(dataframe, name):
    print

    " Debug start ************************************************************************ %s " % name

    cnt = dataframe.count()

    print("DataFrame Name is ", name, "  <<==>> Count INFO", cnt)

    # dataframe.show()

    try:

        # dataframe.filter("vyge_id=153011").show()

        dataframe.show(10)

    except:

        print

        " exception"

    print

    " Debug counts ************************************************************************ %s " % cnt

    print

    " Debug end ************************************************************************ %s " % name


# TODO: sum(cast(coalesce((driver.oh_paid_bkng_cn),0) as int)) as oh_paid_bkng_cn , -- read from consolidated set abd add

def calcPhysInvntryStrmCn(spark, data_loader, debug) :
    print("calculating physical inventory")
    ship_filter = " strm_typ_cd NOT IN ( 'IGT', 'OGT', 'VGT', 'XAM','GTY', 'IRG' ) and UPPER(instnc_st_nm) = 'STANDARD' "
    print("ship_strm_typ_filter", ship_filter)
    ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP").filter(ship_filter)
    #ship_strm_strm_df.printSchema();
    ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")
   
    #print("Done Before ops")
    vyge_txn_dt_df = spark.sql(""" select distinct driver.vyge_id,driver.ship_cd ,driver.vyge_dprt_dt,driver.txn_dt
            FROM driver as driver 
             """)
    
    vyge_txn_dt_df.createOrReplaceTempView("vyge_txn_dt_df");
    
    phys_invtry_strm_cn_df = spark.sql(""" select driver.vyge_id,driver.txn_dt,count(*) as phys_invtry_strm_cn 
        from ship_strm_strm_typ as ship INNER JOIN vyge_txn_dt_df as driver 
        ON driver.ship_cd=ship.ship_cd 
        AND driver.vyge_dprt_dt >= date(ship.ship_strm_strm_strt_dts)
        AND driver.vyge_dprt_dt < date(ship.ship_strm_strm_end_dts)
        AND driver.txn_dt >= date(ship.vrsn_strt_dts)
        AND driver.txn_dt < date(ship.vrsn_end_dts)
        group by driver.vyge_id,driver.txn_dt """)

    phys_invtry_strm_cn_df.createOrReplaceTempView("phys_invtry_strm_cn_df");
    if debug == 1:
        debug_counts(phys_invtry_strm_cn_df, "phys_invtry_strm_cn_df")
 
 
def calc_vf_grs_pd_am(spark, data_loader, debug) :
  
	calc_vf_grs_pd_am_df = spark.sql(
        	 """   
        	 SELECT 
			 driver.vyge_id as vyge_id,
			 driver.sfb_nm as sfb_nm,
			 driver.txn_dt as txn_dt,
			 coalesce((phy_invtry.phys_invtry_strm_cn),0) as phys_invtry_strm_cn ,

			 sum(driver.vfd_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vfd_grs_pd_am ,
			 sum(driver.vfa_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vfa_grs_pd_am ,
			 sum(driver.vfc_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vfc_grs_pd_am ,
			 sum(driver.vfi_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vfi_grs_pd_am ,
			 sum(driver.gawf_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as gawf_am ,

			 sum(driver.rcmd_vfd_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as rcmd_vfd_grs_pd_am ,
			 sum(driver.rcmd_vfa_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as rcmd_vfa_grs_pd_am ,
			 sum(driver.rcmd_vfc_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as rcmd_vfc_grs_pd_am ,
			 sum(driver.rcmd_vfi_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as rcmd_vfi_grs_pd_am ,
			 sum(driver.rcmd_gawf_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as rcmd_gawf_am ,

			 sum(driver.aod_rcmd_vfd_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as aod_rcmd_vfd_grs_pd_am ,
			 sum(driver.aod_rcmd_vfa_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as aod_rcmd_vfa_grs_pd_am ,
			 sum(driver.aod_rcmd_vfc_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as aod_rcmd_vfc_grs_pd_am ,
			 sum(driver.aod_rcmd_vfi_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as aod_rcmd_vfi_grs_pd_am ,
			 sum(driver.aod_rcmd_gawf_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as aod_rcmd_gawf_am ,

			 sum(driver.vdd_rcmd_vfd_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vdd_rcmd_vfd_grs_pd_am ,
			 sum(driver.vdd_rcmd_vfa_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vdd_rcmd_vfa_grs_pd_am  ,
			 sum(driver.vdd_rcmd_vfc_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vdd_rcmd_vfc_grs_pd_am ,
			 sum(driver.vdd_rcmd_vfi_grs_pd_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as vdd_rcmd_vfi_grs_pd_am ,
			 sum(driver.vdd_rcmd_gawf_am*driver.phys_invtry_strm_cn)/phy_invtry.phys_invtry_strm_cn as  vdd_rcmd_gawf_am  

			 FROM driver as driver 

			 LEFT OUTER JOIN phys_invtry_strm_cn_df as phy_invtry                    
			 ON driver.vyge_id = phy_invtry.vyge_id
			 AND driver.txn_dt = phy_invtry.txn_dt

			 WHERE driver.sfb_nm = 'PREVAIL'

			  GROUP BY
				 driver.vyge_id,
				 driver.sfb_nm,
				 driver.txn_dt,
				 phy_invtry.phys_invtry_strm_cn 
         """)
		
	calc_vf_grs_pd_am_df.createOrReplaceTempView("calc_vf_grs_pd_am_df");
	if debug == 1:
		debug_counts(calc_vf_grs_pd_am_df, "calc_vf_grs_pd_am_df")
		
def calc_expect_oh(spark, data_loader, debug) :
    expect_oh_bkng_cn_df = spark.sql(
        """
                SELECT
                        vyge_sfb_baseln.vyge_id,
                        vyge_sfb_baseln.txn_dt ,
                        vyge_sfb_baseln.sfb_nm,
                        sum(expect_oh_bkng.expect_oh_bkng_cn) as  expect_oh_bkng_cn
                
                FROM   driver as vyge_sfb_baseln
                    INNER JOIN
                    expect_oh_bkng  as expect_oh_bkng
                    ON vyge_sfb_baseln.app_vyge_id = expect_oh_bkng.app_vyge_id
                    AND expect_oh_bkng.sfb_nm = vyge_sfb_baseln.sfb_nm
                    AND  expect_oh_bkng.dy_bef_vyge_cn = vyge_sfb_baseln.dy_bef_vyge_cn
                    AND expect_oh_bkng.expect_oh_bkng_run_dts= vyge_sfb_baseln.expect_oh_bkng_run_dts 
                    AND  date(vyge_sfb_baseln.batch_run_dts) <= date(vyge_sfb_baseln.txn_dt)
        
                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
                    ON vyge_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
                    AND vyge_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
                    AND date(vyge_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max) 
                GROUP BY
                    vyge_sfb_baseln.vyge_id,
                    vyge_sfb_baseln.sfb_nm,
                    vyge_sfb_baseln.txn_dt               
                
         """ ).dropDuplicates()
    expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_df");
    if debug == 1:
		debug_counts(expect_oh_bkng_cn_df, "expect_oh_bkng_cn_df")
		
def calc_udf(spark, data_loader, debug) :		
    udf_df = spark.sql(
        """
                SELECT
                    vyge_sfb_baseln.vyge_id
                    ,vyge_sfb_baseln.sfb_nm
                    ,vyge_sfb_baseln.txn_dt
                
                    ,sum(coalesce(uncnstrn_bkng.udf_as_of_dt_rcmd_price_am,0)) AS  udf_as_of_dt_rcmd_price_am
                    ,sum(coalesce(uncnstrn_bkng.udf_curr_price_am,0)) as udf_curr_price_am
                    ,sum(coalesce(uncnstrn_bkng.udf_rcmd_price_am,0)) as udf_rcmd_price_am

                FROM

                    driver as vyge_sfb_baseln
                    INNER JOIN uncnstrn_bkng as uncnstrn_bkng
                    ON vyge_sfb_baseln.app_vyge_id = uncnstrn_bkng.app_vyge_id 
                    AND uncnstrn_bkng.uncnstrn_bkng_run_dts = vyge_sfb_baseln.uncnstrn_bkng_run_dts 
                    AND uncnstrn_bkng.partition_dt = date(vyge_sfb_baseln.uncnstrn_bkng_run_dts)
                    AND vyge_sfb_baseln.sfb_nm = uncnstrn_bkng.sfb_nm 
                    AND uncnstrn_bkng.dy_bef_vyge_cn = vyge_sfb_baseln.dy_bef_vyge_cn
                    AND  date(vyge_sfb_baseln.batch_run_dts) <= date(vyge_sfb_baseln.txn_dt)

                
                    INNER JOIN strm_typ_nest_config as strm_typ_nest_config 
                    ON vyge_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd 
                    AND vyge_sfb_baseln.strm_typ_cd = strm_typ_nest_config.src_sys_strm_typ_nm 
                    AND date(vyge_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max) 
				GROUP BY
                    vyge_sfb_baseln.vyge_id,
                    vyge_sfb_baseln.sfb_nm,
                    vyge_sfb_baseln.txn_dt  
					
            """).dropDuplicates()

    udf_df.createOrReplaceTempView("udf_df")
    if debug == 1:
        debug_counts(udf_df, "udf_df count info")
		

def calc_sl_lim_rcmd_strm_typ_cn(spark, data_loader, debug) :		

    min_driver_df = spark.sql( """ SELECT distinct vyge_id,app_vyge_id, 
									ship_cd,
									vyge_dprt_dt, 
									sl_lim_rcmd_run_dts_max,
									dy_bef_vyge_cn,
									sl_rcmd_dy_bef_vyge_rnge_strt_cn_max, 
									txn_dt , 
									batch_run_dts , 
									FROM driver 
									WHERE date(batch_run_dts) <= date(txn_dt)""")
    min_driver_df.createOrReplaceTempView("min_driver_df")

    sl_lim_rcmd_strm_typ_cn_df = spark.sql("""
                  SELECT
                    vyge_sfb_baseln.app_vyge_id
                     , vyge_sfb_baseln.vyge_id
                    , vyge_sfb_baseln.txn_dt AS txn_dt
                    ,coalesce((sl_lim_rcmd.rcmd_sl_lim_strm_typ_cn),sl_lim_rcmd_by_max_cnt.rcmd_sl_lim_strm_typ_cn,null)  AS rcmd_sl_lim_strm_typ_cn
                FROM   min_driver_df as vyge_sfb_baseln
				
		INNER JOIN strm_typ_nest_config as strm_typ_nest_config
        ON vyge_sfb_baseln.ship_cd = strm_typ_nest_config.ship_cd
		AND strm_typ_nest_config.strm_ctgy_nm ='SHIPSCI'
		AND strm_typ_nest_config.sci_rcmd_excl_in ='N'
		AND strm_typ_nest_config.lgcl_del_in ='N'
        AND date(vyge_sfb_baseln.txn_dt) >=  date(strm_typ_nest_config.strm_typ_nest_config_strt_dts_max)
				
        LEFT OUTER JOIN sl_lim_rcmd as sl_lim_rcmd
        ON vyge_sfb_baseln.app_vyge_id = sl_lim_rcmd.app_vyge_id
		AND sl_lim_rcmd.instnc_st_nm = 'STANDARD'
		AND sl_lim_rcmd.lgcl_del_in ='N'
		AND sl_im_rcmd.strm_ocpncy_cn IS NULL
                AND strm_typ_nest_config.src_sys_strm_typ_nm = sl_lim_rcmd.src_sys_strm_typ_nm 
		AND sl_lim_rcmd.sl_lim_rcmd_run_dts  = vyge_sfb_baseln.sl_lim_rcmd_run_dts_max
                And date( vyge_sfb_baseln.batch_run_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                AND
                (
                    vyge_sfb_baseln.dy_bef_vyge_cn >= sl_lim_rcmd.dy_bef_vyge_rnge_strt_cn
                    AND vyge_sfb_baseln.dy_bef_vyge_cn <= sl_lim_rcmd.dy_bef_vyge_rnge_end_cn

                )

                LEFT OUTER JOIN  sl_lim_rcmd as sl_lim_rcmd_by_max_cnt
                ON vyge_sfb_baseln.app_vyge_id = sl_lim_rcmd_by_max_cnt.app_vyge_id
		AND sl_lim_rcmd_by_max_cnt.instnc_st_nm = 'STANDARD'
		AND sl_lim_rcmd_by_max_cnt.lgcl_del_in ='N'
		AND sl_lim_rcmd_by_max_cnt.strm_ocpncy_cn IS NULL
                AND strm_typ_nest_config.src_sys_strm_typ_nm = sl_lim_rcmd_by_max_cnt.src_sys_strm_typ_nm
		AND sl_lim_rcmd_by_max_cnt.sl_lim_rcmd_run_dts  = vyge_sfb_baseln.sl_lim_rcmd_run_dts_max 
                And date( vyge_sfb_baseln.batch_run_dts) <= vyge_strm_typ_sfb_baseln.txn_dt
                AND
                (
                         sl_lim_rcmd_by_max_cnt.dy_bef_vyge_rnge_strt_cn = vyge_sfb_baseln.sl_rcmd_dy_bef_vyge_rnge_strt_cn_max
                )            
              """).dropDuplicates()
			  
    sl_lim_rcmd_strm_typ_cn_df.createOrReplaceTempView("sl_lim_rcmd_strm_typ_cn_df")
    if debug == 1:
        debug_counts(sl_lim_rcmd_strm_typ_cn_df, "sl_lim_rcmd_strm_typ_cn_df count info")

        
def run_VoyagePriceBOH_FinalMerge(start_dt, end_dt, spark, s3_bucket, debug):
    """ reads proc price pt from S3 and identfies if there is a change

    Attributes:

      start_dt : The start date for which price changes need to be detected

      end_dt :

      sql_context:  spark sql_context

      s3_bucket: s3 bucket where the data resides

      debug

    """

    data_loader = S3DataLoader(spark, s3_bucket)
    con_res_base_df = data_loader.read_data("con", "vyge_sfb_res_baseln_cncl")
    con_res_base_df.createOrReplaceTempView("oh_paid_res_df")
   


    ooo_vyg_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "
    ooo_vyg_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_vyg_filter)
    ooo_vyg_consolidated_df.createOrReplaceTempView("ooo_vyg_consoloidated")

    ooo_vyg_consolidated_sql = """
                              select 
                              sum(vyge_strm_ooo_strm_cn) as ooo_strm_cn
                              ,sum(vyge_strm_phys_invtry_strm_cn) as phys_invtry_strm_cn 
                              ,ooo.txn_dt as txn_dt
                              ,ooo.vyge_id as vyge_id 
                              from ooo_vyg_consoloidated ooo 
                              group by 
                                ooo.vyge_id
                               ,ooo.txn_dt
                            """
    ooo_vyg_inventory_cnt_driver_df = spark.sql(ooo_vyg_consolidated_sql).dropDuplicates()
    ooo_vyg_inventory_cnt_driver_df.createOrReplaceTempView("ooo_vyg_inventory_cnt_driver_df");
    if debug == 1:
        debug_counts(ooo_vyg_inventory_cnt_driver_df, "ooo_vyg_inventory_cnt_driver_df")

    #compute physical inventory
    calcPhysInvntryStrmCn(spark, data_loader, debug)
    calc_vf_grs_pd_am(spark, data_loader, debug)
    calc_expect_oh(spark, data_loader, debug)
    calc_udf(spark, data_loader, debug)
    calc_sl_lim_rcmd_strm_typ_cn(spark, data_loader, debug)
	
    intermediate_df = spark.sql(
        """   
        SELECT
                driver.vyge_id as vyge_id,
                driver.sfb_nm as sfb_nm,
                driver.txn_dt as txn_dt,
                driver.app_vyge_id as app_vyge_id,
                driver.ship_cd as ship_cd,
                driver.vyge_dprt_dt as vyge_dprt_dt,
                cast(driver.vyge_drtn_nght_cn as int) as vyge_drtn_nght_cn ,
                cast(driver.dy_bef_vyge_cn as int) as dy_bef_vyge_cn  ,
                driver.vyge_dprt_seapt_cd as vyge_dprt_seapt_cd,
                driver.vyge_itnry_nm as vyge_itnry_nm,
                driver.orig_vyge_itnry_nm as orig_vyge_itnry_nm,
                driver.vyge_opn_dt as vyge_opn_dt,
                max(driver.batch_run_dts) as batch_run_dts,
                max(driver.as_of_dt) as_of_dt,
                max(coalesce((ooo_ref.ooo_strm_cn),0)) as ooo_strm_cn ,
                sum(coalesce((driver.sl_lim_strm_typ_cn),0)) as sl_lim_strm_typ_cn ,
                avg(driver.price_impct_lvl_am) as price_impct_lvl_am ,                           
                avg(driver.plan_cfdnc_lvl_am) as plan_cfdnc_lvl_am ,
                max(cast(coalesce((driver.price_rcmd_run_dts),NULL) as TIMESTAMP)) as price_rcmd_run_dts,                                       
                max(cast(coalesce((driver.expect_oh_bkng_run_dts),NULL) as TIMESTAMP))as expect_oh_bkng_run_dts ,
                max(cast(coalesce((driver.uncnstrn_dmnd_fcst_run_dts),NULL) as TIMESTAMP)) as uncnstrn_dmnd_fcst_run_dts ,                
                sum(cast(coalesce((driver.vdd_expect_oh_bkng_cn),0) as int)) as vdd_expect_oh_bkng_cn ,
                max(driver.aod_dy_bef_vyge_cn) as aod_dy_bef_vyge_cn
                
            
                FROM driver as driver

                
                LEFT OUTER JOIN ooo_vyg_inventory_cnt_driver_df as ooo_ref                    
				ON driver.vyge_id = ooo_ref.vyge_id    
			    AND driver.txn_dt = ooo_ref.txn_dt
   

            
                GROUP BY
					driver.vyge_id,
					driver.sfb_nm,
					driver.txn_dt,
					app_vyge_id,
					ship_cd,
					vyge_dprt_dt,
					vyge_drtn_nght_cn ,
					dy_bef_vyge_cn  ,
					vyge_dprt_seapt_cd,
					vyge_itnry_nm,
					orig_vyge_itnry_nm,
					vyge_opn_dt 
        """)
		
	
    pre_voyage_price_df_execution = intermediate_df.withColumn("strm_typ_cd", lit("ALL")).withColumn("strm_ctgy_nm",
                                                                                                     lit('ALL'))

    pre_voyage_price_df_execution.createOrReplaceTempView("pre_voyageStateROOM_df_execution")

    if debug == 1:
        debug_counts(pre_voyage_price_df_execution, "state before final values ")

    final_df = spark.sql("""
            SELECT
                   driver.*,
                   
                   CASE    WHEN date(price_rcmd_run_dts) = driver.txn_dt
                           THEN   "PRICE_CONFIG"
                   WHEN   driver.txn_dt >  current_date() THEN  NULL
                   ELSE "PROC_PRICE_PT"
                   END as price_src_nm,
                   
                   CASE  WHEN     current_date() < driver.txn_dt THEN NULL
                   WHEN sl_lim_strm_typ_cn IS NOT NULL THEN "SL_LIM_CONFIG"
                   ELSE "SL_LIM_VYGE_SUM"
                   END as sl_lim_src_nm
                   ,cast(coalesce((oh_ref.oh_paid_bkng_cn),0) as int)as oh_paid_bkng_cn
				   ,coalesce((calc_vf_grs_pd_am_df.phys_invtry_strm_cn),0) as phys_invtry_strm_cn
				   ,calc_vf_grs_pd_am_df.vfd_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vfa_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vfc_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vfi_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.gawf_am 

				   ,calc_vf_grs_pd_am_df.rcmd_vfd_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.rcmd_vfa_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.rcmd_vfc_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.rcmd_vfi_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.rcmd_gawf_am 

				   ,calc_vf_grs_pd_am_df.aod_rcmd_vfd_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.aod_rcmd_vfa_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.aod_rcmd_vfc_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.aod_rcmd_vfi_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.aod_rcmd_gawf_am 

				   ,calc_vf_grs_pd_am_df.vdd_rcmd_vfd_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vdd_rcmd_vfa_grs_pd_am  
				   ,calc_vf_grs_pd_am_df.vdd_rcmd_vfc_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vdd_rcmd_vfi_grs_pd_am 
				   ,calc_vf_grs_pd_am_df.vdd_rcmd_gawf_am 
				   
				   ,expect_oh_bkng_cn_df.expect_oh_bkng_cn
                   ,udf_df.udf_as_of_dt_rcmd_price_am  
                   ,udf_df.udf_curr_price_am 
                   ,udf_df.udf_rcmd_price_am 
				   ,sl_lim_rcmd_strm_typ_cn_df.rcmd_sl_lim_strm_typ_cn 
				   
         		From pre_voyageStateROOM_df_execution driver
      
                          
					LEFT OUTER JOIN calc_vf_grs_pd_am_df as calc_vf_grs_pd_am_df                    
					ON driver.vyge_id = calc_vf_grs_pd_am_df.vyge_id
					AND driver.txn_dt = calc_vf_grs_pd_am_df.txn_dt
                    
					LEFT OUTER JOIN sl_lim_rcmd_strm_typ_cn_df as sl_lim_rcmd_strm_typ_cn_df                    
					ON driver.vyge_id = sl_lim_rcmd_strm_typ_cn_df.vyge_id    
					AND driver.txn_dt = sl_lim_rcmd_strm_typ_cn_df.txn_dt
                
					LEFT OUTER JOIN oh_paid_res_df as oh_ref
					ON driver.vyge_id = oh_ref.vyge_id
					AND driver.sfb_nm = oh_ref.sfb_nm
					AND driver.txn_dt = oh_ref.txn_dt
										
					LEFT OUTER JOIN expect_oh_bkng_cn_df as expect_oh_bkng_cn_df
					ON driver.vyge_id = expect_oh_bkng_cn_df.vyge_id
					AND driver.sfb_nm = expect_oh_bkng_cn_df.sfb_nm
					AND driver.txn_dt = expect_oh_bkng_cn_df.txn_dt

					LEFT OUTER JOIN udf_df as udf_df
					ON driver.vyge_id = udf_df.vyge_id
					AND driver.sfb_nm = udf_df.sfb_nm
					AND driver.txn_dt = udf_df.txn_dt
					
                   """)

    final_df.createOrReplaceTempView("final_df")

    if debug == 1:
        debug_counts(final_df, "final_df ")
    folder_name = "%s%s" % ("vyge_sfb_baseln/partition_dt=", end_dt)
    data_loader.write_data("dm", folder_name, None, final_df.coalesce(2))




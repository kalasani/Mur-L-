
import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from framework.core.BaseJob import *;

from vygestrmctgydly.DataLoaderVygeStrmCtgDly import *;
from vygestrmctgydly.VygeStrmCtgyDlyDriver import *;
# from cancellation.ConSlLimVygeSumCancellationDm import *;
class VygeStrmCtgyDly(BaseJob):
    def __init__(self):
        self.table="VygeStrmCtgyDly"
        super(VygeStrmCtgyDly, self).__init__(self.table)

    def setUp(self):
        self.runType = self.load_type

    def loadData(self):
        print("start_date==>", self.start_date)
        print("end_date==>", self.end_date)
        print("spark==>", self.spark)
        print("s3_root_bucket==>", self.s3_root_bucket)
        print("data_loader==>", self.data_loader)
        print("debug==>", self.debug)
        print("runType ===>",self.runType)
        print("Start DataLoader Process ")
        DataLoaderVygeStrmCtgDly.run_data_loader_vyge_strm_ctgy_dly(self.start_date, self.end_date, self.spark, self.s3_root_bucket, self.data_loader,self.runType, self.debug)
        print("End DataLoader Process ")

    def createDriver(self):
        print("Start CreateDriver Method")
        VygeStrmCtgyDlyDriver.run_vyge_strm_ctgy_dly_Driver(self.start_date, self.end_date, self.spark, self.s3_root_bucket,self.data_loader,self.runType,self.debug)
        print("End CreateDriver Method")




    def preProcess(self):
        pass

    def process(self):
        pass

    def runStrmCtgDlyFinalMerge(self):
        data_loader = self.data_loader;
        vyge_strm_typ_dly_df_1 = self.spark.sql(
            """      select
                        driver.vyge_id,
                        driver.ship_strm_ctgy_nm,
                        driver.txn_dt ,
                        driver.ship_cd,
                        driver.ship_nm,
                        driver.ship_short_nm,
                        driver.ship_cls_nm,
                        driver.vyge_dprt_dt,
                        driver.vyge_arvl_dt,
                        driver.vyge_drtn_nght_cn,
                        driver.dy_bef_vyge_cn,
                        driver.vyge_dprt_seapt_cd,
                        driver.vyge_itnry_nm,

                        cast(coalesce((phys_invtry_strm_cn_df.phys_invtry_strm_cn),0) as int) as phys_invtry_strm_cn,
                        cast(coalesce((ooo_vw.ooo_strm_cn),0) as int) as ooo_strm_cn ,
                        cnts.avail_strm_ctgy_cn as avail_strm_ctgy_cn ,
                        cnts.strm_ctgy_ocpncy_pc as strm_ctgy_ocpncy_pc ,
                        cnts.strm_ctgy_utlz_pc as strm_ctgy_utlz_pc ,
                        cast(coalesce((100 - (((cast(coalesce((phys_invtry_strm_cn_df.phys_invtry_strm_cn),0) as int) - (cast(coalesce((ooo_vw.ooo_strm_cn),0) as int) + cast(coalesce(( con_res_vw.OH_UNASGN_BKNG_CN),0) as int) + cast(coalesce(((con_res_vw.oh_asgn_bkng_cn++alloc_unalloc.alloc_grp_bkng_cn+alloc_unalloc.unalloc_grp_bkng_cn)),0) as int))) / cast(coalesce((phys_invtry_strm_cn_df.phys_invtry_strm_cn),0) as int)) * 100)),0)as int) as ship_strm_utlz_pc
                        ,
                        cnts.sl_lim_strm_ctgy_cn,
                        cnts.sl_lim_strm_ctgy_pc as sl_lim_strm_ctgy_pc ,
                        cast(coalesce((sl_lim_rcmd_lim_vw.sl_lim_strm_cn),0) as int) as sl_lim_strm_cn ,
                        cnts.sl_strm_ctgy_cn as sl_strm_ctgy_cn ,
                        cnts.sl_strm_cn as sl_strm_cn ,
                        cast(coalesce((con_res_vw.pu_bkng_cn),0) as int)as pu_bkng_cn ,
                        cast(coalesce((con_res_vw.cncl_bkng_cn),0) as int)as cncl_bkng_cn ,
                        cast(coalesce((con_res_vw.grs_paid_bkng_cn),0) as int)as grs_paid_bkng_cn ,
                       cast(coalesce((ten_four_prev_wk_metrics_vw.four_wk_pu_bkng_cn),0) as int)  as four_wk_pu_bkng_cn ,
                       cast(coalesce((ten_four_prev_wk_metrics_vw.ten_wk_pkup_bkng_cn),0) as int)  as ten_wk_pu_bkng_cn ,
                        cast(coalesce(( (con_res_vw.OH_PAID_BKNG_CN +alloc_unalloc.alloc_grp_bkng_cn+alloc_unalloc.unalloc_grp_bkng_cn)),0) as int) as paid_bkng_cn  ,
                        cast(coalesce(((con_res_vw.oh_asgn_bkng_cn++alloc_unalloc.alloc_grp_bkng_cn+alloc_unalloc.unalloc_grp_bkng_cn)),0) as int) as asgn_bkng_cn ,
                        cast(coalesce((con_res_vw.OH_PAID_BKNG_CN),0) as int)as oh_paid_bkng_cn ,
                        cast(coalesce(( con_res_vw.oh_asgn_bkng_cn),0) as int)as oh_asgn_bkng_cn ,
                        cast(coalesce(( con_res_vw.OH_UNASGN_BKNG_CN),0) as int)as oh_unasgn_bkng_cn ,
                        cast(coalesce(( alloc_unalloc.alloc_grp_bkng_cn),0) as int)as alloc_grp_bkng_cn ,
                        cast(coalesce(( alloc_unalloc.unalloc_grp_bkng_cn),0) as int)as unalloc_grp_bkng_cn ,
                        cast(coalesce(( con_res_vw.oh_bkng_gst_cn),0) as int)as  oh_bkng_gst_cn,
                        cast(coalesce(( alloc_unalloc.alloc_grp_gst_cn),0) as int)as  alloc_grp_gst_cn,
                        cast(coalesce(( alloc_unalloc.unalloc_grp_gst_cn),0) as int)as  unalloc_grp_gst_cn,
                        cast(coalesce(( alloc_unalloc.dlgt_grp_bkng_cn),0) as int)as  dlgt_grp_bkng_cn,
                        cast(coalesce(( con_res_vw.oh_asgn_bkng_gst_cn),0) as int)as  oh_asgn_bkng_gst_cn,
                        cast(coalesce(( con_res_vw.OH_UNASGN_BKNG_GST_CN),0) as int)as  oh_unasgn_bkng_gst_cn,
                        driver.app_vyge_id ,
                        ((coalesce(oh_bkng_cn_vw.expect_oh_bkng_cn,0) + coalesce(ooo_vw.ooo_strm_cn,0) + coalesce(alloc_unalloc.alloc_grp_bkng_cn,0)
                        + coalesce(alloc_unalloc.unalloc_grp_bkng_cn,0))*100.00)/coalesce(phys_invtry_strm_cn_df.phys_invtry_strm_cn,0) as est_strm_ctgy_ocpncy_pc,
                        sci_rcmd_vw.sci_rcmd_typ_nm,
                        cast(coalesce((vyge_strm_typ_dly_rcmd_vw.price_impct_lvl_am  ),0) as decimal )  as price_impct_lvl_am ,
                        cast(coalesce((vyge_strm_typ_dly_rcmd_vw.plan_cfdnc_lvl_am  ),0) as decimal )  as plan_cfdnc_lvl_am
                        ,cast(coalesce((udf_price_am_vw.udf_curr_price_am ),0) as decimal ) as udf_curr_price_am
                        ,cast(coalesce((udf_price_am_vw.udf_as_of_dt_rcmd_price_am ),0) as decimal ) as udf_as_of_dt_rcmd_price_am
                        ,cast(coalesce((udf_price_am_vw.udf_rcmd_price_am ),0) as decimal ) as udf_rcmd_price_am
                        , price_mod_date_vw.price_mod_dt as price_mod_dt
                        , driver.orig_vyge_itnry_nm
                        ,cast(coalesce((udf_price_am_pc_vw.udf_curr_price_pc ),0) as decimal ) as udf_curr_price_pc
                        ,cast(coalesce((udf_price_am_pc_vw.udf_as_of_dt_rcmd_price_pc ),0) as decimal ) as udf_as_of_dt_rcmd_price_pc
                        ,cast(coalesce((udf_price_am_pc_vw.udf_rcmd_price_pc ),0) as decimal ) as udf_rcmd_price_pc
                        ,cast(coalesce((ten_four_prev_wk_metrics_vw.curr_wk_pu_bkng_cn_tmp),0) as int)   as curr_wk_pu_bkng_cn
                        ,cast(coalesce((ten_four_prev_wk_metrics_vw.prev_wk_pu_bkng_cn),0) as int)    as prev_wk_pu_bkng_cn
                        ,cast(coalesce((ten_four_prev_wk_metrics_vw.four_wk_pu_avg_bkng_cn),0) as int)  as four_wk_pu_avg_bkng_cn
                        ,cast(coalesce((ten_four_prev_wk_metrics_vw.ten_wk_pu_avg_bkng_cn),0) as int) as  ten_wk_pu_avg_bkng_cn
                    FROM

				driver driver

                LEFT OUTER JOIN phys_invtry_strm_cn_df as phys_invtry_strm_cn_df
                    ON driver.vyge_id = phys_invtry_strm_cn_df.vyge_id
                    and driver.ship_strm_ctgy_nm = phys_invtry_strm_cn_df.ship_strm_ctgy_nm
                    and driver.txn_dt = phys_invtry_strm_cn_df.txn_dt

				LEFT OUTER JOIN vyge_strm_typ_dly_rcmd_vw as vyge_strm_typ_dly_rcmd_vw
                      ON driver.vyge_id = vyge_strm_typ_dly_rcmd_vw.vyge_id
					  AND driver.ship_strm_ctgy_nm = vyge_strm_typ_dly_rcmd_vw.ship_strm_ctgy_nm
					  AND driver.txn_dt = vyge_strm_typ_dly_rcmd_vw.txn_dt

                LEFT OUTER JOIN sl_lim_rcmd_lim_vw as sl_lim_rcmd_lim_vw
                      ON driver.vyge_id = sl_lim_rcmd_lim_vw.vyge_id
                      AND driver.ship_strm_ctgy_nm = sl_lim_rcmd_lim_vw.ship_strm_ctgy_nm
                      AND driver.txn_dt = sl_lim_rcmd_lim_vw.txn_date


                LEFT OUTER JOIN count_metrics_vw as cnts
                             ON driver.vyge_id = cnts.vyge_id
                            AND driver.ship_strm_ctgy_nm = cnts.ship_strm_ctgy_nm_temp
                            AND driver.txn_dt = cnts.txn_dt

                LEFT OUTER JOIN ooo_consolidated_vw_ship_strm_ctgy as ooo_vw
                            ON driver.vyge_id = ooo_vw.vyge_id
                            AND driver.ship_strm_ctgy_nm = ooo_vw.ship_strm_ctgy_nm
                            AND driver.txn_dt = ooo_vw.txn_dt

                LEFT OUTER JOIN con_res_vw as con_res_vw
                            ON driver.vyge_id = con_res_vw.vyge_id
                            AND driver.ship_strm_ctgy_nm = con_res_vw.ship_strm_ctgy_nm
                            AND driver.txn_dt = con_res_vw.txn_dt

                LEFT JOIN ship_inventory_alloc_unalloc_vw alloc_unalloc
                            ON driver.vyge_id = alloc_unalloc.vyge_id
                            AND driver.ship_strm_ctgy_nm = alloc_unalloc.ship_strm_ctgy_nm
                            AND driver.txn_dt = alloc_unalloc.txn_dt

                LEFT OUTER JOIN	udf_price_am_vw_pre as udf_price_am_vw
                            ON driver.vyge_id = udf_price_am_vw.vyge_id
                            AND driver.ship_strm_ctgy_nm = udf_price_am_vw.ship_strm_ctgy_nm
                            AND driver.txn_dt = udf_price_am_vw.txn_dt

                LEFT JOIN udf_price_am_pc_vw udf_price_am_pc_vw
                            ON driver.vyge_id = udf_price_am_pc_vw.vyge_id
                             AND driver.ship_strm_ctgy_nm = udf_price_am_pc_vw.ship_strm_ctgy_nm
                                AND driver.txn_dt = udf_price_am_pc_vw.txn_date

				 LEFT JOIN expect_oh_bkng_cn_vw oh_bkng_cn_vw
						ON driver.vyge_id = oh_bkng_cn_vw.vyge_id
						AND driver.ship_strm_ctgy_nm = oh_bkng_cn_vw.ship_strm_ctgy_nm
						AND driver.txn_dt = oh_bkng_cn_vw.txn_dt

				LEFT JOIN vyge_strm_typ_dly_sci_rcmd_vw sci_rcmd_vw
						ON driver.vyge_id = sci_rcmd_vw.vyge_id
						AND driver.ship_strm_ctgy_nm = sci_rcmd_vw.ship_strm_ctgy_nm
						AND driver.txn_dt = sci_rcmd_vw.txn_dt
				LEFT JOIN ten_four_prev_wk_metrics_vw as ten_four_prev_wk_metrics_vw
						ON driver.vyge_id = ten_four_prev_wk_metrics_vw.vyge_id
						AND driver.ship_strm_ctgy_nm = ten_four_prev_wk_metrics_vw.ship_strm_ctgy_nm_temp
						AND driver.txn_dt = ten_four_prev_wk_metrics_vw.txn_dt

				LEFT JOIN price_mod_date_vw as price_mod_date_vw
						ON driver.vyge_id = price_mod_date_vw.vyge_id
						AND driver.ship_strm_ctgy_nm = price_mod_date_vw.ship_strm_ctgy_nm
						AND driver.txn_dt = price_mod_date_vw.txn_dt


                """).dropDuplicates()
        print("Completed :: ",vyge_strm_typ_dly_df_1)

        if self.debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_df_1, "vyge_strm_typ_dly_df_1")

        folder_name = "%s%s" % ("vyge_strm_typ_dly_df_1/partition_dt=", self.end_date)
        data_loader.write_data("dm", folder_name, None, vyge_strm_typ_dly_df_1.coalesce(10))
        print(" ********* Loading of vyge_strm_typ_dly is completed for %s " % self.end_date)

        driver_df1 = data_loader.read_data_one_partitionVoygeStateROOM("dm", "vyge_strm_typ_dly_df_1", "partition_dt",self.end_date,None).dropDuplicates()
        driver_df1.createOrReplaceTempView("vyge_strm_typ_dly_df_1")

        vyge_strm_typ_dly_df_2 = self.spark.sql(
            """      select
                         driver.vyge_id
                         ,driver.ship_strm_ctgy_nm as ship_strm_ctgy_nm_temp
                         ,driver.txn_dt
                         ,proc_price_pt_ntr_gtr_vw.ntr_price_pd_am as ntr_price_pd_am
                         ,vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_ntr_price_pd_am as rcmd_vyge_ntr_price_pd_am
                        ,((vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_ntr_price_pd_am) - (proc_price_pt_ntr_gtr_vw.ntr_price_pd_am)) as ntr_price_pd_chng_am
                        ,(((vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_ntr_price_pd_am) - (proc_price_pt_ntr_gtr_vw.ntr_price_pd_am))*100) /(proc_price_pt_ntr_gtr_vw.ntr_price_pd_am) as ntr_price_pd_chng_pc
                        , cast(coalesce((vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_gtr_price_pd_am ),0) as int ) as rcmd_vyge_gtr_price_pd_am
                        , cast(coalesce((proc_price_pt_ntr_gtr_vw.gtr_price_pd_am),0) as int ) as gtr_price_pd_am
                        , cast(coalesce((proc_price_pt_opn_ntr_gtr_vw.opn_gtr_price_pd_am),0) as int ) as opn_gtr_price_pd_am
                        , cast(coalesce((proc_price_pt_opn_ntr_gtr_vw.opn_ntr_price_pd_am),0) as int ) as opn_ntr_price_pd_am
                        ,((cast(coalesce((vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_gtr_price_pd_am ),0) as int ))-(cast(coalesce((proc_price_pt_ntr_gtr_vw.gtr_price_pd_am),0) as int ))) as gtr_price_pd_chng_am
                        ,(((cast(coalesce((vyge_strm_typ_dly_rcmd_ntr_gtr_vw.rcmd_vyge_gtr_price_pd_am ),0) as int ))-(cast(coalesce((proc_price_pt_ntr_gtr_vw.gtr_price_pd_am),0) as int )))*100/(cast(coalesce((proc_price_pt_ntr_gtr_vw.gtr_price_pd_am),0) as int ))) as gtr_price_pd_chng_pc

                    FROM
                    driver as driver
                     LEFT OUTER JOIN vyge_strm_typ_dly_rcmd_ntr_gtr_vw as vyge_strm_typ_dly_rcmd_ntr_gtr_vw
                        ON driver.vyge_id = vyge_strm_typ_dly_rcmd_ntr_gtr_vw.vyge_id
                        AND driver.ship_strm_ctgy_nm = vyge_strm_typ_dly_rcmd_ntr_gtr_vw.ship_strm_ctgy_nm_temp
                        AND driver.txn_dt = vyge_strm_typ_dly_rcmd_ntr_gtr_vw.txn_date

                        LEFT OUTER JOIN  proc_price_pt_ntr_gtr_vw as proc_price_pt_ntr_gtr_vw
                            ON driver.vyge_id = proc_price_pt_ntr_gtr_vw.vyge_id
                            AND driver.ship_strm_ctgy_nm = proc_price_pt_ntr_gtr_vw.ship_strm_ctgy_nm_temp
                            AND driver.txn_dt = proc_price_pt_ntr_gtr_vw.txn_date



                        LEFT OUTER JOIN  proc_price_pt_opn_ntr_gtr_vw as proc_price_pt_opn_ntr_gtr_vw
                            ON driver.vyge_id = proc_price_pt_opn_ntr_gtr_vw.vyge_id
                            AND driver.ship_strm_ctgy_nm = proc_price_pt_opn_ntr_gtr_vw.ship_strm_ctgy_nm_temp
                            AND driver.txn_dt = proc_price_pt_opn_ntr_gtr_vw.txn_date




                """).dropDuplicates()
        print("Completed :: vyge_strm_typ_dly_df_2")

        if self.debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_df_2, "vyge_strm_typ_dly_df_new")
        folder_name = "%s%s" % ("vyge_strm_typ_dly_df_2/partition_dt=", self.end_date)
        data_loader.write_data("dm", folder_name, None, vyge_strm_typ_dly_df_2.coalesce(10))

        print(" ********* Loading of vyge_strm_typ_dly_df_2 is completed for %s " % self.end_date)
        driver_df2 = data_loader.read_data_one_partitionVoygeStateROOM("dm", "vyge_strm_typ_dly_df_2", "partition_dt",self.end_date, None).dropDuplicates()
        driver_df2.createOrReplaceTempView("vyge_strm_typ_dly_df_2")

        vyge_strm_typ_dly_df = self.spark.sql(
            """      select
                        driver.vyge_id,
                        driver.ship_strm_ctgy_nm,
                        driver.txn_dt ,
                        driver.ship_cd,
                        driver.ship_nm,
                        driver.ship_short_nm,
                        driver.ship_cls_nm,
                        driver.vyge_dprt_dt,
                        driver.vyge_arvl_dt,
                        driver.vyge_drtn_nght_cn,
                        driver.dy_bef_vyge_cn,
                        driver.vyge_dprt_seapt_cd,
                        driver.vyge_itnry_nm,
                        driver.phys_invtry_strm_cn as phys_invtry_strm_cn,
                        driver.ooo_strm_cn as ooo_strm_cn ,
                        driver.avail_strm_ctgy_cn as avail_strm_ctgy_cn ,
                        driver.strm_ctgy_ocpncy_pc as strm_ctgy_ocpncy_pc ,
                        driver.strm_ctgy_utlz_pc as strm_ctgy_utlz_pc ,
                        driver.ship_strm_utlz_pc as ship_strm_utlz_pc,
                        driver.sl_lim_strm_ctgy_cn,
                        driver.sl_lim_strm_ctgy_pc as sl_lim_strm_ctgy_pc ,
                        driver.sl_lim_strm_cn as sl_lim_strm_cn ,
                        driver.sl_strm_ctgy_cn as sl_strm_ctgy_cn ,
                        driver.sl_strm_cn as sl_strm_cn ,
                        driver.pu_bkng_cn as pu_bkng_cn ,
                        driver.cncl_bkng_cn as cncl_bkng_cn ,
                        driver.grs_paid_bkng_cn as grs_paid_bkng_cn ,
                        driver.four_wk_pu_bkng_cn as four_wk_pu_bkng_cn ,
                        driver.ten_wk_pu_bkng_cn as ten_wk_pu_bkng_cn ,
                        driver.paid_bkng_cn as paid_bkng_cn  ,
                        driver.asgn_bkng_cn as asgn_bkng_cn ,
                        driver.oh_paid_bkng_cn as oh_paid_bkng_cn ,
                        driver.oh_asgn_bkng_cn as oh_asgn_bkng_cn ,
                        driver.oh_unasgn_bkng_cn as oh_unasgn_bkng_cn ,
                        driver.alloc_grp_bkng_cn as alloc_grp_bkng_cn ,
                        driver.unalloc_grp_bkng_cn as unalloc_grp_bkng_cn ,
                        driver.oh_bkng_gst_cn as  oh_bkng_gst_cn,
                        driver.alloc_grp_gst_cn as  alloc_grp_gst_cn,
                        driver.unalloc_grp_gst_cn as  unalloc_grp_gst_cn,
                        driver.dlgt_grp_bkng_cn as  dlgt_grp_bkng_cn,
                        driver.oh_asgn_bkng_gst_cn as  oh_asgn_bkng_gst_cn,
                        driver.oh_unasgn_bkng_gst_cn as  oh_unasgn_bkng_gst_cn,
                        driver.app_vyge_id ,
                        driver.est_strm_ctgy_ocpncy_pc as est_strm_ctgy_ocpncy_pc,
                        driver.sci_rcmd_typ_nm,
                        driver.price_impct_lvl_am  as price_impct_lvl_am ,
                        driver.plan_cfdnc_lvl_am as plan_cfdnc_lvl_am ,

                        vyge_strm_ctg_dly_df.ntr_price_pd_am as ntr_price_pd_am ,
                        vyge_strm_ctg_dly_df.rcmd_vyge_ntr_price_pd_am as rcmd_ntr_price_pd_am ,
                         vyge_strm_ctg_dly_df.ntr_price_pd_chng_am as ntr_price_pd_chng_am
                        ,vyge_strm_ctg_dly_df.ntr_price_pd_chng_pc as ntr_price_pd_chng_pc

                        ,driver.udf_curr_price_am as udf_curr_price_am
                        ,driver.udf_as_of_dt_rcmd_price_am as udf_as_of_dt_rcmd_price_am
                        ,driver.udf_rcmd_price_am as udf_rcmd_price_am
                        , driver.txn_dt as price_mod_dt

                        , vyge_strm_ctg_dly_df.rcmd_vyge_gtr_price_pd_am as rcmd_gtr_price_pd_am 
                        ,  vyge_strm_ctg_dly_df.gtr_price_pd_am as gtr_price_pd_am
                        , vyge_strm_ctg_dly_df.opn_gtr_price_pd_am as opn_gtr_price_pd_am
                        , vyge_strm_ctg_dly_df.opn_ntr_price_pd_am as opn_ntr_price_pd_am
                        , vyge_strm_ctg_dly_df.gtr_price_pd_chng_am as gtr_price_pd_chng_am
                        , vyge_strm_ctg_dly_df.gtr_price_pd_chng_pc as gtr_price_pd_chng_pc

                        , driver.orig_vyge_itnry_nm
                        ,driver.udf_curr_price_pc as udf_curr_price_pc
                        ,driver.udf_as_of_dt_rcmd_price_pc  as udf_as_of_dt_rcmd_price_pc
                        ,driver.udf_rcmd_price_pc as udf_rcmd_price_pc
                        ,driver.curr_wk_pu_bkng_cn  as curr_wk_pu_bkng_cn
                        ,driver.prev_wk_pu_bkng_cn   as prev_wk_pu_bkng_cn
                        ,driver.four_wk_pu_avg_bkng_cn as four_wk_pu_avg_bkng_cn
                        ,driver.ten_wk_pu_avg_bkng_cn as ten_wk_pu_avg_bkng_cn
                    FROM
                    vyge_strm_typ_dly_df_1 as driver  inner join vyge_strm_typ_dly_df_2 as vyge_strm_ctg_dly_df
                        ON driver.vyge_id = vyge_strm_ctg_dly_df.vyge_id
                        AND driver.ship_strm_ctgy_nm = vyge_strm_ctg_dly_df.ship_strm_ctgy_nm_temp
                        AND driver.txn_dt = vyge_strm_ctg_dly_df.txn_dt
                """).dropDuplicates()
        print("compelted:: vyge_strm_typ_dly_df")
        print("Count Of INFO ===>",vyge_strm_typ_dly_df.count())

        folder_name = "%s%s" % ("vyge_strm_ctgy_dly/partition_dt=", self.end_date)
        data_loader.write_data("dm", folder_name, None, vyge_strm_typ_dly_df.coalesce(10))
        print(" ********* Loading of vyge_strm_typ_dly_df_new is completed for %s " % self.end_date)


    def writeToHDFS(self):

        self.runStrmCtgDlyFinalMerge();

    def tearDown(self):
        pass




if __name__ == '__main__':

    try:
        obj = VygeStrmCtgyDly()
        obj.execute()

    except:
        traceback.print_exc()
        sys.exit(-1)


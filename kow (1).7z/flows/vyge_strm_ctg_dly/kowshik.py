# #############################################################################
# # Project           : DCL RM - Disney Cruise Line Revenue Management        #
# # Program name      : Demand by Booking  - consolidate resbaseln class load #
# # Author            : Kowshik Yerra                                         #
# # Date created      : 20180920                                              #
# # Purpose           : populate consolidate resbaseln metrics                #
# # Revision History  :                                                       #
# #  Date        Author     Ref    Revision (Date in YYYYMMDD format)         #
# # 20180920     Kowshik Y   Chris                                            #
# #                                                                           #
# #############################################################################
#
# #################################################################################
# # STEP 1: Initializing SPARK variable and importing dependent functions/packages#
# #################################################################################
#
# from datetime import datetime
# from datetime import timedelta
# from pyspark.sql import SparkSession
# from pyspark.sql.window import Window
# from pyspark import SparkContext
# from pyspark import SQLContext
# from pyspark.sql.functions import *
# from pyspark.sql.window import Window
# import sys, traceback
# from framework.core.BaseJob import BaseJob
# from framework.utils.S3DataLoader import *
# from framework.utils.DataFrameUtil import *
# from framework.utils.DebugCount import *
# from pyspark.sql.types import *
#
# from time import time
# import os, sys
#
# class VygeStrmTypCountCalc(object):
#
#     def __init__(self,start_dt,end_dt,sql_context,s3_bucket,data_loader,runType,debug):
#         self.start_dt = start_dt
#         self.end_dt = end_dt
#         self.sql_context = sql_context
#         self.hdfs_path = s3_bucket
#         self.data_loader = data_loader
#         self.debug = debug
#         self.runType = runType
#
#     def runVygeStrmTypCountCalc(self):
#         sl_lim_vyge_sum_df = self.sql_context.sql(" select * from sl_lim_vyge_sum ")
#         vyge_strm_typ_drvr_df = self.sql_context.sql(" select * from driver ")
#         strm_typ_nest_config_df = self.sql_context.sql(" select * from strm_typ_nest_config ")
#         ship_inventory_alloc_df = self.sql_context.sql(""" select * from ship_inventory_alloc
#                                                                 where UPPER(allocation_owner_type) = 'GROUP' """)
#         res_baseln_con_vw_df = self.sql_context.sql(" select * from res_baseln_con_vw ")
#         ooo_inventory_cnt_df = self.sql_context.sql(" select * from ooo_consolidated_vw ")
#
#         #######################################################################
#         #  Calculating max of absolute_lim_nb from sl_lim_vyge_sum dataset    #
#         #######################################################################
#
#         sl_lim_strm_typ_cn_df = vyge_strm_typ_drvr_df.join(sl_lim_vyge_sum_df, \
#                        (vyge_strm_typ_drvr_df.vyge_id == sl_lim_vyge_sum_df.Sail_id) \
#                        & ( vyge_strm_typ_drvr_df.strm_typ_cd == sl_lim_vyge_sum_df.cbn_ctgy_cd) \
#                        & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
#                            sl_lim_vyge_sum_df.vrsn_strt_dts)) \
#                        & (vyge_strm_typ_drvr_df.txn_dt < to_date(
#                            sl_lim_vyge_sum_df.vrsn_end_dts)), "left_outer") \
#                     .select("vyge_id", "strm_typ_cd", "txn_dt", "absolute_lim_nb") \
#                     .groupBy("vyge_id", "strm_typ_cd", "txn_dt") \
#                     .agg(max("absolute_lim_nb").alias("sl_lim_strm_typ_cn"))
#
#         if self.debug == 1:
#             DebugCount.count_check(sl_lim_strm_typ_cn_df, "sl_lim_strm_typ_cn_vw")
#
#         window_vrsn_end_dts_nxt = Window.partitionBy("ship_cd").orderBy("strm_typ_nest_config_strt_dts") \
#             .rowsBetween(-1, -1)
#         filter_clause = "UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM')\
#                             and UPPER(strm_typ_nest_grp_nm) = 'SHIPSCI' \
#                             and lgcl_del_in = 'N'"
#         window_vrsn_end_dts = Window.partitionBy("ship_cd", "src_sys_strm_typ_nm").orderBy(
#             "strm_typ_nest_config_strt_dts") \
#             .rowsBetween(1, 1)
#
#         strm_typ_nest_confg_temp_df1 = strm_typ_nest_config_df.filter(filter_clause) \
#             .select("ship_cd", \
#                     "strm_ctgy_nm", \
#                     "src_sys_strm_typ_nm", \
#                     "sci_rcmd_excl_in", \
#                     "strm_typ_nest_config_strt_dts", \
#                     col("strm_typ_nest_config_strt_dts").alias("vrsn_strt_dts_est"), \
#                     max("strm_typ_nest_config_strt_dts") \
#                     .over(window_vrsn_end_dts_nxt).alias("vrsn_strt_dts_nxt")) \
#             .withColumn("vrsn_end_dts_est", when(col("vrsn_strt_dts_nxt").isNull(), \
#                                                  lit("9999-12-31 00:00:00.000000").cast("timestamp")) \
#                         .otherwise(col("vrsn_strt_dts_nxt"))).drop(col("vrsn_strt_dts_nxt"))
#         if self.debug == 1:
#             DebugCount.count_check(strm_typ_nest_confg_temp_df1, "strm_typ_nest_confg_temp_vw")
#
#         strm_typ_nest_confg_vw_df = strm_typ_nest_confg_temp_df1\
#                             .select("ship_cd", \
#                                     "strm_ctgy_nm", \
#                                     "src_sys_strm_typ_nm", \
#                                     "sci_rcmd_excl_in", \
#                                     "strm_typ_nest_config_strt_dts", \
#                                     col("strm_typ_nest_config_strt_dts").alias(
#                                         "vrsn_strt_dts"), \
#                                     max("strm_typ_nest_config_strt_dts") \
#                                     .over(window_vrsn_end_dts).alias(
#                                         "vrsn_end_dts_tmp")) \
#                             .withColumn("vrsn_end_dts", when(col("vrsn_end_dts_tmp").isNull(), \
#                                     lit("9999-12-31 00:00:00.000000").cast("timestamp")) \
#                             .otherwise(col("vrsn_end_dts_tmp")))
#
#         if self.debug == 1:
#             DebugCount.count_check(strm_typ_nest_confg_vw_df, "strm_typ_nest_confg_vw_df")
#
#         sl_lim_rcmd_lim_temp_df = vyge_strm_typ_drvr_df.join(strm_typ_nest_confg_vw_df, \
#                              (vyge_strm_typ_drvr_df.ship_cd == strm_typ_nest_confg_vw_df.ship_cd) \
#                              & (vyge_strm_typ_drvr_df.txn_dt >= to_date(strm_typ_nest_confg_vw_df.vrsn_strt_dts))) \
#                               .join(sl_lim_vyge_sum_df, (sl_lim_vyge_sum_df.Sail_id == vyge_strm_typ_drvr_df.vyge_id) \
#                                   & (vyge_strm_typ_drvr_df.strm_typ_cd == sl_lim_vyge_sum_df.cbn_ctgy_cd) \
#                                   & (vyge_strm_typ_drvr_df.txn_dt >= to_date(sl_lim_vyge_sum_df.vrsn_strt_dts)) \
#                                   & (vyge_strm_typ_drvr_df.txn_dt < to_date(sl_lim_vyge_sum_df.vrsn_end_dts))) \
#                             .select("vyge_id", \
#                                     "strm_typ_cd", \
#                                     "txn_dt", \
#                                     "src_sys_strm_typ_nm", \
#                                     "absolute_lim_nb") \
#                             .groupBy("vyge_id", "strm_typ_cd", "txn_dt", "src_sys_strm_typ_nm") \
#                             .agg(max("absolute_lim_nb").alias("rcmd_lim"))
#
#
#
#         sl_lim_rcmd_lim_df = sl_lim_rcmd_lim_temp_df.groupBy("vyge_id", \
#                                      "strm_typ_cd", \
#                                      col("txn_dt").alias("txn_date")) \
#                             .agg(sum("rcmd_lim").alias("sl_lim_strm_cn"))
#
#         sl_lim_rcmd_lim_df.createOrReplaceTempView("sl_lim_rcmd_lim_vw")
#
#         if self.debug == 1:
#             DebugCount.count_check(sl_lim_rcmd_lim_df, "sl_lim_rcmd_lim_vw")
#
#         ship_inventory_alloc_unalloc_tmp_df = vyge_strm_typ_drvr_df.join(ship_inventory_alloc_df, \
#                  (vyge_strm_typ_drvr_df.ship_cd == ship_inventory_alloc_df.SHIP_CODE) \
#                  & (vyge_strm_typ_drvr_df.strm_typ_cd == ship_inventory_alloc_df.CABIN_CATEGORY) \
#                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt == ship_inventory_alloc_df.SAIL_DATE_FROM) \
#                  & (vyge_strm_typ_drvr_df.vyge_arvl_dt == ship_inventory_alloc_df.SAIL_DATE_TO) \
#                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_inventory_alloc_df.vrsn_strt_dts)) \
#                  & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_inventory_alloc_df.vrsn_end_dts)) \
#                  & (ship_inventory_alloc_df.ALLOCATION_OWNER_TYPE == 'GROUP')) \
#                 .select(vyge_strm_typ_drvr_df.vyge_id, \
#                         vyge_strm_typ_drvr_df.strm_typ_cd, \
#                         vyge_strm_typ_drvr_df.txn_dt, \
#                         ship_inventory_alloc_df.CABIN_NUMBER, \
#                         ship_inventory_alloc_df.OCCUPANCY, \
#                         ship_inventory_alloc_df.DLGT_RES_ID) \
#                 .withColumn("alloc_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
#                           & (ship_inventory_alloc_df.CABIN_NUMBER.isNotNull()),
#                           lit("1").cast("integer")) \
#                 .otherwise(lit("0").cast("integer"))) \
#                 .withColumn("unalloc_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
#                             & (ship_inventory_alloc_df.CABIN_NUMBER.isNull()),
#                             lit("1").cast("integer")) \
#                 .otherwise(lit("0").cast("integer"))) \
#                 .withColumn("alloc_grp_gst_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
#                              & (ship_inventory_alloc_df.CABIN_NUMBER.isNotNull()),
#                              ship_inventory_alloc_df.OCCUPANCY) \
#                 .otherwise(lit("0").cast("integer"))) \
#                 .withColumn("unalloc_grp_gst_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
#                            & (ship_inventory_alloc_df.CABIN_NUMBER.isNull()),
#                            ship_inventory_alloc_df.OCCUPANCY) \
#                 .otherwise(lit("0").cast("integer"))) \
#                 .withColumn("dlgt_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNotNull()), lit("1") \
#                           .cast("integer")).otherwise(lit("0").cast("integer"))) \
#                 .groupBy("vyge_id", \
#                          "strm_typ_cd", \
#                          "txn_dt") \
#                 .agg(sum("alloc_grp_bkng_cn").alias("alloc_grp_bkng_cn"), \
#                      sum("unalloc_grp_bkng_cn").alias("unalloc_grp_bkng_cn"), \
#                      sum("alloc_grp_gst_cn").alias("alloc_grp_gst_cn"), \
#                      sum("unalloc_grp_gst_cn").alias("unalloc_grp_gst_cn"), \
#                      sum("dlgt_grp_bkng_cn").alias("dlgt_grp_bkng_cn"))
#
#         ship_inventory_alloc_unalloc_df = vyge_strm_typ_drvr_df.join(ship_inventory_alloc_unalloc_tmp_df, \
#                             ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
#                             .select("vyge_id", \
#                                     "strm_typ_cd", \
#                                     "txn_dt", \
#                                     when(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_bkng_cn.isNull(), lit("0") \
#                                          .cast("integer"))\
#                                     .otherwise(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_bkng_cn).alias("alloc_grp_bkng_cn"), \
#                                     when(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_bkng_cn.isNull(), lit("0") \
#                                          .cast("integer"))\
#                                     .otherwise(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_bkng_cn).alias("unalloc_grp_bkng_cn"), \
#                                     when(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_gst_cn.isNull(), lit("0") \
#                                          .cast("integer"))\
#                                     .otherwise(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_gst_cn).alias("alloc_grp_gst_cn"), \
#                                     when(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_gst_cn.isNull(), lit("0") \
#                                          .cast("integer"))\
#                                     .otherwise(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_gst_cn).alias("unalloc_grp_gst_cn"), \
#                                     when(ship_inventory_alloc_unalloc_tmp_df.dlgt_grp_bkng_cn.isNull(), lit("0") \
#                                          .cast("integer"))\
#                                     .otherwise(ship_inventory_alloc_unalloc_tmp_df.dlgt_grp_bkng_cn).alias("dlgt_grp_bkng_cn"))
#
#         # ship_inventory_alloc_unalloc_df.filter("vyge_id = 187005 and strm_typ_cd = '04B'").show()
#
#         ship_inventory_alloc_unalloc_df.createOrReplaceTempView("ship_inventory_alloc_unalloc_vw")
#
#         if self.debug == 1:
#             DebugCount.count_check(ship_inventory_alloc_unalloc_df, "ship_inventory_alloc_unalloc_vw")
#
#         driver_subset_df = vyge_strm_typ_drvr_df.join(res_baseln_con_vw_df, \
#                                                       ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#             .select(vyge_strm_typ_drvr_df.vyge_id, \
#                     vyge_strm_typ_drvr_df.strm_typ_cd, \
#                     vyge_strm_typ_drvr_df.txn_dt, \
#                     res_baseln_con_vw_df.oh_paid_bkng_cn, \
#                     res_baseln_con_vw_df.oh_asgn_bkng_cn, \
#                     res_baseln_con_vw_df.oh_unasgn_bkng_cn).distinct()
#
#         if self.debug == 1:
#             DebugCount.count_check(driver_subset_df, "driver_subset_vw")
#
#         pd_asn_bkng_cn_temp_df = driver_subset_df.join(ship_inventory_alloc_unalloc_df, \
#                                                        ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#             .select(driver_subset_df.vyge_id, \
#                     driver_subset_df.strm_typ_cd, \
#                     driver_subset_df.txn_dt, \
#                     driver_subset_df.oh_paid_bkng_cn, \
#                     driver_subset_df.oh_asgn_bkng_cn, \
#                     ship_inventory_alloc_unalloc_df.unalloc_grp_bkng_cn.alias("unalloc_grp_bkng_cn1"), \
#                     ship_inventory_alloc_unalloc_df.alloc_grp_bkng_cn.alias("alloc_grp_bkng_cn1")).distinct()
#
#         if self.debug == 1:
#             DebugCount.count_check(pd_asn_bkng_cn_temp_df, "pd_asn_bkng_cn_temp_vw")
#
#         pd_asn_bkng_cn_df = pd_asn_bkng_cn_temp_df \
#             .withColumn("paid_bkng_cn", (pd_asn_bkng_cn_temp_df.oh_paid_bkng_cn + \
#                                          pd_asn_bkng_cn_temp_df.alloc_grp_bkng_cn1 + \
#                                          pd_asn_bkng_cn_temp_df.unalloc_grp_bkng_cn1)) \
#             .withColumn("asgn_bkng_cn", (pd_asn_bkng_cn_temp_df.oh_asgn_bkng_cn + \
#                                          pd_asn_bkng_cn_temp_df.alloc_grp_bkng_cn1 + \
#                                          pd_asn_bkng_cn_temp_df.unalloc_grp_bkng_cn1)) \
#             .select("vyge_id", "strm_typ_cd", "txn_dt", "paid_bkng_cn", "asgn_bkng_cn")
#         if self.debug == 1:
#             DebugCount.count_check(pd_asn_bkng_cn_df, "pd_asn_bkng_cn_vw")
#
#         sl_lim_strm_typ_pc_temp_df = sl_lim_strm_typ_cn_df.join(pd_asn_bkng_cn_df, \
#                                     ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                                 .select(sl_lim_strm_typ_cn_df.vyge_id, \
#                                         sl_lim_strm_typ_cn_df.strm_typ_cd, \
#                                         sl_lim_strm_typ_cn_df.txn_dt, \
#                                         sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn, \
#                                         pd_asn_bkng_cn_df.paid_bkng_cn)
#
#         if self.debug == 1:
#             DebugCount.count_check(sl_lim_strm_typ_pc_temp_df, "sl_lim_strm_typ_pc_temp_vw")
#
#         sl_lim_strm_typ_pc_df = sl_lim_strm_typ_pc_temp_df \
#             .withColumn("sl_lim_strm_typ_pc", \
#                         (pd_asn_bkng_cn_df.paid_bkng_cn / sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn) * 100) \
#             .withColumn("sl_strm_cn", \
#                         (sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn - pd_asn_bkng_cn_df.paid_bkng_cn))
#
#         if self.debug == 1:
#             DebugCount.count_check(sl_lim_strm_typ_pc_df, "sl_lim_strm_typ_pc_vw")
#
#         count_metrics_temp_df = driver_subset_df.join(ooo_inventory_cnt_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                         .join(pd_asn_bkng_cn_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                         .join(ship_inventory_alloc_unalloc_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                         .join(sl_lim_strm_typ_pc_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                         .select(driver_subset_df.vyge_id, \
#                                 driver_subset_df.strm_typ_cd, \
#                                 driver_subset_df.txn_dt,
#                                 ooo_inventory_cnt_df.phys_invtry_strm_cn,
#                                 ooo_inventory_cnt_df.ooo_strm_cn,
#                                 pd_asn_bkng_cn_df.asgn_bkng_cn,
#                                 driver_subset_df.oh_unasgn_bkng_cn,
#                                 driver_subset_df.oh_asgn_bkng_cn,
#                                 ship_inventory_alloc_unalloc_df.alloc_grp_bkng_cn,
#                                 ship_inventory_alloc_unalloc_df.unalloc_grp_bkng_cn,
#                                 sl_lim_strm_typ_pc_df.sl_lim_strm_typ_cn,
#                                 sl_lim_strm_typ_pc_df.sl_lim_strm_typ_pc,
#                                 sl_lim_strm_typ_pc_df.sl_strm_cn,
#                                 pd_asn_bkng_cn_df.paid_bkng_cn,
#                                 ship_inventory_alloc_unalloc_df.dlgt_grp_bkng_cn).distinct()
#
#         if self.debug == 1:
#             DebugCount.count_check(count_metrics_temp_df, "count_metrics_temp_vw")
#
#         count_metrics_df = count_metrics_temp_df \
#                     .withColumn("avail_strm_typ_cn", \
#                                 (count_metrics_temp_df.phys_invtry_strm_cn - \
#                                  count_metrics_temp_df.ooo_strm_cn - \
#                                  count_metrics_temp_df.asgn_bkng_cn - \
#                                  count_metrics_temp_df.oh_unasgn_bkng_cn)) \
#                     .withColumn("strm_typ_ocpncy_pc", \
#                                 ((count_metrics_temp_df.oh_asgn_bkng_cn + \
#                                   count_metrics_temp_df.oh_unasgn_bkng_cn + \
#                                   count_metrics_temp_df.alloc_grp_bkng_cn + \
#                                   count_metrics_temp_df.unalloc_grp_bkng_cn + \
#                                   count_metrics_temp_df.ooo_strm_cn) / \
#                                  count_metrics_temp_df.phys_invtry_strm_cn) * 100) \
#                     .withColumn("strm_typ_utlz_pc", \
#                                 ((count_metrics_temp_df.phys_invtry_strm_cn - \
#                                   (count_metrics_temp_df.phys_invtry_strm_cn - \
#                                    count_metrics_temp_df.ooo_strm_cn - \
#                                    count_metrics_temp_df.asgn_bkng_cn - \
#                                    count_metrics_temp_df.oh_unasgn_bkng_cn)) / \
#                                  count_metrics_temp_df.phys_invtry_strm_cn) * 100) \
#                     .withColumn("grp_bkng_cn", \
#                                 (count_metrics_temp_df.dlgt_grp_bkng_cn + \
#                                  count_metrics_temp_df.alloc_grp_bkng_cn + \
#                                  count_metrics_temp_df.unalloc_grp_bkng_cn)) \
#                     .select("vyge_id", \
#                             "strm_typ_cd", \
#                             "txn_dt", \
#                             "asgn_bkng_cn", \
#                             "sl_lim_strm_typ_cn", \
#                             col("sl_lim_strm_typ_pc").alias("sl_lim_strm_typ_pc").cast("decimal(12,2)"), \
#                             "sl_strm_cn", \
#                             "paid_bkng_cn", \
#                             "dlgt_grp_bkng_cn", \
#                             "avail_strm_typ_cn", \
#                             col("strm_typ_ocpncy_pc").alias("strm_typ_ocpncy_pc").cast("decimal(12,2)"), \
#                             col("strm_typ_utlz_pc").alias("strm_typ_utlz_pc").cast("decimal(12,2)"), \
#                             "grp_bkng_cn")
#
#         count_metrics_df.createOrReplaceTempView("count_metrics_vw")
#         if self.debug == 1:
#             DebugCount.count_check(count_metrics_df, "count_metrics_vw")
#
#         sl_strm_typ_cn_temp_df = sl_lim_strm_typ_cn_df.join(count_metrics_df \
#                             .select("vyge_id", "strm_typ_cd", "txn_dt", "paid_bkng_cn") \
#                             , ["vyge_id", "strm_typ_cd", "txn_dt"]) \
#                             .select("vyge_id", \
#                                     "strm_typ_cd", \
#                                     "txn_dt", \
#                                     "sl_lim_strm_typ_cn", \
#                                     "paid_bkng_cn").distinct()
#
#         if self.debug == 1:
#             DebugCount.count_check(sl_strm_typ_cn_temp_df, "sl_strm_typ_cn_temp_vw")
#
#         sl_strm_typ_cn_df = sl_strm_typ_cn_temp_df \
#             .withColumnRenamed("txn_dt", "txn_date") \
#             .withColumn("sl_strm_typ_cn", \
#                         sl_strm_typ_cn_temp_df.sl_lim_strm_typ_cn - sl_strm_typ_cn_temp_df.paid_bkng_cn)
#
#         sl_strm_typ_cn_df.createOrReplaceTempView("sl_strm_typ_cn_vw")
#         if self.debug == 1:
#             DebugCount.count_check(sl_strm_typ_cn_df, "sl_strm_typ_cn_vw")
#
#         print( " END OF COUNT CALC ")
#
# [f-iapdp-dclrm@ia-amb-alpha-pn-9 vygeStrmTypDly]$

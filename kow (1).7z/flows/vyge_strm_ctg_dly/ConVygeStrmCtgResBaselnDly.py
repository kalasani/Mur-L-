import sys, os
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.core.BaseJob import *;

import json
from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql import Row
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys, traceback
import os
from decimal import *

INIT_DT = '1800-01-01'
FLOOR_DT = '2016-01-11'
FOLDER = "con"
DATA_REF = "res_baseln_vyge_strm_ctgy"
PARTITION_COL = "run_dt"
NUM_DAYS_AFTER_ARVL_DT = 20
STRM_PARTITION_COLUMN ="strm_ctgy_nm"
PREV_STRM_PARTITION_COLUMN = "prev_" +STRM_PARTITION_COLUMN

def generate_driver(row, txn_dt_start, txn_dt_end):
    """
       Flat map function which takes a row containing voyage id , voyage init booking date and voyage arrival date
       and returns  a rdd containing vyge_id and txn_dt
    """
    floor_dt = datetime.strptime(FLOOR_DT, "%Y-%m-%d").date()
    start_dt = row.vyge_opn_dt
    end_dt = row.vyge_arvl_dt + timedelta(days=NUM_DAYS_AFTER_ARVL_DT)
    dt = start_dt
    list_obj = []
    present = 0
    while (dt <= end_dt):
        if dt >= txn_dt_start and dt <= txn_dt_end:
            t = (row.vyge_id, dt, 1)
            present = 1
            list_obj.append(t)
        dt = dt + timedelta(days=1)
    if present == 0:
        t = (row.vyge_id, floor_dt, 0)
        list_obj.append(t)

    return list_obj


def summarize_vyge_strm_reservations_by_week(rows):
    """
      map partition method that summarizes data by 7 days - starting from sunday to saturday
      note we reset the counter when the weekday is 6
    """
    res_summary_list = []
    zero_decimal = Decimal(0)
    last_vyge_id = -1
    last_STRM_PARTITION_COLUMN = -1
    curr_wk_oh_bkng_gst_cn = 0
    curr_wk_pu_bkng_gst_cn = 0
    curr_wk_pu_bkng_adlt_gst_cn = 0
    curr_wk_pu_bkng_chld_gst_cn = 0
    curr_wk_pu_bkng_ifnt_gst_cn = 0
    curr_wk_pu_mn_dng_gst_cn = 0
    curr_wk_pu_sec_dng_gst_cn = 0
    curr_wk_pu_gtr_am = zero_decimal
    curr_wk_pu_ntr_am = zero_decimal
    curr_wk_pu_bkng_cn = 0
    curr_wk_dvc_pu_bkng_cn = 0
    curr_wk_obo_pu_bkng_cn = 0
    curr_wk_prevl_pu_bkng_cn = 0
    curr_wk_promo_pu_bkng_cn = 0
    curr_wk_irgs_pu_bkng_cn = 0
    curr_wk_other_pu_bkng_cn = 0
    curr_wk_irgs_oh_bkng_cn = 0
    curr_wk_non_irgs_oh_bkng_cn = 0

    for row in rows:
        new = 0
        if last_vyge_id != row.vyge_id and last_STRM_PARTITION_COLUMN != row[STRM_PARTITION_COLUMN]:
            new = 1
        if row.txn_dt.weekday() == 6 or new == 1:
            curr_wk_oh_bkng_gst_cn = 0
            curr_wk_pu_bkng_gst_cn = 0
            curr_wk_pu_bkng_adlt_gst_cn = 0
            curr_wk_pu_bkng_chld_gst_cn = 0
            curr_wk_pu_bkng_ifnt_gst_cn = 0
            curr_wk_pu_mn_dng_gst_cn = 0
            curr_wk_pu_sec_dng_gst_cn = 0
            curr_wk_pu_gtr_am = zero_decimal
            curr_wk_pu_ntr_am = zero_decimal
            curr_wk_pu_bkng_cn = 0
            curr_wk_dvc_pu_bkng_cn = 0
            curr_wk_obo_pu_bkng_cn = 0
            curr_wk_prevl_pu_bkng_cn = 0
            curr_wk_promo_pu_bkng_cn = 0
            curr_wk_irgs_pu_bkng_cn = 0
            curr_wk_other_pu_bkng_cn = 0
            curr_wk_irgs_oh_bkng_cn = 0
            curr_wk_non_irgs_oh_bkng_cn = 0
            # it is a sunday so reset all values of curr_wk
        if row.fill_flag == 1:
            curr_wk_oh_bkng_gst_cn = curr_wk_oh_bkng_gst_cn + row.pu_bkng_gst_cn_only
            curr_wk_pu_bkng_gst_cn = curr_wk_pu_bkng_gst_cn + row.pu_bkng_gst_cn
            curr_wk_pu_bkng_adlt_gst_cn = curr_wk_pu_bkng_adlt_gst_cn + row.pu_bkng_adlt_gst_cn - row.cncl_bkng_adlt_gst_cn
            curr_wk_pu_bkng_chld_gst_cn = curr_wk_pu_bkng_chld_gst_cn + row.pu_bkng_chld_gst_cn - row.cncl_bkng_chld_gst_cn
            curr_wk_pu_bkng_ifnt_gst_cn = curr_wk_pu_bkng_ifnt_gst_cn + row.pu_bkng_ifnt_gst_cn - row.cncl_bkng_ifnt_gst_cn
            curr_wk_pu_mn_dng_gst_cn = curr_wk_pu_mn_dng_gst_cn + row.pu_mn_dng_gst_cn
            curr_wk_pu_sec_dng_gst_cn = curr_wk_pu_sec_dng_gst_cn + row.pu_sec_dng_gst_cn
            curr_wk_pu_gtr_am = curr_wk_pu_gtr_am + Decimal(row.pu_gtr_am)
            curr_wk_pu_ntr_am = curr_wk_pu_ntr_am + Decimal(row.pu_ntr_am)
            curr_wk_pu_bkng_cn = curr_wk_pu_bkng_cn + row.pu_bkng_cn - row.cncl_bkng_cn
            curr_wk_dvc_pu_bkng_cn = curr_wk_dvc_pu_bkng_cn + row.dvc_pu_bkng_cn
            curr_wk_obo_pu_bkng_cn = curr_wk_obo_pu_bkng_cn + row.obo_pu_bkng_cn
            curr_wk_prevl_pu_bkng_cn = curr_wk_prevl_pu_bkng_cn + row.prevl_pu_bkng_cn
            curr_wk_promo_pu_bkng_cn = curr_wk_promo_pu_bkng_cn + row.promo_pu_bkng_cn
            curr_wk_irgs_pu_bkng_cn = curr_wk_irgs_pu_bkng_cn + row.irgs_pu_bkng_cn
            curr_wk_other_pu_bkng_cn = curr_wk_other_pu_bkng_cn + row.other_pu_bkng_cn + row.non_irgs_other_pu_bkng_cn
            if row.txn_dt.weekday() == 6:
                # first day so only include pickups for irgs_oh_bkng_cn
                curr_wk_irgs_oh_bkng_cn = curr_wk_irgs_oh_bkng_cn + row.irgs_pu_only
                curr_wk_non_irgs_oh_bkng_cn = curr_wk_non_irgs_oh_bkng_cn + row.non_irgs_other_pu_only
            else:
                curr_wk_irgs_oh_bkng_cn = curr_wk_irgs_oh_bkng_cn + row.irgs_pu_only + row.cncl_weekly_irgs
                curr_wk_non_irgs_oh_bkng_cn = curr_wk_non_irgs_oh_bkng_cn + row.non_irgs_other_pu_only + row.cncl_weekly_not_irgs

        res_summary_list.append(Row(row.vyge_id, row[STRM_PARTITION_COLUMN], row.txn_dt, \
                                    curr_wk_oh_bkng_gst_cn, \
                                    curr_wk_pu_bkng_gst_cn, \
                                    curr_wk_pu_bkng_adlt_gst_cn, \
                                    curr_wk_pu_bkng_chld_gst_cn, \
                                    curr_wk_pu_bkng_ifnt_gst_cn, \
                                    curr_wk_pu_mn_dng_gst_cn, \
                                    curr_wk_pu_sec_dng_gst_cn, \
                                    curr_wk_pu_gtr_am, \
                                    curr_wk_pu_ntr_am, \
                                    curr_wk_pu_bkng_cn, \
                                    curr_wk_dvc_pu_bkng_cn, \
                                    curr_wk_obo_pu_bkng_cn, \
                                    curr_wk_prevl_pu_bkng_cn, \
                                    curr_wk_promo_pu_bkng_cn, \
                                    curr_wk_irgs_pu_bkng_cn, \
                                    curr_wk_other_pu_bkng_cn, \
                                    curr_wk_irgs_oh_bkng_cn, \
                                    curr_wk_non_irgs_oh_bkng_cn))

        last_vyge_id = row.vyge_id
        last_STRM_PARTITION_COLUMN = row[STRM_PARTITION_COLUMN]
    return iter(res_summary_list)


# summarizes each reservation
# each reservation is a sequence of updated transactions with a single res_id
def summarize_vyge_strm_reservations(rows):
    res_summary_list = []
    gross_end_dt = datetime.strptime('9999-12-31', "%Y-%m-%d").date()
    last_week_start_dt = -1
    last_res_id = -1
    last_adlt_gst_cn = 0
    last_chld_gst_cn = 0
    last_ifnt_gst_cn = 0
    zero_decimal = Decimal(0)
    last_gst_cn = 0
    gross_vyge = {}
    for row in rows:
        new = 0
        if last_res_id != -1 and last_res_id != row.res_id:
            last_adlt_gst_cn = 0
            last_chld_gst_cn = 0
            last_ifnt_gst_cn = 0
            last_gst_cn = 0
            new = 1
        comp_dt = row.vrsn_strt_dts
        if str(comp_dt) == '1800-01-01':
            comp_dt = row.res_init_bkng_dt
        subtract_days = -1 * (comp_dt.weekday() + 1)
        week_start_dt = comp_dt + timedelta(days=(subtract_days))
        if new == 1:
            last_week_start_dt = week_start_dt

        if new == 1 or row.prev_vyge_id != row.vyge_id or row[PREV_STRM_PARTITION_COLUMN] != row[STRM_PARTITION_COLUMN]:
            # vyge_id,start_dt,end_Dt,cancel,oh_book,pickup,pu_gst_cn_only,asigned,gross_cnt,oh_asgn_bkng_gst_cn,oh_bkng_gst_cn,oh_bkng_adlt_gst_cn,chld_gst_cn,ifnt_gst_cn,pu_bkng_adlt,pu_bkng_chld,
            # pu_bkng_inf,cncl_adlt,cncl_chld,cncl_ifnt,gtr_am,ntr_am,comm_am,non_comm_am,dvc,obo,prevl,promo,irgs,other,no_irgs_other,
            # pu_bkng_gst_cn,main,second,dvc,obo,prevl,promo,irgs,other,no_irgs_other,gtr,ntr
            # oh_main_dining, oh_sec_ding, irgs_pu, no_irgs_other_pu, cancel_weekly_irgs, cancel_weekly_no_irgs

            if not (row.res_sts_cd in ('CX', 'CT') and row.prev_vyge_id == None and str(
                    row.vrsn_strt_dts) != '1800-01-01') and row.res_sts_cd != 'WL' and \
                    not (row.res_init_bkng_dt == row.res_cncl_dt and str(row.vrsn_strt_dts) == '1800-01-01'):
                # no same day cancellations and status code not a waitlist and special handling for 180-01-01
                res_summary_list.append(
                    Row(row.vyge_id, row[STRM_PARTITION_COLUMN], comp_dt, gross_end_dt, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, \
                        zero_decimal, zero_decimal, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0))

        prevl_cnt = 0
        dvc_cnt = 0
        obo_cnt = 0
        promo_cnt = 0
        irgs_cnt = 0
        irgs_other_cnt = 0
        other_cnt = 0
        no_irgs_other_cnt = 0
        if row.sfb_nm in ('DVC'):
            dvc_cnt = 1
        elif row.sfb_nm in ('PREVAIL'):
            prevl_cnt = 1
        elif row.sfb_nm in ('OBO'):
            obo_cnt = 1
        elif row.sfb_nm in ('WDW_CAST', 'MTO', 'CANADIAN', 'KIDS_FREE', 'DCL_CAST', 'FLR', 'GTY', 'TAAP', 'INTERLINE'):
            promo_cnt = 1
        elif row.sfb_nm in ('WORKER') and row.intrnl_req_for_gst_strm_in == 1:
            irgs_cnt = 1
        elif row.sfb_nm in ('WORKER') and row.intrnl_req_for_gst_strm_in == 0:
            no_irgs_other_cnt = 1
        elif row.sfb_nm in ('GROUP', 'CMR', 'CHARTER', 'OTHERS'):
            other_cnt = 1

        gtr_am = zero_decimal
        ntr_am = zero_decimal
        if row.gtr_am != None:
            gtr_am = Decimal(row.gtr_am)
        if row.ntr_am != None:
            ntr_am = Decimal(row.ntr_am)
        main_dining = 0
        second_dining = 0
        if row.dng_cd != None:
            if row.dng_cd.upper() == 'MAIN':
                main_dining = row.tot_gst_cn
            elif row.dng_cd.upper() == 'SECOND':
                second_dining = row.tot_gst_cn
        if row.res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
            end_dt = row.vrsn_end_dts + timedelta(days=-1)
            asgn_cnt = 0
            asgn_gst_cn = 0
            comp_dt = row.vrsn_strt_dts
            if str(comp_dt) == '1800-01-01':
                comp_dt = row.res_init_bkng_dt
            if row.asgn_strm_typ_cd != None:
                asgn_cnt = 1
                asgn_gst_cn = row.tot_gst_cn
            non_comm_am = Decimal(0)
            comm_am = Decimal(0)
            if row.comm_am != None:
                comm_am = Decimal(row.comm_am)
            if row.non_comm_am != None:
                non_comm_am = Decimal(row.non_comm_am)

            # vyge_id,start_dt,end_Dt,cancel,oh_book,pickup,pu_gst_cn_only,asigned,gross_cnt,oh_asgn_bkng_gst_cn,oh_bkng_gst_cn,oh_bkng_adlt_gst_cn,chld_gst_cn,ifnt_gst_cn,pu_bkng_adlt,pu_bkng_chld,
            # pu_bkng_inf,cncl_adlt,cncl_chld,cncl_ifnt,gtr_am,ntr_am,comm_am,non_comm_am,dvc,obo,prevl,promo,irgs,other,no_irgs_other,
            # pu_bkng_gst_cn,main,second,dvc,obo,prevl,promo,irgs,other,no_irgs_other,gtr,ntr
            # oh_main_dining, oh_sec_ding, irgs_pu, no_irgs_other_pu, cancel_weekly_irgs, cancel_weekly_no_irgs
            res_summary_list.append(
                Row(row.vyge_id, row[STRM_PARTITION_COLUMN], comp_dt, end_dt, 0, 1, 0, 0, asgn_cnt, 0, asgn_gst_cn, row.tot_gst_cn,
                    row.adlt_gst_cn, row.chld_gst_cn, row.ifnt_gst_cn, \
                    0, 0, 0, 0, 0, 0, gtr_am, ntr_am, comm_am, non_comm_am, \
                    dvc_cnt, obo_cnt, prevl_cnt, promo_cnt, irgs_cnt, other_cnt, no_irgs_other_cnt, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, zero_decimal, zero_decimal, \
                    main_dining, second_dining, 0, 0, 0, 0))
            # if not row.vyge_id  in gross_vyge:
            #   res_summary_list.append(Row(row.vyge_id,comp_dt,gross_end_dt,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,\
            #                               zero_decimal,zero_decimal,zero_decimal,zero_decimal,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,zero_decimal,zero_decimal))
            #   gross_vyge[row.vyge_id]=1
            # accum_map[key]["oh_paid_bkng_cn"] = accum_map[key]["oh_paid_bkng_cn"] +1

            if row.prev_res_sts_cd == None or row.prev_res_sts_cd in (
            'CX', 'CT', 'WL') or row.vyge_id != row.prev_vyge_id or row[PREV_STRM_PARTITION_COLUMN] != row[STRM_PARTITION_COLUMN]:
                res_summary_list.append(
                    Row(row.vyge_id, row[STRM_PARTITION_COLUMN], comp_dt, row.vrsn_strt_dts, 0, 0, 1, row.tot_gst_cn, 0, 0, 0, 0,
                        0, 0, 0, row.adlt_gst_cn, row.chld_gst_cn, row.ifnt_gst_cn, \
                        0, 0, 0, zero_decimal, zero_decimal, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0, 0,
                        row.tot_gst_cn, main_dining, second_dining, \
                        dvc_cnt, obo_cnt, prevl_cnt, promo_cnt, irgs_cnt, other_cnt, no_irgs_other_cnt, gtr_am, ntr_am,
                        0, 0, irgs_cnt, no_irgs_other_cnt, 0, 0))
                # accum_map[key]["pu_bkng_cn"] = accum_map[key]["pu_bkng_cn"] +1
                # check for fake cancels on the business date
                if row.prev_res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
                    # accum_map[temp_key]["cncl_bkng_cn"] = accum_map[temp_key]["cncl_bkng_cn"] +1
                    cncl_weekly_irgs = 0
                    cncl_weekly_no_irgs = 0
                    if week_start_dt == last_week_start_dt:
                        cncl_weekly_irgs = -1 * irgs_cnt
                        cncl_weekly_no_irgs = -1 * no_irgs_other_cnt
                    res_summary_list.append(
                        Row(row.prev_vyge_id, row[STRM_PARTITION_COLUMN], row.vrsn_strt_dts, row.vrsn_strt_dts, 1, 0, 0, 0, 0, 0,
                            0, 0, 0, 0, 0, 0, 0, 0, last_adlt_gst_cn, \
                            last_chld_gst_cn, last_ifnt_gst_cn, zero_decimal, zero_decimal, zero_decimal, zero_decimal, \
                            0, 0, 0, 0, 0, 0, 0, \
                            -1 * row.tot_gst_cn, -1 * main_dining, -1 * second_dining, -1 * dvc_cnt, \
                            -1 * obo_cnt, -1 * prevl_cnt, -1 * promo_cnt, -1 * irgs_cnt, -1 * other_cnt,
                            -1 * no_irgs_other_cnt, -1 * gtr_am, -1 * ntr_am, 0, 0, 0, 0, \
                            cncl_weekly_irgs, cncl_weekly_no_irgs))

        if row.res_sts_cd in ('CX', 'CT', 'WL'):
            if row.prev_res_sts_cd != 'WL' and row.prev_res_sts_cd in ('OF', 'BK', 'CL', 'TM'):
                # regular cancellation
                if row.prev_vyge_id == row.vyge_id and row[PREV_STRM_PARTITION_COLUMN] == row[STRM_PARTITION_COLUMN]:
                    # accum_map[key]["cncl_bkng_cn"] = accum_map[key]["cncl_bkng_cn"] +1
                    cncl_weekly_irgs = 0
                    cncl_weekly_no_irgs = 0
                    if week_start_dt == last_week_start_dt:
                        cncl_weekly_irgs = -1 * irgs_cnt
                        cncl_weekly_no_irgs = -1 * no_irgs_other_cnt
                    res_summary_list.append(
                        Row(row.vyge_id, row[STRM_PARTITION_COLUMN], row.vrsn_strt_dts, row.vrsn_strt_dts, 1, 0, 0, 0, 0, 0, 0, 0,
                            0, 0, 0, 0, 0, 0, row.adlt_gst_cn, row.chld_gst_cn, row.ifnt_gst_cn, \
                            zero_decimal, zero_decimal, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0, 0, \
                            -1 * row.tot_gst_cn, -1 * main_dining, -1 * second_dining, -1 * dvc_cnt, \
                            -1 * obo_cnt, -1 * prevl_cnt, -1 * promo_cnt, -1 * irgs_cnt, -1 * other_cnt,
                            -1 * no_irgs_other_cnt, -1 * gtr_am, -1 * ntr_am, 0, 0, 0, 0, \
                            cncl_weekly_irgs, cncl_weekly_no_irgs))
                    # if not row.vyge_id  in gross_vyge:
                    #    res_summary_list.append(Row(row.vyge_id,row.vrsn_strt_dts,gross_end_dt,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,\
                    #                                zero_decimal,zero_decimal,zero_decimal,zero_decimal,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,zero_decimal,zero_decimal))
                    #    gross_vyge[row.vyge_id]=1
                else:
                    # same day cancellation - so we need to apply a cancellation on the previous pk
                    # accum_map[temp_key]["cncl_bkng_cn"] = accum_map[temp_key]["cncl_bkng_cn"] +1
                    res_summary_list.append(
                        Row(row.prev_vyge_id, row[PREV_STRM_PARTITION_COLUMN], row.vrsn_strt_dts, row.vrsn_strt_dts, 1, 0, 0, 0, 0,
                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                            zero_decimal, zero_decimal, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0, 0, \
                            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, zero_decimal, zero_decimal, 0, 0, 0, 0, 0, 0))
                    # if not row.prev_vyge_id  in gross_vyge:
                    #    res_summary_list.append(Row(row.vyge_id,row.vrsn_strt_dts,gross_end_dt,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,\
                    #                            zero_decimal,zero_decimal,zero_decimal,zero_decimal,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,zero_decimal,zero_decimal))
                    #    gross_vyge[row.prev_vyge_id]=1
        last_res_id = row.res_id
        last_adlt_gst_cn = row.adlt_gst_cn
        last_chld_gst_cn = row.chld_gst_cn
        last_ifnt_gst_cn = row.ifnt_gst_cn
        last_gst_cn = row.tot_gst_cn
        last_week_start_dt = week_start_dt
    # for key,value in accum_map.iteritems():
    #      res_summary_list.append(Row(value["vyge_id"],value["txn_dt"],\
    #                                      value["cncl_bkng_cn"],value["oh_paid_bkng_cn"],\
    #                                      value["pu_bkng_cn"]))
    return iter(res_summary_list)




class ConVygeStrmCtgResBaselnDly(BaseJob):
    def __init__(self):
        self.name = "ConVygeStrmCtgResBaselnDly"
        super(ConVygeStrmCtgResBaselnDly, self).__init__(self.name)

    def setUp(self):
        pass

    def loadData(self):
        pass

    def createDriver(self):
        pass

    def preProcess(self):
        pass

    def process(self):
        self.run_con_res_baseln_vyge_strm(self.start_date, self.end_date, self.spark, self.data_loader)


    def writeToHDFS(self):
        pass

    def tearDown(self):
        pass

    def run_con_res_baseln_vyge_strm(self,txn_dt_start,txn_dt_end,sql_context,data_loader):
        """ reads resbaseln and processes it on a sunday-saturday basis persists it on a weekly basis and puts a date in yyyy-mm-dd format for that saturday
        Attributes:
          txn_dt_start : The date for which bookings need to be summarized
          txn_dt_end: the date until which we need to summarize bookings
          data_loader : utility class to load data
          converter: a converter to convert data from rdd to dataframe givein a schema
          sql_context:  spark sql_context
        """
        converter = DataFrameUtil(sql_context)

        # since we need to weekly aggregations we need to ensure the txn_dt_start goes back to include a sunday
        orig_txn_dt_start = txn_dt_start
        week_day = txn_dt_start.weekday()
        if week_day != 6:
            subtract_days = -1 * (week_day + 1)
            txn_dt_start = txn_dt_start + timedelta(days=(subtract_days))
        print
        " the value of txn_dt orig and modifed are %s and %s " % (orig_txn_dt_start, txn_dt_start)

        # read the dt data set and identify the start and end date boundaries - sundaty to saturday
        # if the input txn_dt_start falls on a monday we will roll it back one day to make it sunday and add 6 days and keep going until we hit the end_dt. End date is fixed
        # python weekday function gives 0 for Monday and 6 for Sunday
        if (data_loader.check_parition_if_date_exists(FOLDER, DATA_REF, "txn_dt", str(txn_dt_start))):
            # data exists already print a message and exit
            print
            " Data for the period starting from %s already exists, consider running a full data load or adjust your dates " % txn_dt_start
            sys.exit(-1)

        coalesce_count = 2
        if (txn_dt_end - txn_dt_start).days > 30:
            coalesce_count = (txn_dt_end - txn_dt_start).days / 30

        # vyge_id,start_dt,end_Dt,cancel,oh_book,pickup,asigned,gross_cnt,oh_asgn_bkng_gst_cn,oh_bkng_gst_cn,oh_bkng_adlt_gst_cn,chld_gst_cn,ifnt_gst_cn,pu_bkng_adlt,pu_bkng_chld,
        # pu_bkng_inf,cncl_adlt,cncl_chld,cncl_ifnt,gtr_am,ntr_am,comm_am,non_comm_am,dvc,obo,prevl,promo,irgs,other

        f = lambda x: summarize_vyge_strm_reservations(x)
        print
        " the values of revised start and end date are %s %s " % (txn_dt_start, txn_dt_end)
        # extract res baseline and cache it
        res_baseln_sum_df = data_loader.read_data_with_filter("dm", "RES_BASELN", "partition_dt", INIT_DT,
                                                              str(txn_dt_end),
                                                              None) \
            .filter("price_strm_typ_cd != 'IRG' and price_strm_typ_cd != 'XAM' and sfb_nm!='OFFICER'") \
            .select("res_id", col("vrsn_strt_dts").cast("date"), col("vrsn_end_dts").cast("date"), "res_cncl_dt",
                    "sfb_nm", \
                    "res_sts_cd", "vyge_id", "prev_vyge_id", col("price_strm_typ_cd").alias("strm_typ_cd"),
                    "prev_res_sts_cd", "res_init_bkng_dt", col("price_ship_strm_ctgy_nm").alias("strm_ctgy_nm"), \
                    col("prev_price_ship_strm_ctgy_nm").alias("prev_strm_ctgy_nm") \
                    , "prev_strm_typ_cd", "intrnl_req_for_gst_strm_in", "tot_gst_cn", "adlt_gst_cn", "chld_gst_cn", \
                    "ifnt_gst_cn", "gtr_am", "ntr_am", "non_comm_am", "comm_am", "asgn_strm_typ_cd", "dng_cd") \
            .repartition("res_id") \
            .sortWithinPartitions("res_id", asc("vrsn_strt_dts")) \
            .rdd.mapPartitions(f, preservesPartitioning=True)

        res_baseln_sum_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                            StructField(STRM_PARTITION_COLUMN, StringType(), True),
                                            StructField("txn_dt_start", DateType(), True),
                                            StructField("txn_dt_end", DateType(), True),
                                            StructField("cncl_bkng_cn", IntegerType(), True),
                                            StructField("oh_bkng_cn", IntegerType(), True),
                                            StructField("pu_bkng_cn", IntegerType(), True),
                                            StructField("pu_bkng_gst_cn_only", IntegerType(), True),
                                            StructField("oh_asgn_bkng_cn", IntegerType(), True),
                                            StructField("grs_paid_bkng_cn", IntegerType(), True),
                                            StructField("oh_asgn_bkng_gst_cn", IntegerType(), True),
                                            StructField("oh_bkng_gst_cn", IntegerType(), True),
                                            StructField("oh_bkng_adlt_gst_cn", IntegerType(), True),
                                            StructField("oh_bkng_chld_gst_cn", IntegerType(), True),
                                            StructField("oh_bkng_ifnt_gst_cn", IntegerType(), True),
                                            StructField("pu_bkng_adlt_gst_cn", IntegerType(), True),
                                            StructField("pu_bkng_chld_gst_cn", IntegerType(), True),
                                            StructField("pu_bkng_ifnt_gst_cn", IntegerType(), True),
                                            StructField("cncl_bkng_adlt_gst_cn", IntegerType(), True),
                                            StructField("cncl_bkng_chld_gst_cn", IntegerType(), True),
                                            StructField("cncl_bkng_ifnt_gst_cn", IntegerType(), True),
                                            StructField("gtr_am", DecimalType(10, 2), True),
                                            StructField("ntr_am", DecimalType(10, 2), True),
                                            StructField("comm_am", DecimalType(10, 2), True),
                                            StructField("non_comm_am", DecimalType(10, 2), True),
                                            StructField("dvc_oh_bkng_cn", IntegerType(), True),
                                            StructField("obo_oh_bkng_cn", IntegerType(), True),
                                            StructField("prevl_oh_bkng_cn", IntegerType(), True),
                                            StructField("promo_oh_bkng_cn", IntegerType(), True),
                                            StructField("irgs_oh_bkng_cn", IntegerType(), True),
                                            StructField("other_oh_bkng_cn", IntegerType(), True),
                                            StructField("non_irgs_other_oh_bkng_cn", IntegerType(), True),
                                            StructField("pu_bkng_gst_cn", IntegerType(), True),
                                            StructField("pu_mn_dng_gst_cn", IntegerType(), True),
                                            StructField("pu_sec_dng_gst_cn", IntegerType(), True),
                                            StructField("dvc_pu_bkng_cn", IntegerType(), True),
                                            StructField("obo_pu_bkng_cn", IntegerType(), True),
                                            StructField("prevl_pu_bkng_cn", IntegerType(), True),
                                            StructField("promo_pu_bkng_cn", IntegerType(), True),
                                            StructField("irgs_pu_bkng_cn", IntegerType(), True),
                                            StructField("other_pu_bkng_cn", IntegerType(), True),
                                            StructField("non_irgs_other_pu_bkng_cn", IntegerType(), True),
                                            StructField("pu_gtr_am", DecimalType(10, 2), True),
                                            StructField("pu_ntr_am", DecimalType(10, 2), True),
                                            StructField("oh_bkng_mn_dng_gst_cn", IntegerType(), True),
                                            StructField("oh_bkng_sec_dng_gst_cn", IntegerType(), True),
                                            StructField("irgs_pu_only", IntegerType(), True),
                                            StructField("non_irgs_other_pu_only", IntegerType(), True),
                                            StructField("cncl_weekly_irgs", IntegerType(), True),
                                            StructField("cncl_weekly_not_irgs", IntegerType(), True)
                                            ])
        res_baseln_vyge_con_df = converter.convertRddToDataFrame(res_baseln_sum_df, res_baseln_sum_schema)
        res_baseln_final_df = res_baseln_vyge_con_df.groupBy("vyge_id", STRM_PARTITION_COLUMN, "txn_dt_start",
                                                             "txn_dt_end") \
            .agg(sum("cncl_bkng_cn").alias("cncl_bkng_cn"), \
                 sum("oh_bkng_cn").alias("oh_bkng_cn"), \
                 sum("pu_bkng_cn").alias("pu_bkng_cn"), \
                 sum("pu_bkng_gst_cn_only").alias("pu_bkng_gst_cn_only"), \
                 sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
                 sum("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
                 sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"), \
                 sum("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
                 sum("oh_bkng_adlt_gst_cn").alias("oh_bkng_adlt_gst_cn"), \
                 sum("oh_bkng_chld_gst_cn").alias("oh_bkng_chld_gst_cn"), \
                 sum("oh_bkng_ifnt_gst_cn").alias("oh_bkng_ifnt_gst_cn"), \
                 sum("oh_bkng_mn_dng_gst_cn").alias("oh_bkng_mn_dng_gst_cn"), \
                 sum("oh_bkng_sec_dng_gst_cn").alias("oh_bkng_sec_dng_gst_cn"), \
                 sum("pu_bkng_adlt_gst_cn").alias("pu_bkng_adlt_gst_cn"), \
                 sum("pu_bkng_chld_gst_cn").alias("pu_bkng_chld_gst_cn"), \
                 sum("pu_bkng_ifnt_gst_cn").alias("pu_bkng_ifnt_gst_cn"), \
                 sum("cncl_bkng_adlt_gst_cn").alias("cncl_bkng_adlt_gst_cn"), \
                 sum("cncl_bkng_chld_gst_cn").alias("cncl_bkng_chld_gst_cn"), \
                 sum("cncl_bkng_ifnt_gst_cn").alias("cncl_bkng_ifnt_gst_cn"), \
                 round(sum("gtr_am"), 2).alias("gtr_am"), \
                 round(sum("ntr_am"), 2).alias("ntr_am"), \
                 round(sum("comm_am"), 2).alias("comm_am"), \
                 round(sum("non_comm_am"), 2).alias("non_comm_am"), \
                 sum("dvc_oh_bkng_cn").alias("dvc_oh_bkng_cn"), \
                 sum("obo_oh_bkng_cn").alias("obo_oh_bkng_cn"), \
                 sum("prevl_oh_bkng_cn").alias("prevl_oh_bkng_cn"), \
                 sum("promo_oh_bkng_cn").alias("promo_oh_bkng_cn"), \
                 sum("irgs_oh_bkng_cn").alias("irgs_oh_bkng_cn"), \
                 sum("other_oh_bkng_cn").alias("other_oh_bkng_cn"), \
                 sum("non_irgs_other_oh_bkng_cn").alias("non_irgs_other_oh_bkng_cn"), \
                 sum("pu_bkng_gst_cn").alias("pu_bkng_gst_cn"), \
                 sum("pu_mn_dng_gst_cn").alias("pu_mn_dng_gst_cn"), \
                 sum("pu_sec_dng_gst_cn").alias("pu_sec_dng_gst_cn"), \
                 sum("dvc_pu_bkng_cn").alias("dvc_pu_bkng_cn"), \
                 sum("obo_pu_bkng_cn").alias("obo_pu_bkng_cn"), \
                 sum("prevl_pu_bkng_cn").alias("prevl_pu_bkng_cn"), \
                 sum("promo_pu_bkng_cn").alias("promo_pu_bkng_cn"), \
                 sum("irgs_pu_bkng_cn").alias("irgs_pu_bkng_cn"), \
                 sum("cncl_weekly_irgs").alias("cncl_weekly_irgs"), \
                 sum("cncl_weekly_not_irgs").alias("cncl_weekly_not_irgs"), \
                 sum("non_irgs_other_pu_bkng_cn").alias("non_irgs_other_pu_bkng_cn"), \
                 sum("irgs_pu_only").alias("irgs_pu_only"), \
                 sum("non_irgs_other_pu_only").alias("non_irgs_other_pu_only"), \
                 sum("other_pu_bkng_cn").alias("other_pu_bkng_cn"), \
                 sum("pu_gtr_am").alias("pu_gtr_am"), \
                 sum("pu_ntr_am").alias("pu_ntr_am"))

        # after summarization is done we need to ensure we get all the voyages and fill in the driver
        all_vyge_attr_valid_df = data_loader.read_data("dm", "VYGE_ATTR") \
            .filter("invld_vyge_in = 0 and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null) \
                                                        and upper(instnc_st_nm)='STANDARD'") \
            .select("vyge_id") \
            .distinct()
        all_vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR") \
            .filter("invld_vyge_in = 0 and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null)") \
            .groupBy("vyge_id") \
            .agg(min("vyge_opn_dt").alias("vyge_opn_dt"), \
                 min("vyge_init_bkng_dt").alias("vyge_init_bkng_dt"), \
                 min("vyge_arvl_dt").alias("vyge_arvl_dt")) \
            .select("vyge_id", "vyge_arvl_dt", "vyge_opn_dt", "vyge_init_bkng_dt").join(all_vyge_attr_valid_df,
                                                                                        ["vyge_id"]) \
            .select("vyge_id", least("vyge_opn_dt", "vyge_init_bkng_dt").alias("vyge_opn_dt"), "vyge_arvl_dt")

        f = lambda x: generate_driver(x, txn_dt_start, txn_dt_end)
        keys_df = all_vyge_attr_df.rdd.flatMap(f)
        keys_schema = StructType([StructField("vyge_id", IntegerType(), True), StructField("txn_dt", DateType(), True),
                                  StructField("fill_flag", IntegerType(), True)])
        driver_df = sql_context.createDataFrame(keys_df, keys_schema)

        # end of creating driver
        # create final table
        res_baseln_vyge_df = res_baseln_final_df.join(driver_df, ["vyge_id"]) \
            .filter("txn_dt >= txn_dt_start and txn_dt <= txn_dt_end") \
            .groupBy("vyge_id", STRM_PARTITION_COLUMN, "txn_dt") \
            .agg(sum("cncl_bkng_cn").alias("cncl_bkng_cn"), \
                 sum("oh_bkng_cn").alias("oh_bkng_cn"), \
                 sum("pu_bkng_cn").alias("pu_bkng_cn"), \
                 sum("pu_bkng_gst_cn_only").alias("pu_bkng_gst_cn_only"), \
                 sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
                 sum("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
                 sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"), \
                 sum("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
                 sum("oh_bkng_adlt_gst_cn").alias("oh_bkng_adlt_gst_cn"), \
                 sum("oh_bkng_chld_gst_cn").alias("oh_bkng_chld_gst_cn"), \
                 sum("oh_bkng_mn_dng_gst_cn").alias("oh_bkng_mn_dng_gst_cn"), \
                 sum("oh_bkng_sec_dng_gst_cn").alias("oh_bkng_sec_dng_gst_cn"), \
                 sum("oh_bkng_ifnt_gst_cn").alias("oh_bkng_ifnt_gst_cn"), \
                 sum("pu_bkng_adlt_gst_cn").alias("pu_bkng_adlt_gst_cn"), \
                 sum("pu_bkng_chld_gst_cn").alias("pu_bkng_chld_gst_cn"), \
                 sum("pu_bkng_ifnt_gst_cn").alias("pu_bkng_ifnt_gst_cn"), \
                 sum("cncl_bkng_adlt_gst_cn").alias("cncl_bkng_adlt_gst_cn"), \
                 sum("cncl_bkng_chld_gst_cn").alias("cncl_bkng_chld_gst_cn"), \
                 sum("cncl_bkng_ifnt_gst_cn").alias("cncl_bkng_ifnt_gst_cn"), \
                 round(sum("gtr_am"), 2).alias("gtr_am"), \
                 round(sum("ntr_am"), 2).alias("ntr_am"), \
                 round(sum("comm_am"), 2).alias("comm_am"), \
                 round(sum("non_comm_am"), 2).alias("non_comm_am"), \
                 sum("dvc_oh_bkng_cn").alias("dvc_oh_bkng_cn"), \
                 sum("obo_oh_bkng_cn").alias("obo_oh_bkng_cn"), \
                 sum("prevl_oh_bkng_cn").alias("prevl_oh_bkng_cn"), \
                 sum("promo_oh_bkng_cn").alias("promo_oh_bkng_cn"), \
                 sum("irgs_oh_bkng_cn").alias("irgs_oh_bkng_cn"), \
                 sum(res_baseln_final_df.other_oh_bkng_cn + res_baseln_final_df.non_irgs_other_oh_bkng_cn).alias(
                     "other_oh_bkng_cn"), \
                 sum("pu_bkng_gst_cn").alias("pu_bkng_gst_cn"), \
                 sum("pu_mn_dng_gst_cn").alias("pu_mn_dng_gst_cn"), \
                 sum("pu_sec_dng_gst_cn").alias("pu_sec_dng_gst_cn"), \
                 sum("dvc_pu_bkng_cn").alias("dvc_pu_bkng_cn"), \
                 sum("obo_pu_bkng_cn").alias("obo_pu_bkng_cn"), \
                 sum("prevl_pu_bkng_cn").alias("prevl_pu_bkng_cn"), \
                 sum("promo_pu_bkng_cn").alias("promo_pu_bkng_cn"), \
                 sum("irgs_pu_bkng_cn").alias("irgs_pu_bkng_cn"), \
                 sum("irgs_pu_only").alias("irgs_pu_only"), \
                 sum("other_pu_bkng_cn").alias("other_pu_bkng_cn"), \
                 sum("non_irgs_other_oh_bkng_cn").alias("non_irgs_other_oh_bkng_cn"), \
                 sum("cncl_weekly_irgs").alias("cncl_weekly_irgs"), \
                 sum("cncl_weekly_not_irgs").alias("cncl_weekly_not_irgs"), \
                 sum("non_irgs_other_pu_bkng_cn").alias("non_irgs_other_pu_bkng_cn"), \
                 sum("non_irgs_other_pu_only").alias("non_irgs_other_pu_only"), \
                 sum("pu_gtr_am").alias("pu_gtr_am"), \
                 sum("pu_ntr_am").alias("pu_ntr_am"), \
                 max("fill_flag").alias("fill_flag"))

        # enf of table creating aggregations at txn_dt level
        # start of 7 day aggregtions
        f = lambda x: summarize_vyge_strm_reservations_by_week(x)
        res_baseln_vyge_weekly_df = res_baseln_vyge_df.repartition("vyge_id", STRM_PARTITION_COLUMN) \
            .sortWithinPartitions("vyge_id", STRM_PARTITION_COLUMN, asc("txn_dt")) \
            .rdd.mapPartitions(f, preservesPartitioning=True)

        res_baseln_week_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                             StructField(STRM_PARTITION_COLUMN, StringType(), True),
                                             StructField("txn_dt", DateType(), True),
                                             StructField("curr_wk_oh_bkng_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_bkng_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_bkng_adlt_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_bkng_chld_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_bkng_ifnt_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_mn_dng_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_sec_dng_gst_cn", IntegerType(), True),
                                             StructField("curr_wk_pu_gtr_am", DecimalType(11, 2), True),
                                             StructField("curr_wk_pu_ntr_am", DecimalType(11, 2), True),
                                             StructField("curr_wk_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_dvc_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_obo_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_prevl_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_promo_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_irgs_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_other_pu_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_irgs_oh_bkng_cn", IntegerType(), True),
                                             StructField("curr_wk_non_irgs_oh_bkng_cn", IntegerType(), True)
                                             ])
        res_baseln_vyge_week_df = converter.convertRddToDataFrame(res_baseln_vyge_weekly_df, res_baseln_week_schema)
        res_baseln_vyge_fnl_df = res_baseln_vyge_df.join(res_baseln_vyge_week_df,
                                                         ["vyge_id", "txn_dt", STRM_PARTITION_COLUMN]).drop("fill_flag")
        sub_filter = " txn_dt >= date('%s') " % (orig_txn_dt_start)
        res_baseln_vyge_fnl_df = res_baseln_vyge_fnl_df.filter(sub_filter)
        data_loader.write_data_to_partition(FOLDER, DATA_REF, PARTITION_COL, str(txn_dt_end),
                                            res_baseln_vyge_fnl_df.coalesce(coalesce_count), "overwrite")


if __name__ == '__main__':
    try:
        obj = ConVygeStrmCtgResBaselnDly()
        obj.execute()
    except:
        traceback.print_exc()
        raise
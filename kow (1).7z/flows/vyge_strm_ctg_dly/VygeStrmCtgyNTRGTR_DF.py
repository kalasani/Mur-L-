#############################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management        #
# Program name      : Demand by Booking  - consolidate resbaseln class load #
# Author            : Kowshik Yerra                                         #
# Date created      : 20180920                                              #
# Purpose           : populate consolidate resbaseln metrics                #
# Revision History  :                                                       #
#  Date        Author     Ref    Revision (Date in YYYYMMDD format)         #
# 20180920     Kowshik Y   Chris                                            #
#                                                                           #
#############################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import sys, traceback
from framework.core.BaseJob import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *
from pyspark.sql.types import *

from time import time
import os, sys

from pyspark.sql import Row
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row


class VygeStrmTypGtrNtrMetrics(object):

    def __init__(self, start_dt, end_dt, sql_context, s3_bucket, data_loader, runType, debug):
        self.start_dt = start_dt
        self.end_dt = end_dt
        self.sql_context = sql_context
        self.hdfs_path = s3_bucket
        self.data_loader = data_loader
        self.debug = debug
        self.runType = runType

    @staticmethod
    def populate_ppp_metrics(rows):
        last_vyge_id = -1
        last_version_start_date = None
        last_strm_typ_cd = -1
        last_metric = -1.0
        first_rec = 1
        vyge_drtn_nght_cn = None
        vfd_am = None
        vfa_extra_am = None
        vfc_extra_am = None
        vfi_extra_am = None
        non_comm_am = None
        ppm_metric_list = []
        for row in rows:
            if (
                    last_vyge_id != row.vyge_id or last_version_start_date != row.txn_dt or last_strm_typ_cd != row.strm_typ_cd) and first_rec != 1:
                # this is the first one
                ppm_metric_list.append(
                    Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am,
                        vfa_extra_am, vfc_extra_am, vfi_extra_am, non_comm_am))
                vyge_drtn_nght_cn = None
                vfd_am = None
                vfa_extra_am = None
                vfc_extra_am = None
                vfi_extra_am = None
                non_comm_am = None

            first_rec = 0
            if row.vyge_drtn_nght_cn != None and row.vfd_am != None and row.vfa_extra_am != None and row.vfc_extra_am != None and row.vfi_extra_am != None and row.non_comm_am != None:
                # assuming that we re processing price first and then cabing
                vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
                vfd_am = row.vfd_am
                vfa_extra_am = row.vfa_extra_am
                vfc_extra_am = row.vfc_extra_am
                vfi_extra_am = row.vfi_extra_am
                non_comm_am = row.non_comm_am

            last_vyge_id = row.vyge_id
            last_version_start_date = row.txn_dt
            last_strm_typ_cd = row.strm_typ_cd
            vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
            vfd_am = row.vfd_am
            vfa_extra_am = row.vfa_extra_am
            vfc_extra_am = row.vfc_extra_am
            vfi_extra_am = row.vfi_extra_am
            non_comm_am = row.non_comm_am
        if last_vyge_id != -1 and vfd_am != None and vfa_extra_am != None and vfc_extra_am != None and vfi_extra_am != None and non_comm_am != None:
            ppm_metric_list.append(
                Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am, vfa_extra_am,
                    vfc_extra_am,
                    vfi_extra_am, non_comm_am))
        return iter(ppm_metric_list)

    def runVygeStrmTypGtrNtrMetrics(self):
        vyge_attr_df = self.sql_context.sql("select * from vyge_attr ")
        proc_price_pt_vw_df = self.sql_context.sql("select * from proc_price_pt ")
        proc_price_pt_drvd_df = self.sql_context.sql("select * from proc_price_pt_vw ")
        vyge_strm_typ_dly_rcmd_drvd_df = self.sql_context.sql(""" select distinct vyge_id, strm_typ_cd, txn_dt,
								rcmd_vyge_gtr_pd_am,
								rcmd_vyge_adlt_gtr_pd_am,
								rcmd_vyge_chld_gtr_pd_am
							from vyge_strm_typ_dly_rcmd_vw """)
        vyge_strm_typ_drvr_df = self.sql_context.sql("select * from driver ")
        voyages_only_df = vyge_strm_typ_drvr_df.join(vyge_attr_df, ["vyge_id", "txn_dt"]) \
            .select("vyge_id", "txn_dt", vyge_strm_typ_drvr_df.strm_typ_cd, "vyge_init_bkng_dt")

        vyge_fnc_fcst_var_df = self.sql_context.sql(" select * from vyge_fnc_fcst_var_vw ")
        dflt_ship_fnc_fcst_df = self.sql_context.sql(" select * from dflt_ship_fnc_fcst_vw ")
        ooo_consolidated_vw_df = self.sql_context.sql("select * from ooo_consolidated_vw ")

        window_max = Window.partitionBy("ship_cd", "vyge_strt_dt").orderBy(col("data_ld_dts").asc()).rowsBetween(+1, +1)
        vyge_fnc_fcst_var_temp_df = vyge_fnc_fcst_var_df.withColumn("vrsn_end_dts",
                                                                    coalesce(max("data_ld_dts").over(window_max), \
                                                                             lit('9999-12-31 00:00:00.000000').cast(
                                                                                 "timestamp")))
        vyge_fnc_fcst_var_temp_df.createOrReplaceTempView("vyge_fnc_fcst_var_temp_vw")

        vyge_ship_fnc_dflt_fcst_df = vyge_strm_typ_drvr_df.join(dflt_ship_fnc_fcst_df, \
                                                                (
                                                                            dflt_ship_fnc_fcst_df.ship_cd == vyge_strm_typ_drvr_df.ship_cd) \
                                                                & (
                                                                            dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_strt_dts <= vyge_strm_typ_drvr_df.txn_dt) \
                                                                & (
                                                                            dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_end_dts > vyge_strm_typ_drvr_df.txn_dt) \
                                                                & (dflt_ship_fnc_fcst_df.lgcl_del_in == 'N')) \
            .join(vyge_fnc_fcst_var_temp_df, \
                  (vyge_strm_typ_drvr_df.ship_cd == vyge_fnc_fcst_var_temp_df.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt == vyge_fnc_fcst_var_temp_df.vyge_strt_dt) \
                  & (vyge_fnc_fcst_var_temp_df.vrsn_end_dts == '9999-12-31 00:00:00.000000'), "left_outer") \
            .withColumn("fcst_ship_ocpncy_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_ship_ocpncy_pc, \
                                 dflt_ship_fnc_fcst_df.fcst_ship_ocpncy_pc)) \
            .withColumn("fcst_comm_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_comm_pc, \
                                 dflt_ship_fnc_fcst_df.fcst_comm_pc)) \
            .withColumn("fcst_gst_per_strm_cn_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_gst_per_strm_cn, \
                                 dflt_ship_fnc_fcst_df.fcst_gst_per_strm_cn)) \
            .withColumn("fcst_ooo_gst_per_strm_cn_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_ooo_gst_per_strm_cn, \
                                 dflt_ship_fnc_fcst_df.fcst_ooo_gst_per_strm_cn)) \
            .withColumn("vyge_adlt_split_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.vyge_adlt_split_pc, \
                                 dflt_ship_fnc_fcst_df.vyge_adlt_split_pc)) \
            .withColumn("vyge_chld_split_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.vyge_chld_split_pc, \
                                 dflt_ship_fnc_fcst_df.vyge_chld_split_pc)) \
            .select("vyge_id", \
                    "strm_typ_cd", \
                    "txn_dt", \
                    vyge_strm_typ_drvr_df.ship_cd, \
                    col("fcst_ship_ocpncy_pc_tmp").alias("fcst_ship_ocpncy_pc"), \
                    col("fcst_comm_pc_tmp").alias("fcst_comm_pc"), \
                    col("fcst_gst_per_strm_cn_tmp").alias("fcst_gst_per_strm_cn"), \
                    col("fcst_ooo_gst_per_strm_cn_tmp").alias("fcst_ooo_gst_per_strm_cn"), \
                    col("vyge_adlt_split_pc_tmp").alias("adlt_split"), \
                    col("vyge_chld_split_pc_tmp").alias("chld_split")).distinct()

        # vyge_ship_fnc_dflt_fcst_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        #########################################################
        #  CALCULATE GTR_PRICE_PD_AM & NTR_PRICE_PD_AM METRICS  #
        #########################################################

        proc_price_pt_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                         (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                         & (voyages_only_df.txn_dt == proc_price_pt_vw_df.txn_dt) \
                                                         & (
                                                                     proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, proc_price_pt_vw_df.strm_typ_cd, voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_vw_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        proc_price_pt_prev_metric_rdd = proc_price_pt_calc_df \
            .repartition("vyge_id", "txn_dt", "strm_typ_cd").sortWithinPartitions("vyge_id", "strm_typ_cd", "txn_dt",
                                                                                  desc("rank")) \
            .rdd.mapPartitions(VygeStrmTypGtrNtrMetrics.populate_ppp_metrics, preservesPartitioning=True)

        proc_price_pt_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("txn_dt", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        proc_price_pt_metrics_df = self.sql_context.createDataFrame(proc_price_pt_prev_metric_rdd, proc_price_pt_schema)
        # proc_price_pt_metrics_df.write.mode("overwrite").format("orc").save("/wdpr-apps-data/dclrms/dev/dm/ppp_metrics/data")
        # print " done "

        proc_price_pt_gtr_ntr_subset_df = proc_price_pt_metrics_df.select("vyge_id", "txn_dt", "strm_typ_cd", \
                                                                          "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am",
                                                                          "vfc_extra_am", \
                                                                          "vfi_extra_am", "non_comm_am").distinct()

        proc_price_pt_ntr_gtr_calc_df = vyge_strm_typ_drvr_df.join(proc_price_pt_gtr_ntr_subset_df, \
                                                                   ["vyge_id", "txn_dt", "strm_typ_cd"]) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    proc_price_pt_gtr_ntr_subset_df.vfd_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfa_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfc_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfi_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.non_comm_am)
        # proc_price_pt_ntr_gtr_calc_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        proc_price_pt_gtr_ntr_tmp_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_vw_df, \
                                                                  ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(proc_price_pt_ntr_gtr_calc_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(vyge_ship_fnc_dflt_fcst_df, ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
            .withColumn("grs_gtr_ntr_revenue", (((2 * ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                        vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn)) * \
                                                 (
                                                             proc_price_pt_ntr_gtr_calc_df.vfd_am + proc_price_pt_ntr_gtr_calc_df.non_comm_am)) \
                                                + \
                                                ((proc_price_pt_ntr_gtr_calc_df.vfa_extra_am + \
                                                  proc_price_pt_ntr_gtr_calc_df.non_comm_am) * (
                                                             vyge_ship_fnc_dflt_fcst_df.adlt_split * \
                                                             ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                               vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn) \
                                                             * (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2))) \
                                                + \
                                                ((proc_price_pt_ntr_gtr_calc_df.vfc_extra_am + \
                                                  proc_price_pt_ntr_gtr_calc_df.non_comm_am) * (
                                                             vyge_ship_fnc_dflt_fcst_df.chld_split * \
                                                             ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                               vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn) \
                                                             * (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2))))) \
            .withColumn("grs_gtr_ntr_pcd", (
                    (((ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                      ooo_consolidated_vw_df.ooo_strm_cn) * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * \
                     vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn) + \
                    (ooo_consolidated_vw_df.ooo_strm_cn * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * \
                     vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn))) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc, \
                    col("grs_gtr_ntr_revenue"), \
                    col("grs_gtr_ntr_pcd")).distinct()

        proc_price_pt_gtr_tmp_df = proc_price_pt_gtr_ntr_tmp_df \
            .withColumn("gtr_price_pd_am", \
                        (
                                    proc_price_pt_gtr_ntr_tmp_df.grs_gtr_ntr_revenue / proc_price_pt_gtr_ntr_tmp_df.grs_gtr_ntr_pcd) \
                        .cast("decimal(12,2)")) \
            .select("vyge_id", \
                    "strm_typ_cd", \
                    "txn_dt", \
                    col("fcst_comm_pc").alias("fcst_tmp"), \
                    "gtr_price_pd_am")

        proc_price_pt_ntr_gtr_df = proc_price_pt_gtr_tmp_df \
            .select("vyge_id",
                    "strm_typ_cd",
                    col("txn_dt").alias("txn_date"),
                    "fcst_tmp",
                    "gtr_price_pd_am") \
            .withColumn("ntr_price_pd_am", (proc_price_pt_gtr_tmp_df.gtr_price_pd_am * (1 - col("fcst_tmp"))) \
                        .cast("decimal(12,2)")).drop(col("fcst_tmp"))

        proc_price_pt_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_ntr_gtr_vw")

        proc_price_pt_ntr_gtr_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        #################################################################
        #  CALCULATE OPN_GTR_PRICE_PD_AM & OPN_NTR_PRICE_PD_AM METRICS  #
        #################################################################

        proc_price_pt_opn_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                             (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                             & (coalesce(voyages_only_df.vyge_init_bkng_dt, \
                                                                         date_add(voyages_only_df.vyge_init_bkng_dt,
                                                                                  1)) == proc_price_pt_vw_df.txn_dt) \
                                                             & (
                                                                         proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, proc_price_pt_vw_df.strm_typ_cd, voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_vw_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        proc_price_pt_opn_prev_metric_rdd = proc_price_pt_opn_calc_df \
            .repartition("vyge_id", "txn_dt", "strm_typ_cd") \
            .sortWithinPartitions("vyge_id", "strm_typ_cd", "txn_dt", asc("rank")) \
            .rdd.mapPartitions(VygeStrmTypGtrNtrMetrics.populate_ppp_metrics, preservesPartitioning=True)

        proc_price_pt_opn_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("txn_dt", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        proc_price_pt_opn_metrics_df = self.sql_context.createDataFrame(proc_price_pt_opn_prev_metric_rdd,
                                                                        proc_price_pt_opn_schema)
        proc_price_pt_opn_metrics_df.write.mode("overwrite").format("orc").save(
            "/wdpr-apps-data/dclrms/dev/dm/ppp_opn_metrics/data")
        print
        " done "

        proc_price_pt_opn_gtr_ntr_subset_df = proc_price_pt_opn_metrics_df.select("vyge_id", "txn_dt", "strm_typ_cd", \
                                                                                  "vyge_drtn_nght_cn", "vfd_am",
                                                                                  "vfa_extra_am", "vfc_extra_am", \
                                                                                  "vfi_extra_am",
                                                                                  "non_comm_am").distinct()

        proc_price_pt_opn_ntr_gtr_calc_df = vyge_strm_typ_drvr_df.join(proc_price_pt_opn_gtr_ntr_subset_df, \
                                                                       ["vyge_id", "txn_dt", "strm_typ_cd"]) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfd_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfa_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfc_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfi_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.non_comm_am)
        proc_price_pt_opn_ntr_gtr_calc_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        proc_price_pt_opn_gtr_ntr_tmp_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_vw_df, \
                                                                      ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(proc_price_pt_opn_ntr_gtr_calc_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(vyge_ship_fnc_dflt_fcst_df, ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
            .withColumn("grs_gtr_ntr_revenue", (((2 * ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                        vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn)) * \
                                                 (
                                                             proc_price_pt_opn_ntr_gtr_calc_df.vfd_am + proc_price_pt_opn_ntr_gtr_calc_df.non_comm_am)) \
                                                + \
                                                ((proc_price_pt_opn_ntr_gtr_calc_df.vfa_extra_am + \
                                                  proc_price_pt_opn_ntr_gtr_calc_df.non_comm_am) * (
                                                             vyge_ship_fnc_dflt_fcst_df.adlt_split * \
                                                             ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                               vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn) \
                                                             * (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2))) \
                                                + \
                                                ((proc_price_pt_opn_ntr_gtr_calc_df.vfc_extra_am + \
                                                  proc_price_pt_opn_ntr_gtr_calc_df.non_comm_am) * (
                                                             vyge_ship_fnc_dflt_fcst_df.chld_split * \
                                                             ((ooo_consolidated_vw_df.phys_invtry_strm_cn * \
                                                               vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - ooo_consolidated_vw_df.ooo_strm_cn) \
                                                             * (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2))))) \
            .withColumn("grs_gtr_ntr_pcd", (
                    (((ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                      ooo_consolidated_vw_df.ooo_strm_cn) * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * \
                     vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn) + \
                    (ooo_consolidated_vw_df.ooo_strm_cn * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * \
                     vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn))) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc, \
                    col("grs_gtr_ntr_revenue"), \
                    col("grs_gtr_ntr_pcd")).distinct()

        proc_price_pt_opn_gtr_tmp_df = proc_price_pt_opn_gtr_ntr_tmp_df \
            .withColumn("opn_gtr_price_pd_am", \
                        (
                                    proc_price_pt_opn_gtr_ntr_tmp_df.grs_gtr_ntr_revenue / proc_price_pt_opn_gtr_ntr_tmp_df.grs_gtr_ntr_pcd) \
                        .cast("decimal(12,2)")) \
            .select("vyge_id", \
                    "strm_typ_cd", \
                    "txn_dt", \
                    col("fcst_comm_pc").alias("fcst_tmp"), \
                    "opn_gtr_price_pd_am")

        proc_price_pt_opn_ntr_gtr_df = proc_price_pt_opn_gtr_tmp_df \
            .select("vyge_id",
                    "strm_typ_cd",
                    col("txn_dt").alias("txn_date"),
                    "fcst_tmp",
                    "opn_gtr_price_pd_am") \
            .withColumn("opn_ntr_price_pd_am",
                        (proc_price_pt_opn_gtr_tmp_df.opn_gtr_price_pd_am * (1 - col("fcst_tmp"))) \
                        .cast("decimal(12,2)")).drop(col("fcst_tmp"))

        proc_price_pt_opn_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_vw")

        proc_price_pt_opn_ntr_gtr_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        #############################################################################
        #  calculate rcmd_vyge_gtr_price_pd_am & rcmd_vyge_ntr_price_pd_am metrics  #
        #############################################################################

        vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_vw_df, \
                                                                            ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(vyge_strm_typ_dly_rcmd_drvd_df, ["vyge_id", "strm_typ_cd", "txn_dt"]) \
            .join(vyge_ship_fnc_dflt_fcst_df, ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
            .withColumn("grs_rcmd_revenue", (((vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_gtr_pd_am * \
                                               vyge_strm_typ_drvr_df.vyge_drtn_nght_cn) * 2 \
                                              * ((
                                                             ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                                                 ooo_consolidated_vw_df.ooo_strm_cn)) \
                                             + \
                                             ((
                                                          vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_adlt_gtr_pd_am * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn) * \
                                              vyge_ship_fnc_dflt_fcst_df.adlt_split * \
                                              ((
                                                           ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                                               ooo_consolidated_vw_df.ooo_strm_cn) \
                                              * (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2)) \
                                             + \
                                             ((
                                                          vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_chld_gtr_pd_am * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn) * \
                                              vyge_ship_fnc_dflt_fcst_df.chld_split * \
                                              ((
                                                           ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                                               ooo_consolidated_vw_df.ooo_strm_cn) * \
                                              (vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn - 2)))) \
            .withColumn("grs_rcmd_pcd", (
                    (((ooo_consolidated_vw_df.phys_invtry_strm_cn * vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc) - \
                      ooo_consolidated_vw_df.ooo_strm_cn) * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn) \
                    + \
                    (ooo_consolidated_vw_df.ooo_strm_cn * vyge_strm_typ_drvr_df.vyge_drtn_nght_cn * \
                     vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn))) \
            .select(vyge_strm_typ_drvr_df.vyge_id,
                    vyge_strm_typ_drvr_df.strm_typ_cd,
                    vyge_strm_typ_drvr_df.txn_dt,
                    col("grs_rcmd_revenue"),
                    col("grs_rcmd_pcd"),
                    vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc).distinct()

        vyge_strm_typ_dly_rcmd_gtr_tmp_df = vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df \
            .withColumn("rcmd_vyge_gtr_price_pd_am", \
                        (
                                    vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df.grs_rcmd_revenue / vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df.grs_rcmd_pcd) \
                        .cast("decimal(12,2)")) \
            .select("vyge_id", \
                    "strm_typ_cd", \
                    "txn_dt", \
                    col("fcst_comm_pc").alias("fcst_tmp"), \
                    "rcmd_vyge_gtr_price_pd_am")

        vyge_strm_typ_dly_rcmd_ntr_gtr_df = vyge_strm_typ_dly_rcmd_gtr_tmp_df \
            .select("vyge_id",
                    "strm_typ_cd",
                    "txn_dt",
                    "fcst_tmp",
                    "rcmd_vyge_gtr_price_pd_am") \
            .withColumn("rcmd_vyge_ntr_price_pd_am", (vyge_strm_typ_dly_rcmd_gtr_tmp_df.rcmd_vyge_gtr_price_pd_am \
                                                      * (1 - col("fcst_tmp"))) \
                        .cast("decimal(12,2)")).drop(col("fcst_tmp"))

        vyge_strm_typ_dly_rcmd_ntr_gtr_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_ntr_gtr_vw")
        vyge_strm_typ_dly_rcmd_ntr_gtr_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        #####################################################
        # Calculate gtr_pd_chng_am & gtr_pd_chng_pc metrics #
        #####################################################
        # proc_price_pt_drvd_df.filter("vyge_id = 148025 and strm_typ_cd = '10A' and txn_dt = date('2016-10-22')").show()

        rcmd_gtr_pd_chng_df = vyge_strm_typ_dly_rcmd_drvd_df.join(proc_price_pt_drvd_df, \
                                                                  ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
            .withColumn("gtr_pd_chng_am",
                        (vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_gtr_pd_am - proc_price_pt_drvd_df.gtr_pd_am) \
                        .cast("decimal(12,2)")) \
            .withColumn("gtr_pd_chng_pc", (((vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_gtr_pd_am - \
                                             proc_price_pt_drvd_df.gtr_pd_am) * 100) / proc_price_pt_drvd_df.gtr_pd_am).cast(
            "decimal(12,2)")) \
            .select(vyge_strm_typ_dly_rcmd_drvd_df.vyge_id,
                    vyge_strm_typ_dly_rcmd_drvd_df.strm_typ_cd,
                    vyge_strm_typ_dly_rcmd_drvd_df.txn_dt,
                    vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_gtr_pd_am,
                    col("gtr_pd_chng_am"),
                    col("gtr_pd_chng_pc"))

        rcmd_gtr_pd_chng_df.createOrReplaceTempView("rcmd_gtr_pd_chng_vw")
        rcmd_gtr_pd_chng_df.filter("vyge_id = 148025 and strm_typ_cd = '10A'").show()

        print(" END OF GTR NTR ")



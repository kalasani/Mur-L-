#############################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management        #
# Program name      : VoyageCtgDly- DataLoading class         #
# Author            : Anjaiah M                                         #
# Date created      : 20180920                                              #
# Purpose           : data set loaded to populate promotional daily table   #
# Revision History  :                                                       #
#  Date        Author     Ref    Revision (Date in YYYYMMDD format)        #
# 20180920     Kowshik Y   Chris                                            #
#                                                                           #
#############################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import sys, traceback
from framework.core.BaseJob import BaseJob
from framework.utils.DebugCount import *
from pyspark.sql.types import *
from time import time
import os, sys


class DataLoaderVygeStrmCtgDly(object):

    @staticmethod
    def expand_weekday_calc(end_date):

        start_dt = datetime.strptime('2016-01-11', "%Y-%m-%d").date()
        list_obj = []
        dt = start_dt
        week_num = 1
        while (dt <= end_date):
            week_day = dt.weekday()
            if week_day == 6:
                week_num = week_num + 1
            t = (dt, week_num)
            list_obj.append(t)
            dt = dt + timedelta(days=1)
        return list_obj

    @staticmethod
    def vygeStrmTypExpandKeys(row, job_run_strt_dt, job_run_dt, runType):
        """
           Flat map function which takes a row containing voyage id , voyage init booking date and voyage arrival date
           and returns  a rdd containing vyge_id and txn_dt
        """
        floor_dt = datetime.strptime('2016-01-11', "%Y-%m-%d").date()
        start_dt = row.vyge_opn_dt
        if runType == 'incremental':
            job_run_strt_dt = job_run_strt_dt - timedelta(days=75)
        # end_dt = row.vyge_arvl_dt + timedelta(days=10)
        # start_dt = init_bkng_dt
        if start_dt < floor_dt:
            start_dt = floor_dt
        if start_dt < job_run_strt_dt:
            start_dt = job_run_strt_dt

        end_dt = row.vyge_arvl_dt + timedelta(days=10)
        if end_dt < floor_dt:
            end_dt = floor_dt
        if end_dt > job_run_dt:
            end_dt = job_run_dt

        list_obj = []
        dt = start_dt
        while (dt <= end_dt):
            t = (row.vyge_id, dt)
            list_obj.append(t)
            dt = dt + timedelta(days=1)
        return list_obj

    @staticmethod
    def run_data_loader_vyge_strm_ctgy_dly(start_dt,end_dt,sql_context,s3_bucket,data_loader,runType,debug):
        """
        Driver program to run cancellation_dm
        Attributes
        start_dt    : the time slice that is being executed
        sql_context : the spark sql context
        s3_bucket   : the s3 bucket that identifies the data source
        debug       :  debug flag
        """

        ##################################################################
        # Driver program to run run_promo_data_loader dm  process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################

        ###########################################################################
        # STEP 2:   Loading data from hdfs and create corresponding dataframes    #
        ###########################################################################

        #########################################################
        #                         VOYAGE                        #
        #########################################################

        ## Get all voyages and meta information  - TBD needs to go in a common class ##
        voyage_filter_clause = "ship_cd != 'XP' \
                                       and upper(instnc_st_nm)='STANDARD' \
                                       and invld_vyge_in = 0 "
        voyage_df = data_loader.read_data("dm", "VYGE") \
            .filter(voyage_filter_clause) \
            .select('vyge_id', 'invld_vyge_in', 'instnc_st_nm', 'ship_cd', 'vyge_arvl_dt', \
                    'vyge_dprt_dt', 'vyge_drtn_nght_cn', 'vyge_dprt_seapt_cd', \
                    'vyge_itnry_nm', 'orig_vyge_itnry_nm', 'app_vyge_id', 'vrsn_strt_dts', 'vrsn_end_dts') \
            .distinct()
        voyage_df.cache()
        # all active voyages meta information collected in voyage_df
        voyage_df.createOrReplaceTempView("vyge")
        if debug == 1:
            DebugCount.debug_counts(voyage_df, "voyage_df")

        #########################################################
        #                   VOYAGE_ATTR                         #
        #########################################################

        ## Get all voyages and meta information  - TBD needs to go in a common class ##

        all_vyge_attr_valid_clause = """ ship_cd != 'XP' 
        				and UPPER(instnc_st_nm)='STANDARD' 
        				and invld_vyge_in = 0 
        				and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null) 
        				and upper(instnc_st_nm)='STANDARD'
        				and greatest(date_add(vyge_arvl_dt,10), date('2016-01-11')) >= date('%s') """ % start_dt

        all_vyge_attr_valid_df = data_loader.read_data("dm", "VYGE_ATTR").filter(all_vyge_attr_valid_clause).distinct()

        vyge_attr_invld_df = all_vyge_attr_valid_df.groupBy("vyge_id", "ship_cd", "vrsn_strt_dts", "vrsn_end_dts").agg(
            min("vyge_opn_dt").alias("vyge_opn_dt") \
            , min("vyge_init_bkng_dt").alias("vyge_init_bkng_dt"), \
            min("vyge_dprt_dt").alias("vyge_dprt_dt") \
            , min("vyge_arvl_dt").alias("vyge_arvl_dt")) \
            .select("vyge_id", "ship_cd", "vrsn_strt_dts", "vrsn_end_dts", "vyge_arvl_dt", "vyge_opn_dt", \
                    "vyge_dprt_dt", "vyge_init_bkng_dt").filter("vyge_opn_dt is not null").distinct()

        vyge_attr_invld_df.createOrReplaceTempView(" vyge_attr_invld ")
        keys_df = vyge_attr_invld_df
        f = lambda x: DataLoaderVygeStrmCtgDly.vygeStrmTypExpandKeys(x, start_dt, end_dt, runType)
        keys_df = keys_df.rdd.flatMap(f)

        keys_schema = StructType([StructField("vyge_id", IntegerType(), True),
                                  StructField("txn_dt", DateType(), True)
                                  ])
        vyge_txn_attr_dt_df1 = sql_context.createDataFrame(keys_df, keys_schema).dropDuplicates()
        cnt = vyge_txn_attr_dt_df1.select("vyge_id").distinct().count()
        # print " expand keys distinct vyge_id count for %s is %s" %(start_dt,cnt)
        # cnt = vyge_txn_attr_dt_df1.count()
        # print " total records count is %s" %cnt
        vyge_txn_attr_dt_df = vyge_txn_attr_dt_df1.join(vyge_attr_invld_df, "vyge_id") \
            .select("vyge_id", "txn_dt", "ship_cd", "vyge_arvl_dt", "vyge_opn_dt", \
                    "vyge_dprt_dt", "vyge_init_bkng_dt", "vrsn_strt_dts", "vrsn_end_dts") \
            .filter("txn_dt >= vrsn_strt_dts and txn_dt < vrsn_end_dts").distinct()

        vyge_txn_attr_dt_df.createOrReplaceTempView(" vyge_attr ")

        folder_name = "%s%s" % ("vyge_attr_transc/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        data_loader.write_data("dm", folder_name, None, vyge_txn_attr_dt_df)

        #vyge_txn_attr_dt_df.write.format("orc").mode("overwrite").save(
        #   "/wdpr-apps-data/dclrms/dev/stage/dm/vyge_temp/data")
        # cnt = vyge_txn_attr_dt_df.select("vyge_id").distinct().count()
        # print "vyge_attr distinct  vyge_id count for %s is %s" %(start_dt,cnt)

        keys_schema_wk_num = StructType(
            [StructField("txn_date", DateType(), True), StructField("week_num", IntegerType(), True)])
        txn_dt_week_num_df = sql_context.createDataFrame(DataLoaderVygeStrmCtgDly.expand_weekday_calc(end_dt),
                                                         keys_schema_wk_num).dropDuplicates()
        txn_dt_week_num_df.createOrReplaceTempView("txn_dt_week_num")

        #########################################################
        #                       RES_BASELN                      #
        #########################################################

        res_baseln_filter = "upper(instnc_st_nm)= 'STANDARD' \
                            AND upper(sfb_nm) <> 'OFFICER' "

        res_baseln_df = data_loader.read_data("dm", "RES_BASELN") \
            .filter(res_baseln_filter) \
            .join(vyge_txn_attr_dt_df.select("vyge_id"), "vyge_id") \
            .dropDuplicates()
        res_baseln_df.createOrReplaceTempView("res_baseln")
        res_baseln_df.persist()

        if debug == 1:
            DebugCount.count_check(res_baseln_df, "res_baseln")
        #########################################################
        #                   SHIP_STRM_STRM_TYP                  #
        #########################################################
        ## Get all ship category type code and ship code details from SHIP_STRM_STRM_TYP ##

        ship_strm_strm_typ_filter_clause1 = " UPPER(strm_typ_cd) NOT IN('IRG','XAM') \
                            and UPPER(instnc_st_nm)='STANDARD' and ship_cd != 'XP'"
        ship_strm_strm_typ_df1 = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
            .select("ship_cd", \
                    "strm_typ_cd", \
                    "ship_strm_nb", \
                    "strm_cpcty_nb", \
                    col("vrsn_strt_dts").alias('shp_vrsn_strt_dts'), \
                    col("vrsn_end_dts").alias('shp_vrsn_end_dts'), \
                    "ship_strm_strm_end_dts", \
                    "ship_strm_strm_strt_dts") \
            .filter(ship_strm_strm_typ_filter_clause1).distinct()
        ship_strm_strm_typ_df1.createOrReplaceTempView(" ship_strm_strm_typ1 ")
        ship_strm_strm_typ_df1.persist()

        if debug == 1:
            DebugCount.count_check(ship_strm_strm_typ_df1, "ship_strm_strm_typ1")

        #########################################################
        #                   SHIP_STRM_TYP_EXT                   #
        #########################################################

        ship_strm_typ_ext_filter_clause1 = " UPPER(ship_strm_typ_cd) NOT IN('IRG','XAM') \
                            and UPPER(instnc_st_nm)='STANDARD' and ship_cd != 'XP'"

        ship_strm_typ_ext_df1 = data_loader.read_data("dm", "SHIP_STRM_TYP_EXT") \
            .select("ship_cd", \
                    "ship_ctgy_nm", \
                    "ship_strm_typ_cd", \
                    col("vrsn_strt_dts").alias('ext_vrsn_strt_dts'), \
                    col("vrsn_end_dts").alias('ext_vrsn_end_dts')) \
            .filter(ship_strm_typ_ext_filter_clause1).distinct()
        ship_strm_typ_ext_df1.createOrReplaceTempView(" ship_strm_typ_ext1 ")
        ship_strm_typ_ext_df1.persist()
        if debug == 1:
            DebugCount.count_check(ship_strm_typ_ext_df1, "ship_strm_typ_ext1")

        #########################################################
        #                   SHIP_FEAT                           #
        #########################################################

        ship_feat_df = data_loader.read_data("app", "SHIP_FEAT").filter("UPPER(LGCL_DEL_IN) = 'N'") \
            .select('ship_cd', 'ship_nm', 'ship_short_nm', 'ship_cls_nm').distinct()
        ship_feat_df.createOrReplaceTempView("ship_feat")

        #########################################################
        #                    SL_LIM_CONFIG                      #
        #########################################################

        sl_lim_config_attr = "UPPER(lgcl_del_in) = 'N'   AND UPPER(btch_sts_nm) = 'SUCCESSFUL'"
        sl_lim_config_df = data_loader.read_data("sha", "SL_LIM_CONFIG").filter(sl_lim_config_attr).dropDuplicates()
        sl_lim_config_df.createOrReplaceTempView("sl_lim_config")
        sl_lim_config_df.cache()
        if debug == 1:
            DebugCount.count_check(sl_lim_config_df, "sl_lim_confg_max_df count info")

        ##########################################
        #             STRM_TYP_NEST              #
        ##########################################

        strm_typ_nest_filter_clause = "upper(lgcl_del_in) = 'N'"
        strm_typ_nest_df = data_loader.read_data("app", "STRM_TYP_NEST") \
            .filter(strm_typ_nest_filter_clause)
        strm_typ_nest_df.createOrReplaceTempView("strm_typ_nest")
        if debug == 1:
            DebugCount.count_check(strm_typ_nest_df, "strm_typ_nest")

        #########################################################
        #                    APP_VYGE_XREF                      #
        #########################################################

        ## Get all application voyage information and loaded entirely as dataframe ##
        app_vyge_xref_filter_clause = "UPPER(lgcl_del_in) = 'N'"

        app_vyge_xref_df = data_loader.read_data("app", "APP_VYGE_XREF") \
            .filter(app_vyge_xref_filter_clause)
        app_vyge_xref_df.createOrReplaceTempView("app_vyge_xref")
        app_vyge_xref_df.persist()
        if debug == 1:
            DebugCount.count_check(app_vyge_xref_df, "app_vyge_xref")

        #########################################################
        #                    SL_LIM_VYGE_SUM                    #
        #########################################################

        sl_lim_vyge_sum_filter_clause = """ upper(instnc_st_nm) = 'STANDARD'
        			and age_ctgy_cd is null
        			and ocpncy_cn is null
        			and promo_cd is null
        			and ref_src_nm is null
        			and res_typ_cd is null
        			and agcy_id is null
        			and grp_typ_cd is null
        			and dng_tm is null
        			and age_fr_nb is null
        			and age_to_nb is null
        			and cbn_ctgy_cd is not null
        			and gst_seq_fr_nb is null
        			and gst_seq_to_nb is null
        			and conditiontext is null
        			and auth_cd is null
        			and cbn_ctgy_cd not in ('IRG','XAM')	"""

        sl_lim_vyge_sum_df = data_loader.read_data("dm", "SL_LIM_VYGE_SUM") \
            .filter(sl_lim_vyge_sum_filter_clause)
        sl_lim_vyge_sum_df.createOrReplaceTempView("sl_lim_vyge_sum")

        #########################################################
        #                    SHIPINVENTORYALLOC                 #
        #########################################################

        ship_inventory_alloc_filter = """ upper(instnc_st_nm)='STANDARD' \
        					and cabin_category not in ('IRG','XAM') """

        ship_inventory_alloc_df = data_loader.read_data("sha", "SHIPINVENTORYALLOC") \
            .filter(ship_inventory_alloc_filter).distinct()
        ship_inventory_alloc_df.createOrReplaceTempView("ship_inventory_alloc")

        ###################################################################
        #                   PRICE_RCMD_DTL                                #
        ###################################################################

        price_rcmd_dtl_attr = "upper(lgcl_del_in)= 'N'"
        price_rcmd_dtl_df = data_loader.read_data("sha", "PRICE_RCMD_DTL").filter(price_rcmd_dtl_attr).dropDuplicates()
        price_rcmd_dtl_df.createOrReplaceTempView("price_rcmd_dtl")
        # print " price_rcmd_dtl_df schema "
        # price_rcmd_dtl_df.printSchema()
        ###################################################################
        #                   UNCNSTRN_BKNG                                 #
        ###################################################################

        # uncnstrn_bkng_filter_clause = " UPPER(LGCL_DEL_IN) =  'N'"

        uncnstrn_bkng_rcmd_df = data_loader.read_data("sha", "UNCNSTRN_BKNG") \
            .dropDuplicates()
        # print "uncnstrn_bkng_rcmd_df show"
        uncnstrn_bkng_rcmd_df.createOrReplaceTempView("uncnstrn_bkng")
        # uncnstrn_bkng_rcmd_df.printSchema()
        ###################################################
        #             STRM_TYP_NEST_CONFIG                #
        ###################################################

        strm_typ_nest_config_attr = "upper(lgcl_del_in) = 'N'\
                                           "
        strm_typ_nest_config_df = data_loader.read_data("app", "STRM_TYP_NEST_CONFIG").filter(
            strm_typ_nest_config_attr).dropDuplicates()
        strm_typ_nest_config_df.createOrReplaceTempView("strm_typ_nest_config")

        if debug == 1:
            DebugCount.count_check(strm_typ_nest_config_df, "strm_typ_nest_config count info")

        #################################################
        #             DFLT_SHIP_FNC_FCST                #
        #################################################

        dflt_ship_fnc_fcst_filter_clause = "upper(lgcl_del_in) = 'N'"
        dflt_ship_fnc_fcst_df = data_loader.read_data("app", "DFLT_SHIP_FNC_FCST") \
            .filter(dflt_ship_fnc_fcst_filter_clause)
        dflt_ship_fnc_fcst_df.createOrReplaceTempView("dflt_ship_fnc_fcst_vw")

        ########################################################
        #                   VYGE_FNC_FCST_VAR                  #
        ########################################################

        vyge_fnc_fcst_var_filter_clause = "upper(lgcl_del_in) = 'N'"
        vyge_fnc_fcst_var_df = data_loader.read_data("app", "VYGE_FNC_FCST_VAR") \
            .filter(vyge_fnc_fcst_var_filter_clause)
        vyge_fnc_fcst_var_df.createOrReplaceTempView("vyge_fnc_fcst_var_vw")

        #######################################################
        #                   PRICE_CONFIG                      #
        #######################################################

        price_config_df = data_loader.read_data("sha", "PRICE_CONFIG").dropDuplicates()
        price_config_df.createOrReplaceTempView("price_config")

        #######################################################
        #                   GAWF_VAR                          #
        #######################################################

        gawf_var_df = data_loader.read_data("app", "GAWF_VAR").dropDuplicates()
        gawf_var_df.createOrReplaceTempView("gawf_var");
        if debug == 1:
            DebugCount.count_check(gawf_var_df, " gawf_var_df ")

        #######################################################
        #                   DFLT_GAWF_VAR                     #
        #######################################################

        dflt_gawf_var_df = data_loader.read_data("app", "DFLT_GAWF_VAR").dropDuplicates()

        dflt_gawf_var_df.createOrReplaceTempView("dflt_gawf_var")

        if debug == 1:
            DebugCount.count_check(dflt_gawf_var_df, " dflt_gawf_var_df ")

        ##########################################################
        #                   MASTER_SAILING_SCIENCE               #
        ##########################################################

        master_sailing_science_df = data_loader.read_data("arch", "MASTER_SAILING_SCIENCE").dropDuplicates()
        master_sailing_science_df.createOrReplaceTempView("master_sailing_science")
        if debug == 1:
            DebugCount.count_check(master_sailing_science_df, " master_sailing_science_df ")


        #####################################################################
        #                           DT                                      #
        #####################################################################
        dt_df = data_loader.read_data("dt", "DT")
        dt_df.createOrReplaceTempView("dt")
        dt_df.persist()
        if debug == 1:
            DebugCount.count_check(dt_df, "dt")

        ##########################################################
        #                   EXPECT_OH_BKNG                       #
        ##########################################################

        window_rank = Window.partitionBy("app_vyge_id", "asofdate") \
            .orderBy(col("expect_oh_bkng_run_dts").asc())
        expect_oh_fliter = " UPPER(lgcl_del_in) = 'N' and dy_bef_vyge_cn = 0"
        expect_oh_max_batch_df = data_loader.read_data("sha", "EXPECT_OH_BKNG").filter(
            expect_oh_fliter).dropDuplicates()
        expect_oh_max_batch_df.createOrReplaceTempView("expect_oh_bkng")
        expect_oh_bkng_vw_df = expect_oh_max_batch_df.select("app_vyge_id", "strm_typ_cd", "expect_oh_bkng_run_dts", \
                                                             "asofdate", "expect_oh_bkng_cn", \
                                                             rank().over(window_rank).alias("rank_num")) \
            .filter("rank_num = 1") \
            .groupBy("app_vyge_id", "strm_typ_cd", "expect_oh_bkng_run_dts", "asofdate") \
            .agg(sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn")).distinct()
        expect_oh_bkng_vw_df.createOrReplaceTempView("expect_oh_bkng_vw")


        expect_oh_fliter = "UPPER(lgcl_del_in) = 'N' and DY_BEF_VYGE_CN=0"
        expect_oh_max_batch_df = data_loader.read_data("sha", "EXPECT_OH_BKNG").filter(expect_oh_fliter).dropDuplicates()
        expect_oh_max_batch_df.createOrReplaceTempView("expect_oh_bkng")

        if debug == 1:
                DebugCount.count_check(expect_oh_max_batch_df, "expect_oh_max_batch_df execution start here ")

        #########################################################
        #                    PROC_PRICE_PT                      #
        #########################################################

        proc_price_pt_filter_clause = " upper(instnc_st_nm) = 'STANDARD' AND upper(sfb_nm) <> 'OFFICER'"
        # proc_price_pt_df = data_loader.read_data("dm", "PROC_PRICE_PT").filter(proc_price_pt_filter_clause) \
        #         .join(vyge_txn_attr_dt_df.select("vyge_id", "txn_dt", "ship_cd"), ["vyge_id", "txn_dt", "ship_cd"])
        proc_price_pt_df = data_loader.read_data("dm", "PROC_PRICE_PT").filter(proc_price_pt_filter_clause)
        proc_price_pt_df.createOrReplaceTempView("proc_price_pt")
        proc_price_pt_df.cache()

        if debug == 1:
            DebugCount.count_check(proc_price_pt_df, "proc_price_pt")

    	#################################################
    	#                   SL_LIM_RCMD                 #
    	#################################################

    	sl_lim_rcmd_dtl_attr = "upper(lgcl_del_in)= 'N'"
    	sl_lim_rcmd_dtl_df = data_loader.read_data("sha", "SL_LIM_RCMD").filter(sl_lim_rcmd_dtl_attr).dropDuplicates()
    	sl_lim_rcmd_dtl_df.createOrReplaceTempView("sl_lim_rcmd")

        ######################################################################
        #                         SHIPCABINRESERVED                          #
        ######################################################################
        shipcabinreserved_df = data_loader.read_data("sha", "SHIPCABINRESERVED")
        shipcabinreserved_df.createOrReplaceTempView("shipcabinreserved")
        if debug == 1:
            DebugCount.count_check(shipcabinreserved_df, "shipcabinreserved")

        print(" END OF DATA LOADER ")


import sys, os
from os import path

from pyspark import sql
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *
from datetime import datetime

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))
from datetime import datetime
from framework.utils.DebugCount import *;
from vygestrmctgydly.VygeStrmCtgDlyNtrGTR import *;
from vygestrmctgydly.VygeStrmCtgDlyPriceModDt import *;
from vygestrmctgydly.VygeStrmCtgDlyResBaselnCons import *;
from vygestrmctgydly.VygeStrmCtgDlySlCounts import *;


class VygeStrmCtgyDlyDriver(object):

    @staticmethod
    def run_vyge_strm_ctgy_dly_Driver(sql_context, data_loader, config_map):
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################

        ################################################################################
        # Merge ship_strm_typ_df and ship_strm_typ_ext_df on ship_cd and typ_cd to     #
        # populate ship category names for the corresponding ship category type codes  #
        ################################################################################

        start_dt = config_map["start_date"]
        end_dt = config_map["end_date"]
        s3_bucket = config_map["hdfs.root.directory"]
        debug = config_map["job.debug"]
        runType = config_map["etl.load.type"]
        print
        " driver started at %s" % datetime.now()

        vyge_df = sql_context.sql("select * from vyge")
        vyge_attr_df = sql_context.sql("select * from vyge_attr") \
            .select(col("vyge_id").alias("vyge_id_tmp"),
                    "txn_dt",
                    "ship_cd",
                    "vyge_arvl_dt",
                    "vyge_opn_dt",
                    "vyge_dprt_dt",
                    "vyge_init_bkng_dt",
                    "vrsn_strt_dts",
                    "vrsn_end_dts").dropDuplicates()

        # ('  vyge_attr_df count====>> ', 30040)
        # == == == == == == == = >> txn_driver_df <<= == == == == ==
        # ('count ==>', 30039)

        ship_feat_df = sql_context.sql("select * from ship_feat")
        app_vyge_xref_df = sql_context.sql("select * from app_vyge_xref")
        txn_driver_df = vyge_df.join(vyge_attr_df, (vyge_df.vyge_id == vyge_attr_df.vyge_id_tmp) \
                                     & (vyge_attr_df.txn_dt >= to_date(vyge_df.vrsn_strt_dts)) \
                                     & (vyge_attr_df.txn_dt < to_date(vyge_df.vrsn_end_dts))) \
            .join(ship_feat_df, (vyge_df.ship_cd == ship_feat_df.ship_cd)) \
            .join(app_vyge_xref_df, (vyge_df.vyge_id == app_vyge_xref_df.vyge_id)) \
            .select(vyge_df.vyge_id, \
                    vyge_attr_df.txn_dt, \
                    vyge_df.ship_cd, \
                    ship_feat_df.ship_nm, \
                    ship_feat_df.ship_short_nm, \
                    ship_feat_df.ship_cls_nm, \
                    vyge_df.vyge_dprt_dt, \
                    vyge_df.vyge_arvl_dt, \
                    vyge_df.vyge_drtn_nght_cn, \
                    vyge_df.vyge_dprt_seapt_cd, \
                    vyge_df.vyge_itnry_nm, \
                    app_vyge_xref_df.app_vyge_id, \
                    vyge_df.orig_vyge_itnry_nm) \
            .withColumn("dy_bef_vyge_cn", when((vyge_df.vyge_dprt_dt == "") | (vyge_attr_df.txn_dt == ""), lit("")) \
                        .otherwise(datediff(to_date(vyge_df.vyge_dprt_dt), vyge_attr_df.txn_dt)))
        txn_driver_df = txn_driver_df.cache()
        txn_driver_df_cn = txn_driver_df.count()
        if debug == 1:
            DebugCount.debug_counts(txn_driver_df, "txn_driver")

        txn_driver_df = txn_driver_df.dropDuplicates()
        txn_driver_df = txn_driver_df.cache()
        txn_driver_df_cn = txn_driver_df.count()

        ship_strm_strm_typ1_df = sql_context.sql("select * from ship_strm_strm_typ1").dropDuplicates()
        ship_strm_typ_ext1_df = sql_context.sql("select * from ship_strm_typ_ext1").dropDuplicates()

        ship_strm_strm_typ_txn_df = ship_strm_strm_typ1_df.join(txn_driver_df,
                                                                (
                                                                        txn_driver_df.ship_cd == ship_strm_strm_typ1_df.ship_cd) \
                                                                & (txn_driver_df.txn_dt >= to_date(
                                                                    ship_strm_strm_typ1_df.shp_vrsn_strt_dts)) \
                                                                & (txn_driver_df.txn_dt < to_date(
                                                                    ship_strm_strm_typ1_df.shp_vrsn_end_dts))) \
            .select(ship_strm_strm_typ1_df.ship_cd, \
                    ship_strm_strm_typ1_df.ship_strm_strm_end_dts, \
                    ship_strm_strm_typ1_df.ship_strm_nb, \
                    ship_strm_strm_typ1_df.strm_typ_cd, \
                    txn_driver_df.txn_dt, \
                    ship_strm_strm_typ1_df.shp_vrsn_strt_dts.alias("vrsn_strt_dts"), \
                    ship_strm_strm_typ1_df.shp_vrsn_end_dts.alias("vrsn_end_dts"), \
                    ship_strm_strm_typ1_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ1_df.strm_cpcty_nb).dropDuplicates()
        ship_strm_strm_typ_txn_df.createOrReplaceTempView("ship_strm_strm_typ_vw")

        if debug == 1:
            DebugCount.debug_counts(ship_strm_strm_typ_txn_df, "ship_strm_strm_typ_txn")

        ship_strm_typ_ext_txn_df = ship_strm_typ_ext1_df.join(txn_driver_df,
                                                              (txn_driver_df.ship_cd == ship_strm_typ_ext1_df.ship_cd) \
                                                              & (txn_driver_df.txn_dt >= to_date(
                                                                  ship_strm_typ_ext1_df.ext_vrsn_strt_dts)) \
                                                              & (txn_driver_df.txn_dt < to_date(
                                                                  ship_strm_typ_ext1_df.ext_vrsn_end_dts)) \
                                                              & (ship_strm_typ_ext1_df.ship_ctgy_nm != "")) \
            .select(ship_strm_typ_ext1_df.ship_cd, \
                    ship_strm_typ_ext1_df.ship_strm_typ_cd, \
                    ship_strm_typ_ext1_df.ship_ctgy_nm, \
                    txn_driver_df.txn_dt, \
                    ship_strm_typ_ext1_df.ext_vrsn_strt_dts.alias("vrsn_strt_dts"), \
                    ship_strm_typ_ext1_df.ext_vrsn_end_dts.alias("vrsn_end_dts")).dropDuplicates()
        ship_strm_typ_ext_txn_df.createOrReplaceTempView("ship_strm_typ_ext_vw")

        if debug == 1:
            DebugCount.debug_counts(ship_strm_typ_ext_txn_df, "ship_strm_typ_ext_txn")

        ship_strm_strm_typ_ext_df = ship_strm_strm_typ_txn_df.join(ship_strm_typ_ext_txn_df, \
                                                                   (
                                                                           ship_strm_typ_ext_txn_df.ship_strm_typ_cd == ship_strm_strm_typ_txn_df.strm_typ_cd) \
                                                                   & (
                                                                           ship_strm_typ_ext_txn_df.ship_cd == ship_strm_strm_typ_txn_df.ship_cd) \
                                                                   & (
                                                                           ship_strm_typ_ext_txn_df.txn_dt == ship_strm_strm_typ_txn_df.txn_dt)) \
            .select(ship_strm_typ_ext_txn_df.ship_cd, \
                    ship_strm_typ_ext_txn_df.txn_dt, \
                    ship_strm_typ_ext_txn_df.ship_ctgy_nm, \
                    ship_strm_strm_typ_txn_df.strm_cpcty_nb, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_end_dts).dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(ship_strm_strm_typ_ext_df, "ship_strm_strm_typ_ext")

        vyge_attr_shp_ctgy_nm_df = ship_strm_strm_typ_ext_df.join(vyge_attr_df, \
                                                                  (
                                                                          vyge_attr_df.ship_cd == ship_strm_strm_typ_ext_df.ship_cd) \
                                                                  & (
                                                                          vyge_attr_df.txn_dt == ship_strm_strm_typ_ext_df.txn_dt) \
                                                                  & (vyge_attr_df.vyge_dprt_dt < to_date(
                                                                      ship_strm_strm_typ_ext_df.ship_strm_strm_end_dts)) \
                                                                  & (vyge_attr_df.vyge_dprt_dt >= to_date(
                                                                      ship_strm_strm_typ_ext_df.ship_strm_strm_strt_dts))) \
            .select(vyge_attr_df.vyge_id_tmp, \
                    vyge_attr_df.txn_dt, \
                    ship_strm_strm_typ_ext_df.strm_cpcty_nb, \
                    ship_strm_strm_typ_ext_df.ship_ctgy_nm, \
                    ship_strm_strm_typ_ext_df.ship_cd).dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(vyge_attr_shp_ctgy_nm_df, "vyge_attr_shp_ctgy_nm")

        price_rcmd_dtl_df = sql_context.sql("select * from price_rcmd_dtl ")
        uncnstrn_bkng_df = sql_context.sql("select * from uncnstrn_bkng ")

        price_rcmd_dtl_max_df = price_rcmd_dtl_df.groupBy("app_vyge_id").agg(
            max("price_rcmd_run_dts").alias("price_rcmd_run_dts_max")).dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(price_rcmd_dtl_max_df, "price_rcmd_dtl_max")

        uncnstrn_bkng_max_df = uncnstrn_bkng_df.groupBy("app_vyge_id").agg(
            max("uncnstrn_bkng_run_dts").alias("uncnstrn_bkng_run_dts_max")).dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(uncnstrn_bkng_max_df, "uncnstrn_bkng_max_df")

        vyge_strm_typ_drvr_temp_df = txn_driver_df.join(vyge_attr_shp_ctgy_nm_df,
                                                        (txn_driver_df.ship_cd == vyge_attr_shp_ctgy_nm_df.ship_cd) \
                                                        & (
                                                                txn_driver_df.vyge_id == vyge_attr_shp_ctgy_nm_df.vyge_id_tmp) \
                                                        & (txn_driver_df.txn_dt == vyge_attr_shp_ctgy_nm_df.txn_dt)) \
            .select(txn_driver_df.vyge_id, \
                    vyge_attr_shp_ctgy_nm_df.ship_ctgy_nm.alias("ship_strm_ctgy_nm"), \
                    txn_driver_df.txn_dt, \
                    txn_driver_df.ship_cd, \
                    txn_driver_df.ship_nm, \
                    txn_driver_df.ship_short_nm, \
                    txn_driver_df.ship_cls_nm, \
                    txn_driver_df.vyge_dprt_dt, \
                    txn_driver_df.vyge_arvl_dt, \
                    txn_driver_df.vyge_drtn_nght_cn, \
                    txn_driver_df.dy_bef_vyge_cn, \
                    txn_driver_df.vyge_dprt_seapt_cd, \
                    txn_driver_df.vyge_itnry_nm, \
                    txn_driver_df.app_vyge_id, \
                    txn_driver_df.orig_vyge_itnry_nm).dropDuplicates()
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_temp_df, "vyge_strm_typ_drvr_temp")

        vyge_strm_typ_drvr_wk_txn_df = vyge_strm_typ_drvr_temp_df.join(price_rcmd_dtl_max_df, "app_vyge_id",
                                                                       "left_outer") \
            .join(uncnstrn_bkng_max_df, "app_vyge_id", "left_outer") \
            .select(vyge_strm_typ_drvr_temp_df.vyge_id, \
                    vyge_strm_typ_drvr_temp_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_temp_df.txn_dt, \
                    vyge_strm_typ_drvr_temp_df.ship_cd, \
                    vyge_strm_typ_drvr_temp_df.ship_nm, \
                    vyge_strm_typ_drvr_temp_df.ship_short_nm, \
                    vyge_strm_typ_drvr_temp_df.ship_cls_nm, \
                    vyge_strm_typ_drvr_temp_df.vyge_dprt_dt, \
                    vyge_strm_typ_drvr_temp_df.vyge_arvl_dt, \
                    vyge_strm_typ_drvr_temp_df.vyge_drtn_nght_cn, \
                    vyge_strm_typ_drvr_temp_df.dy_bef_vyge_cn, \
                    vyge_strm_typ_drvr_temp_df.vyge_dprt_seapt_cd, \
                    vyge_strm_typ_drvr_temp_df.vyge_itnry_nm, \
                    vyge_strm_typ_drvr_temp_df.app_vyge_id, \
                    vyge_strm_typ_drvr_temp_df.orig_vyge_itnry_nm, \
                    price_rcmd_dtl_max_df.price_rcmd_run_dts_max, \
                    uncnstrn_bkng_max_df.uncnstrn_bkng_run_dts_max) \
            .dropDuplicates()
        vyge_strm_typ_drvr_wk_txn_df.createOrReplaceTempView("vyge_strm_typ_drvr_wk_txn_vw")

        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_wk_txn_df, "vyge_strm_typ_drvr_wk_txn_vw")

        filter_txn_clause = "txn_dt >= date('%s') and txn_dt <= date('%s')" % (start_dt, end_dt)

        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_wk_txn_df.filter(filter_txn_clause)
        vyge_strm_typ_drvr_df.createOrReplaceTempView("driver")
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_df, "driver")

        # folder_name = "%s%s" % ("vyge_strm_typ_drvr_df_new/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm",folder_name,None,vyge_strm_typ_drvr_df)
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_df, "vyge_strm_typ_drvr_df")

        opn_vyge_strm_typ_config_df = sql_context.read.format("orc").load(
            "/wdpr-apps-data/dclrms/works/opn_vyge_strm_typ_config/data/")
        opn_vyge_strm_typ_config_df.createOrReplaceTempView("opn_vyge_strm_typ_config")

        if debug == 1:
            DebugCount.debug_counts(opn_vyge_strm_typ_config_df, "opn_vyge_strm_typ_config_df")

        ship_strm_typ_ext_df = sql_context.sql("SELECT * FROM ship_strm_typ_ext1")
        if debug == 1:
            DebugCount.debug_counts(ship_strm_typ_ext_df, "ship_strm_typ_ext_df")

        ship_strm_strm_typ_df1 = sql_context.sql("SELECT * FROM ship_strm_strm_typ1");
        if debug == 1:
            DebugCount.debug_counts(ship_strm_strm_typ_df1, "ship_strm_strm_typ_df1")

        vyge_strm_ctgy_dly_strm_typ = vyge_strm_typ_drvr_df.join(ship_strm_typ_ext_df, (
                vyge_strm_typ_drvr_df.ship_cd == ship_strm_typ_ext_df.ship_cd) \
                                                                 & (
                                                                         vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm) \
                                                                 & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
            ship_strm_typ_ext_df.ext_vrsn_strt_dts)) \
                                                                 & (vyge_strm_typ_drvr_df.txn_dt < to_date(
            ship_strm_typ_ext_df.ext_vrsn_end_dts))) \
            .join(ship_strm_strm_typ_df1, \
                  (ship_strm_strm_typ_df1.strm_typ_cd == ship_strm_typ_ext_df.ship_strm_typ_cd) \
                  & (vyge_strm_typ_drvr_df.ship_cd == ship_strm_strm_typ_df1.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(ship_strm_strm_typ_df1.ship_strm_strm_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(ship_strm_strm_typ_df1.ship_strm_strm_end_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                  ).join(opn_vyge_strm_typ_config_df, \
                         (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                             opn_vyge_strm_typ_config_df.vyge_strm_typ_config_strt_dts)) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                             opn_vyge_strm_typ_config_df.vyge_strm_typ_config_end_dts)) \
                         & (vyge_strm_typ_drvr_df.ship_cd == opn_vyge_strm_typ_config_df.ship_cd) \
                         & (ship_strm_strm_typ_df1.strm_typ_cd == opn_vyge_strm_typ_config_df.strm_typ_cd) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                         , "leftouter").select(vyge_strm_typ_drvr_df.vyge_id, ship_strm_typ_ext_df.ship_strm_typ_cd, \
                                               vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, vyge_strm_typ_drvr_df.txn_dt,
                                               opn_vyge_strm_typ_config_df.strm_typ_cd,
                                               opn_vyge_strm_typ_config_df.ooo_strm_cn).dropDuplicates()

        vyge_strm_ctgy_dly_strm_typ_driver = vyge_strm_ctgy_dly_strm_typ.select("vyge_id", "ship_strm_typ_cd",
                                                                                "ship_strm_ctgy_nm", "txn_dt",
                                                                                "ooo_strm_cn").groupBy("vyge_id",
                                                                                                       "ship_strm_typ_cd",
                                                                                                       "ship_strm_ctgy_nm",
                                                                                                       "txn_dt").agg(
            (sum("ooo_strm_cn").alias("ooo_strm_cn_sum")))
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_ctgy_dly_strm_typ_driver, "vyge_strm_ctgy_dly_strm_typ_driver")

        vyge_strm_ctgy_dly_strm_typ_driver.createOrReplaceTempView("vyge_strm_ctgy_strm_typ_cd_driver")
        # folder_name = "%s%s" % ("vyge_strm_typ_cd_driver/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, vyge_strm_ctgy_dly_strm_typ_driver)
        expect_oh_bkng_vw_df = sql_context.sql("select * from expect_oh_bkng")
        strm_typ_nest_config_df = sql_context.sql(" select * from strm_typ_nest_config ")
        filter_clause = " UPPER(strm_typ_nest_grp_nm) = 'SHIPSCI' \
        					AND UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM') "
        strm_typ_nest_confg_df = strm_typ_nest_config_df.filter(filter_clause) \
            .select("ship_cd", \
                    "strm_typ_nest_grp_nm", \
                    "src_sys_strm_typ_nm") \
            .dropDuplicates()

        strm_typ_nest_config_split_df = strm_typ_nest_confg_df.withColumn("strm_typ_cd", explode(
            split(strm_typ_nest_confg_df.src_sys_strm_typ_nm, "[;]"))) \
            .select("ship_cd", "strm_typ_nest_grp_nm", "strm_typ_cd").dropDuplicates()

        ship_strm_nest_config_temp_df = ship_strm_strm_typ_txn_df.join(strm_typ_nest_config_split_df,
                                                                       ["ship_cd", "strm_typ_cd"]) \
            .select(ship_strm_strm_typ_txn_df.ship_cd, \
                    ship_strm_strm_typ_txn_df.strm_typ_cd.alias("strm_typ_cd_alias"), \
                    ship_strm_strm_typ_txn_df.txn_dt, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_end_dts, \
                    ship_strm_strm_typ_txn_df.strm_cpcty_nb) \
            .dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(ship_strm_nest_config_temp_df, "ship_strm_nest_config_temp_df")

        strm_cpcty_nb_df = vyge_strm_typ_drvr_df.join(vyge_strm_ctgy_dly_strm_typ_driver, \
                                                      (
                                                                  vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                                                      & (
                                                                  vyge_strm_ctgy_dly_strm_typ_driver.txn_dt == vyge_strm_typ_drvr_df.txn_dt) \
                                                      & (
                                                                  vyge_strm_ctgy_dly_strm_typ_driver.vyge_id == vyge_strm_typ_drvr_df.vyge_id) \
                                                      ).join(ship_strm_nest_config_temp_df, \
                                                             (
                                                                         vyge_strm_typ_drvr_df.ship_cd == ship_strm_nest_config_temp_df.ship_cd) \
                                                             & (
                                                                         vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd == ship_strm_nest_config_temp_df.strm_typ_cd_alias) \
                                                             & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(
                                                                 ship_strm_nest_config_temp_df.ship_strm_strm_strt_dts)) \
                                                             & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(
                                                                 ship_strm_nest_config_temp_df.ship_strm_strm_end_dts)),
                                                             "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.ship_cd, \
                    ship_strm_nest_config_temp_df.strm_cpcty_nb) \
            .groupBy("vyge_id", \
                     "ship_strm_ctgy_nm", \
                     "txn_dt") \
            .agg(sum("strm_cpcty_nb").alias("strm_cpcty_nb_sum")) \
            .dropDuplicates()

        if debug == 1:
            DebugCount.debug_counts(strm_cpcty_nb_df, "strm_cpcty_nb_df")

        strm_cpcty_nb_df.createOrReplaceTempView("strm_cpcty_nb_vw")
        # data_loader.write_data("dm", folder_name, None, strm_cpcty_nb_df)
        # print("Completed : strm_cpcty_nb_df")

        #udf_price_am_pc_df = sql_context.sql("select * from uncnstrn_bkng");

        distinct_app_vyge_df = vyge_strm_typ_drvr_df.select("app_vyge_id", col("vyge_id").alias("vyge_id_temp")).dropDuplicates()
        print("Done distinct_app_vyge_df")

        udf_price_am_pc_df = uncnstrn_bkng_df.filter("dy_bef_vyge_cn = 1") \
            .join(distinct_app_vyge_df, ["app_vyge_id"]) \
            .select("vyge_id_temp", "strm_typ_cd", "udf_curr_price_am", \
                    "udf_as_of_dt_rcmd_price_am", "udf_rcmd_price_am", \
                    "uncnstrn_bkng_run_dts","app_vyge_id")

        print("Done udf_price_am_pc_df")

        uncnstrn_bkng_max_df = vyge_strm_ctgy_dly_strm_typ_driver.join(udf_price_am_pc_df,
                                                          ((vyge_strm_ctgy_dly_strm_typ_driver.vyge_id == udf_price_am_pc_df.vyge_id_temp)
                                                        &(vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd == udf_price_am_pc_df.strm_typ_cd)
                                                       &(vyge_strm_ctgy_dly_strm_typ_driver.txn_dt >= to_date( udf_price_am_pc_df.uncnstrn_bkng_run_dts)))) \
            .select(col("vyge_id"), \
                    vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm,\
                    vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd \
                    , col("txn_dt") \
                    , col("uncnstrn_bkng_run_dts")) \
            .groupBy("vyge_id", "ship_strm_typ_cd", "ship_strm_ctgy_nm","txn_dt") \
            .agg(max("uncnstrn_bkng_run_dts").alias("uncnstrn_bkng_run_dts"))
        print("Done uncnstrn_bkng_max_df")

        uncnstrn_bkng_max_tmp_df = udf_price_am_pc_df.join(uncnstrn_bkng_max_df,
                                                                ((udf_price_am_pc_df.vyge_id_temp == uncnstrn_bkng_max_df.vyge_id)
                                                                 &(udf_price_am_pc_df.strm_typ_cd == uncnstrn_bkng_max_df.ship_strm_typ_cd)
                                                                 &(udf_price_am_pc_df.uncnstrn_bkng_run_dts == uncnstrn_bkng_max_df.uncnstrn_bkng_run_dts))) \
            .select("vyge_id" \
                    , udf_price_am_pc_df.strm_typ_cd, \
                    uncnstrn_bkng_max_df.ship_strm_ctgy_nm,\
                    "txn_dt" \
                    , udf_price_am_pc_df.uncnstrn_bkng_run_dts, \
                    udf_price_am_pc_df.udf_curr_price_am, \
                    udf_price_am_pc_df.udf_as_of_dt_rcmd_price_am, \
                    udf_price_am_pc_df.udf_rcmd_price_am)
        print("Done uncnstrn_bkng_max_tmp_df");


        udf_price_am_pc_pre_df = vyge_strm_typ_drvr_df.join(uncnstrn_bkng_max_tmp_df, \
                                               (vyge_strm_typ_drvr_df.vyge_id == uncnstrn_bkng_max_tmp_df.vyge_id) \
                                               & (vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == uncnstrn_bkng_max_tmp_df.ship_strm_ctgy_nm) \
                                                &(vyge_strm_typ_drvr_df.txn_dt == uncnstrn_bkng_max_tmp_df.txn_dt)
                                                            )\
            .select(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                           vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    uncnstrn_bkng_max_tmp_df.udf_curr_price_am, uncnstrn_bkng_max_tmp_df.udf_as_of_dt_rcmd_price_am,
                    uncnstrn_bkng_max_tmp_df.udf_rcmd_price_am) \
            .groupBy(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                     vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
            .agg((sum(uncnstrn_bkng_max_tmp_df.udf_curr_price_am).alias("udf_curr_price_am")),
                 (sum(uncnstrn_bkng_max_tmp_df.udf_as_of_dt_rcmd_price_am).alias("udf_as_of_dt_rcmd_price_am")),
                 (sum(uncnstrn_bkng_max_tmp_df.udf_rcmd_price_am).alias("udf_rcmd_price_am"))).dropDuplicates()
        udf_price_am_pc_pre_df.createOrReplaceTempView("udf_price_am_vw_pre")
        print("Done udf_price_am_pc_pre_df");
        if debug == 1:
            DebugCount.debug_counts(udf_price_am_pc_pre_df, "udf_price_am_pc_pre_df")

        udf_price_am_pc_df = vyge_strm_typ_drvr_df.join(udf_price_am_pc_pre_df,
                                                        ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"], "left_outer") \
            .join(strm_cpcty_nb_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"], "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt.alias("txn_date"), \
                    udf_price_am_pc_pre_df.udf_curr_price_am, \
                    udf_price_am_pc_pre_df.udf_as_of_dt_rcmd_price_am, \
                    udf_price_am_pc_pre_df.udf_rcmd_price_am, \
                    strm_cpcty_nb_df.strm_cpcty_nb_sum) \
            .withColumn("udf_curr_price_pc",
                        ((udf_price_am_pc_pre_df.udf_curr_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)")) \
            .withColumn("udf_as_of_dt_rcmd_price_pc",
                        ((udf_price_am_pc_pre_df.udf_as_of_dt_rcmd_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)")) \
            .withColumn("udf_rcmd_price_pc",
                        ((udf_price_am_pc_pre_df.udf_rcmd_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)")).dropDuplicates()

        udf_price_am_pc_df.createOrReplaceTempView("udf_price_am_pc_vw")
        if debug == 1:
            DebugCount.debug_counts(udf_price_am_pc_df, "udf_price_am_pc_df")

        ship_filter = " strm_typ_cd NOT IN ( 'IGT', 'OGT', 'VGT', 'XAM','GTY', 'IRG' ) and UPPER(instnc_st_nm) = 'STANDARD' "
        ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP").filter(ship_filter)
        ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")

        # print("Done Before ops")
        vyge_txn_dt_df = sql_context.sql(""" select distinct driver.vyge_id,driver.ship_strm_ctgy_nm,driver.ship_cd ,driver.vyge_dprt_dt,driver.txn_dt
                        FROM driver as driver        """)

        vyge_txn_dt_df.createOrReplaceTempView("vyge_txn_dt_df");

        ship_strm_typ_ext_df = ship_strm_typ_ext_df.filter(
            "SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')")

        phys_invtry_strm_cn_df = vyge_strm_typ_drvr_df.join(ship_strm_typ_ext_df, (
                vyge_strm_typ_drvr_df.ship_cd == ship_strm_typ_ext_df.ship_cd) \
                                                            & (
                                                                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm) \
                                                            & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
            ship_strm_typ_ext_df.ext_vrsn_strt_dts)) \
                                                            & (vyge_strm_typ_drvr_df.txn_dt < to_date(
            ship_strm_typ_ext_df.ext_vrsn_end_dts))) \
            .join(ship_strm_strm_typ_df1, \
                  (ship_strm_strm_typ_df1.strm_typ_cd == ship_strm_typ_ext_df.ship_strm_typ_cd) \
                  & (vyge_strm_typ_drvr_df.ship_cd == ship_strm_strm_typ_df1.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(ship_strm_strm_typ_df1.ship_strm_strm_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(ship_strm_strm_typ_df1.ship_strm_strm_end_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                  ).select(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                           vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, ship_strm_strm_typ_df1.ship_strm_nb).groupBy(
            vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt, vyge_strm_typ_drvr_df.ship_strm_ctgy_nm).agg(
            (count(ship_strm_strm_typ_df1.ship_strm_nb).alias("phys_invtry_strm_cn"))).dropDuplicates()
        phys_invtry_strm_cn_df.createOrReplaceTempView("phys_invtry_strm_cn_df");
        if debug == 1:
            DebugCount.debug_counts(phys_invtry_strm_cn_df, "phys_invtry_strm_cn_df")

        ooo_vyg_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "
        ooo_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_vyg_filter)
        ooo_consolidated_df.createOrReplaceTempView("ooo_vyg_consoloidated")
        ooo_vyg_inventory_cnt_driver_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df,
                                                                     (
                                                                                 vyge_strm_typ_drvr_df.txn_dt == ooo_consolidated_df.txn_dt) \
                                                                     & (
                                                                                 vyge_strm_typ_drvr_df.vyge_id == ooo_consolidated_df.vyge_id) \
                                                                     ).select(vyge_strm_typ_drvr_df.txn_dt,
                                                                              vyge_strm_typ_drvr_df.vyge_id,
                                                                              vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                                                                              ooo_consolidated_df.vyge_strm_ooo_strm_cn).groupBy(
            vyge_strm_typ_drvr_df.txn_dt, vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.ship_strm_ctgy_nm).agg(
            (sum(ooo_consolidated_df.vyge_strm_ooo_strm_cn).alias("ooo_strm_cn"))).dropDuplicates()
        ooo_vyg_inventory_cnt_driver_df.createOrReplaceTempView("ooo_consolidated_vw_ship_strm_ctgy");

        if debug == 1:
            DebugCount.debug_counts(ooo_vyg_inventory_cnt_driver_df, "ooo_vyg_inventory_cnt_driver_df")

        strm_df = vyge_strm_ctgy_dly_strm_typ_driver;

        expect_oh_bkng_vw_df = sql_context.sql("select * from expect_oh_bkng_vw")
        window_rnk = Window.partitionBy("vyge_id", "txn_dt").orderBy(col("expect_oh_bkng_run_dts").desc())

        sl_lim_rcmd_df = sql_context.sql(
            " select distinct app_vyge_id,	sl_lim_rcmd_run_dts,asofdate from sl_lim_rcmd ")

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_df, "sl_lim_rcmd_df")
        price_rcmd_dtl_df = sql_context.sql(
            "select distinct app_vyge_id,price_rcmd_run_dts,asofdate from price_rcmd_dtl")
        if debug == 1:
            DebugCount.debug_counts(price_rcmd_dtl_df, "price_rcmd_dtl_df")
        vyge_strm_typ_dly_sci_rcmd_temp_df = vyge_strm_typ_drvr_df.join(price_rcmd_dtl_df, \
                                                                        (
                                                                                    vyge_strm_typ_drvr_df.app_vyge_id == price_rcmd_dtl_df.app_vyge_id) \
                                                                        & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                                            price_rcmd_dtl_df.price_rcmd_run_dts)) \
                                                                        & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                                            price_rcmd_dtl_df.asofdate)), "left_outer") \
            .join(sl_lim_rcmd_df, \
                  (vyge_strm_typ_drvr_df.app_vyge_id == sl_lim_rcmd_df.app_vyge_id) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(sl_lim_rcmd_df.sl_lim_rcmd_run_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(sl_lim_rcmd_df.asofdate)), "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.app_vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    price_rcmd_dtl_df.price_rcmd_run_dts, \
                    sl_lim_rcmd_df.sl_lim_rcmd_run_dts) \
            .groupBy("vyge_id", "app_vyge_id", "ship_strm_ctgy_nm", "txn_dt") \
            .agg(max("price_rcmd_run_dts").alias("max_price_rcmd_run_dts") \
                 , max("sl_lim_rcmd_run_dts").alias("max_sl_lim_rcmd_run_dts")).dropDuplicates()
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_sci_rcmd_temp_df, "vyge_strm_typ_dly_sci_rcmd_temp_df")

        vyge_strm_typ_dly_sci_rcmd_df = vyge_strm_typ_dly_sci_rcmd_temp_df.withColumn("sci_rcmd_typ_nm", \
                                                                                      when((
                                                                                               vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNull()) \
                                                                                           & (
                                                                                               vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNull()), \
                                                                                           vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts) \
                                                                                      .otherwise(when((
                                                                                                          vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNull()) \
                                                                                                      & (
                                                                                                          vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNotNull()),
                                                                                                      lit(
                                                                                                          "Selling Limit")) \
                                                                                                 .otherwise(when((
                                                                                                                     vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNotNull()) \
                                                                                                                 & (
                                                                                                                     vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNull()),
                                                                                                                 lit(
                                                                                                                     "Pricing")) \
                                                                                                            .otherwise(
                                                                                          when((
                                                                                                           vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts \
                                                                                                           >= vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts),
                                                                                               lit("Pricing")) \
                                                                                          .otherwise(when((
                                                                                                                      vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts \
                                                                                                                      < vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts),
                                                                                                          lit(
                                                                                                              "Selling Limit"))))))) \
            .select("vyge_id", \
                    "ship_strm_ctgy_nm", \
                    "txn_dt", \
                    "sci_rcmd_typ_nm") \
            .dropDuplicates()

        vyge_strm_typ_dly_sci_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_sci_rcmd_vw")

        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_sci_rcmd_df, "vyge_strm_typ_dly_sci_rcmd_df")

        VygeStrmCtgDlyResBaselnCons.run_con_resbaseln(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,
                                                      debug)

        VygeStrmCtgDlySlCounts.run_viz_vyge_count_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,
                                                       debug)

        VygeStrmCtgDlyNtrGTR.run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,
                                                       debug)

        expect_oh_bkng_cn_df = expect_oh_bkng_vw_df.join(vyge_strm_typ_drvr_df, \
                                                         (
                                                                     vyge_strm_typ_drvr_df.app_vyge_id == expect_oh_bkng_vw_df.app_vyge_id) \
                                                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                             expect_oh_bkng_vw_df.expect_oh_bkng_run_dts)) \
                                                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                             expect_oh_bkng_vw_df.asofdate))). \
            join(strm_df, \
                 (strm_df.ship_strm_typ_cd == expect_oh_bkng_vw_df.strm_typ_cd) \
                 & (strm_df.txn_dt >= to_date(expect_oh_bkng_vw_df.expect_oh_bkng_run_dts)) \
                 & (strm_df.txn_dt >= to_date(expect_oh_bkng_vw_df.asofdate)) \
                 & (strm_df.ship_strm_ctgy_nm == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                 & (strm_df.vyge_id == vyge_strm_typ_drvr_df.vyge_id) \
                 ) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    expect_oh_bkng_vw_df.expect_oh_bkng_cn, \
                    strm_df.ship_strm_typ_cd).dropDuplicates()

        expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_df")
        if debug == 1:
            DebugCount.debug_counts(expect_oh_bkng_cn_df, "expect_oh_bkng_cn_df")

        expect_oh_bkng_cn_final_df = expect_oh_bkng_cn_df.select("vyge_id", "ship_strm_ctgy_nm", "txn_dt",
                                                                 "expect_oh_bkng_cn").groupBy("vyge_id",
                                                                                              "ship_strm_ctgy_nm",
                                                                                              "txn_dt").agg(
            sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn")).dropDuplicates()

        expect_oh_bkng_cn_final_df.createOrReplaceTempView("expect_oh_bkng_cn_vw")
        if debug == 1:
            DebugCount.debug_counts(expect_oh_bkng_cn_final_df, "expect_oh_bkng_cn_final_df")















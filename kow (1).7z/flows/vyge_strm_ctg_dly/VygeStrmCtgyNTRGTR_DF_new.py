##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : NTR & GTR Call
# Author            : Anjaiah  M                                                          #
# Date created      : 2018-08-26                                                         #
# Purpose           : To build the driver program                                        #
# Revision History  :                                                                    #
# Date           Author     Ref    Revision (Date in YYYYMMDD format)                    #
# 2018-08-26    kowshik Y   Chris                                                        #
#                                                                                        #
##########################################################################################


#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.DebugCount import *;
from pyspark.sql.types import *
import os, sys
from os import path
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *
import pyspark.sql.functions as F


class VygeStrmCtgDlyNtrGTR(object):

    @staticmethod
    def populate_ppp_metrics(rows):
        last_vyge_id = -1
        last_version_start_date = None
        last_strm_typ_cd = -1
        last_metric = -1.0
        first_rec = 1
        vyge_drtn_nght_cn = None
        vfd_am = None
        vfa_extra_am = None
        vfc_extra_am = None
        vfi_extra_am = None
        non_comm_am = None
        ppm_metric_list = []
        for row in rows:
            if (
                    last_vyge_id != row.vyge_id or last_version_start_date != row.txn_dt or last_strm_typ_cd != row.strm_typ_cd) and first_rec != 1:
                # this is the first one
                ppm_metric_list.append(
                    Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am,
                        vfa_extra_am, vfc_extra_am, vfi_extra_am, non_comm_am))
                vyge_drtn_nght_cn = None
                vfd_am = None
                vfa_extra_am = None
                vfc_extra_am = None
                vfi_extra_am = None
                non_comm_am = None

            first_rec = 0
            if row.vyge_drtn_nght_cn != None and row.vfd_am != None and row.vfa_extra_am != None and row.vfc_extra_am != None and row.vfi_extra_am != None and row.non_comm_am != None:
                # assuming that we re processing price first and then cabing
                vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
                vfd_am = row.vfd_am
                vfa_extra_am = row.vfa_extra_am
                vfc_extra_am = row.vfc_extra_am
                vfi_extra_am = row.vfi_extra_am
                non_comm_am = row.non_comm_am

            last_vyge_id = row.vyge_id
            last_version_start_date = row.txn_dt
            last_strm_typ_cd = row.strm_typ_cd
            vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
            vfd_am = row.vfd_am
            vfa_extra_am = row.vfa_extra_am
            vfc_extra_am = row.vfc_extra_am
            vfi_extra_am = row.vfi_extra_am
            non_comm_am = row.non_comm_am
        if last_vyge_id != -1 and vfd_am != None and vfa_extra_am != None and vfc_extra_am != None and vfi_extra_am != None and non_comm_am != None:
            ppm_metric_list.append(
                Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am, vfa_extra_am,
                    vfc_extra_am,
                    vfi_extra_am, non_comm_am))
        return iter(ppm_metric_list)

    @staticmethod
    def run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, spark, s3_bucket, data_loader,debug):
        vyge_strm_typ_drvr_df1 = spark.sql("select * from driver ");
        ship_strm_typ_ext_df = spark.sql("select * from ship_strm_typ_ext1");
        vyge_attr_df = spark.sql("select * from vyge_attr")
        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_df1.join(ship_strm_typ_ext_df, \
                                                            (vyge_strm_typ_drvr_df1.ship_cd == ship_strm_typ_ext_df.ship_cd)
                                                            & (vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm)
                                                            & ( vyge_strm_typ_drvr_df1.txn_dt >= ship_strm_typ_ext_df.ext_vrsn_strt_dts)
                                                            & (vyge_strm_typ_drvr_df1.txn_dt < ship_strm_typ_ext_df.ext_vrsn_end_dts)) \
            .select(vyge_strm_typ_drvr_df1.vyge_id,
                    ship_strm_typ_ext_df.ship_strm_typ_cd.alias("strm_typ_cd"),
                    vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm,
                    vyge_strm_typ_drvr_df1.txn_dt,
                    vyge_strm_typ_drvr_df1.ship_cd,
                    vyge_strm_typ_drvr_df1.vyge_dprt_dt,
                    vyge_strm_typ_drvr_df1.app_vyge_id,
                    vyge_strm_typ_drvr_df1.dy_bef_vyge_cn,
                    vyge_strm_typ_drvr_df1.vyge_drtn_nght_cn).distinct()

        vyge_strm_typ_drvr_df.createOrReplaceTempView("driver_strm")


        ##########################################
        # Calculate rcmd_vyge_gtr_pd_am metrics  #
        ##########################################

        window_rnk_asofdate = Window.partitionBy(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.strm_typ_cd,
                                                 vyge_strm_typ_drvr_df.txn_dt) \
            .orderBy(col("price_rcmd_run_dts").desc())
        window_rnk_rcmd_run_dts = Window.partitionBy(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.strm_typ_cd,
                                                     vyge_strm_typ_drvr_df.txn_dt) \
            .orderBy(col("price_rcmd_run_dts").desc(), col("asofdate").desc())
        price_rcmd_dtl_vw_df = spark.sql(" select * from price_rcmd_dtl ")
        vyge_strm_typ_dly_rcmd_tmp_df = vyge_strm_typ_drvr_df.join(price_rcmd_dtl_vw_df, \
                                                                   ( vyge_strm_typ_drvr_df.app_vyge_id == price_rcmd_dtl_vw_df.app_vyge_id) \
                                                                   &(vyge_strm_typ_drvr_df.strm_typ_cd == price_rcmd_dtl_vw_df.strm_typ_cd) \
                                                                   &(vyge_strm_typ_drvr_df.txn_dt >= price_rcmd_dtl_vw_df.asofdate.cast(
                                                                           "date")) \
                                                                   &(vyge_strm_typ_drvr_df.dy_bef_vyge_cn >= price_rcmd_dtl_vw_df.dy_bef_vyge_rnge_strt_cn) \
                                                                   &(vyge_strm_typ_drvr_df.dy_bef_vyge_cn <= price_rcmd_dtl_vw_df.dy_bef_vyge_rnge_end_cn),
                                                                   "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id
                    , vyge_strm_typ_drvr_df.app_vyge_id
                    , vyge_strm_typ_drvr_df.strm_typ_cd
                    , vyge_strm_typ_drvr_df.ship_strm_ctgy_nm
                    , vyge_strm_typ_drvr_df.txn_dt
                    , vyge_strm_typ_drvr_df.dy_bef_vyge_cn
                    , price_rcmd_dtl_vw_df.price_rcmd_run_dts
                    , price_rcmd_dtl_vw_df.non_comm_fare_am
                    , price_rcmd_dtl_vw_df.plan_cfdnc_lvl_am
                    , price_rcmd_dtl_vw_df.price_impct_lvl_am
                    , price_rcmd_dtl_vw_df.vfd_pd_am
                    , price_rcmd_dtl_vw_df.vfa_pd_am
                    , price_rcmd_dtl_vw_df.vfc_pd_am,
                    rank().over(window_rnk_asofdate).alias("rnk_asofdate"),
                    rank().over(window_rnk_rcmd_run_dts).alias("rnk_rcmd_dts")) \
            .filter("rnk_asofdate = 1 and rnk_rcmd_dts = 1")

        vyge_strm_typ_dly_rcmd_tmp_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_tmp_df")

        vyge_strm_typ_dly_rcmd_df = vyge_strm_typ_dly_rcmd_tmp_df.withColumn("vfd_pd_am_drvd",
                                                                             col("vfd_pd_am") + col("non_comm_fare_am")) \
            .withColumn("vfa_pd_am_drvd", col("vfa_pd_am") + col("non_comm_fare_am")) \
            .withColumn("vfc_pd_am_drvd", col("vfc_pd_am") + col("non_comm_fare_am")) \
            .groupby("vyge_id", "strm_typ_cd", "txn_dt") \
            .agg(sum("plan_cfdnc_lvl_am").alias("plan_cfdnc_lvl_am"), \
                 sum("price_impct_lvl_am").alias("price_impct_lvl_am"), \
                 sum("vfd_pd_am_drvd").alias("rcmd_vyge_gtr_pd_am"), \
                 sum("vfa_pd_am_drvd").alias("rcmd_vyge_adlt_gtr_pd_am"), \
                 sum("vfc_pd_am_drvd").alias("rcmd_vyge_chld_gtr_pd_am")).distinct()
        vyge_strm_typ_dly_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_vw")

        vyge_strm_typ_dly_rcmd_drvd_df = spark.sql(""" select distinct vyge_id, strm_typ_cd, txn_dt,
        								rcmd_vyge_gtr_pd_am,
        								rcmd_vyge_adlt_gtr_pd_am,
        								rcmd_vyge_chld_gtr_pd_am
        							from vyge_strm_typ_dly_rcmd_vw """)

        if debug == 1:
            DebugCount.count_check(vyge_strm_typ_dly_rcmd_df, "vyge_strm_typ_dly_rcmd_vw")

        #ooo_filter_clause = """ src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') """
        #ooo_consolidated_df = spark.read.format("orc").load("/wdpr-apps-data/dclrms/stg/dm/vygestatrmtypinventory/data").filter(ooo_filter_clause)
        ooo_vyg_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "
        ooo_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_vyg_filter)

        ooo_inventory_cnt_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df, \
                                                          (vyge_strm_typ_drvr_df.vyge_id == ooo_consolidated_df.vyge_id) \
                                                          & (vyge_strm_typ_drvr_df.strm_typ_cd == ooo_consolidated_df.src_sys_strm_typ_cd) \
                                                          & (vyge_strm_typ_drvr_df.txn_dt == ooo_consolidated_df.txn_dt),
                                                          "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    ooo_consolidated_df.vyge_strm_ooo_strm_cn, \
                    ooo_consolidated_df.vyge_strm_phys_invtry_strm_cn) \
            .groupBy("vyge_id", "strm_typ_cd", "txn_dt") \
            .agg(sum("vyge_strm_ooo_strm_cn").alias("ooo_strm_cn"),
                 sum("vyge_strm_phys_invtry_strm_cn").alias("phys_invtry_strm_cn"))
        ooo_inventory_cnt_df.createOrReplaceTempView("ooo_consolidated_vw")
        vyge_fnc_fcst_var_df = spark.sql(" select * from vyge_fnc_fcst_var_vw ")
        dflt_ship_fnc_fcst_df = spark.sql(" select * from dflt_ship_fnc_fcst_vw ")
        proc_price_pt_vw_df = spark.sql("""select * from PROC_PRICE_PT """)

        window_max = Window.partitionBy("ship_cd", "vyge_strt_dt").orderBy(col("data_ld_dts").asc()).rowsBetween(+1, +1)
        vyge_fnc_fcst_var_temp_df = vyge_fnc_fcst_var_df.withColumn("vrsn_end_dts",
                                                                    coalesce(max("data_ld_dts").over(window_max), \
                                                                             lit('9999-12-31 00:00:00.000000').cast(
                                                                                 "timestamp")))
        vyge_fnc_fcst_var_temp_df.createOrReplaceTempView("vyge_fnc_fcst_var_temp_vw")

        vyge_ship_fnc_dflt_fcst_df = vyge_strm_typ_drvr_df.join(dflt_ship_fnc_fcst_df, \
                                                                (
                                                                        dflt_ship_fnc_fcst_df.ship_cd == vyge_strm_typ_drvr_df.ship_cd) \
                                                                & (
                                                                        dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_strt_dts <= vyge_strm_typ_drvr_df.txn_dt) \
                                                                & (
                                                                        dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_end_dts > vyge_strm_typ_drvr_df.txn_dt) \
                                                                & (dflt_ship_fnc_fcst_df.lgcl_del_in == 'N')) \
            .join(vyge_fnc_fcst_var_temp_df, \
                  (vyge_strm_typ_drvr_df.ship_cd == vyge_fnc_fcst_var_temp_df.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt == vyge_fnc_fcst_var_temp_df.vyge_strt_dt) \
                  & (vyge_fnc_fcst_var_temp_df.vrsn_end_dts == '9999-12-31 00:00:00.000000'), "left_outer") \
            .withColumn("fcst_ship_ocpncy_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_ship_ocpncy_pc, \
                                 dflt_ship_fnc_fcst_df.fcst_ship_ocpncy_pc)) \
            .withColumn("fcst_comm_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_comm_pc, \
                                 dflt_ship_fnc_fcst_df.fcst_comm_pc)) \
            .withColumn("fcst_gst_per_strm_cn_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_gst_per_strm_cn, \
                                 dflt_ship_fnc_fcst_df.fcst_gst_per_strm_cn)) \
            .withColumn("fcst_ooo_gst_per_strm_cn_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.fcst_ooo_gst_per_strm_cn, \
                                 dflt_ship_fnc_fcst_df.fcst_ooo_gst_per_strm_cn)) \
            .withColumn("vyge_adlt_split_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.vyge_adlt_split_pc, \
                                 dflt_ship_fnc_fcst_df.vyge_adlt_split_pc)) \
            .withColumn("vyge_chld_split_pc_tmp", \
                        coalesce(vyge_fnc_fcst_var_temp_df.vyge_chld_split_pc, \
                                 dflt_ship_fnc_fcst_df.vyge_chld_split_pc)) \
            .select("vyge_id", \
                    "strm_typ_cd", \
                    "txn_dt", \
                    vyge_strm_typ_drvr_df.ship_cd, \
                    col("fcst_ship_ocpncy_pc_tmp").alias("fcst_ship_ocpncy_pc"), \
                    col("fcst_comm_pc_tmp").alias("fcst_comm_pc"), \
                    col("fcst_gst_per_strm_cn_tmp").alias("fcst_gst_per_strm_cn"), \
                    col("fcst_ooo_gst_per_strm_cn_tmp").alias("fcst_ooo_gst_per_strm_cn"), \
                    col("vyge_adlt_split_pc_tmp").alias("adlt_split"), \
                    col("vyge_chld_split_pc_tmp").alias("chld_split")).distinct()
        vyge_ship_fnc_dflt_fcst_df.createOrReplaceTempView("vyge_ship_fnc_dflt_fcst_vw")

        # folder_name = "%s%s" % ("vyge_ship_fnc_dflt_fcst_df/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, vyge_ship_fnc_dflt_fcst_df)


        voyages_only_df = vyge_strm_typ_drvr_df.join(vyge_attr_df, ["vyge_id", "txn_dt"]) \
            .select("vyge_id", "txn_dt", vyge_strm_typ_drvr_df.strm_typ_cd, "vyge_init_bkng_dt")
        proc_price_pt_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                         (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                         & (voyages_only_df.txn_dt == proc_price_pt_vw_df.txn_dt) \
                                                         & (
                                                                 proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, proc_price_pt_vw_df.strm_typ_cd, voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_vw_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        proc_price_pt_prev_metric_rdd = proc_price_pt_calc_df \
            .repartition("vyge_id", "txn_dt", "strm_typ_cd").sortWithinPartitions("vyge_id", "strm_typ_cd", "txn_dt",
                                                                                  desc("rank")) \
            .rdd.mapPartitions(VygeStrmCtgDlyNtrGTR.populate_ppp_metrics, preservesPartitioning=True)

        proc_price_pt_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("txn_dt", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        proc_price_pt_metrics_df = spark.createDataFrame(proc_price_pt_prev_metric_rdd, proc_price_pt_schema)



        proc_price_pt_gtr_ntr_subset_df = proc_price_pt_metrics_df.select("vyge_id", "txn_dt", "strm_typ_cd", \
                                                                          "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am",
                                                                          "vfc_extra_am", \
                                                                          "vfi_extra_am", "non_comm_am").distinct()

        proc_price_pt_ntr_gtr_calc_df = vyge_strm_typ_drvr_df.join(proc_price_pt_gtr_ntr_subset_df, \
                                                                   ["vyge_id", "txn_dt", "strm_typ_cd"]) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    proc_price_pt_gtr_ntr_subset_df.vfd_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfa_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfc_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.vfi_extra_am, \
                    proc_price_pt_gtr_ntr_subset_df.non_comm_am)

        ooo_consolidated_df = ooo_consolidated_df.withColumnRenamed("vyge_id", "vyge_id_new")
        ooo_consolidated_df = ooo_consolidated_df.withColumnRenamed("txn_dt", "txn_dt_new")

        proc_price_pt_ntr_gtr_calc_df=proc_price_pt_ntr_gtr_calc_df.withColumnRenamed("strm_typ_cd", "strm_typ_cd_new")
        proc_price_pt_ntr_gtr_calc_df = proc_price_pt_ntr_gtr_calc_df.withColumnRenamed("vyge_id","vyge_id_new")
        proc_price_pt_ntr_gtr_calc_df = proc_price_pt_ntr_gtr_calc_df.withColumnRenamed("txn_dt", "txn_dt_new")

        # folder_name = "%s%s" % ("proc_price_pt_ntr_gtr_calc_df/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, proc_price_pt_ntr_gtr_calc_df)


        vyge_ship_fnc_dflt_fcst_df = vyge_ship_fnc_dflt_fcst_df.withColumnRenamed("strm_typ_cd", "strm_typ_cd_new")
        vyge_ship_fnc_dflt_fcst_df = vyge_ship_fnc_dflt_fcst_df.withColumnRenamed("vyge_id", "vyge_id_new")
        vyge_ship_fnc_dflt_fcst_df = vyge_ship_fnc_dflt_fcst_df.withColumnRenamed("txn_dt", "txn_dt_new")

        # folder_name = "%s%s" % ("vyge_strm_typ_drvr_df_cd/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, vyge_strm_typ_drvr_df)

        ####################### One Step Complete
        ########################################################

        pro_tmp_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df, \
                                                                  (ooo_consolidated_df.vyge_id_new==vyge_strm_typ_drvr_df.vyge_id)\
                                                                 & (ooo_consolidated_df.src_sys_strm_typ_cd==vyge_strm_typ_drvr_df.strm_typ_cd)\
                                                                 & (ooo_consolidated_df.txn_dt_new==vyge_strm_typ_drvr_df.txn_dt))\
                                                            .join(proc_price_pt_ntr_gtr_calc_df, \
                                                                  (proc_price_pt_ntr_gtr_calc_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                                                                  & (proc_price_pt_ntr_gtr_calc_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                                                                  & (proc_price_pt_ntr_gtr_calc_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt)) \
                                                             .join(vyge_ship_fnc_dflt_fcst_df, \
                                                                        (vyge_ship_fnc_dflt_fcst_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                                                                        & (vyge_ship_fnc_dflt_fcst_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                                                                        & (vyge_ship_fnc_dflt_fcst_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt), "left_outer") \
                                                            .select(vyge_strm_typ_drvr_df.vyge_id, \
                                                            vyge_strm_typ_drvr_df.txn_dt, \
                                                            vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                                                            vyge_strm_typ_drvr_df.strm_typ_cd, \
                                                            vyge_strm_typ_drvr_df.ship_strm_ctgy_nm.alias("ship_strm_ctgy_nm_temp"), \
                                                            proc_price_pt_ntr_gtr_calc_df.vfd_am, \
                                                            proc_price_pt_ntr_gtr_calc_df.vfa_extra_am.alias("vfa_am"), \
                                                            proc_price_pt_ntr_gtr_calc_df.vfc_extra_am.alias( "vfc_am"), \
                                                            proc_price_pt_ntr_gtr_calc_df.non_comm_am, \
                                                            coalesce(ooo_consolidated_df.vyge_strm_ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                                                            vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn, \
                                                            vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn, \
                                                            vyge_ship_fnc_dflt_fcst_df.chld_split, \
                                                            vyge_ship_fnc_dflt_fcst_df.adlt_split, \
                                                            vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc, \
                                                            vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc, \
                                                            ooo_consolidated_df.vyge_strm_phys_invtry_strm_cn).distinct()
        # folder_name = "%s%s" % ("pro_tmp_df/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, pro_tmp_df)
        proc_price_pt_gtr_tmp_df = pro_tmp_df.groupBy("vyge_id", "txn_dt", "strm_typ_cd", "ship_strm_ctgy_nm_temp") \
            .agg(min(pro_tmp_df.fcst_ship_ocpncy_pc).alias("fcst_ship_ocpncy_pc"), \
                 min(pro_tmp_df.fcst_gst_per_strm_cn).alias("fcst_gst_per_strm_cn"), \
                 min(pro_tmp_df.fcst_ooo_gst_per_strm_cn).alias("fcst_ooo_gst_per_strm_cn"), \
                 min(pro_tmp_df.fcst_comm_pc).alias("fcst_comm_pc"), \
                 sum((((pro_tmp_df.vfd_am + pro_tmp_df.non_comm_am) * 2) * ((pro_tmp_df.vyge_strm_phys_invtry_strm_cn * pro_tmp_df.fcst_ship_ocpncy_pc) - pro_tmp_df.ooo_strm_cn)) +
                     (((pro_tmp_df.vfa_am + pro_tmp_df.non_comm_am) * pro_tmp_df.adlt_split) * ((pro_tmp_df.vyge_strm_phys_invtry_strm_cn * pro_tmp_df.fcst_ship_ocpncy_pc) - pro_tmp_df.ooo_strm_cn) * (
                                  pro_tmp_df.fcst_gst_per_strm_cn - 2)) +
                     (((pro_tmp_df.vfc_am + pro_tmp_df.non_comm_am) * pro_tmp_df.chld_split) * ((pro_tmp_df.vyge_strm_phys_invtry_strm_cn * pro_tmp_df.fcst_ship_ocpncy_pc) - pro_tmp_df.ooo_strm_cn) * (
                                  pro_tmp_df.fcst_gst_per_strm_cn - 2))) \
                 .alias("grs_revenue"), \
                 sum((pro_tmp_df.vyge_strm_phys_invtry_strm_cn * pro_tmp_df.vyge_drtn_nght_cn * pro_tmp_df.fcst_ship_ocpncy_pc - pro_tmp_df.vyge_drtn_nght_cn * pro_tmp_df.ooo_strm_cn) * pro_tmp_df.fcst_gst_per_strm_cn +
                     (pro_tmp_df.ooo_strm_cn * pro_tmp_df.vyge_drtn_nght_cn * pro_tmp_df.fcst_ooo_gst_per_strm_cn)) \
                 .alias("grs_pcd"))
        proc_price_pt_gtr_tmp_df.createOrReplaceTempView("proc_price_pt_gtr_tmp_vw")

        proc_price_pt_gtr_df=proc_price_pt_gtr_tmp_df.groupBy("vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp")\
                                    .agg((sum("grs_revenue") / sum("grs_pcd")).cast(DecimalType(12, 2)) \
                                    .alias("gtr_price_pd_am"))
        proc_price_pt_gtr_df.createOrReplaceTempView("proc_price_pt_gtr_vw")

        proc_price_pt_ntr_gtr_df = proc_price_pt_gtr_df \
            .join(proc_price_pt_gtr_tmp_df, ["vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp"]) \
            .select(proc_price_pt_gtr_df.vyge_id, \
                    proc_price_pt_gtr_df.txn_dt.alias("txn_date"), \
                    proc_price_pt_gtr_df.ship_strm_ctgy_nm_temp, \
                    proc_price_pt_gtr_df.gtr_price_pd_am, \
                    (proc_price_pt_gtr_df.gtr_price_pd_am * \
                     (1 - (proc_price_pt_gtr_tmp_df.fcst_comm_pc))).cast(DecimalType(12, 2)) \
                    .alias("ntr_price_pd_am")).distinct()


        proc_price_pt_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_ntr_gtr_vw")

        #################################################################
        #  CALCULATE OPN_GTR_PRICE_PD_AM & OPN_NTR_PRICE_PD_AM METRICS  #
        #################################################################

        proc_price_pt_opn_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                             (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                             & (coalesce(voyages_only_df.vyge_init_bkng_dt, \
                                                                         date_add(voyages_only_df.vyge_init_bkng_dt,
                                                                                  1)) == proc_price_pt_vw_df.txn_dt) \
                                                             & (
                                                                     proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, proc_price_pt_vw_df.strm_typ_cd, voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_vw_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        proc_price_pt_opn_prev_metric_rdd = proc_price_pt_opn_calc_df \
            .repartition("vyge_id", "txn_dt", "strm_typ_cd") \
            .sortWithinPartitions("vyge_id", "strm_typ_cd", "txn_dt", desc("rank")) \
            .rdd.mapPartitions(VygeStrmCtgDlyNtrGTR.populate_ppp_metrics, preservesPartitioning=True)

        proc_price_pt_opn_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("txn_dt", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        proc_price_pt_opn_metrics_df = spark.createDataFrame(proc_price_pt_opn_prev_metric_rdd,
                                                                        proc_price_pt_opn_schema)
        #proc_price_pt_opn_metrics_df.write.mode("overwrite").format("orc").save("/wdpr-apps-data/dclrms/dev/dm/ppp_opn_metrics/data")

        proc_price_pt_opn_gtr_ntr_subset_df = proc_price_pt_opn_metrics_df.select("vyge_id", "txn_dt", "strm_typ_cd", \
                                                                                  "vyge_drtn_nght_cn", "vfd_am",
                                                                                  "vfa_extra_am", "vfc_extra_am", \
                                                                                  "vfi_extra_am",
                                                                                  "non_comm_am").distinct()

        proc_price_pt_opn_ntr_gtr_calc_df = vyge_strm_typ_drvr_df.join(proc_price_pt_opn_gtr_ntr_subset_df, \
                                                                       ["vyge_id", "txn_dt", "strm_typ_cd"]) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfd_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfa_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfc_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.vfi_extra_am, \
                    proc_price_pt_opn_gtr_ntr_subset_df.non_comm_am)
        proc_price_pt_opn_ntr_gtr_calc_df = proc_price_pt_opn_ntr_gtr_calc_df.withColumnRenamed("strm_typ_cd", "strm_typ_cd_new")
        proc_price_pt_opn_ntr_gtr_calc_df = proc_price_pt_opn_ntr_gtr_calc_df.withColumnRenamed("vyge_id",  "vyge_id_new")
        proc_price_pt_opn_ntr_gtr_calc_df = proc_price_pt_opn_ntr_gtr_calc_df.withColumnRenamed("txn_dt","txn_dt_new")

        proc_tmp_opn_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df, \
                                                                      (ooo_consolidated_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                                                                      &(ooo_consolidated_df.src_sys_strm_typ_cd == vyge_strm_typ_drvr_df.strm_typ_cd) \
                                                                      &(ooo_consolidated_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt)) \
            .join(proc_price_pt_opn_ntr_gtr_calc_df, \
                  (proc_price_pt_opn_ntr_gtr_calc_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                  & (proc_price_pt_opn_ntr_gtr_calc_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                  & (proc_price_pt_opn_ntr_gtr_calc_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt)) \
            .join(vyge_ship_fnc_dflt_fcst_df, \
                  (vyge_ship_fnc_dflt_fcst_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                  & (vyge_ship_fnc_dflt_fcst_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                  & (vyge_ship_fnc_dflt_fcst_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt), "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm.alias("ship_strm_ctgy_nm_temp"), \
                    proc_price_pt_opn_ntr_gtr_calc_df.vfd_am, \
                    proc_price_pt_opn_ntr_gtr_calc_df.vfa_extra_am.alias("vfa_am"), \
                    proc_price_pt_opn_ntr_gtr_calc_df.vfc_extra_am.alias("vfc_am"), \
                    proc_price_pt_opn_ntr_gtr_calc_df.non_comm_am, \
                    coalesce(ooo_consolidated_df.vyge_strm_ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                    vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn, \
                    vyge_ship_fnc_dflt_fcst_df.chld_split, \
                    vyge_ship_fnc_dflt_fcst_df.adlt_split, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc, \
                    ooo_consolidated_df.vyge_strm_phys_invtry_strm_cn).distinct()

        proc_price_opn_ntr_gtr_temp_df = proc_tmp_opn_df.groupBy("vyge_id", "txn_dt", "strm_typ_cd", "ship_strm_ctgy_nm_temp") \
            .agg(min(proc_tmp_opn_df.fcst_ship_ocpncy_pc).alias("fcst_ship_ocpncy_pc"), \
                 min(proc_tmp_opn_df.fcst_gst_per_strm_cn).alias("fcst_gst_per_strm_cn"), \
                 min(proc_tmp_opn_df.fcst_ooo_gst_per_strm_cn).alias("fcst_ooo_gst_per_strm_cn"), \
                 min(proc_tmp_opn_df.fcst_comm_pc).alias("fcst_comm_pc"), \
                 sum((((proc_tmp_opn_df.vfd_am + proc_tmp_opn_df.non_comm_am) * 2) * (( proc_tmp_opn_df.vyge_strm_phys_invtry_strm_cn * proc_tmp_opn_df.fcst_ship_ocpncy_pc) - proc_tmp_opn_df.ooo_strm_cn)) +
                     (((proc_tmp_opn_df.vfa_am + proc_tmp_opn_df.non_comm_am) * proc_tmp_opn_df.adlt_split) * (( proc_tmp_opn_df.vyge_strm_phys_invtry_strm_cn * proc_tmp_opn_df.fcst_ship_ocpncy_pc) - proc_tmp_opn_df.ooo_strm_cn) * (
                              proc_tmp_opn_df.fcst_gst_per_strm_cn - 2)) +
                     (((proc_tmp_opn_df.vfc_am + proc_tmp_opn_df.non_comm_am) * proc_tmp_opn_df.chld_split) * ((proc_tmp_opn_df.vyge_strm_phys_invtry_strm_cn * proc_tmp_opn_df.fcst_ship_ocpncy_pc) - proc_tmp_opn_df.ooo_strm_cn) * (
                              proc_tmp_opn_df.fcst_gst_per_strm_cn - 2))) \
                 .alias("grs_revenue"), \
                 sum(( proc_tmp_opn_df.vyge_strm_phys_invtry_strm_cn * proc_tmp_opn_df.vyge_drtn_nght_cn * proc_tmp_opn_df.fcst_ship_ocpncy_pc - proc_tmp_opn_df.vyge_drtn_nght_cn * proc_tmp_opn_df.ooo_strm_cn) * proc_tmp_opn_df.fcst_gst_per_strm_cn +
                     ( proc_tmp_opn_df.ooo_strm_cn * proc_tmp_opn_df.vyge_drtn_nght_cn * proc_tmp_opn_df.fcst_ooo_gst_per_strm_cn)) \
                 .alias("grs_pcd"))
        proc_price_opn_ntr_gtr_temp_df.createOrReplaceTempView("proc_price_pt_opn_gtr_tmp_vw")


        proc_price_opn_ntr_gtr_temp_df.createOrReplaceTempView("proc_price_pt_opn_gtr_tmp_vw")
        # print("Completed: proc_price_pt_opn_gtr_tmp_df")
        # folder_name = "%s%s" % ("proc_price_opn_ntr_gtr_temp_df/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, proc_price_opn_ntr_gtr_temp_df)



        proc_price_pt_opn_gtr_df = proc_price_opn_ntr_gtr_temp_df.groupBy("vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp") \
            .agg((sum("grs_revenue") / sum("grs_pcd")).cast(DecimalType(12, 2)) \
                 .alias("opn_gtr_price_pd_am"))

        #proc_price_pt_opn_gtr_df.createOrReplaceTempView("proc_price_pt_opn_gtr_vw")


        proc_price_pt_opn_ntr_gtr_df = proc_price_pt_opn_gtr_df \
            .join(proc_price_opn_ntr_gtr_temp_df, ["vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp"]) \
            .select(proc_price_pt_opn_gtr_df.vyge_id, \
                    proc_price_pt_opn_gtr_df.txn_dt.alias("txn_date"), \
                    proc_price_pt_opn_gtr_df.ship_strm_ctgy_nm_temp, \
                    proc_price_pt_opn_gtr_df.opn_gtr_price_pd_am, \
                    (proc_price_pt_opn_gtr_df.opn_gtr_price_pd_am * \
                     (1 - (proc_price_opn_ntr_gtr_temp_df.fcst_comm_pc))).cast(DecimalType(12, 2)) \
                    .alias("opn_ntr_price_pd_am")).distinct()

        proc_price_pt_opn_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_vw")

        #############################################################################
        #  calculate rcmd_vyge_gtr_price_pd_am & rcmd_vyge_ntr_price_pd_am metrics  #
        #############################################################################
        vyge_strm_typ_dly_rcmd_drvd_df = vyge_strm_typ_dly_rcmd_drvd_df.withColumnRenamed("strm_typ_cd", "strm_typ_cd_new")
        vyge_strm_typ_dly_rcmd_drvd_df = vyge_strm_typ_dly_rcmd_drvd_df.withColumnRenamed("vyge_id","vyge_id_new")
        vyge_strm_typ_dly_rcmd_drvd_df = vyge_strm_typ_dly_rcmd_drvd_df.withColumnRenamed("txn_dt", "txn_dt_new")

        rcmd_tmp_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df, \
                                                     (ooo_consolidated_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                                                     & (ooo_consolidated_df.src_sys_strm_typ_cd == vyge_strm_typ_drvr_df.strm_typ_cd) \
                                                     & (ooo_consolidated_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt)) \
            .join(vyge_strm_typ_dly_rcmd_drvd_df, \
                  (vyge_strm_typ_dly_rcmd_drvd_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                  & (vyge_strm_typ_dly_rcmd_drvd_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                  & (vyge_strm_typ_dly_rcmd_drvd_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt)) \
            .join(vyge_ship_fnc_dflt_fcst_df, \
                  (vyge_ship_fnc_dflt_fcst_df.vyge_id_new == vyge_strm_typ_drvr_df.vyge_id) \
                  & (vyge_ship_fnc_dflt_fcst_df.strm_typ_cd_new == vyge_strm_typ_drvr_df.strm_typ_cd) \
                  & (vyge_ship_fnc_dflt_fcst_df.txn_dt_new == vyge_strm_typ_drvr_df.txn_dt), "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.vyge_drtn_nght_cn, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm.alias("ship_strm_ctgy_nm_temp"), \
                    vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_gtr_pd_am, \
                    vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_adlt_gtr_pd_am, \
                    vyge_strm_typ_dly_rcmd_drvd_df.rcmd_vyge_chld_gtr_pd_am, \
                    coalesce(ooo_consolidated_df.vyge_strm_ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                    vyge_ship_fnc_dflt_fcst_df.fcst_gst_per_strm_cn, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_ooo_gst_per_strm_cn, \
                    vyge_ship_fnc_dflt_fcst_df.chld_split, \
                    vyge_ship_fnc_dflt_fcst_df.adlt_split, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_ship_ocpncy_pc, \
                    vyge_ship_fnc_dflt_fcst_df.fcst_comm_pc, \
                    ooo_consolidated_df.vyge_strm_phys_invtry_strm_cn).distinct()
        # folder_name = "%s%s" % ("rcmd_tmp_df/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, rcmd_tmp_df)



        proc_price_pt_rcmd_gtr_df = rcmd_tmp_df.groupBy("vyge_id", "txn_dt", "strm_typ_cd", "ship_strm_ctgy_nm_temp") \
            .agg(min(rcmd_tmp_df.fcst_ship_ocpncy_pc).alias("fcst_ship_ocpncy_pc"), \
                 min(rcmd_tmp_df.fcst_gst_per_strm_cn).alias("fcst_gst_per_strm_cn"), \
                 min(rcmd_tmp_df.fcst_ooo_gst_per_strm_cn).alias("fcst_ooo_gst_per_strm_cn"), \
                 min(rcmd_tmp_df.fcst_comm_pc).alias("fcst_comm_pc"), \
                 sum(((rcmd_tmp_df.rcmd_vyge_gtr_pd_am * rcmd_tmp_df.vyge_drtn_nght_cn * 2) * ((
                                                                                                           rcmd_tmp_df.vyge_strm_phys_invtry_strm_cn * rcmd_tmp_df.fcst_ship_ocpncy_pc) - rcmd_tmp_df.ooo_strm_cn)) + (
                             rcmd_tmp_df.rcmd_vyge_adlt_gtr_pd_am * rcmd_tmp_df.vyge_drtn_nght_cn * rcmd_tmp_df.adlt_split * (
                                 (
                                             rcmd_tmp_df.vyge_strm_phys_invtry_strm_cn * rcmd_tmp_df.fcst_ship_ocpncy_pc) - rcmd_tmp_df.ooo_strm_cn) * (
                                     rcmd_tmp_df.fcst_gst_per_strm_cn - 2)) + (
                             rcmd_tmp_df.rcmd_vyge_chld_gtr_pd_am * rcmd_tmp_df.vyge_drtn_nght_cn * rcmd_tmp_df.chld_split * (
                             (
                                         rcmd_tmp_df.vyge_strm_phys_invtry_strm_cn * rcmd_tmp_df.fcst_ship_ocpncy_pc) - rcmd_tmp_df.ooo_strm_cn) * (
                                     rcmd_tmp_df.fcst_gst_per_strm_cn - 2))).alias("grs_rcmd_revenue"), \
                 sum((
                                 rcmd_tmp_df.vyge_strm_phys_invtry_strm_cn * rcmd_tmp_df.vyge_drtn_nght_cn * rcmd_tmp_df.fcst_ship_ocpncy_pc - rcmd_tmp_df.vyge_drtn_nght_cn * rcmd_tmp_df.ooo_strm_cn) * rcmd_tmp_df.fcst_gst_per_strm_cn + (
                             rcmd_tmp_df.ooo_strm_cn * rcmd_tmp_df.vyge_drtn_nght_cn * rcmd_tmp_df.fcst_ooo_gst_per_strm_cn)).alias(
                     "grs_rcmd_pcd"))
        proc_price_pt_rcmd_gtr_df.createOrReplaceTempView("vyge_strm_ctgy_dly_rcmd_gtr_temp_vw")




        proc_price_pt_rcmd_gtr_temp_df = proc_price_pt_rcmd_gtr_df.groupBy("vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp") \
            .agg((sum("grs_rcmd_revenue") / sum("grs_rcmd_pcd")).cast(DecimalType(12, 2)) \
                 .alias("rcmd_gtr_price_pd_am"))
        #proc_price_pt_rcmd_gtr_temp_df.createOrReplaceTempView("proc_price_pt_rcmd_gtr_vw")


        vyge_strm_ctgy_dly_rcmd_ntr_gtr_df = proc_price_pt_rcmd_gtr_temp_df \
            .join(proc_price_pt_rcmd_gtr_df, ["vyge_id", "txn_dt", "ship_strm_ctgy_nm_temp"]) \
            .select(proc_price_pt_rcmd_gtr_temp_df.vyge_id, \
                    proc_price_pt_rcmd_gtr_temp_df.txn_dt.alias("txn_date"), \
                    proc_price_pt_rcmd_gtr_temp_df.ship_strm_ctgy_nm_temp, \
                    proc_price_pt_rcmd_gtr_temp_df.rcmd_gtr_price_pd_am.alias("rcmd_vyge_gtr_price_pd_am"), \
                    (proc_price_pt_rcmd_gtr_temp_df.rcmd_gtr_price_pd_am * \
                     (1 - (proc_price_pt_rcmd_gtr_df.fcst_comm_pc))).cast(DecimalType(12, 2)) \
                    .alias("rcmd_vyge_ntr_price_pd_am")).distinct()

        vyge_strm_ctgy_dly_rcmd_ntr_gtr_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_ntr_gtr_vw")

        vyge_strm_typ_dly_rcmd_df = spark.sql("""
        							select
        									vyge_id
        									,ship_strm_ctgy_nm
        									,txn_dt
        									,sum(DISTINCT plan_cfdnc_lvl_am) as plan_cfdnc_lvl_am
        									,sum(price_impct_lvl_am) as price_impct_lvl_am
        									,sum(vfd_pd_am + non_comm_fare_am) as rcmd_vyge_gtr_pd_am
        									,sum(vfa_pd_am + non_comm_fare_am) as rcmd_vyge_adlt_gtr_pd_am
        									,sum(vfc_pd_am + non_comm_fare_am) as rcmd_vyge_chld_gtr_pd_am
        							FROM vyge_strm_typ_dly_rcmd_tmp_df group by vyge_id,ship_strm_ctgy_nm,txn_dt
        							""").dropDuplicates()
        vyge_strm_typ_dly_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_vw")










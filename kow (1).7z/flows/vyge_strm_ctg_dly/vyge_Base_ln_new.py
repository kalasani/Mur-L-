# Import the Required Modules
from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.DebugCount import *;
from pyspark.sql.types import *

import os


class ExpectedFinalRevenue(object):

    @staticmethod
    def expand_keys(row, start_dt, end_dt):
        """
        Flat map function which takes a row containing voyage id , voyage init booking date and voyage arrival date
        and returns  a rdd containing vyge_id and txn_dt
        """
        dt = start_dt
        list_obj = []
        counter = 0
        while (dt <= end_dt):
            counter = counter + 1
            t = (counter, dt)
            list_obj.append(t)
            dt = dt + timedelta(days=1)
        return list_obj

    @staticmethod
    def populate_prev_ppm(rows):
        last_vyge_id = -1
        last_version_start_date = None
        last_strm_typ_cd = -1
        last_metric = -1.0
        first_rec = 1
        vyge_drtn_nght_cn = None
        vfd_am = None
        vfa_extra_am = None
        vfc_extra_am = None
        vfi_extra_am = None
        non_comm_am = None
        ppm_metric_list = []
        for row in rows:
            if (
                    last_vyge_id != row.vyge_id or last_version_start_date != row.version_start_date or last_strm_typ_cd != row.strm_typ_cd) and first_rec != 1:
                # this is the first one
                ppm_metric_list.append(
                    Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am,
                        vfa_extra_am, vfc_extra_am, vfi_extra_am, non_comm_am))
                vyge_drtn_nght_cn = None
                vfd_am = None
                vfa_extra_am = None
                vfc_extra_am = None
                vfi_extra_am = None
                non_comm_am = None

            first_rec = 0
            if row.vyge_drtn_nght_cn != None and row.vfd_am != None and row.vfa_extra_am != None and row.vfc_extra_am != None and row.vfi_extra_am != None and row.non_comm_am != None:
                # assuming that we re processing price first and then cabing
                vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
                vfd_am = row.vfd_am
                vfa_extra_am = row.vfa_extra_am
                vfc_extra_am = row.vfc_extra_am
                vfi_extra_am = row.vfi_extra_am
                non_comm_am = row.non_comm_am

            last_vyge_id = row.vyge_id
            last_version_start_date = row.version_start_date
            last_strm_typ_cd = row.strm_typ_cd
            vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
            vfd_am = row.vfd_am
            vfa_extra_am = row.vfa_extra_am
            vfc_extra_am = row.vfc_extra_am
            vfi_extra_am = row.vfi_extra_am
            non_comm_am = row.non_comm_am
        if last_vyge_id != -1 and vfd_am != None and vfa_extra_am != None and vfc_extra_am != None and vfi_extra_am != None and non_comm_am != None:
            ppm_metric_list.append(
                Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am, vfa_extra_am,
                    vfc_extra_am,
                    vfi_extra_am, non_comm_am))
        return iter(ppm_metric_list)

    @staticmethod
    def identify_voyages_with_version_changes(data_loader, valid_voyages_df, start_dt, end_dt, debug):
        """
        Identify if any of the voyages have version changes

        """
        version_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                % ("vrsn_strt_dts", start_dt, "vrsn_end_dts", end_dt)
        APP_VYGE_XREF_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                      % ("UPDT_DTS", start_dt, "UPDT_DTS", end_dt)
        # CNCL_PLCY_CONFIG_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
        #        % ("cncl_plcy_config_strt_dts", start_dt, "cncl_plcy_config_strt_dts", end_dt)
        # CRUS_GEO_AREA_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
        #        % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        expect_oh_bkng_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                       % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        mstr_vyge_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                  % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        price_bkng_oh_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                      % ("btch_run_dt", start_dt, "btch_run_dt", end_dt)
        price_rcmd_dtl_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                       % ("price_rcmd_run_dts", start_dt, "price_rcmd_run_dts", end_dt)
        proc_price_pt_filter = "date(%s) >=  date('%s') and date(%s) <= date('%s')" % (
        "txn_dt", start_dt, "txn_dt", end_dt)

        RES_BASELN_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                   % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        ship_feat_tm_dts = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                           % ("ship_feat_config_strt_dts", start_dt, "ship_feat_config_strt_dts", end_dt)

        ship_strm_rstrct_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                         % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        ship_strm_typ_dts = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                            % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        ship_strm_typ_ext_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                          % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        SHIP_STRM_STRM_TYP_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                           % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        sl_lim_vyge_sum_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                        % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        strm_typ_nest_config_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                             % ("updt_dts", start_dt, "updt_dts", end_dt)
        VOYAGE_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                               % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        vyge_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                             % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        VYGE_ATTR_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                  % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        vyge_fnc_fcst_var_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
                                          % ("data_ld_dts", start_dt, "data_ld_dts", end_dt)
        # vyge_strm_ctgy_dly_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
        #           % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
        # est_physical_inventory_cnt_filter_clause = "date(%s) >=  date('%s') and date(%s) <= date('%s')" \
        #          % ("vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)

        if debug == 1:
            DebugCount.count_check(valid_voyages_df, "valid voyages")

        version_change_APP_VYGE_XREF_df = valid_voyages_df.join((data_loader.read_data("app", "APP_VYGE_XREF") \
                                                                 .select("vyge_id",
                                                                         col("UPDT_DTS").alias(
                                                                             "version_start_date").cast(
                                                                             "date"))) \
                                                                , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_APP_VYGE_XREF_df, "versioned_APP_VYGE_XREF")

        # version_change_CNCL_PLCY_CONFIG_df = valid_voyages_df.join((data_loader.read_data("app", "CNCL_PLCY_CONFIG") \
        #                               .select("vyge_id",
        #                                     col("cncl_plcy_config_strt_dts").alias(
        #                                       "version_start_date").cast("date"))) \
        #                                 , ["vyge_id", "version_start_date"]) \
        #                                 .select("vyge_id", valid_voyages_df.version_start_date)

        # if debug == 1:
        #       DebugCount.count_check(version_change_CNCL_PLCY_CONFIG_df, "versioned_CNCL_PLCY_CONFIG")

        # version_change_CRUS_GEO_AREA_df = valid_voyages_df.join((data_loader.read_data("dm", "CRUS_GEO_AREA") \
        #             .select("vyge_id", col("vrsn_strt_dts").alias(\
        #                                 "version_start_date").cast("date"))) \
        #                                   , ["vyge_id", "version_start_date"]) \
        #             .select("vyge_id", valid_voyages_df.version_start_date)
        # if debug == 1:
        #       DebugCount.count_check(version_change_CRUS_GEO_AREA_df, "versioned_CRUS_GEO_AREA")

        #   version_change_expect_oh_bkng_df = valid_voyages_df.join((data_loader.read_data("sha", "expect_oh_bkng") \
        #              .select("vyge_id", col("vrsn_strt_dts").alias(
        #                                 "version_start_date").cast("date"))) \
        #                , ["vyge_id", "version_start_date"]) \
        #                                 .select("vyge_id", valid_voyages_df.version_start_date)
        # if debug == 1:
        #       DebugCount.count_check(version_change_expect_oh_bkng_df, "versioned_expect_oh_bkng")

        version_change_mstr_vyge_df = valid_voyages_df.join((data_loader.read_data("dm", "MSTR_VYGE_BASELN") \
                                                             .select("vyge_id",
                                                                     col("vrsn_strt_dts").alias(
                                                                         "version_start_date").cast(
                                                                         "date"))) \
                                                            , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_mstr_vyge_df, "versioned_mstr_vyge")

        version_change_RES_BASELN_df = valid_voyages_df.join((data_loader.read_data("dm", "RES_BASELN") \
                                                              .select("vyge_id",
                                                                      col("vrsn_strt_dts").alias(
                                                                          "version_start_date").cast(
                                                                          "date"))) \
                                                             , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_RES_BASELN_df, "versioned_RES_BASELN")

        version_change_ship_feat_df = data_loader.read_data("app", "SHIP_FEAT") \
            .filter(ship_feat_tm_dts) \
            .select("ship_cd", col("ship_feat_config_strt_dts").alias("version_start_date").cast("date"))

        version_change_ship_feat_df = valid_voyages_df.join(version_change_ship_feat_df,
                                                            ["ship_cd", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_ship_feat_df, "versioned_ship_feat")

        version_change_ship_strm_rstrct_df = data_loader.read_data("dm", "SHIP_STRM_RSTRCT") \
            .filter(ship_strm_rstrct_filter_clause) \
            .select("ship_cd", col("vrsn_strt_dts").alias("version_start_date").cast("date"))
        version_change_ship_strm_rstrct_df = valid_voyages_df.join(version_change_ship_strm_rstrct_df,
                                                                   ["ship_cd", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)

        if debug == 1:
            DebugCount.count_check(version_change_ship_strm_rstrct_df, "versioned_ship_strm_rstrct")

        version_change_ship_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
            .select("ship_cd", "SHIP_STRM_STRM_STRT_DTS", "SHIP_STRM_STRM_END_DTS",
                    col("vrsn_strt_dts").alias("version_start_date").cast("date"))
        version_change_ship_strm_df = valid_voyages_df.join(version_change_ship_strm_df,
                                                            ["ship_cd", "version_start_date"]) \
            .where("VYGE_DPRT_DT >=date(SHIP_STRM_STRM_STRT_DTS) AND VYGE_DPRT_DT < date(SHIP_STRM_STRM_END_DTS)") \
            .select("vyge_id", valid_voyages_df.version_start_date)

        if debug == 1:
            DebugCount.count_check(version_change_ship_strm_df, "versioned_ship_strm_strm_typ")

        version_change_ship_strm_typ_ext_df = data_loader.read_data("dm", "SHIP_STRM_TYP_EXT") \
            .filter(ship_strm_typ_ext_filter_clause) \
            .select("ship_cd", col("vrsn_strt_dts").alias("version_start_date").cast("date"))
        version_change_ship_strm_typ_ext_df = valid_voyages_df.join(version_change_ship_strm_typ_ext_df,
                                                                    ["ship_cd", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)

        if debug == 1:
            DebugCount.count_check(version_change_ship_strm_typ_ext_df, "versioned_ship_strm_typ_ext")

        version_change_sl_lim_vyge_sum_df = valid_voyages_df.join((data_loader.read_data("dm", "SL_LIM_VYGE_SUM") \
                                                                   .select(col("sail_id").alias("vyge_id"),
                                                                           col("vrsn_strt_dts").alias(
                                                                               "version_start_date").cast("date"))) \
                                                                  , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_sl_lim_vyge_sum_df, "versioned_sl_lim_vyge_sum")

        version_change_strm_typ_nest_config_df = data_loader.read_data("app", "STRM_TYP_NEST_CONFIG") \
            .filter(strm_typ_nest_config_filter_clause) \
            .select("ship_cd", col("updt_dts").alias("version_start_date").cast("date"))
        version_change_strm_typ_nest_config_df = valid_voyages_df.join(version_change_strm_typ_nest_config_df,
                                                                       ["ship_cd", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_strm_typ_nest_config_df, "versioned_strm_typ_nest_config")

        version_change_VOYAGE_df = valid_voyages_df.join((data_loader.read_data("sha", "VOYAGE") \
                                                          .select(col("sailid").alias("vyge_id"), \
                                                                  col("vrsn_strt_dts").alias("version_start_date").cast(
                                                                      "date"))) \
                                                         , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_VOYAGE_df, "versioned_VOYAGE")

        version_change_vyge_df = valid_voyages_df.join((data_loader.read_data("dm", "VYGE") \
                                                        .select("vyge_id",
                                                                col("vrsn_strt_dts").alias("version_start_date").cast(
                                                                    "date"))) \
                                                       , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_vyge_df, "versioned_vyge")

        version_change_VYGE_ATTR_df = valid_voyages_df.join((data_loader.read_data("dm", "VYGE_ATTR") \
                                                             .select("vyge_id", \
                                                                     col("vrsn_strt_dts").alias(
                                                                         "version_start_date").cast(
                                                                         "date"))) \
                                                            , ["vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_VYGE_ATTR_df, "versioned_VYGE_ATTR")

        version_change_vyge_fnc_fcst_var_df = data_loader.read_data("app", "VYGE_FNC_FCST_VAR") \
            .filter(vyge_fnc_fcst_var_filter_clause) \
            .select("ship_cd", "VYGE_STRT_DT", col("data_ld_dts").alias("version_start_date").cast("date"))

        version_change_vyge_fnc_fcst_var_df = valid_voyages_df.join(version_change_vyge_fnc_fcst_var_df,
                                                                    ["ship_cd", "version_start_date"]) \
            .where("VYGE_DPRT_DT = VYGE_STRT_DT") \
            .select("vyge_id", valid_voyages_df.version_start_date)
        if debug == 1:
            DebugCount.count_check(version_change_vyge_fnc_fcst_var_df, "versioned_vyge_fnc_fcst_var")

        version_change_expect_oh_bkng_df = data_loader.read_data("sha", "EXPECT_OH_BKNG") \
            .filter(expect_oh_bkng_filter_clause) \
            .select("app_vyge_id", col("vrsn_strt_dts").alias("version_start_date").cast("date"))
        version_change_expect_oh_bkng_df = valid_voyages_df.join(version_change_expect_oh_bkng_df,
                                                                 ["app_vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)

        if debug == 1:
            DebugCount.count_check(version_change_expect_oh_bkng_df, "versioned_expect_oh_bkng")

        version_change_price_rcmd_dtl_df = data_loader.read_data("sha", "PRICE_RCMD_DTL") \
            .filter(price_rcmd_dtl_filter_clause) \
            .select("app_vyge_id", col("price_rcmd_run_dts").alias("version_start_date").cast("date"))
        version_change_price_rcmd_dtl_df = valid_voyages_df.join(version_change_price_rcmd_dtl_df,
                                                                 ["app_vyge_id", "version_start_date"]) \
            .select("vyge_id", valid_voyages_df.version_start_date)

        if debug == 1:
            DebugCount.count_check(version_change_price_rcmd_dtl_df, "versioned_price_rcmd_dtl")
        # version_change_vyge_strm_ctgy_dly_df = valid_voyages_df.join((data_loader.read_data("dm", "vyge_strm_ctgy_dly") \
        #                  .select("vyge_id", col("data_ld_dts").alias(
        #  "version_start_date").cast("date"))) \
        #                 , ["vyge_id", "version_start_date"]) \
        #  .select("vyge_id", valid_voyages_df.version_start_date)
        # if debug == 1:
        #     DebugCount.count_check(version_change_vyge_strm_ctgy_dly_df, "versioned_vyge_strm_ctgy_dly")

        # version_change_est_physical_inventory_cnt_df = valid_voyages_df.join((data_loader.read_data("dm", "est_physical_inventory_cnt") \
        #              :wq   .select("vyge_id", col("data_ld_dts").alias(
        #  "version_start_date").cast("date"))) \
        #                , ["vyge_id", "version_start_date"]) \
        #  .select("vyge_id", valid_voyages_df.version_start_date)
        # if debug == 1:
        #     DebugCount.count_check(version_change_est_physical_inventory_cnt_df, "versioned_est_physical_inventory_cnt")

        # Union all
        union_df = version_change_vyge_df.union(version_change_APP_VYGE_XREF_df) \
            .union(version_change_mstr_vyge_df) \
            .union(version_change_RES_BASELN_df) \
            .union(version_change_ship_feat_df) \
            .union(version_change_ship_strm_rstrct_df) \
            .union(version_change_ship_strm_df) \
            .union(version_change_ship_strm_typ_ext_df) \
            .union(version_change_ship_strm_df) \
            .union(version_change_sl_lim_vyge_sum_df) \
            .union(version_change_strm_typ_nest_config_df) \
            .union(version_change_VOYAGE_df) \
            .union(version_change_vyge_df) \
            .union(version_change_VYGE_ATTR_df) \
            .union(version_change_vyge_fnc_fcst_var_df) \
            .union(version_change_expect_oh_bkng_df) \
            .union(version_change_price_rcmd_dtl_df)

        version_change_ship_cabin_p_df = data_loader.read_data("sha", "SHIPCABINRESERVED").filter(version_filter_clause)

        if version_change_ship_cabin_p_df != None:
            version_change_ship_cabin_df = version_change_ship_cabin_p_df.select(col("code").alias("ship_cd"), \
                                                                                 "SailDateTo", "SailDateFrom", \
                                                                                 col("vrsn_strt_dts").alias(
                                                                                     "version_start_date"))

            version_change_ship_cabin_df = valid_voyages_df.join(version_change_ship_cabin_df,
                                                                 ["ship_cd", "version_start_date"]) \
                .where("vyge_dprt_dt >=SailDateFrom and vyge_dprt_dt< SailDateTo") \
                .select("vyge_id", "version_start_date")
            union_df = union_df.union(version_change_ship_cabin_df)

        if debug == 1:
            DebugCount.count_check(union_df, "versioned_ship_cabin")

        version_change_ship_inventory_p_df = data_loader.read_data("sha", "SHIPINVENTORYALLOC").filter(
            version_filter_clause)

        if version_change_ship_inventory_p_df != None:
            version_change_ship_inventory_df = version_change_ship_inventory_p_df.select(
                col("ship_code").alias("ship_cd"), \
                "SAIL_DATE_FROM", \
                col("vrsn_strt_dts").alias(
                    "version_start_date"))

            version_change_ship_inventory_df = valid_voyages_df.join(version_change_ship_inventory_df,
                                                                     ["ship_cd", "version_start_date"]) \
                .where("vyge_dprt_dt == SAIL_DATE_FROM") \
                .select("vyge_id", "version_start_date")
            union_df = union_df.union(version_change_ship_inventory_df)

        version_change_proc_price_pt_p_df = data_loader.read_data_with_filter("dm", "PROC_PRICE_PT", "partition_dt",
                                                                              start_dt, end_dt, None)
        if version_change_proc_price_pt_p_df != None:
            version_change_proc_price_pt_df = version_change_proc_price_pt_p_df.filter(proc_price_pt_filter) \
                .select("vyge_id", col("txn_dt").alias("version_start_date"))

        version_change_proc_price_pt_df = valid_voyages_df.join(version_change_proc_price_pt_df,
                                                                ["vyge_id", "version_start_date"]) \
            .select("vyge_id", "version_start_date")
        union_df = union_df.union(version_change_proc_price_pt_df)

        if debug == 1:
            DebugCount.count_check(version_change_proc_price_pt_df, "versioned_proc_price")

        return union_df.dropDuplicates()

    @staticmethod
    def get_driver_for_days(version_df, start_dt, end_dt, sql_context, s3_bucket, debug, data_loader, converter):
        """
        Driver program to run hpsppd
        Attributes
        start_dt -> the time slice that is being executed
        sql_context : the spark sql context
        s3_bucket the s3 bucket that identifies the data source
        debug debug flag
        """
        print
        datetime.now()
        vyge_attr_df = data_loader.read_data("dm", "VYGE_ATTR")
        vyge_attr_df.persist()
        all_vyge_attr_valid_df = vyge_attr_df.filter("invld_vyge_in = 0 and \
              (vyge_opn_dt is not null or vyge_init_bkng_dt is not null) \
              and upper(instnc_st_nm)='STANDARD'") \
            .select("vyge_id").distinct()

        all_voyage_attr_filter_clause = " vyge_opn_dt <= version_start_date"
        all_vyge_attr_df = vyge_attr_df.filter(
            "invld_vyge_in = 0 and (vyge_opn_dt is not null or vyge_init_bkng_dt is not null)") \
            .groupBy("vyge_id") \
            .agg(min("vyge_opn_dt").alias("vyge_opn_dt"), \
                 min("vyge_init_bkng_dt").alias("vyge_init_bkng_dt"), \
                 min("vyge_arvl_dt").alias("vyge_arvl_dt")) \
            .select("vyge_id", "vyge_arvl_dt", "vyge_opn_dt", "vyge_init_bkng_dt") \
            .join(all_vyge_attr_valid_df, ["vyge_id"]) \
            .select("vyge_id", least("vyge_opn_dt", "vyge_init_bkng_dt").alias("vyge_opn_dt")) \
            .join(version_df).filter(all_voyage_attr_filter_clause)

        all_vyge_attr_df.createOrReplaceTempView("vyge_attr_df")
        if debug == 1:
            DebugCount.count_check(all_vyge_attr_df, "all_vyge_attr_df")

        voyage_attr_filter_clause = "version_start_date >= date(vrsn_strt_dts) \
              and  version_start_date < date(vrsn_end_dts)"
        voyage_attr_temp_df = vyge_attr_df.join(version_df).where(voyage_attr_filter_clause) \
            .select("vyge_id", "ship_cd", "vyge_dprt_dt", "version_start_date", \
                    "vyge_arvl_dt", "vyge_drtn_nght_cn", "vyge_itnry_nm", \
                    "vyge_init_bkng_dt", "orig_vyge_itnry_nm", \
                    "app_vyge_id", "ASSC_HLDY_NM") \
            .join(all_vyge_attr_df, ["vyge_id", "version_start_date"])
        vyge_attr_df.unpersist()
        # voyage_attr_temp_df.persist()
        if debug == 1:
            DebugCount.count_check(voyage_attr_temp_df, "voyage_attr_temp_df")

        # read ship_feat
        ship_feat_filter_clause = "upper(lgcl_del_in) = 'N' and \
             version_start_date >= date(ship_feat_config_strt_dts) and \
             version_start_date < date(ship_feat_config_end_dts)"

        ship_feat_df = data_loader.read_data("app", "SHIP_FEAT") \
            .join(version_df).filter(ship_feat_filter_clause) \
            .select("ship_cd", "ship_nm", "ship_short_nm", "ship_cls_nm", "ship_lfboat_cpcty_cn", "ship_max_chld_cn",
                    "version_start_date")
        ship_feat_df.createOrReplaceTempView("ship_feat")
        if debug == 1:
            DebugCount.count_check(ship_feat_df, "ship_feat_df")

        voyage_filter_clause = "upper(instnc_st_nm)='STANDARD' \
             and  version_start_date >= date(vrsn_strt_dts) \
             and  version_start_date < date(vrsn_end_dts) "

        voyage_df = data_loader.read_data("dm", "VYGE").join(version_df) \
            .filter(voyage_filter_clause) \
            .select("vyge_id", "vyge_dprt_seapt_cd", "version_start_date")
        voyage_df.createOrReplaceTempView("voyage")
        if debug == 1:
            DebugCount.count_check(voyage_df, "voyage_df")

        # create voyage attribute
        voyage_attr_df = voyage_attr_temp_df.join(ship_feat_df, ["ship_cd", "version_start_date"]).join(voyage_df,
                                                                                                        ["vyge_id",
                                                                                                         "version_start_date"]).dropDuplicates()
        voyage_attr_df.createOrReplaceTempView("voyage_attr")
        if debug == 1:
            DebugCount.count_check(voyage_attr_df, "voyage_attr_df")

        version_change_voyages_df = ExpectedFinalRevenue.identify_voyages_with_version_changes(data_loader,
                                                                                               voyage_attr_temp_df,
                                                                                               start_dt,
                                                                                               end_dt, debug)
        voyage_attr_temp_df.unpersist()
        if debug == 1:
            DebugCount.count_check(version_change_voyages_df, "versioned voyages")

        final_driver_df = version_change_voyages_df.select("vyge_id", "version_start_date") \
            .join(voyage_attr_df, ["vyge_id", "version_start_date"]) \
            .select("version_start_date", "vyge_id", "ship_cd", "vyge_opn_dt", "vyge_dprt_dt", "vyge_drtn_nght_cn",
                    "ASSC_HLDY_NM") \
            .dropDuplicates()
        final_driver_df.createOrReplaceTempView("final_driver")
        if debug == 1:
            DebugCount.count_check(final_driver_df, "final_driver_df")

        # adding the join with CNCL_PLCY_CONFIG

        cncl_plcy_config_filter = "CNCL_PLCY_STE_CNCRG_IN = 'N' and LGCL_DEL_IN = 'N'"
        cncl_plcy_config_df = data_loader.read_data("app", "CNCL_PLCY_CONFIG").filter(cncl_plcy_config_filter)
        cncl_plcy_config_df.createOrReplaceTempView("CNCL_PLCY_CONFIG")

        temp_final_drvr_df = final_driver_df.join(cncl_plcy_config_df, \
                                                  ((
                                                               cncl_plcy_config_df.cncl_plcy_hldy_nm == final_driver_df.ASSC_HLDY_NM) | \
                                                   (cncl_plcy_config_df.cncl_plcy_hldy_nm.isNull())) \
                                                  & (
                                                              final_driver_df.vyge_drtn_nght_cn >= cncl_plcy_config_df.vyge_drtn_rnge_strt_cn) \
                                                  & (
                                                              final_driver_df.vyge_drtn_nght_cn < cncl_plcy_config_df.vyge_drtn_rnge_end_cn) \
                                                  & (
                                                              final_driver_df.version_start_date >= cncl_plcy_config_df.cncl_plcy_eff_dt) \
                                                  & (final_driver_df.version_start_date < coalesce(
                                                      cncl_plcy_config_df.cncl_plcy_eff_end_dt, \
                                                      lit('9999-12-31').cast("date"))) \
                                                  & (to_date(
                                                      cncl_plcy_config_df.cncl_plcy_config_strt_dts) <= final_driver_df.version_start_date) \
                                                  & (to_date(
                                                      cncl_plcy_config_df.cncl_plcy_config_end_dts) > final_driver_df.version_start_date),
                                                  "left_outer") \
            .select(cncl_plcy_config_df.fnl_pmt_dy_bef_vyge_cn) \
            .distinct()

        temp_final_drvr_df.createOrReplaceTempView("temp_final_drvr")
        # generate driver  completed need to add price_mod_dt_end for identifying the range to complete the driver
        final_driver_sql = """
                             select E.*,
                                     A.vyge_arvl_dt,
                                     A.vyge_itnry_nm,
                                     A.vyge_init_bkng_dt,
                                     A.orig_vyge_itnry_nm,
                                     A.app_vyge_id,
                                     I.vyge_dprt_seapt_cd,
                                     B.ship_nm,
                                     B.ship_short_nm,
                                     B.ship_cls_nm,
                                     B.ship_lfboat_cpcty_cn,
                                     B.ship_max_chld_cn
                                from  final_driver E
                                inner join voyage_attr A 
                                on  E.vyge_id = A.vyge_id 
                                and E.version_start_date = A.version_start_date
                                inner join voyage I 
                                on E.vyge_id = I.vyge_id  
                                and I.version_start_date = E.version_start_date
                                inner join ship_feat B 
                                on E.ship_cd = B.ship_cd
                                and B.version_start_date = E.version_start_date
                             """
        final_driver_meta_info_df = sql_context.sql(final_driver_sql)

        # ==============================================================================
        #         final_driver_meta_info_df = final_driver_df \
        #                                     .join(voyage_attr_df,["vyge_id","version_start_date"]) \
        #                                     .join(voyage_df,["vyge_id","version_start_date"]) \
        #                                     .join(ship_feat_df,["ship_cd","version_start_date"])\
        #                                     .select(final_driver_df.version_start_date,\
        #                                             final_driver_df.vyge_id,\
        #                                             final_driver_df.ship_cd,\
        #                                             final_driver_df.vyge_opn_dt,\
        #                                             final_driver_df.vyge_dprt_dt,\
        #                                             final_driver_df.vyge_drtn_nght_cn,\
        #                                             final_driver_df.ASSC_HLDY_NM,\
        #                                             voyage_attr_df.vyge_arvl_dt, \
        #                                              voyage_attr_df.vyge_itnry_nm, \
        #                                              voyage_attr_df.vyge_init_bkng_dt, \
        #                                              voyage_attr_df.orig_vyge_itnry_nm, \
        #                                              voyage_attr_df.app_vyge_id, \
        #                                              voyage_df.vyge_dprt_seapt_cd, \
        #                                              ship_feat_df.ship_nm, \
        #                                              ship_feat_df.ship_short_nm, \
        #                                              ship_feat_df.ship_cls_nm, \
        #                                              ship_feat_df.ship_lfboat_cpcty_cn, \
        #                                              ship_feat_df.ship_max_chld_cn).dropDuplicates()
        # ==============================================================================
        if debug == 1:
            DebugCount.count_check(final_driver_meta_info_df, "final_driver")
            cnt1 = final_driver_meta_info_df.count()
            cnt2 = final_driver_meta_info_df.dropDuplicates().count()
            print
            "*************************************** %s " % cnt1
            print
            "*************************************** %s " % cnt2
        folder_name = "%s%s" % ("vyge_baseln_driver/partition_dt=", end_dt)
        data_loader.write_data("dm", folder_name, None, final_driver_meta_info_df)
        return final_driver_meta_info_df

    @staticmethod
    def run_expected_final_rev(sql_context, data_loader, config_map):
        start_dt = config_map["start_date"]
        end_dt = config_map["end_date"]
        s3_bucket = config_map["hdfs.root.directory"]
        debug = config_map["job.debug"]

        converter = DataFrameUtil(sql_context)
        keys_df = sql_context.range(1)
        f = lambda x: ExpectedFinalRevenue.expand_keys(x, start_dt, end_dt)
        keys_df = keys_df.rdd.flatMap(f)
        keys_schema = StructType(
            [StructField("counter", IntegerType(), True), StructField("version_start_date", DateType(), True)])
        version_df = sql_context.createDataFrame(keys_df, keys_schema).dropDuplicates().drop("counter")
        if debug == 1:
            DebugCount.count_check(version_df, "version_table")
        final_driver_df2 = ExpectedFinalRevenue.get_driver_for_days(version_df, start_dt, end_dt, sql_context,s3_bucket, debug, data_loader, converter)


        final_driver_df2.createOrReplaceTempView("final_driver_1")
        final_driver_df2.cache()
        print
        "final_driver_df2 count is %s" % final_driver_df2.count()

        dt_df = data_loader.read_data("dt", "DT") \
            .select("clndr_dt", "fscl_yr_nb", "fscl_wk_nb", "fscl_qtr_nb", "fscl_wk_strt_dt", "fscl_wk_end_dt",
                    "fscl_mo_nb", "clndr_wk_dy_nb", "fscl_wk_dy_nb")
        dt_dprt_df = final_driver_df2.join(dt_df, final_driver_df2.vyge_dprt_dt == dt_df.clndr_dt) \
            .select(final_driver_df2.vyge_id \
                    , final_driver_df2.version_start_date \
                    , dt_df.fscl_yr_nb.alias("vyge_fscl_yr_nb") \
                    , dt_df.fscl_qtr_nb.alias("vyge_dprt_qtr_nb") \
                    , dt_df.fscl_wk_nb.alias("curr_yr_fscl_wk_nb") \
                    , dt_df.fscl_wk_strt_dt.alias("curr_yr_fscl_wk_strt_dt") \
                    , dt_df.fscl_wk_end_dt.alias("curr_yr_fscl_wk_end_dt") \
                    , dt_df.fscl_mo_nb.alias("vyge_fscl_mo_nb") \
                    , dt_df.clndr_wk_dy_nb.alias("dprt_dt_wk_dy_nb"))

        if debug == 1:
            DebugCount.count_check(dt_dprt_df, "dt_dprt_df")

        dt_dprt_df.createOrReplaceTempView("dt_dprt_tbl")

        dt_arvl_df = final_driver_df2.join(dt_df, final_driver_df2.vyge_arvl_dt == dt_df.clndr_dt) \
            .select(final_driver_df2.vyge_id \
                    , final_driver_df2.version_start_date \
                    , dt_df.clndr_wk_dy_nb.alias("arvl_dt_wk_dy_nb"))

        if debug == 1:
            DebugCount.count_check(dt_arvl_df, "dt_arvl_df")

        dt_arvl_df.createOrReplaceTempView("dt_arvl_tbl")

        dt_prev_df = final_driver_df2.join(dt_df, add_months(final_driver_df2.vyge_dprt_dt, -12) == dt_df.clndr_dt,
                                           "left_outer") \
            .select(final_driver_df2.vyge_id \
                    , final_driver_df2.version_start_date \
                    , dt_df.fscl_wk_nb.alias("prev_yr_fscl_wk_nb") \
                    , dt_df.fscl_wk_strt_dt.alias("prev_yr_fscl_wk_strt_dt") \
                    , dt_df.fscl_wk_end_dt.alias("prev_yr_fscl_wk_end_dt"))

        if debug == 1:
            DebugCount.count_check(dt_prev_df, "dt_prev_df")

        dt_prev_df.createOrReplaceTempView("dt_prev_tbl")

        ### get physical inventory informaiton - from ship_strm_strm_typ
        ship_strm_typ_filter = "upper(instnc_st_nm)='STANDARD' \
        and strm_typ_cd not in ('IRG','IGT','OGT','VGT','XAM','GTY') and upper(ship_cd) <> 'XP'"
        ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
            .filter(ship_strm_typ_filter) \
            .join(final_driver_df2, "ship_cd") \
            .filter("vyge_dprt_dt >= date(ship_strm_strm_strt_dts) \
             and vyge_dprt_dt < date(ship_strm_strm_end_dts)\
             and version_start_date >= date(vrsn_strt_dts) \
             and version_start_date < date(vrsn_end_dts)") \
            .select("vyge_id", "strm_typ_cd", "strm_cpcty_nb", "ship_strm_nb", "version_start_date")
        ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")
        ship_strm_strm_df.persist()

        physical_inventory_cnt_df = ship_strm_strm_df.groupby("vyge_id", "version_start_date") \
            .agg(count("*").alias("phys_invtry_strm_cn"))
        physical_inventory_cnt_df.createOrReplaceTempView("physical_inventory_cnt")

        if debug == 1:
            DebugCount.count_check(physical_inventory_cnt_df, "physical_inventory_cnt")

        est_physical_inventory_cnt_df = ship_strm_strm_df.groupby("vyge_id", "version_start_date", "strm_typ_cd") \
            .agg(count("*").alias("phys_invtry_strm_cn"))
        est_physical_inventory_cnt_df.createOrReplaceTempView("est_physical_inventory_cnt")

        if debug == 1:
            DebugCount.count_check(est_physical_inventory_cnt_df, "est_physical_inventory_cnt_df")

        ### get strm ooo

        ooo_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory")
        ooo_consolidated_df.createOrReplaceTempView("ooo_consoloidated")

        ooo_inventory_cnt_df = ooo_consolidated_df.groupby("vyge_id", "txn_dt") \
            .agg(sum("vyge_strm_ooo_strm_cn").alias("ooo_strm_cn"))
        ooo_inventory_cnt_df.createOrReplaceTempView("ooo_counts")

        if debug == 1:
            DebugCount.count_check(ooo_inventory_cnt_df, "ooo_inventory_cnt_df")

        est_ooo_inventory_cnt_df = ooo_consolidated_df.groupby("vyge_id", "txn_dt",
                                                               ooo_consolidated_df.src_sys_strm_typ_cd.alias(
                                                                   "strm_typ_cd")) \
            .agg(sum("vyge_strm_ooo_strm_cn").alias("ooo_strm_cn"))
        est_ooo_inventory_cnt_df.createOrReplaceTempView("est_ooo_inventory_cnt")

        if debug == 1:
            DebugCount.count_check(est_ooo_inventory_cnt_df, "est_ooo_inventory_cnt_df")

        ######### ADDED FROM HERE #########
        ###############################################################################
        #####    PRICE_MOD_DT AND PROC_PRICE_PT   #########################
        ###############################################################################
        # Find the price_mod_dt from the proc_price_pt_diff consolidated table
        # This will give the latest business date when a price was changed for Sailing

        ppp_diff_df = data_loader.read_data("con", "PROC_PRICE_PT_DIFF") \
            .select("vyge_id", "txn_dt")

        ppp_diff_df.createOrReplaceTempView("ppp_diff")
        price_md_dt_tbl_df = final_driver_df2.join(ppp_diff_df, ["vyge_id"]) \
            .filter("txn_dt <= version_start_date") \
            .groupBy("vyge_id", "version_start_date") \
            .agg(max("txn_dt").alias("price_mod_dt"))

        proc_price_pt_filter = "upper(trim(strm_typ_cd)) not in ('IGT','OGT','VGT','XAM','GTY') and upper(sfb_nm) = 'PREVAIL' \
           and upper(trim(proc_price_src_sys_nm)) in ('PRICING EXTRACT','CABIN CAT')"
        proc_price_pt_temp_df = data_loader.read_data("dm", "PROC_PRICE_PT").filter(proc_price_pt_filter) \
            .select("vyge_id", "vyge_drtn_nght_cn", "txn_dt", \
                    "strm_typ_cd", "vfd_am", "vfa_extra_am", "vfc_extra_am", "proc_price_src_sys_nm", "vfi_extra_am",
                    "Non_comm_am")
        proc_price_pt_temp_df.persist()
        ########################################################
        #   strm_typ_prevl_price_diff_am     #
        ########################################################

        proc_price_pt_strm_df = proc_price_pt_temp_df.filter("upper(trim(strm_typ_cd)) in ('04A','11C')")
        ppp_df = proc_price_pt_strm_df.join(final_driver_df2, \
                                            (proc_price_pt_strm_df.vyge_id == final_driver_df2.vyge_id) \
                                            & (final_driver_df2.version_start_date >= proc_price_pt_strm_df.txn_dt)) \
            .select(final_driver_df2.vyge_id \
                    , proc_price_pt_strm_df.strm_typ_cd \
                    , proc_price_pt_strm_df.txn_dt \
                    , proc_price_pt_strm_df.vfd_am \
                    , proc_price_pt_strm_df.vfa_extra_am \
                    , proc_price_pt_strm_df.vfc_extra_am \
                    , proc_price_pt_strm_df.Non_comm_am \
                    , final_driver_df2.version_start_date \
                    , when(upper(proc_price_pt_strm_df.proc_price_src_sys_nm) == 'PRICING EXTRACT', 1) \
                    .otherwise(2) \
                    .alias("price_ind")).distinct()

        ppp_rank_df = ppp_df.select("vyge_id", "strm_typ_cd", "txn_dt", "vfd_am", "vfa_extra_am", \
                                    "vfc_extra_am", "Non_comm_am", "version_start_date", "price_ind", \
                                    rank().over(Window.partitionBy(ppp_df.vyge_id \
                                                                   , ppp_df.strm_typ_cd \
                                                                   , ppp_df.version_start_date) \
                                                .orderBy(ppp_df.txn_dt.desc(), ppp_df.price_ind)).alias('rank')) \
            .filter("rank = 1")

        pp_df = ppp_rank_df.select("vyge_id" \
                                   , "version_start_date" \
                                   , sum( \
                when(ppp_rank_df.strm_typ_cd == '04A',
                     when(ppp_rank_df.vfd_am == 0, None).otherwise(ppp_rank_df.vfd_am).alias(
                         "vfd_am") + ppp_rank_df.Non_comm_am) \
                    .otherwise(None) \
                ).over(Window.partitionBy(ppp_rank_df.vyge_id, ppp_rank_df.strm_typ_cd, ppp_rank_df.version_start_date)) \
                                   .alias("vfd_04a") \
                                   , sum( \
                when(ppp_rank_df.strm_typ_cd == '11C',
                     when(ppp_rank_df.vfd_am == 0, None).otherwise(ppp_rank_df.vfd_am).alias(
                         "vfd_am") + ppp_rank_df.Non_comm_am) \
                    .otherwise(None) \
                ).over(Window.partitionBy(ppp_rank_df.vyge_id, ppp_rank_df.strm_typ_cd, ppp_rank_df.version_start_date)) \
                                   .alias("vfd_11c"))

        vyge_baseln_strm_typ_prevl_df = pp_df.groupby("vyge_id", "version_start_date") \
            .agg((sum(pp_df.vfd_04a) - sum(pp_df.vfd_11c)).alias("strm_typ_prevl_price_diff_am"))

        vyge_baseln_strm_typ_prevl_df.createOrReplaceTempView("strm_typ_prevl")

        ####################################################################
        #     RESBASELN CURRENT WEEK METRICS       #
        ####################################################################

        res_baseln_curr_wk_metrics_df = data_loader.read_data("con", "vyge_sfb_res_baseln_cncl")

        res_baseln_curr_wk_driver_temp_df = final_driver_df2.join(res_baseln_curr_wk_metrics_df, \
                                                                  (
                                                                          final_driver_df2.vyge_id == res_baseln_curr_wk_metrics_df.vyge_id) \
                                                                  & (
                                                                          final_driver_df2.version_start_date == res_baseln_curr_wk_metrics_df.txn_dt) \
                                                                  ) \
            .groupby(final_driver_df2.vyge_id \
                     , final_driver_df2.version_start_date \
                     , res_baseln_curr_wk_metrics_df.sfb_nm) \
            .agg(when(
            res_baseln_curr_wk_metrics_df.sfb_nm.isin('WDW_CAST', 'MTO', 'CANADIAN', 'KIDS_FREE', 'DCL_CAST', 'FLR',
                                                      'GTY',
                                                      'TAAP', 'INTERLINE') \
            , sum(res_baseln_curr_wk_metrics_df.curr_wk_oh_sfb_bkng_cn)).otherwise(0).alias("curr_wk_promo_oh_bkng_cn") \
                 , when(res_baseln_curr_wk_metrics_df.sfb_nm.isin('GROUP', 'CMR', 'CHARTER', 'OTHERS') \
                        , sum(res_baseln_curr_wk_metrics_df.curr_wk_oh_sfb_bkng_cn)).otherwise(0).alias(
                "curr_wk_other_oh_bkng_cn") \
                 , when(res_baseln_curr_wk_metrics_df.sfb_nm == 'DVC' \
                        , sum(res_baseln_curr_wk_metrics_df.curr_wk_oh_sfb_bkng_cn)).otherwise(0).alias(
                "curr_wk_dvc_oh_bkng_cn") \
                 , when(res_baseln_curr_wk_metrics_df.sfb_nm == 'OBO' \
                        , sum(res_baseln_curr_wk_metrics_df.curr_wk_oh_sfb_bkng_cn)).otherwise(0).alias(
                "curr_wk_obo_oh_bkng_cn") \
                 , when(res_baseln_curr_wk_metrics_df.sfb_nm == 'PREVAIL' \
                        , sum(res_baseln_curr_wk_metrics_df.curr_wk_oh_sfb_bkng_cn)).otherwise(0).alias(
                "curr_wk_prevl_oh_bkng_cn")) \
            .select(final_driver_df2.vyge_id, final_driver_df2.version_start_date, \
                    "curr_wk_promo_oh_bkng_cn", "curr_wk_other_oh_bkng_cn", "curr_wk_dvc_oh_bkng_cn", \
                    "curr_wk_obo_oh_bkng_cn", "curr_wk_prevl_oh_bkng_cn")

        res_baseln_curr_wk_driver_df = res_baseln_curr_wk_driver_temp_df.groupby("vyge_id", "version_start_date") \
            .agg(sum(res_baseln_curr_wk_driver_temp_df.curr_wk_promo_oh_bkng_cn).alias("curr_wk_promo_oh_bkng_cn") \
                 , sum(res_baseln_curr_wk_driver_temp_df.curr_wk_other_oh_bkng_cn).alias("curr_wk_other_oh_bkng_cn") \
                 , sum(res_baseln_curr_wk_driver_temp_df.curr_wk_dvc_oh_bkng_cn).alias("curr_wk_dvc_oh_bkng_cn") \
                 , sum(res_baseln_curr_wk_driver_temp_df.curr_wk_obo_oh_bkng_cn).alias("curr_wk_obo_oh_bkng_cn") \
                 , sum(res_baseln_curr_wk_driver_temp_df.curr_wk_prevl_oh_bkng_cn).alias("curr_wk_prevl_oh_bkng_cn")) \
            .select("vyge_id", "version_start_date", \
                    "curr_wk_promo_oh_bkng_cn", "curr_wk_other_oh_bkng_cn", "curr_wk_dvc_oh_bkng_cn", \
                    "curr_wk_obo_oh_bkng_cn", "curr_wk_prevl_oh_bkng_cn").distinct()

        # all res_baseln attributes are collected in res_baseln_curr_wk_driver_df
        res_baseln_curr_wk_driver_df.createOrReplaceTempView("res_baseln_curr_wk_driver")
        if debug == 1:
            DebugCount.count_check(res_baseln_curr_wk_driver_df, "res_baseln_curr_wk_driver_df")
        ###############################################################################
        # Collecting vyge_fnc_fcst_var attributes in vyge_fnc_fcst_metrics_df   #
        ###############################################################################

        dflt_ship_fnc_fcst_filter_clause = "upper(lgcl_del_in) = 'N'"

        dflt_ship_fnc_fcst_df = data_loader.read_data("app", "DFLT_SHIP_FNC_FCST") \
            .filter(dflt_ship_fnc_fcst_filter_clause)

        vyge_fnc_fcst_var_filter_clause = "upper(lgcl_del_in) = 'N'"

        vyge_fnc_fcst_var_df_temp = data_loader.read_data("app", "VYGE_FNC_FCST_VAR") \
            .filter(vyge_fnc_fcst_var_filter_clause)
        vyge_fnc_fcst_var_df_temp.createOrReplaceTempView("vyge_fnc_fcst_var_temp")

        vyge_fnc_fcst_var_df = sql_context.sql("""SELECT *,COALESCE(MAX(data_ld_dts) OVER(
                  PARTITION BY SHIP_CD,VYGE_STRT_DT
                  ORDER BY data_ld_dts ASC ROWS BETWEEN 1 FOLLOWING AND 1 FOLLOWING
                  ),CAST('9999-12-31 00:00:00.000000' AS TIMESTAMP)) AS VRSN_END_DTS
                  from vyge_fnc_fcst_var_temp""")
        # ==============================================================================
        #     vyge_fnc_fcst_var_df = vyge_fnc_fcst_var_df_temp.select
        #                                         (vyge_fnc_fcst_var_df_temp.*
        #                                         ,COALESCE(MAX("data_ld_dts")
        #                                         OVER(
        #           PARTITION BY vyge_fnc_fcst_var_df_temp.SHIP_CD,vyge_fnc_fcst_var_df_temp.VYGE_STRT_DT
        #           ORDER BY vyge_fnc_fcst_var_df_temp.data_ld_dts ASC ROWS BETWEEN 1 FOLLOWING AND 1 FOLLOWING
        #           )
        #                                         ,CAST('9999-12-31 00:00:00.000000' AS TIMESTAMP)).alias("VRSN_END_DTS"))
        # ==============================================================================

        vyge_fnc_fcst_var_df.createOrReplaceTempView("vyge_fnc_fcst_var")

        vyge_fnc_fcst_metrics_df = final_driver_df2.join(vyge_fnc_fcst_var_df, \
                                                         (final_driver_df2.ship_cd == vyge_fnc_fcst_var_df.ship_cd) \
                                                         & (
                                                                 final_driver_df2.vyge_dprt_dt == vyge_fnc_fcst_var_df.vyge_strt_dt) \
                                                         & (vyge_fnc_fcst_var_df.VRSN_END_DTS \
                                                            == '9999-12-31 00:00:00.000000'), "left_outer") \
            .join(dflt_ship_fnc_fcst_df, \
                  (dflt_ship_fnc_fcst_df.ship_cd == final_driver_df2.ship_cd) \
                  & (dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_strt_dts \
                     <= final_driver_df2.version_start_date) \
                  & (dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_end_dts \
                     > final_driver_df2.version_start_date), "left_outer") \
            .select(final_driver_df2.vyge_id \
                    , final_driver_df2.version_start_date \
                    , vyge_fnc_fcst_var_df.ship_cd \
                    , vyge_fnc_fcst_var_df.vyge_strt_dt \
                    , vyge_fnc_fcst_var_df.vyge_grs_rev_am.alias("fcst_vyge_grs_rev_am") \
                    , vyge_fnc_fcst_var_df.vyge_net_rev_am.alias("fcst_vyge_net_rev_am") \
                    , (coalesce(vyge_fnc_fcst_var_df.fcst_comm_pc \
                                , dflt_ship_fnc_fcst_df.fcst_comm_pc) * 100).alias("fcst_comm_pc") \
                    , (coalesce(vyge_fnc_fcst_var_df.fcst_comm_pc \
                                , dflt_ship_fnc_fcst_df.fcst_comm_pc)).alias("fcst_comm_pc_orig") \
                    , vyge_fnc_fcst_var_df.vyge_avg_price_per_dy_am \
                    .alias("fcst_vyge_avg_price_per_dy_am") \
                    , vyge_fnc_fcst_var_df.vyge_net_price_per_dy_am \
                    .alias("fcst_vyge_net_price_per_dy_am") \
                    , coalesce(vyge_fnc_fcst_var_df.fcst_gst_per_strm_cn
                               , dflt_ship_fnc_fcst_df.fcst_gst_per_strm_cn).alias("fcst_gst_per_strm_cn")
                    ,
                    coalesce(vyge_fnc_fcst_var_df.fcst_ooo_gst_per_strm_cn,
                             dflt_ship_fnc_fcst_df.fcst_ooo_gst_per_strm_cn) \
                    .alias("fcst_ooo_gst_per_strm_cn") \
                    , (coalesce(vyge_fnc_fcst_var_df.fcst_ship_ocpncy_pc \
                                , dflt_ship_fnc_fcst_df.fcst_ship_ocpncy_pc) * 100).alias("fcst_ship_ocpncy_pc") \
                    , (coalesce(vyge_fnc_fcst_var_df.fcst_ship_ocpncy_pc \
                                , dflt_ship_fnc_fcst_df.fcst_ship_ocpncy_pc)).alias("fcst_ship_ocpncy_pc_orig") \
                    , coalesce(vyge_fnc_fcst_var_df.vyge_adlt_split_pc, dflt_ship_fnc_fcst_df.vyge_adlt_split_pc).alias(
                "vyge_adlt_split_pc") \
                    , coalesce(vyge_fnc_fcst_var_df.vyge_chld_split_pc, dflt_ship_fnc_fcst_df.vyge_chld_split_pc).alias(
                "vyge_chld_split_pc"))

        vyge_fnc_fcst_metrics_df.createOrReplaceTempView("vyge_fnc_fcst_metrics")
        vyge_fnc_fcst_metrics_df.persist()

        ###########################################################################################################
        # Join the driver table with the MSTR_VYGE_BASELN to fetch the fnl_pmt_dt         #
        #                           #
        ###########################################################################################################

        mstr_vyge_baseln_df = data_loader.read_data("dm", "MSTR_VYGE_BASELN") \
            .select("vyge_id", \
                    col('vrsn_strt_dts').alias("version_start_date"), \
                    "VRSN_END_DTS", col('fnl_dpst_due_dt').alias("fnl_pmt_dt"), "SHIP_OCPNCY_PC").distinct()

        mstr_vyge_baseln_df.createOrReplaceTempView("mstr_vyge_baseln")

        mstr_vyge_drvr_df = final_driver_df2.join(mstr_vyge_baseln_df, \
                                                  (final_driver_df2.vyge_id == mstr_vyge_baseln_df.vyge_id) \
                                                  & (
                                                          final_driver_df2.version_start_date >= mstr_vyge_baseln_df.version_start_date) \
                                                  & (
                                                          final_driver_df2.version_start_date < mstr_vyge_baseln_df.VRSN_END_DTS)) \
            .select(final_driver_df2.vyge_id, final_driver_df2.version_start_date, "fnl_pmt_dt").distinct()

        mstr_vyge_drvr_df.createOrReplaceTempView("mstr_vyge_drvr")

        if debug == 1:
            DebugCount.count_check(mstr_vyge_drvr_df, "mstr_vyge_drvr_df")

        ###########################################################################################################
        # Join the driver table with the RESBASELN METRICS to fetch the RES_BASELN METRICS      #
        #                           #
        ###########################################################################################################

        res_baseln_metrics_df = data_loader.read_data("con", "res_baseln_vyge")

        res_baseln_metrics_df.createOrReplaceTempView("res_baseln_metrics")

        vyge_res_baseln_metrics_df = final_driver_df2.join(res_baseln_metrics_df, \
                                                           (final_driver_df2.vyge_id == res_baseln_metrics_df.vyge_id) \
                                                           & (
                                                                       final_driver_df2.version_start_date == res_baseln_metrics_df.txn_dt)) \
            .select(final_driver_df2.vyge_id, \
                    final_driver_df2.version_start_date, \
                    "cncl_bkng_cn", "oh_bkng_cn", "pu_bkng_cn", "oh_asgn_bkng_cn", "grs_paid_bkng_cn" \
                    , "oh_asgn_bkng_gst_cn", "oh_bkng_gst_cn", "oh_bkng_adlt_gst_cn", "oh_bkng_chld_gst_cn" \
                    , "oh_bkng_mn_dng_gst_cn", "oh_bkng_sec_dng_gst_cn", "oh_bkng_ifnt_gst_cn", "pu_bkng_adlt_gst_cn" \
                    , "pu_bkng_chld_gst_cn", "pu_bkng_ifnt_gst_cn", "cncl_bkng_adlt_gst_cn", "cncl_bkng_chld_gst_cn" \
                    , "cncl_bkng_ifnt_gst_cn", "gtr_am", "ntr_am", "comm_am", "non_comm_am", "dvc_oh_bkng_cn",
                    "obo_oh_bkng_cn" \
                    , "prevl_oh_bkng_cn", "promo_oh_bkng_cn", "irgs_oh_bkng_cn", "other_oh_bkng_cn", "pu_bkng_gst_cn" \
                    , "pu_mn_dng_gst_cn", "pu_sec_dng_gst_cn", "dvc_pu_bkng_cn", "obo_pu_bkng_cn", "prevl_pu_bkng_cn" \
                    , "promo_pu_bkng_cn", "irgs_pu_bkng_cn", "other_pu_bkng_cn", "pu_gtr_am", "pu_ntr_am" \
                    , "curr_wk_oh_bkng_gst_cn", "curr_wk_pu_bkng_gst_cn", "curr_wk_pu_bkng_adlt_gst_cn" \
                    , "curr_wk_pu_bkng_chld_gst_cn", "curr_wk_pu_bkng_ifnt_gst_cn", "curr_wk_pu_mn_dng_gst_cn" \
                    , "curr_wk_pu_sec_dng_gst_cn", "curr_wk_pu_gtr_am", "curr_wk_pu_ntr_am", "curr_wk_pu_bkng_cn" \
                    , "curr_wk_dvc_pu_bkng_cn", "curr_wk_obo_pu_bkng_cn", "curr_wk_prevl_pu_bkng_cn" \
                    , "curr_wk_promo_pu_bkng_cn", "curr_wk_irgs_oh_bkng_cn", "curr_wk_irgs_pu_bkng_cn",
                    "curr_wk_other_pu_bkng_cn")

        vyge_res_baseln_metrics_df.createOrReplaceTempView("vyge_res_baseln_metrics")
        vyge_res_baseln_metrics_df.cache()
        print
        "vyge_res_baseln_metrics_df count is %s" % vyge_res_baseln_metrics_df.count()

        if debug == 1:
            DebugCount.count_check(vyge_res_baseln_metrics_df, "vyge_res_baseln_metrics_df")

        ###########################################################################################################
        # Join the voyage attribute table with the SHIPINVENTORYALLOC to fetch the Allocation information   #
        #                           #
        ###########################################################################################################
        ## get alloc information

        ship_inventory_alloc_filter = "upper(instnc_st_nm)='STANDARD' and \
         upper(allocation_owner_type)='GROUP'\
         and cabin_category not in ('IRG','XAM') "

        ship_inventory_alloc_df = data_loader.read_data("sha", "SHIPINVENTORYALLOC") \
            .filter(ship_inventory_alloc_filter).distinct()

        ship_inventory_alloc_df.createOrReplaceTempView("ship_inventory_alloc")
        drv_alloc_df = final_driver_df2.join(ship_inventory_alloc_df, \
                                             (final_driver_df2.ship_cd == ship_inventory_alloc_df.SHIP_CODE) \
                                             & (final_driver_df2.vyge_dprt_dt == ship_inventory_alloc_df.SAIL_DATE_FROM) \
                                             & (final_driver_df2.vyge_arvl_dt == ship_inventory_alloc_df.SAIL_DATE_TO) \
                                             & (final_driver_df2.version_start_date >= to_date(
                                                 ship_inventory_alloc_df.vrsn_strt_dts)) \
                                             & (final_driver_df2.version_start_date < to_date(
                                                 ship_inventory_alloc_df.vrsn_end_dts))) \
            .select(final_driver_df2.vyge_id, \
                    final_driver_df2.version_start_date, \
                    ship_inventory_alloc_df.CABIN_NUMBER, \
                    ship_inventory_alloc_df.OCCUPANCY, \
                    ship_inventory_alloc_df.DLGT_RES_ID)

        ship_inventory_alloc_unalloc_df = drv_alloc_df.groupby("vyge_id", "version_start_date") \
            .agg( \
            coalesce(sum(when((drv_alloc_df.DLGT_RES_ID.isNull()) & (drv_alloc_df.CABIN_NUMBER.isNotNull()), 1) \
                         .otherwise(0)), lit(0)).alias("alloc_grp_bkng_cn")
            , coalesce(sum(when((drv_alloc_df.DLGT_RES_ID.isNull()) & (drv_alloc_df.CABIN_NUMBER.isNull()), 1) \
                           .otherwise(0)) \
                       , lit(0)).alias("unalloc_grp_bkng_cn") \
            , coalesce(sum(when((drv_alloc_df.DLGT_RES_ID.isNull()) & (drv_alloc_df.CABIN_NUMBER.isNotNull()),
                                drv_alloc_df.OCCUPANCY) \
                           .otherwise(0)) \
                       , lit(0)).alias("alloc_grp_gst_cn"), \
            coalesce(sum(
                when((drv_alloc_df.DLGT_RES_ID.isNull()) & (drv_alloc_df.CABIN_NUMBER.isNull()), drv_alloc_df.OCCUPANCY) \
                .otherwise(0)) \
                     , lit(0)).alias("unalloc_grp_gst_cn") \
            )
        if debug == 1:
            DebugCount.count_check(ship_inventory_alloc_unalloc_df, "ship_inventory_alloc_unalloc_df")

        merged_group_alloc_unalloc_counts_df = final_driver_df2.join(ship_inventory_alloc_unalloc_df, \
                                                                     ["vyge_id", "version_start_date"], \
                                                                     "left_outer").select("vyge_id",
                                                                                          "version_start_date", \
                                                                                          coalesce("alloc_grp_bkng_cn",
                                                                                                   lit(0)).alias(
                                                                                              "alloc_grp_bkng_cn"),
                                                                                          coalesce("Alloc_grp_Gst_Cn",
                                                                                                   lit(0)).alias(
                                                                                              "alloc_grp_gst_cn"), \
                                                                                          coalesce(
                                                                                              "unalloc_grp_bkng_cn",
                                                                                              lit(0)).alias(
                                                                                              "unalloc_grp_bkng_cn"),
                                                                                          coalesce("UnAlloc_grp_Gst_Cn",
                                                                                                   lit(0)).alias(
                                                                                              "unalloc_grp_gst_cn")).distinct()
        merged_group_alloc_unalloc_counts_df.createOrReplaceTempView("temp_alloc_counts")
        if debug == 1:
            DebugCount.count_check(merged_group_alloc_unalloc_counts_df, "merged_group_alloc_unalloc_counts_df")

        alloc_counts_df = vyge_res_baseln_metrics_df.join(merged_group_alloc_unalloc_counts_df \
                                                          , ["vyge_id", "version_start_date"]) \
            .select(merged_group_alloc_unalloc_counts_df.vyge_id \
                    , merged_group_alloc_unalloc_counts_df.version_start_date \
                    , when(vyge_res_baseln_metrics_df.oh_bkng_cn == 0, 0) \
                    .otherwise(
                (vyge_res_baseln_metrics_df.promo_oh_bkng_cn * 100.00) / vyge_res_baseln_metrics_df.oh_bkng_cn) \
                    .cast(DecimalType(7, 2)).alias("PROMO_OH_BKNG_PC") \
                    , when(vyge_res_baseln_metrics_df.oh_bkng_cn == 0, 0) \
                    .otherwise(
                coalesce((vyge_res_baseln_metrics_df.oh_bkng_gst_cn * 1.00000 / vyge_res_baseln_metrics_df.oh_bkng_cn),
                         lit(0))) \
                    .cast(DecimalType(8, 5)).alias("OH_BKNG_AVG_GPS_VL") \
                    , "alloc_grp_bkng_cn" \
                    , "alloc_grp_gst_cn" \
                    , "unalloc_grp_bkng_cn" \
                    , "unalloc_grp_gst_cn" \
                    , coalesce(
                merged_group_alloc_unalloc_counts_df.alloc_grp_gst_cn + merged_group_alloc_unalloc_counts_df.unalloc_grp_gst_cn + vyge_res_baseln_metrics_df.oh_bkng_adlt_gst_cn,
                lit(0)).alias("paid_adlt_gst_cn") \
                    , coalesce(
                vyge_res_baseln_metrics_df.oh_bkng_cn + merged_group_alloc_unalloc_counts_df.alloc_grp_bkng_cn + merged_group_alloc_unalloc_counts_df.unalloc_grp_bkng_cn,
                lit(0)).alias("paid_bkng_cn") \
                    , coalesce(
                vyge_res_baseln_metrics_df.oh_bkng_gst_cn + merged_group_alloc_unalloc_counts_df.alloc_grp_gst_cn + merged_group_alloc_unalloc_counts_df.unalloc_grp_gst_cn,
                lit(0)).alias("paid_bkng_gst_cn") \
                    , coalesce(
                vyge_res_baseln_metrics_df.oh_asgn_bkng_cn + merged_group_alloc_unalloc_counts_df.alloc_grp_bkng_cn + merged_group_alloc_unalloc_counts_df.unalloc_grp_bkng_cn,
                lit(0)).alias("asgn_bkng_cn") \
                    , coalesce(
                vyge_res_baseln_metrics_df.oh_asgn_bkng_gst_cn + merged_group_alloc_unalloc_counts_df.alloc_grp_gst_cn + merged_group_alloc_unalloc_counts_df.unalloc_grp_gst_cn,
                lit(0)).alias("asgn_bkng_gst_cn"))

        if debug == 1:
            DebugCount.count_check(alloc_counts_df, "alloc_counts_df")

        alloc_counts_df.createOrReplaceTempView("alloc_counts")

        #########################################################
        #       SL_LIM_VYGE_SUM         #
        #########################################################

        sl_lim_vyge_sum_filter_clause = " UPPER(instnc_st_nm)='STANDARD' \
             AND OCPNCY_CN IS NULL \
             AND CBN_CTGY_CD  IS NULL \
             AND PROMO_CD IS NULL \
             AND ABSOLUTE_LIM_NB IS NOT NULL"

        sl_lim_vyge_sum_df = data_loader.read_data("dm", "SL_LIM_VYGE_SUM") \
            .filter(sl_lim_vyge_sum_filter_clause)

        sl_lim_vyge_sum_df = sl_lim_vyge_sum_df.coalesce(200)

        sl_lim_vyge_sum_driver_df = sl_lim_vyge_sum_df.groupby("Sail_id", "vrsn_end_dts", "vrsn_strt_dts") \
            .agg(max(when((sl_lim_vyge_sum_df.dng_tm == 'MAIN') \
                          & (sl_lim_vyge_sum_df.age_fr_nb.isNull()) \
                          & (sl_lim_vyge_sum_df.age_to_nb.isNull()) \
                          , sl_lim_vyge_sum_df.Absolute_lim_nb) \
                     .otherwise(None) \
                     ).alias("vyge_mn_dng_sl_lim_gst_cn") \
                 , max(when((sl_lim_vyge_sum_df.dng_tm == 'Second') \
                            & (sl_lim_vyge_sum_df.age_fr_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.age_to_nb.isNull()) \
                            , sl_lim_vyge_sum_df.Absolute_lim_nb) \
                       .otherwise(None) \
                       ).alias("vyge_sec_dng_sl_lim_gst_cn") \
                 , max(when((sl_lim_vyge_sum_df.dng_tm.isNull()) \
                            & (sl_lim_vyge_sum_df.age_fr_nb == 0) \
                            & (sl_lim_vyge_sum_df.age_to_nb == 2) \
                            , sl_lim_vyge_sum_df.Absolute_lim_nb) \
                       .otherwise(None) \
                       ).alias("vyge_ifnt_lim_gst_cn") \
                 , max(when((sl_lim_vyge_sum_df.dng_tm.isNull()) \
                            & (sl_lim_vyge_sum_df.age_fr_nb == 3) \
                            & (sl_lim_vyge_sum_df.age_to_nb == 12) \
                            , sl_lim_vyge_sum_df.Absolute_lim_nb) \
                       .otherwise(None) \
                       ).alias("vyge_chld_lim_gst_cn") \
                 , max(when((sl_lim_vyge_sum_df.dng_tm.isNull()) \
                            & (sl_lim_vyge_sum_df.age_fr_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.age_to_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.gst_seq_fr_nb == 1) \
                            & (sl_lim_vyge_sum_df.gst_seq_to_nb == 99) \
                            , sl_lim_vyge_sum_df.Absolute_lim_nb) \
                       .otherwise(None) \
                       ).alias("vyge_lim_gst_cn"))

        sl_lim_vyge_sum_driver_df.createOrReplaceTempView("VYGE_BASELN_SL_LIM_MTRCS")
        # vyge_baseln_sl_lim_mtrcs_df.coalesce

        # sl_lim_vyge_sum_driver_df.cache()
        # sl_lim_vyge_sum_driver_df.count()
        print
        "sl_lim_vyge_sum_driver_df count is %s" % sl_lim_vyge_sum_driver_df.count()

        if debug == 1:
            DebugCount.count_check(sl_lim_vyge_sum_driver_df, "sl_lim_vyge_sum_driver")

        vyge_baseln_sl_lim_mtrcs_df = sl_lim_vyge_sum_driver_df.join(final_driver_df2, \
                                                                     (
                                                                                 final_driver_df2.vyge_id == sl_lim_vyge_sum_driver_df.Sail_id) \
                                                                     & (
                                                                                 final_driver_df2.version_start_date >= sl_lim_vyge_sum_driver_df.vrsn_strt_dts.cast(
                                                                             "date")) \
                                                                     & (
                                                                                 final_driver_df2.version_start_date < sl_lim_vyge_sum_driver_df.vrsn_end_dts.cast(
                                                                             "date"))) \
            .groupby("vyge_id", "version_start_date") \
            .agg(max("vyge_mn_dng_sl_lim_gst_cn").alias("vyge_mn_dng_sl_lim_gst_cn") \
                 , max("vyge_sec_dng_sl_lim_gst_cn").alias("vyge_sec_dng_sl_lim_gst_cn") \
                 , max("vyge_ifnt_lim_gst_cn").alias("vyge_ifnt_lim_gst_cn") \
                 , max("vyge_chld_lim_gst_cn").alias("vyge_chld_lim_gst_cn") \
                 , max("vyge_lim_gst_cn").alias("vyge_lim_gst_cn"))

        vyge_baseln_sl_lim_mtrcs_df.createOrReplaceTempView("vyge_baseln_sl_lim_mtrcs")
        vyge_baseln_sl_lim_mtrcs_df.cache()
        print
        "vyge_baseln_sl_lim_mtrcs_df count is %s" % vyge_baseln_sl_lim_mtrcs_df.count()

        #########################################################
        #       AGE CATEGORY      #
        #########################################################
        age_category_df = data_loader.read_data("sha", "AGECATEGORY") \
            .filter("BUSINESSAREA = 'SHIP'")

        sl_lim_vyge_sum_filter_clause = " UPPER(instnc_st_nm)='STANDARD' \
                             AND OCPNCY_CN IS NULL \
                             AND CBN_CTGY_CD  IS NULL \
                             AND PROMO_CD IS NULL \
                             AND WGT_LIM_NB  IS NULL \
                             AND PROD_TYP_CD IS NULL \
                             AND PKG_TYP_CD IS NULL \
                             AND AGE_CTGY_CD IS NULL \
                             AND REF_SRC_NM IS NULL \
                             AND RES_TYP_CD IS NULL \
                             AND AGCY_ID IS NULL \
                             AND GRP_TYP_CD IS NULL \
                             AND DNG_TM IS NULL \
                             AND CONDITIONTEXT IS NULL \
                             AND AUTH_CD IS NULL"

        sl_lim_vyge_sum_df = data_loader.read_data("dm", "SL_LIM_VYGE_SUM") \
            .filter(sl_lim_vyge_sum_filter_clause)

        sl_lim_vyge_sum_df = sl_lim_vyge_sum_df.coalesce(200)

        age_category_driver_df = age_category_df.join(sl_lim_vyge_sum_df, (sl_lim_vyge_sum_df.Sail_fr_dt \
                                                                           >= age_category_df.EffectiveDateFrom) \
                                                      & (
                                                                  sl_lim_vyge_sum_df.Sail_fr_dt < age_category_df.EffectiveDateTo))

        age_category_driver_df.createOrReplaceTempView("age_category_driver")
        age_category_driver_df.persist()

        age_category_df.createOrReplaceTempView("age_category")

        vyge_baseln_age_chld_mtrcs_df = age_category_driver_df.join(sl_lim_vyge_sum_df, \
                                                                    (
                                                                                sl_lim_vyge_sum_df.Sail_id == age_category_driver_df.Sail_id) \
                                                                    & (
                                                                                sl_lim_vyge_sum_df.age_fr_nb == age_category_driver_df.AgeFrom) \
                                                                    & (
                                                                                sl_lim_vyge_sum_df.age_to_nb == age_category_driver_df.AgeTo)) \
            .filter("AgeType == 'CHILD'") \
            .select(sl_lim_vyge_sum_df.Sail_id.alias("vyge_id") \
                    , sl_lim_vyge_sum_df.vrsn_strt_dts.cast("date") \
                    , sl_lim_vyge_sum_df.vrsn_end_dts.cast("date") \
                    , sl_lim_vyge_sum_df.age_fr_nb.alias("chld_min_age_nb") \
                    , sl_lim_vyge_sum_df.age_to_nb.alias("chld_max_age_nb"))
        vyge_baseln_age_chld_mtrcs_df.createOrReplaceTempView("VYGE_BASELN_AGE_CHLD_MTRCS")
        vyge_baseln_age_chld_mtrcs_df.cache()
        vyge_baseln_age_chld_mtrcs_df.count()
        if debug == 1:
            DebugCount.count_check(vyge_baseln_age_chld_mtrcs_df, "vyge_baseln_age_chld_mtrcs_df")

        vyge_baseln_age_inft_mtrcs_df = age_category_driver_df.join(sl_lim_vyge_sum_df, \
                                                                    (
                                                                                sl_lim_vyge_sum_df.Sail_id == age_category_driver_df.Sail_id) \
                                                                    & (
                                                                                sl_lim_vyge_sum_df.age_fr_nb == age_category_driver_df.AgeFrom) \
                                                                    & (
                                                                                sl_lim_vyge_sum_df.age_to_nb == age_category_driver_df.AgeTo)) \
            .filter("AgeType == 'INFANT'") \
            .select(sl_lim_vyge_sum_df.Sail_id.alias("vyge_id") \
                    , sl_lim_vyge_sum_df.vrsn_strt_dts.cast("date") \
                    , sl_lim_vyge_sum_df.vrsn_end_dts.cast("date") \
                    , sl_lim_vyge_sum_df.age_fr_nb.alias("ifnt_min_age_nb") \
                    , sl_lim_vyge_sum_df.age_to_nb.alias("ifnt_max_age_nb"))
        vyge_baseln_age_inft_mtrcs_df.createOrReplaceTempView("vyge_baseln_age_inft_mtrcs")
        vyge_baseln_age_inft_mtrcs_df.cache()
        print
        "vyge_baseln_age_inft_mtrcs_df count is %s" % vyge_baseln_age_inft_mtrcs_df.count()

        if debug == 1:
            DebugCount.count_check(vyge_baseln_age_inft_mtrcs_df, "vyge_baseln_age_inft_mtrcs_df")

        vyge_baseln_age_mtrcs_df = final_driver_df2 \
            .join(vyge_baseln_age_chld_mtrcs_df, ["vyge_id"]) \
            .join(vyge_baseln_age_inft_mtrcs_df, ["vyge_id"]) \
            .join(vyge_baseln_sl_lim_mtrcs_df, ["vyge_id", "version_start_date"]) \
            .filter( \
            (final_driver_df2.version_start_date >= vyge_baseln_age_chld_mtrcs_df.vrsn_strt_dts) \
            & (final_driver_df2.version_start_date < vyge_baseln_age_chld_mtrcs_df.vrsn_end_dts) \
            & (final_driver_df2.version_start_date >= vyge_baseln_age_inft_mtrcs_df.vrsn_strt_dts) \
            & (final_driver_df2.version_start_date < vyge_baseln_age_inft_mtrcs_df.vrsn_end_dts)) \
            .groupby("vyge_id", "version_start_date") \
            .agg(min("chld_min_age_nb").alias("chld_min_age_nb") \
                 , max("chld_max_age_nb").alias("chld_max_age_nb") \
                 , min("ifnt_min_age_nb").alias("ifnt_min_age_nb") \
                 , max("ifnt_max_age_nb").alias("ifnt_max_age_nb") \
                 , max("vyge_mn_dng_sl_lim_gst_cn").alias("vyge_mn_dng_sl_lim_gst_cn") \
                 , max("vyge_sec_dng_sl_lim_gst_cn").alias("vyge_sec_dng_sl_lim_gst_cn") \
                 , max("vyge_ifnt_lim_gst_cn").alias("vyge_ifnt_lim_gst_cn") \
                 , max("vyge_chld_lim_gst_cn").alias("vyge_chld_lim_gst_cn") \
                 , max("vyge_lim_gst_cn").alias("vyge_lim_gst_cn"))

        vyge_baseln_age_mtrcs_df.createOrReplaceTempView("vyge_baseln_age_mtrcs")
        vyge_baseln_age_mtrcs_df.cache()
        print
        "vyge_baseln_age_mtrcs_df count is %s" % vyge_baseln_age_mtrcs_df.count()
        if debug == 1:
            DebugCount.count_check(vyge_baseln_age_mtrcs_df, "vyge_baseln_age_mtrcs_df")

        vyge_baseln_stop_sl_in_df = final_driver_df2.join(vyge_baseln_age_mtrcs_df, ["vyge_id", "version_start_date"]) \
            .join(sl_lim_vyge_sum_df, (final_driver_df2.vyge_id == sl_lim_vyge_sum_df.Sail_id)) \
            .filter( \
            (final_driver_df2.version_start_date >= sl_lim_vyge_sum_df.vrsn_strt_dts.cast("date")) \
            & (final_driver_df2.version_start_date < sl_lim_vyge_sum_df.vrsn_end_dts.cast("date"))) \
            .groupby(final_driver_df2.vyge_id, final_driver_df2.version_start_date) \
            .agg(max(when((sl_lim_vyge_sum_df.gst_seq_fr_nb.isNull()) \
                          & (sl_lim_vyge_sum_df.gst_seq_to_nb.isNull()) \
                          & (sl_lim_vyge_sum_df.age_fr_nb == vyge_baseln_age_mtrcs_df.ifnt_min_age_nb) \
                          & (sl_lim_vyge_sum_df.age_to_nb == vyge_baseln_age_mtrcs_df.ifnt_max_age_nb) \
                          , sl_lim_vyge_sum_df.Is_stop_sl_in) \
                     .otherwise(None) \
                     ).alias("vyge_ifnt_stop_sl_in") \
                 , max(when((sl_lim_vyge_sum_df.gst_seq_fr_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.gst_seq_to_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.age_fr_nb == vyge_baseln_age_mtrcs_df.chld_min_age_nb) \
                            & (sl_lim_vyge_sum_df.age_to_nb == vyge_baseln_age_mtrcs_df.chld_max_age_nb) \
                            , sl_lim_vyge_sum_df.Is_stop_sl_in) \
                       .otherwise(None) \
                       ).alias("vyge_chld_stop_sl_in") \
                 , max(when((sl_lim_vyge_sum_df.age_fr_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.age_to_nb.isNull()) \
                            & (sl_lim_vyge_sum_df.gst_seq_fr_nb == 1) \
                            & (sl_lim_vyge_sum_df.gst_seq_to_nb == 99) \
                            , sl_lim_vyge_sum_df.Is_stop_sl_in) \
                       .otherwise(None) \
                       ).alias("vyge_tot_stop_sl_in"))
        vyge_baseln_stop_sl_in_df.createOrReplaceTempView("vyge_baseln_stop_sl_in")
        print
        "vyge_baseln_stop_sl_in_df count is %s" % vyge_baseln_stop_sl_in_df.count()

        if debug == 1:
            DebugCount.count_check(vyge_baseln_stop_sl_in_df, "VYGE_BASELN_STOP_SL_IN")

        expect_rev_df = data_loader.read_data("arch", "EXPECT_REV")

        expect_rev_df.createOrReplaceTempView("expect_rev_tbl")

        expect_rev_max_df = expect_rev_df.join(final_driver_df2, \
                                               (expect_rev_df.app_vyge_id == final_driver_df2.app_vyge_id) \
                                               & ((expect_rev_df.expect_rev_run_dts.cast("date")) <= (
                                                   final_driver_df2.version_start_date))) \
            .groupby(expect_rev_df.app_vyge_id) \
            .agg(max(expect_rev_df.expect_rev_run_dts).alias("expect_rev_run_dts_max")) \
            .select(expect_rev_df.app_vyge_id, "expect_rev_run_dts_max")

        expect_rev_max_df.createOrReplaceTempView("expect_rev_max")

        expect_rev_metrics_df = final_driver_df2.join(expect_rev_max_df, "app_vyge_id") \
            .join(expect_rev_df, (final_driver_df2.app_vyge_id == expect_rev_max_df.app_vyge_id) \
                  & (expect_rev_max_df.expect_rev_run_dts_max == expect_rev_df.expect_rev_run_dts)) \
            .groupby(final_driver_df2.vyge_id, final_driver_df2.version_start_date, \
                     final_driver_df2.app_vyge_id, expect_rev_df.expect_rev_run_dts) \
            .agg(sum(expect_rev_df.expect_rev_am).cast("int").alias("expect_rev_am")) \
            .select(final_driver_df2.vyge_id, final_driver_df2.version_start_date \
                    , final_driver_df2.app_vyge_id, expect_rev_df.expect_rev_run_dts, "expect_rev_am").distinct()

        expect_rev_metrics_df.createOrReplaceTempView("expect_rev_metrics")

        if debug == 1:
            DebugCount.count_check(expect_rev_metrics_df, "expect_rev_metrics")

        strm_typ_nest_config_filter_clause = "upper(trim(strm_typ_nest_grp_nm)) = 'SHIPSCI' \
                        AND upper(trim(lgcl_del_in)) = 'N' \
                        AND upper(trim(src_sys_strm_typ_nm)) NOT IN ('IRG','XAM')"

        strm_typ_nest_config_df = data_loader.read_data("app", "STRM_TYP_NEST_CONFIG") \
            .filter(strm_typ_nest_config_filter_clause)
        strm_typ_nest_config_df.createOrReplaceTempView("strm_typ_nest_config")
        strm_typ_nest_df = strm_typ_nest_config_df.select("ship_cd", "strm_typ_nest_config_strt_dts",
                                                          "src_sys_strm_typ_nm", "sci_rcmd_excl_in")
        strm_typ_nest_df_explode_df = strm_typ_nest_df.withColumn("strm_typ_cd", explode(
            split(strm_typ_nest_df.src_sys_strm_typ_nm, "[;]"))) \
            .filter("strm_typ_cd != 'IRG' and strm_typ_cd != 'XAM' ")

        ship_strm_typ_filter = "upper(instnc_st_nm)='STANDARD'"
        ship_strm_strm_typ_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP") \
            .filter(ship_strm_typ_filter)
        ship_cpcty_df = strm_typ_nest_df_explode_df.join(ship_strm_strm_typ_df, ["ship_cd", "strm_typ_cd"]) \
            .groupBy("ship_cd", "strm_typ_cd", "ship_strm_nb", "strm_typ_nest_config_strt_dts",
                     "ship_strm_strm_strt_dts", \
                     "ship_strm_strm_end_dts", "vrsn_strt_dts", "vrsn_end_dts") \
            .agg(sum("strm_cpcty_nb").alias("strm_cpcty_nb"))

        ship_cpcty_driver_df = final_driver_df2.join(ship_cpcty_df, ["ship_cd"]) \
            .filter("version_start_date >=  date(strm_typ_nest_config_strt_dts) and vyge_dprt_dt >=  date(ship_strm_strm_strt_dts) \
                and vyge_dprt_dt < date(ship_strm_strm_end_dts) and version_start_date >= date(vrsn_strt_dts) and \
                version_start_date < date(vrsn_end_dts) ") \
            .groupBy("ship_cd", "version_start_date", "vyge_id") \
            .agg(sum("strm_cpcty_nb").alias("strm_cpcty_nb"))

        opn_vyge_strm_typ_filter_clause = "upper(lgcl_del_in)= 'N'"

        opn_vyge_strm_typ_config_df = data_loader.read_data("app", "OPN_VYGE_STRM_TYP_CONFIG") \
            .filter(opn_vyge_strm_typ_filter_clause)
        opn_vyge_strm_typ_config_df.createOrReplaceTempView("opn_vyge_strm_typ_config")

        opn_vyge_strm_typ_voyage_df = opn_vyge_strm_typ_config_df.join(final_driver_df2 \
                                                                       , (
                                                                                   opn_vyge_strm_typ_config_df.ship_cd == final_driver_df2.ship_cd) \
                                                                       & (
                                                                                   final_driver_df2.vyge_dprt_dt >= opn_vyge_strm_typ_config_df.vyge_dprt_dt) \
                                                                       & (
                                                                                   final_driver_df2.vyge_dprt_dt < opn_vyge_strm_typ_config_df.vyge_arvl_dt) \
                                                                       & (
                                                                                   final_driver_df2.version_start_date >= to_date(
                                                                               opn_vyge_strm_typ_config_df.vyge_strm_typ_config_strt_dts)) \
                                                                       & (final_driver_df2.version_start_date < to_date(
                opn_vyge_strm_typ_config_df.vyge_strm_typ_config_end_dts))) \
            .select(final_driver_df2.vyge_id, opn_vyge_strm_typ_config_df.strm_typ_cd,
                    final_driver_df2.version_start_date, \
                    opn_vyge_strm_typ_config_df.ooo_strm_cn.alias("ooo_strm_cn") \
                    )
        opn_vyge_strm_typ_voyage_df.createOrReplaceTempView("opn_vyge_strm_typ")
        if debug == 1:
            DebugCount.count_check(opn_vyge_strm_typ_voyage_df, "opn_vyge_strm_typ_voyage_df")

        est_opn_vyge_strm_typ_voyage_df = opn_vyge_strm_typ_config_df.join(final_driver_df2 \
                                                                           , (
                                                                                       opn_vyge_strm_typ_config_df.ship_cd == final_driver_df2.ship_cd) \
                                                                           & (
                                                                                       final_driver_df2.vyge_dprt_dt >= opn_vyge_strm_typ_config_df.vyge_dprt_dt) \
                                                                           & (
                                                                                       final_driver_df2.vyge_dprt_dt < opn_vyge_strm_typ_config_df.vyge_arvl_dt) \
                                                                           & (
                                                                                       final_driver_df2.version_start_date >= to_date(
                                                                                   opn_vyge_strm_typ_config_df.vyge_strm_typ_config_strt_dts)) \
                                                                           & (
                                                                                       final_driver_df2.version_start_date < to_date(
                                                                                   opn_vyge_strm_typ_config_df.vyge_strm_typ_config_end_dts))) \
            .groupby(final_driver_df2.vyge_id, final_driver_df2.version_start_date) \
            .agg(sum(opn_vyge_strm_typ_config_df.ooo_strm_cn).alias("est_ooo_strm_cn"))

        est_opn_vyge_strm_typ_voyage_df.createOrReplaceTempView("est_opn_vyge_strm_typ")

        if debug == 1:
            DebugCount.count_check(est_opn_vyge_strm_typ_voyage_df, "est_opn_vyge_strm_typ_voyage_df")

        ###############################################################################
        ##### merge with proc price pt to compute ppm metrics #########################
        ###############################################################################
        voyages_only_df = final_driver_df2.select("vyge_id", "version_start_date", "vyge_init_bkng_dt")
        # read proc_price_pt from opening date of voyage to transaction date

        proc_price_pt_drvr_df = proc_price_pt_temp_df.join(voyages_only_df, \
                                                           (voyages_only_df.vyge_id == proc_price_pt_temp_df.vyge_id) \
                                                           & (
                                                                       voyages_only_df.version_start_date == proc_price_pt_temp_df.txn_dt)) \
            .select(proc_price_pt_temp_df.vyge_id, "vyge_drtn_nght_cn", "version_start_date", "strm_typ_cd", "vfd_am", \
                    "vfa_extra_am", "vfc_extra_am", "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_temp_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        prev_ppm_metric_rdd = proc_price_pt_drvr_df \
            .repartition("vyge_id", "version_start_date", "strm_typ_cd") \
            .sortWithinPartitions("vyge_id", "strm_typ_cd", "version_start_date", desc("rank")) \
            .rdd.mapPartitions(ExpectedFinalRevenue.populate_prev_ppm, preservesPartitioning=True)

        ppm_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("version_start_date", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        ppm_metrics_df = converter.convertRddToDataFrame(prev_ppm_metric_rdd, ppm_schema)
        ppp_subset_gtr_ntr_df = ppm_metrics_df.select("vyge_id", "version_start_date", "strm_typ_cd",
                                                      "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am",
                                                      "vfi_extra_am", "non_comm_am").distinct()
        ppp_subset_gtr_ntr_df.createOrReplaceTempView("ppp_subset_gtr_ntr")

        ppm_tmp_df = final_driver_df2.join(ppp_subset_gtr_ntr_df, ["vyge_id", "version_start_date"]) \
            .select(final_driver_df2.vyge_id, \
                    final_driver_df2.version_start_date, \
                    final_driver_df2.vyge_drtn_nght_cn, \
                    ppp_subset_gtr_ntr_df.strm_typ_cd, \
                    ppp_subset_gtr_ntr_df.vfd_am, \
                    ppp_subset_gtr_ntr_df.vfa_extra_am, \
                    ppp_subset_gtr_ntr_df.vfc_extra_am, \
                    ppp_subset_gtr_ntr_df.vfi_extra_am, \
                    ppp_subset_gtr_ntr_df.non_comm_am)

        proc_price_pt_df = ppm_tmp_df.join(opn_vyge_strm_typ_voyage_df,
                                           ["vyge_id", "version_start_date", "strm_typ_cd"], "left_outer") \
            .join(vyge_fnc_fcst_metrics_df, ["vyge_id", "version_start_date"], "left_outer") \
            .join(est_physical_inventory_cnt_df, ["vyge_id", "version_start_date", "strm_typ_cd"], "left_outer") \
            .select(ppm_tmp_df.vyge_id, \
                    ppm_tmp_df.version_start_date, \
                    ppm_tmp_df.vyge_drtn_nght_cn, \
                    ppm_tmp_df.strm_typ_cd, \
                    ppm_tmp_df.vfd_am, \
                    ppm_tmp_df.vfa_extra_am.alias("vfa_am"), \
                    ppm_tmp_df.vfc_extra_am.alias("vfc_am"), \
                    ppm_tmp_df.non_comm_am, \
                    coalesce(opn_vyge_strm_typ_voyage_df.ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                    vyge_fnc_fcst_metrics_df.fcst_ship_ocpncy_pc_orig, \
                    vyge_fnc_fcst_metrics_df.fcst_gst_per_strm_cn, \
                    vyge_fnc_fcst_metrics_df.fcst_ooo_gst_per_strm_cn, \
                    vyge_fnc_fcst_metrics_df.fcst_comm_pc_orig, \
                    vyge_fnc_fcst_metrics_df.vyge_chld_split_pc, \
                    vyge_fnc_fcst_metrics_df.vyge_adlt_split_pc, \
                    est_physical_inventory_cnt_df.phys_invtry_strm_cn)
        proc_price_pt_df.createOrReplaceTempView("compute_ppm_view")
        if debug == 1:
            DebugCount.count_check(proc_price_pt_df, "proc_price_pt_df")

        voyage_price_mod_vdf_cat_df = proc_price_pt_df.groupby("vyge_id", "version_start_date", "strm_typ_cd") \
            .agg(min("fcst_ship_ocpncy_pc_orig").alias("fcst_ship_ocpncy_pc_orig"), \
                 min("fcst_gst_per_strm_cn").alias("fcst_gst_per_strm_cn"), \
                 min("fcst_ooo_gst_per_strm_cn").alias("fcst_ooo_gst_per_strm_cn"), \
                 min("fcst_comm_pc_orig").alias("fcst_comm_pc_orig"), \
                 sum((((proc_price_pt_df.vfd_am + proc_price_pt_df.non_comm_am) * 2)
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn)) +
                     (((proc_price_pt_df.vfa_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_adlt_split_pc) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2)) + \
                     (((proc_price_pt_df.vfc_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_chld_split_pc) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2))) \
                 .alias("gross_revenue"), \
                 sum((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.fcst_ship_ocpncy_pc_orig - proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.ooo_strm_cn) * proc_price_pt_df.fcst_gst_per_strm_cn + \
                     (
                                 proc_price_pt_df.ooo_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn * proc_price_pt_df.fcst_ooo_gst_per_strm_cn)) \
                 .alias("gross_price_pd"))
        if debug == 1:
            DebugCount.count_check(voyage_price_mod_vdf_cat_df, "voyage_price_mod_vdf_cat_df")
        voyage_price_mod_vdf_cat_df.createOrReplaceTempView("compute_ppm_voyage")

        voyage_price_mod_vdf_summary = voyage_price_mod_vdf_cat_df.groupby("vyge_id", "version_start_date") \
            .agg((sum("gross_revenue") / sum("gross_price_pd")).cast(DecimalType(12, 2)) \
                 .alias("gtr_price_pd_am"))
        voyage_price_mod_vdf_summary.createOrReplaceTempView("gtr_am")

        gtr_ntr_amts_df = voyage_price_mod_vdf_summary \
            .join(voyage_price_mod_vdf_cat_df, ["vyge_id", "version_start_date"]) \
            .select(voyage_price_mod_vdf_summary.vyge_id, \
                    voyage_price_mod_vdf_summary.version_start_date, \
                    voyage_price_mod_vdf_summary.gtr_price_pd_am, \
                    (voyage_price_mod_vdf_summary.gtr_price_pd_am * \
                     (1 - (voyage_price_mod_vdf_cat_df.fcst_comm_pc_orig))).cast(DecimalType(12, 2)) \
                    .alias("ntr_price_pd_am")).distinct()
        gtr_ntr_amts_df.cache()
        gtr_ntr_amts_df.count()
        if debug == 1:
            DebugCount.count_check(gtr_ntr_amts_df, "gtr_ntr_amts_df")

        #################### OPN_GTR_PRICE_PD_AM,OPN_NTR_PRICE_PD_AM  ###############

        proc_price_pt_drvr_df = proc_price_pt_temp_df.join(voyages_only_df, \
                                                           (voyages_only_df.vyge_id == proc_price_pt_temp_df.vyge_id) \
                                                           & (coalesce(voyages_only_df.vyge_init_bkng_dt, \
                                                                       date_add(voyages_only_df.vyge_init_bkng_dt,
                                                                                1)) == \
                                                              proc_price_pt_temp_df.txn_dt)) \
            .select(proc_price_pt_temp_df.vyge_id, "vyge_drtn_nght_cn", "version_start_date", "strm_typ_cd", "vfd_am", \
                    "vfa_extra_am", "vfc_extra_am", "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .withColumn("rank", when(proc_price_pt_temp_df.proc_price_src_sys_nm == 'Pricing Extract', 1).otherwise(2))

        prev_ppm_metric_rdd = proc_price_pt_drvr_df \
            .repartition("vyge_id", "version_start_date", "strm_typ_cd") \
            .sortWithinPartitions("vyge_id", "strm_typ_cd", "version_start_date", desc("rank")) \
            .rdd.mapPartitions(ExpectedFinalRevenue.populate_prev_ppm, preservesPartitioning=True)

        ppm_schema = StructType([
            StructField("vyge_id", IntegerType(), True),
            StructField("version_start_date", DateType(), True),
            StructField("strm_typ_cd", StringType(), True),
            StructField("vyge_drtn_nght_cn", IntegerType(), True),
            StructField("vfd_am", DecimalType(10, 2), True),
            StructField("vfa_extra_am", DecimalType(10, 2), True),
            StructField("vfc_extra_am", DecimalType(10, 2), True),
            StructField("vfi_extra_am", DecimalType(10, 2), True),
            StructField("non_comm_am", DecimalType(10, 2), True)
        ])

        ppm_metrics_df = converter.convertRddToDataFrame(prev_ppm_metric_rdd, ppm_schema)
        ppp_subset_opn_gtr_ntr_df = ppm_metrics_df.select("vyge_id", "version_start_date", "strm_typ_cd",
                                                          "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am",
                                                          "vfi_extra_am", "non_comm_am").distinct()
        ppm_tmp_df = final_driver_df2.join(ppp_subset_opn_gtr_ntr_df, ["vyge_id", "version_start_date"]) \
            .select(final_driver_df2.vyge_id, \
                    final_driver_df2.version_start_date, \
                    final_driver_df2.vyge_drtn_nght_cn, \
                    ppp_subset_opn_gtr_ntr_df.strm_typ_cd, \
                    ppp_subset_opn_gtr_ntr_df.vfd_am, \
                    ppp_subset_opn_gtr_ntr_df.vfa_extra_am, \
                    ppp_subset_opn_gtr_ntr_df.vfc_extra_am, \
                    ppp_subset_opn_gtr_ntr_df.vfi_extra_am, \
                    ppp_subset_opn_gtr_ntr_df.non_comm_am)

        proc_price_pt_df = ppm_tmp_df.join(opn_vyge_strm_typ_voyage_df,
                                           ["vyge_id", "version_start_date", "strm_typ_cd"], "left_outer") \
            .join(vyge_fnc_fcst_metrics_df, ["vyge_id", "version_start_date"], "left_outer") \
            .join(est_physical_inventory_cnt_df, ["vyge_id", "version_start_date", "strm_typ_cd"], "left_outer") \
            .select(ppm_tmp_df.vyge_id, \
                    ppm_tmp_df.version_start_date, \
                    ppm_tmp_df.vyge_drtn_nght_cn, \
                    ppm_tmp_df.strm_typ_cd, \
                    ppm_tmp_df.vfd_am, \
                    ppm_tmp_df.vfa_extra_am.alias("vfa_am"), \
                    ppm_tmp_df.vfc_extra_am.alias("vfc_am"), \
                    ppm_tmp_df.non_comm_am, \
                    coalesce(opn_vyge_strm_typ_voyage_df.ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                    vyge_fnc_fcst_metrics_df.fcst_ship_ocpncy_pc_orig, \
                    vyge_fnc_fcst_metrics_df.fcst_gst_per_strm_cn, \
                    vyge_fnc_fcst_metrics_df.fcst_ooo_gst_per_strm_cn, \
                    vyge_fnc_fcst_metrics_df.fcst_comm_pc_orig, \
                    vyge_fnc_fcst_metrics_df.vyge_chld_split_pc, \
                    vyge_fnc_fcst_metrics_df.vyge_adlt_split_pc, \
                    est_physical_inventory_cnt_df.phys_invtry_strm_cn)
        proc_price_pt_df.createOrReplaceTempView("compute_ppm_view")
        if debug == 1:
            DebugCount.count_check(proc_price_pt_df, "proc_price_pt_df")

        voyage_price_mod_vdf_cat_df = proc_price_pt_df.groupby("vyge_id", "version_start_date", "strm_typ_cd") \
            .agg(min("fcst_ship_ocpncy_pc_orig").alias("fcst_ship_ocpncy_pc_orig"), \
                 min("fcst_gst_per_strm_cn").alias("fcst_gst_per_strm_cn"), \
                 min("fcst_ooo_gst_per_strm_cn").alias("fcst_ooo_gst_per_strm_cn"), \
                 min("fcst_comm_pc_orig").alias("fcst_comm_pc_orig"), \
                 sum((((proc_price_pt_df.vfd_am + proc_price_pt_df.non_comm_am) * 2)
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn)) +
                     (((proc_price_pt_df.vfa_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_adlt_split_pc) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2)) + \
                     (((proc_price_pt_df.vfc_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_chld_split_pc) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2))) \
                 .alias("gross_revenue"), \
                 sum((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.fcst_ship_ocpncy_pc_orig - proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.ooo_strm_cn) * proc_price_pt_df.fcst_gst_per_strm_cn + \
                     (
                                 proc_price_pt_df.ooo_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn * proc_price_pt_df.fcst_ooo_gst_per_strm_cn)) \
                 .alias("gross_price_pd"))

        if debug == 1:
            DebugCount.count_check(voyage_price_mod_vdf_cat_df, "voyage_price_mod_vdf_cat_df")
        voyage_price_mod_vdf_cat_df.createOrReplaceTempView("compute_ppm_voyage")

        voyage_price_mod_vdf_summary = voyage_price_mod_vdf_cat_df.groupby("vyge_id", "version_start_date") \
            .agg((sum("gross_revenue") / sum("gross_price_pd")).cast(DecimalType(12, 2)) \
                 .alias("opn_gtr_price_pd_am"))
        voyage_price_mod_vdf_summary.createOrReplaceTempView("opn_gtr_am")

        opn_gtr_ntr_amts_df = voyage_price_mod_vdf_summary \
            .join(voyage_price_mod_vdf_cat_df, ["vyge_id", "version_start_date"]) \
            .select(voyage_price_mod_vdf_summary.vyge_id, \
                    voyage_price_mod_vdf_summary.version_start_date, \
                    voyage_price_mod_vdf_summary.opn_gtr_price_pd_am, \
                    (voyage_price_mod_vdf_summary.opn_gtr_price_pd_am * \
                     (1 - (voyage_price_mod_vdf_cat_df.fcst_comm_pc_orig))).cast(DecimalType(12, 2)) \
                    .alias("opn_ntr_price_pd_am")).distinct()
        opn_gtr_ntr_amts_df.cache()
        opn_gtr_ntr_amts_df.count()
        if debug == 1:
            DebugCount.count_check(opn_gtr_ntr_amts_df, "opn_gtr_ntr_amts_df")

        ################# RCMD_VYGE_NTR_PRICE_PD_AM ###################################

        price_rcmd_dtl_filter_clause = "upper(trim(lgcl_del_in)) = 'N'"

        price_rcmd_dtl_df = data_loader.read_data("sha", "PRICE_RCMD_DTL") \
            .filter(price_rcmd_dtl_filter_clause) \
            .select("app_vyge_id", "strm_typ_cd", "dy_bef_vyge_rnge_strt_cn", "dy_bef_vyge_rnge_end_cn",
                    "price_rcmd_run_dts", "non_comm_fare_am", "vfd_pd_am", "vfa_pd_am", "vfc_pd_am", "vfi_pd_am")
        price_rcmd_dtl_df.createOrReplaceTempView("price_rcmd_dtl")
        final_driver_df2 = final_driver_df2.withColumn("dy_bef_vyge_cn", datediff(final_driver_df2.vyge_dprt_dt,
                                                                                  final_driver_df2.version_start_date))

        price_rcmd_dtl_temp_df = final_driver_df2.join(
            price_rcmd_dtl_df.select("app_vyge_id", "price_rcmd_run_dts", "dy_bef_vyge_rnge_strt_cn",
                                     "dy_bef_vyge_rnge_end_cn", "strm_typ_cd"), ["app_vyge_id"]) \
            .where((final_driver_df2.version_start_date >= to_date(price_rcmd_dtl_df.price_rcmd_run_dts)) \
                   & (final_driver_df2.dy_bef_vyge_cn >= price_rcmd_dtl_df.dy_bef_vyge_rnge_strt_cn) \
                   & (final_driver_df2.dy_bef_vyge_cn <= price_rcmd_dtl_df.dy_bef_vyge_rnge_end_cn)) \
            .groupBy("app_vyge_id" \
                     , final_driver_df2.vyge_id \
                     , final_driver_df2.version_start_date \
                     , price_rcmd_dtl_df.dy_bef_vyge_rnge_strt_cn \
                     , price_rcmd_dtl_df.dy_bef_vyge_rnge_end_cn \
                     , price_rcmd_dtl_df.strm_typ_cd) \
            .agg(max(price_rcmd_dtl_df.price_rcmd_run_dts).alias("price_rcmd_run_dts"))

        price_rcmd_dtl_typ_df = price_rcmd_dtl_temp_df.join(price_rcmd_dtl_df, \
                                                            ["app_vyge_id", "price_rcmd_run_dts",
                                                             "dy_bef_vyge_rnge_strt_cn", "dy_bef_vyge_rnge_end_cn",
                                                             "strm_typ_cd"]) \
            .select("vyge_id", "app_vyge_id", price_rcmd_dtl_temp_df.version_start_date, "strm_typ_cd",
                    "dy_bef_vyge_rnge_strt_cn", "dy_bef_vyge_rnge_end_cn", "price_rcmd_run_dts", "non_comm_fare_am",
                    "vfd_pd_am", "vfa_pd_am", "vfc_pd_am", "vfi_pd_am").distinct()

        price_rcmd_dtl_typ_df.createOrReplaceTempView("price_rcmd_dtl_typ")
        if debug == 1:
            DebugCount.count_check(price_rcmd_dtl_typ_df, "price_rcmd_dtl_typ_df")

        ppm_df = sql_context.sql("""select ppp.vyge_id as vyge_id
                                    ,ppp.version_start_date as version_start_date
                                    ,ppp.strm_typ_cd
                                    ,ppp.vyge_drtn_nght_cn
                                    ,ppp.vyge_drtn_nght_cn as sail_days
                                    ,coalesce(rmnd.non_comm_fare_am,ppp.non_comm_am) as non_comm_am
                                    ,coalesce(rmnd.vfd_pd_am,ppp.vfd_am) as vfd_am
                                    ,coalesce(rmnd.vfa_pd_am,ppp.vfa_extra_am) as vfa_am
                                    ,coalesce(rmnd.vfc_pd_am,ppp.vfc_extra_am) as vfc_am
                                    ,case when rmnd.strm_typ_cd is null then 1 else ppp.vyge_drtn_nght_cn
                                    end as rmnd_ind
                           from  price_rcmd_dtl_typ rmnd
                           right join ppp_subset_gtr_ntr ppp 
                           on rmnd.vyge_id = ppp.vyge_id  
                           and rmnd.version_start_date = ppp.version_start_date 
                           and rmnd.strm_typ_cd = ppp.strm_typ_cd """)

        proc_price_pt_df = ppm_df.join(opn_vyge_strm_typ_voyage_df, ["vyge_id", "version_start_date", "strm_typ_cd"],
                                       "left") \
            .join(vyge_fnc_fcst_metrics_df, ["vyge_id", "version_start_date"], "left") \
            .join(est_physical_inventory_cnt_df, ["vyge_id", "version_start_date", "strm_typ_cd"], "left") \
            .select(ppm_df.vyge_id, \
                    ppm_df.version_start_date, \
                    ppm_df.vyge_drtn_nght_cn, \
                    ppm_df.strm_typ_cd, \
                    ppm_df.sail_days, \
                    ppm_df.vfd_am, \
                    ppm_df.vfa_am, \
                    ppm_df.vfc_am, \
                    ppm_df.non_comm_am, \
                    coalesce(opn_vyge_strm_typ_voyage_df.ooo_strm_cn, lit(0)).alias("ooo_strm_cn"), \
                    "fcst_ship_ocpncy_pc_orig", \
                    "fcst_gst_per_strm_cn", \
                    "fcst_ooo_gst_per_strm_cn", \
                    "fcst_comm_pc_orig", \
                    "vyge_chld_split_pc", \
                    "vyge_adlt_split_pc", \
                    "phys_invtry_strm_cn", \
                    ppm_df.rmnd_ind)

        voyage_price_mod_vdf_cat_df = proc_price_pt_df.groupby("vyge_id", "version_start_date", "strm_typ_cd") \
            .agg(min("fcst_ship_ocpncy_pc_orig").alias("fcst_ship_ocpncy_pc_orig"), \
                 min("fcst_gst_per_strm_cn").alias("fcst_gst_per_strm_cn"), \
                 min("fcst_ooo_gst_per_strm_cn").alias("fcst_ooo_gst_per_strm_cn"), \
                 min("fcst_comm_pc_orig").alias("fcst_comm_pc_orig"), \
                 sum((((proc_price_pt_df.vfd_am + proc_price_pt_df.non_comm_am) * 2 * proc_price_pt_df.rmnd_ind)
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn)) +
                     (((
                                   proc_price_pt_df.vfa_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_adlt_split_pc * proc_price_pt_df.rmnd_ind) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2)) + \
                     (((
                                   proc_price_pt_df.vfc_am + proc_price_pt_df.non_comm_am) * proc_price_pt_df.vyge_chld_split_pc * proc_price_pt_df.rmnd_ind) \
                      * ((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.fcst_ship_ocpncy_pc_orig) \
                         - proc_price_pt_df.ooo_strm_cn) * (proc_price_pt_df.fcst_gst_per_strm_cn - 2))) \
                 .alias("gross_revenue"), \
                 sum((proc_price_pt_df.phys_invtry_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.fcst_ship_ocpncy_pc_orig - proc_price_pt_df.vyge_drtn_nght_cn \
                      * proc_price_pt_df.ooo_strm_cn) * proc_price_pt_df.fcst_gst_per_strm_cn + \
                     (
                                 proc_price_pt_df.ooo_strm_cn * proc_price_pt_df.vyge_drtn_nght_cn * proc_price_pt_df.fcst_ooo_gst_per_strm_cn)) \
                 .alias("gross_price_pd"))
        voyage_price_mod_vdf_cat_df.createOrReplaceTempView("compute_ppm_voyage")
        if debug == 1:
            DebugCount.count_check(voyage_price_mod_vdf_cat_df, "voyage_price_mod_vdf_cat_df")
        voyage_price_mod_vdf_cat_df.createOrReplaceTempView("compute_ppm_voyage")

        voyage_price_mod_vdf_summary = voyage_price_mod_vdf_cat_df.groupby("vyge_id", "version_start_date") \
            .agg((sum("gross_revenue") / sum("gross_price_pd")).cast(DecimalType(12, 2)) \
                 .alias("rcmd_gtr_price_pd_am"))
        voyage_price_mod_vdf_summary.createOrReplaceTempView("rcmd_gtr")

        rcmd_vyge_ntr_am_df = voyage_price_mod_vdf_summary \
            .join(voyage_price_mod_vdf_cat_df, ["vyge_id", "version_start_date"]) \
            .select(voyage_price_mod_vdf_summary.vyge_id, \
                    voyage_price_mod_vdf_summary.version_start_date, \
                    (voyage_price_mod_vdf_summary.rcmd_gtr_price_pd_am * \
                     (1 - (voyage_price_mod_vdf_cat_df.fcst_comm_pc_orig))).cast(DecimalType(12, 2)) \
                    .alias("rcmd_vyge_ntr_price_pd_am")).distinct()

        rcmd_vyge_ntr_am_df.createOrReplaceTempView("rcmd_vyge_ntr_am")
        rcmd_vyge_ntr_am_df.cache()
        if debug == 1:
            DebugCount.count_check(rcmd_vyge_ntr_am_df, "rcmd_vyge_ntr_am_df")

        expect_oh_bkng_filter = "upper(trim(lgcl_del_in)) = 'N' and dy_bef_vyge_cn = 0"
        expect_oh_bkng_df = data_loader.read_data("sha", "EXPECT_OH_BKNG").filter(expect_oh_bkng_filter)
        expect_oh_bkng_df.createOrReplaceTempView("expect_oh_bkng")
        expect_oh_bkng_max_df = final_driver_df2.join(expect_oh_bkng_df, ["app_vyge_id"]) \
            .filter("version_start_date >= expect_oh_bkng_run_dts") \
            .groupBy("vyge_id", "app_vyge_id", "ship_cd", "version_start_date") \
            .agg(max("expect_oh_bkng_run_dts").alias("expect_oh_bkng_run_dts"))
        expect_oh_bkng_final_df = expect_oh_bkng_max_df.join(expect_oh_bkng_df,
                                                             ["app_vyge_id", "expect_oh_bkng_run_dts"]) \
            .groupBy("vyge_id", "ship_cd", "version_start_date", "strm_typ_cd").agg(
            sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn"))

        expect_strm_typ_df = final_driver_df2.join(
            (strm_typ_nest_df_explode_df.select("strm_typ_cd", "strm_typ_nest_config_strt_dts", "ship_cd") \
             .join(expect_oh_bkng_final_df, ["strm_typ_cd", "ship_cd"], "left") \
             .filter("version_start_date >= date(strm_typ_nest_config_strt_dts)") \
             .select("strm_typ_cd", "ship_cd").dropDuplicates()), ["ship_cd"]) \
            .select("vyge_id", "version_start_date", "strm_typ_cd")

        expect_at_strm_df = expect_strm_typ_df.join(expect_oh_bkng_final_df,
                                                    ["vyge_id", "version_start_date", "strm_typ_cd"]) \
            .join(physical_inventory_cnt_df, ["vyge_id", "version_start_date"]) \
            .join(est_ooo_inventory_cnt_df.select("vyge_id", "ooo_strm_cn", "strm_typ_cd",
                                                  col("txn_dt").alias("version_start_date")),
                  ["vyge_id", "version_start_date", "strm_typ_cd"]) \
            .select("vyge_id", "version_start_date", "strm_typ_cd", "expect_oh_bkng_cn", "ooo_strm_cn",
                    "phys_invtry_strm_cn")

        expect_oh_metric_df = expect_at_strm_df.groupBy("vyge_id", "version_start_date") \
            .agg(sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn"), sum("ooo_strm_cn").alias("ooo_strm_cn"),
                 max("phys_invtry_strm_cn").alias("phys_invtry_cn"))

        est_ship_ocpncy_pc_df = expect_oh_metric_df \
            .withColumn("est_ship_ocpncy_pc", lit(((
                                                               expect_oh_metric_df.expect_oh_bkng_cn + expect_oh_metric_df.ooo_strm_cn) * 100) / expect_oh_metric_df.phys_invtry_cn).cast(
            DecimalType(12, 2)))

        if debug == 1:
            DebugCount.debug_counts(est_ship_ocpncy_pc_df, "est_ship_ocpncy_pc_df")

        uncnstrn_bkng_filter_clause = "dy_bef_vyge_cn = 1"

        uncnstrn_bkng_df = data_loader.read_data("sha", "UNCNSTRN_BKNG") \
            .filter(uncnstrn_bkng_filter_clause)

        # uncnstrn_bkng_df.createOrReplaceTempView("uncnstrn_bkng_tbl")
        #
        # vyge_baseln_UDF_COLS_max_sql = """
        #                            select vyge_id , drvr.version_start_date , udf_curr_price_am
        #                                ,UDF_AS_OF_DT_RCMD_PRICE_AM
        #                                ,UDF_RCMD_PRICE_AM,uncnstrn_bkng_run_dts,drvr.app_vyge_id
        #                            from  vyge_baseln_strm_typ drvr
        #                            inner JOIN uncnstrn_bkng_tbl as uncnstrn_bkng
        #                                ON drvr.app_vyge_id = uncnstrn_bkng.app_vyge_id
        #                                AND drvr.strm_typ_cd = uncnstrn_bkng.strm_typ_cd
        #                            WHERE uncnstrn_bkng.dy_bef_vyge_cn = 1"""

        # vyge_baseln_UDF_COLS_max_df = sql_context.sql(vyge_baseln_UDF_COLS_max_sql)

        # vyge_baseln_UDF_COLS_max_df.createOrReplaceTempView("vyge_baseln_UDF_COLS_max")
        # t60= time() - t59
        # print "vyge_baseln_UDF_COLS_max_df completed in %s seconds" %t60

        windowVal = Window.partitionBy("vyge_id", "strm_typ_cd", "sfb_nm").orderBy(col("uncnstrn_bkng_run_dts").asc())
        # filter just the needed strm_typ_cd and app_vyge_id
        distinct_vyge_df = final_driver_df2.select("app_vyge_id", "vyge_id").dropDuplicates()
        uncnstrn_bkng_filter_df = uncnstrn_bkng_df.filter("dy_bef_vyge_cn = 1").join(distinct_vyge_df, ["app_vyge_id"]) \
            .select("vyge_id", "udf_curr_price_am", "udf_as_of_dt_rcmd_price_am", "udf_rcmd_price_am", \
                    "uncnstrn_bkng_run_dts", "strm_typ_cd", "sfb_nm") \
            .withColumn("prev_udf_curr_price_am", lag('udf_curr_price_am').over(windowVal)) \
            .withColumn("prev_uncnstrn_bkng_run_dts", lag('uncnstrn_bkng_run_dts').over(windowVal))

        uncnstrn_bkng_max_df = uncnstrn_bkng_filter_df.join(final_driver_df2, ["vyge_id"]).filter( \
            "date(uncnstrn_bkng_run_dts) <= version_start_date") \
            .groupBy("vyge_id", "version_start_date", "ship_cd").agg(
            max("uncnstrn_bkng_run_dts").alias("uncnstrn_bkng_run_dts"))
        # join with unconstrain data to get values
        uncnstrn_bkng_final_df = uncnstrn_bkng_filter_df.join(uncnstrn_bkng_max_df,
                                                              ["vyge_id", "uncnstrn_bkng_run_dts"])
        uncnstrn_strm_typ_df = final_driver_df2.join(
            (strm_typ_nest_df_explode_df.select("strm_typ_cd", "strm_typ_nest_config_strt_dts", "ship_cd") \
             .join(uncnstrn_bkng_final_df, ["strm_typ_cd", "ship_cd"], "left") \
             .filter("version_start_date >= date(strm_typ_nest_config_strt_dts)") \
             .select("strm_typ_cd", "ship_cd").dropDuplicates()), ["ship_cd"]) \
            .select("vyge_id", "version_start_date", "strm_typ_cd")
        udf_df = uncnstrn_bkng_final_df.join(uncnstrn_strm_typ_df, ["vyge_id", "strm_typ_cd", "version_start_date"]) \
            .groupBy("vyge_id", "version_start_date", "prev_uncnstrn_bkng_run_dts", "uncnstrn_bkng_run_dts") \
            .agg(sum("udf_curr_price_am").alias("udf_curr_price_am"),
                 sum("udf_as_of_dt_rcmd_price_am").alias("udf_as_of_dt_rcmd_price_am"),
                 sum("udf_rcmd_price_am").alias("udf_rcmd_price_am"),
                 sum("prev_udf_curr_price_am").alias("prev_udf_curr_price_am"))

        udf_final_df = final_driver_df2.join(udf_df, ["vyge_id", "version_start_date"], "left") \
            .join(ship_cpcty_driver_df, ["vyge_id", "version_start_date"], "left") \
            .join(est_ship_ocpncy_pc_df, ["vyge_id", "version_start_date"], "left") \
            .select("vyge_id", "version_start_date", "est_ship_ocpncy_pc", "udf_curr_price_am", \
                    "udf_as_of_dt_rcmd_price_am", "udf_rcmd_price_am", "strm_cpcty_nb", "prev_udf_curr_price_am", \
                    "uncnstrn_bkng_run_dts", "prev_uncnstrn_bkng_run_dts")

        udf_final_df2 = udf_final_df.withColumn("udf_as_of_dt_rcmd_price_pc", \
                                                when(udf_final_df.strm_cpcty_nb == 0, 0) \
                                                .otherwise(
                                                    udf_final_df.udf_as_of_dt_rcmd_price_am * 100 / udf_final_df.strm_cpcty_nb)) \
            .withColumn("udf_rcmd_price_pc", \
                        when(udf_final_df.strm_cpcty_nb == 0, 0) \
                        .otherwise(udf_final_df.udf_rcmd_price_am * 100 / udf_final_df.strm_cpcty_nb)) \
            .withColumn("udf_curr_price_pc", \
                        when(udf_final_df.strm_cpcty_nb == 0, 0) \
                        .otherwise(udf_final_df.udf_curr_price_am * 100 / udf_final_df.strm_cpcty_nb)) \
            .withColumn("udf_curr_price_chng_am", \
                        (udf_final_df.udf_curr_price_am - udf_final_df.prev_udf_curr_price_am)) \
            .withColumn("btwn_uncnstrn_bkng_run_dy_cn", \
                        datediff(to_date(udf_final_df.uncnstrn_bkng_run_dts),
                                 to_date(udf_final_df.prev_uncnstrn_bkng_run_dts)))
        # strm_cpcty_nb_temp_df = sql_context.sql(strm_cpcty_nb_temp_sql)
        # strm_cpcty_nb_temp_df.show()

        # strm_cpcty_nb_temp_df.createOrReplaceTempView("strm_cpcty_nb_temp")

        # if debug == 1:
        #    DebugCount.debug_counts(strm_cpcty_nb_temp_df, "strm_cpcty_nb_temp")

        # strm_cpcty_nb_df = sql_context.sql(strm_cpcty_nb_sql)
        # strm_cpcty_nb_df.show()

        # strm_cpcty_nb_df.createOrReplaceTempView("strm_cpcty_nb")

        # if debug == 1:
        #    DebugCount.debug_counts(strm_cpcty_nb_df, "strm_cpcty_nb_tbl")

        age_res_baseln_metrics_df = final_driver_df2.join(vyge_baseln_age_mtrcs_df, ["vyge_id", "version_start_date"],
                                                          "left") \
            .join(vyge_res_baseln_metrics_df, ["vyge_id", "version_start_date"], "left") \
            .withColumn("curr_wk_pu_gtr_price_pd_am", when(vyge_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                                                           * final_driver_df2.vyge_drtn_nght_cn == 0, 0) \
                        .otherwise(vyge_res_baseln_metrics_df.curr_wk_pu_gtr_am \
                                   / when(vyge_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                                          * final_driver_df2.vyge_drtn_nght_cn == 0, None) \
                                   .otherwise(vyge_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                                              * final_driver_df2.vyge_drtn_nght_cn) \
                                   ).cast(DecimalType(12, 2))) \
            .withColumn("vyge_mn_dng_sl_lim_gst_pc", when(vyge_baseln_age_mtrcs_df.vyge_mn_dng_sl_lim_gst_cn == 0, 0) \
                        .otherwise((vyge_res_baseln_metrics_df.oh_bkng_mn_dng_gst_cn * 100.00).cast(DecimalType(12, 2)) \
                                   / (when(vyge_baseln_age_mtrcs_df.vyge_mn_dng_sl_lim_gst_cn == 0, None) \
                                      .otherwise(vyge_baseln_age_mtrcs_df.vyge_mn_dng_sl_lim_gst_cn)))) \
            .withColumn("vyge_sec_dng_sl_lim_gst_pc", when(vyge_baseln_age_mtrcs_df.vyge_sec_dng_sl_lim_gst_cn == 0, 0) \
                        .otherwise((vyge_res_baseln_metrics_df.oh_bkng_sec_dng_gst_cn * 100.00).cast(DecimalType(12, 2)) \
                                   / (when(vyge_baseln_age_mtrcs_df.vyge_sec_dng_sl_lim_gst_cn == 0, None) \
                                      .otherwise(vyge_baseln_age_mtrcs_df.vyge_sec_dng_sl_lim_gst_cn)))) \
            .withColumn("vyge_ifnt_lim_gst_pc", when(vyge_baseln_age_mtrcs_df.vyge_ifnt_lim_gst_cn == 0, 0) \
                        .otherwise((vyge_res_baseln_metrics_df.oh_bkng_ifnt_gst_cn * 100.00) \
                                   / (when(vyge_baseln_age_mtrcs_df.vyge_ifnt_lim_gst_cn == 0, None) \
                                      .otherwise(vyge_baseln_age_mtrcs_df.vyge_ifnt_lim_gst_cn))).cast(
            DecimalType(7, 2))) \
            .withColumn("vyge_avail_bkng_ifnt_gst_cn", (vyge_baseln_age_mtrcs_df.vyge_ifnt_lim_gst_cn \
                                                        - vyge_res_baseln_metrics_df.oh_bkng_ifnt_gst_cn)) \
            .withColumn("vyge_chld_lim_gst_pc", when(vyge_baseln_age_mtrcs_df.vyge_chld_lim_gst_cn == 0, 0) \
                        .otherwise((vyge_res_baseln_metrics_df.oh_bkng_chld_gst_cn * 100.00) \
                                   / (when(vyge_baseln_age_mtrcs_df.vyge_chld_lim_gst_cn == 0, None) \
                                      .otherwise(vyge_baseln_age_mtrcs_df.vyge_chld_lim_gst_cn))).cast(
            DecimalType(7, 2))) \
            .withColumn("vyge_avail_bkng_chld_gst_cn", (vyge_baseln_age_mtrcs_df.vyge_chld_lim_gst_cn \
                                                        - vyge_res_baseln_metrics_df.oh_bkng_chld_gst_cn)) \
            .withColumn("vyge_lim_gst_pc", when(vyge_baseln_age_mtrcs_df.vyge_lim_gst_cn == 0, 0) \
                        .otherwise((vyge_res_baseln_metrics_df.oh_bkng_gst_cn * 100.00) \
                                   / (when(vyge_baseln_age_mtrcs_df.vyge_lim_gst_cn == 0, None) \
                                      .otherwise(vyge_baseln_age_mtrcs_df.vyge_lim_gst_cn))).cast(DecimalType(7, 2))) \
            .withColumn("vyge_avail_bkng_tot_gst_cn", (vyge_baseln_age_mtrcs_df.vyge_lim_gst_cn \
                                                       - vyge_res_baseln_metrics_df.oh_bkng_gst_cn))

        age_res_baseln_metrics_df = age_res_baseln_metrics_df.coalesce(100)
        age_res_baseln_metrics_df.cache()
        print
        "age_res_baseln_metrics_df count is %s" % age_res_baseln_metrics_df.count()

        vyge_strm_typ_dly_df = data_loader.read_data_from_path("con/vyge_strm_typ_dly_est_metrics")

        est_rev_df = final_driver_df2.join(vyge_strm_typ_dly_df, \
                                           (final_driver_df2.vyge_id == vyge_strm_typ_dly_df.vyge_id) \
                                           & (final_driver_df2.version_start_date == vyge_strm_typ_dly_df.txn_dt) \
                                           , "left_outer") \
            .groupby(final_driver_df2.vyge_id \
                     , final_driver_df2.version_start_date) \
            .agg(sum(vyge_strm_typ_dly_df.est_vyge_tkt_rev_am).alias("est_vyge_tkt_rev_am") \
                 , sum(vyge_strm_typ_dly_df.est_vyge_gtr_remn_am).alias("est_vyge_gtr_remn_am") \
                 , sum(vyge_strm_typ_dly_df.est_vyge_ntr_remn_am).alias("est_vyge_ntr_remn_am"))

        sub_query_df = final_driver_df2.join(est_rev_df, \
                                             ["vyge_id", "version_start_date"], "left_outer") \
            .join(vyge_fnc_fcst_var_df, \
                  (final_driver_df2.ship_cd == vyge_fnc_fcst_var_df.ship_cd) \
                  & (final_driver_df2.vyge_dprt_dt == vyge_fnc_fcst_var_df.vyge_strt_dt) \
                  & (vyge_fnc_fcst_var_df.VRSN_END_DTS == '9999-12-31 00:00:00.000000'), "left_outer") \
            .join(dflt_ship_fnc_fcst_df, \
                  (dflt_ship_fnc_fcst_df.ship_cd == final_driver_df2.ship_cd) \
                  & (dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_strt_dts.cast("date") \
                     <= final_driver_df2.version_start_date) \
                  & (dflt_ship_fnc_fcst_df.dflt_ship_fnc_fcst_end_dts.cast("date") > \
                     final_driver_df2.version_start_date) \
                  , "left_outer") \
            .join(physical_inventory_cnt_df, ["vyge_id", "version_start_date"], "left_outer") \
            .join(ooo_inventory_cnt_df, (final_driver_df2.vyge_id == ooo_inventory_cnt_df.vyge_id) \
                  & (final_driver_df2.version_start_date == ooo_inventory_cnt_df.txn_dt), "left_outer") \
            .join(vyge_res_baseln_metrics_df, ["vyge_id", "version_start_date"], "left_outer") \
            .withColumn("est_vyge_gtr_am", (est_rev_df.est_vyge_gtr_remn_am) + (vyge_res_baseln_metrics_df.gtr_am)) \
            .withColumn("est_psng_crus_dy_cn",
                        ((coalesce(final_driver_df2.vyge_drtn_nght_cn, lit("0").cast("integer")) * \
                          (coalesce(vyge_fnc_fcst_var_df.fcst_gst_per_strm_cn,
                                    dflt_ship_fnc_fcst_df.fcst_gst_per_strm_cn)) * \
                          (coalesce(physical_inventory_cnt_df.phys_invtry_strm_cn, lit("0").cast("integer")) - \
                           coalesce(vyge_res_baseln_metrics_df.oh_bkng_cn, lit("0").cast("integer")) \
                           )) \
                         - \
                         (coalesce(vyge_fnc_fcst_var_df.fcst_ship_ocpncy_pc,
                                   dflt_ship_fnc_fcst_df.fcst_ship_ocpncy_pc) * \
                          coalesce(physical_inventory_cnt_df.phys_invtry_strm_cn, lit("0").cast("integer"))) \
                         + \
                         (coalesce(final_driver_df2.vyge_drtn_nght_cn, lit("0").cast("integer")) * \
                          coalesce(vyge_fnc_fcst_var_df.fcst_ooo_gst_per_strm_cn,
                                   dflt_ship_fnc_fcst_df.fcst_ooo_gst_per_strm_cn) * \
                          coalesce(ooo_inventory_cnt_df.ooo_strm_cn, lit("0").cast("integer"))) \
                         + \
                         (coalesce(vyge_res_baseln_metrics_df.oh_bkng_gst_cn, lit("0").cast("integer")) * coalesce(
                             final_driver_df2.vyge_drtn_nght_cn, lit("0").cast("integer"))) \
                         ).cast(DecimalType(12, 2))) \
            .withColumn("est_vyge_ntr_am", \
                        ((est_rev_df.est_vyge_gtr_remn_am) * \
                         ( \
                                     1 - (
                                 coalesce(vyge_fnc_fcst_var_df.fcst_comm_pc, dflt_ship_fnc_fcst_df.fcst_comm_pc)) \
                             ) + \
                         (vyge_res_baseln_metrics_df.ntr_am).cast(DecimalType(12, 2)))) \
            .select(final_driver_df2.vyge_id, final_driver_df2.version_start_date, \
                    "est_vyge_gtr_am", "est_vyge_ntr_remn_am", "est_vyge_gtr_remn_am", "est_psng_crus_dy_cn",
                    "est_vyge_ntr_am").distinct()

        vyge_est_rev_metrics_df = sub_query_df.withColumn("est_vyge_grs_pd_am", \
                                                          when(sub_query_df.est_psng_crus_dy_cn == lit("0").cast(
                                                              "integer"), None) \
                                                          .otherwise(
                                                              (coalesce(sub_query_df.est_vyge_gtr_remn_am, lit("0") \
                                                                        .cast("integer")) \
                                                               + coalesce(sub_query_df.est_vyge_gtr_am, lit("0") \
                                                                          .cast("integer"))) / (
                                                                  sub_query_df.est_psng_crus_dy_cn))) \
            .withColumn("est_vyge_net_pd_am", \
                        when(sub_query_df.est_psng_crus_dy_cn == lit("0").cast("integer"), None) \
                        .otherwise((coalesce(sub_query_df.est_vyge_ntr_remn_am, lit("0").cast("integer")) \
                                    + coalesce(sub_query_df.est_vyge_ntr_am, lit("0").cast("integer"))) / (
                                       sub_query_df.est_psng_crus_dy_cn)))

        sub_merge_1_df = final_driver_df2.join(vyge_fnc_fcst_metrics_df, ["vyge_id", "version_start_date"], "left") \
            .join(physical_inventory_cnt_df, ["vyge_id", "version_start_date"], "left") \
            .join(vyge_baseln_stop_sl_in_df, ["vyge_id", "version_start_date"], "left") \
            .join(ooo_inventory_cnt_df, (final_driver_df2.vyge_id == ooo_inventory_cnt_df.vyge_id) \
                  & (final_driver_df2.version_start_date == ooo_inventory_cnt_df.txn_dt), "left") \
            .join(alloc_counts_df, ["vyge_id", "version_start_date"], "left") \
            .join(age_res_baseln_metrics_df, ["vyge_id", "version_start_date"], "left") \
            .select(final_driver_df2.version_start_date, \
                    final_driver_df2.vyge_id, \
                    "cncl_bkng_cn", \
                    "oh_bkng_cn", \
                    "pu_bkng_cn", \
                    "oh_asgn_bkng_cn", \
                    "grs_paid_bkng_cn", \
                    "oh_asgn_bkng_gst_cn", \
                    "oh_bkng_gst_cn", \
                    "oh_bkng_adlt_gst_cn", \
                    "oh_bkng_chld_gst_cn", \
                    "oh_bkng_mn_dng_gst_cn", \
                    "oh_bkng_sec_dng_gst_cn", \
                    "oh_bkng_ifnt_gst_cn", \
                    "pu_bkng_adlt_gst_cn", \
                    "pu_bkng_chld_gst_cn", \
                    "pu_bkng_ifnt_gst_cn", \
                    "cncl_bkng_adlt_gst_cn", \
                    "cncl_bkng_chld_gst_cn", \
                    "cncl_bkng_ifnt_gst_cn", \
                    "gtr_am", \
                    "ntr_am", \
                    "comm_am", \
                    "non_comm_am", \
                    "dvc_oh_bkng_cn", \
                    "obo_oh_bkng_cn", \
                    "prevl_oh_bkng_cn", \
                    "promo_oh_bkng_cn", \
                    "irgs_oh_bkng_cn", \
                    "other_oh_bkng_cn", \
                    "pu_bkng_gst_cn", \
                    "pu_mn_dng_gst_cn", \
                    "pu_sec_dng_gst_cn", \
                    "dvc_pu_bkng_cn", \
                    "obo_pu_bkng_cn", \
                    "prevl_pu_bkng_cn", \
                    "promo_pu_bkng_cn", \
                    "irgs_pu_bkng_cn", \
                    "other_pu_bkng_cn", \
                    "pu_gtr_am", \
                    "pu_ntr_am", \
                    "curr_wk_oh_bkng_gst_cn", \
                    "curr_wk_pu_bkng_gst_cn", \
                    "promo_oh_bkng_pc", \
                    "oh_bkng_avg_gps_vl", \
                    "alloc_grp_bkng_cn", \
                    "alloc_grp_gst_cn", \
                    "unalloc_grp_bkng_cn", \
                    "unalloc_grp_gst_cn", \
                    "paid_adlt_gst_cn", \
                    "paid_bkng_cn", \
                    "paid_bkng_gst_cn", \
                    "asgn_bkng_cn", \
                    "asgn_bkng_gst_cn", \
                    "curr_wk_pu_gtr_price_pd_am", \
                    "curr_wk_pu_bkng_adlt_gst_cn", \
                    "curr_wk_pu_bkng_chld_gst_cn", \
                    "curr_wk_pu_bkng_ifnt_gst_cn", \
                    "curr_wk_pu_mn_dng_gst_cn", \
                    "curr_wk_pu_sec_dng_gst_cn", \
                    "curr_wk_pu_gtr_am", \
                    "curr_wk_pu_ntr_am", \
                    "curr_wk_pu_bkng_cn", \
                    "curr_wk_dvc_pu_bkng_cn", \
                    "curr_wk_obo_pu_bkng_cn", \
                    "curr_wk_prevl_pu_bkng_cn", \
                    "curr_wk_promo_pu_bkng_cn", \
                    "curr_wk_irgs_oh_bkng_cn", \
                    "curr_wk_irgs_pu_bkng_cn", \
                    "curr_wk_other_pu_bkng_cn", \
                    "phys_invtry_strm_cn", \
                    "chld_min_age_nb", \
                    "chld_max_age_nb", \
                    "ifnt_min_age_nb", \
                    "ifnt_max_age_nb", \
                    "vyge_mn_dng_sl_lim_gst_cn", \
                    "vyge_mn_dng_sl_lim_gst_pc", \
                    "vyge_sec_dng_sl_lim_gst_cn", \
                    "vyge_sec_dng_sl_lim_gst_pc", \
                    "vyge_ifnt_lim_gst_cn", \
                    "vyge_ifnt_lim_gst_pc", \
                    "vyge_avail_bkng_ifnt_gst_cn", \
                    "vyge_chld_lim_gst_cn", \
                    "vyge_chld_lim_gst_pc", \
                    "vyge_avail_bkng_chld_gst_cn", \
                    "vyge_lim_gst_cn", \
                    "vyge_lim_gst_pc", \
                    "vyge_avail_bkng_tot_gst_cn", \
                    "vyge_ifnt_stop_sl_in", \
                    "vyge_chld_stop_sl_in", \
                    "vyge_tot_stop_sl_in", \
                    "ooo_strm_cn", \
                    when(physical_inventory_cnt_df.phys_invtry_strm_cn == 0, 0) \
                    .otherwise(coalesce(
                        (((age_res_baseln_metrics_df.curr_wk_pu_bkng_cn + ooo_inventory_cnt_df.ooo_strm_cn) * 100.00) \
                         / (when(physical_inventory_cnt_df.phys_invtry_strm_cn == 0, None) \
                            .otherwise(physical_inventory_cnt_df.phys_invtry_strm_cn))), lit(0))) \
                    .cast(DecimalType(9, 2)).alias("curr_wk_pu_ocpncy_pc"), \
                    coalesce((physical_inventory_cnt_df.phys_invtry_strm_cn \
                              - ooo_inventory_cnt_df.ooo_strm_cn \
                              - alloc_counts_df.paid_bkng_cn), lit(0)).alias("avail_strm_cn"), \
                    when(age_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                         * final_driver_df2.vyge_drtn_nght_cn == 0, 0) \
                    .otherwise((age_res_baseln_metrics_df.curr_wk_pu_ntr_am) \
                               / (when(age_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                                       * final_driver_df2.vyge_drtn_nght_cn == 0, None) \
                                  .otherwise(age_res_baseln_metrics_df.curr_wk_pu_bkng_gst_cn \
                                             * final_driver_df2.vyge_drtn_nght_cn))) \
                    .cast(DecimalType(12, 2)).alias("curr_wk_pu_ntr_price_pd_am"), \
                    when(physical_inventory_cnt_df.phys_invtry_strm_cn == 0, 0) \
                    .otherwise(coalesce(((alloc_counts_df.paid_bkng_cn \
                                          + ooo_inventory_cnt_df.ooo_strm_cn) * 100.00) / (
                                            when(physical_inventory_cnt_df.phys_invtry_strm_cn == 0, None) \
                                            .otherwise(physical_inventory_cnt_df.phys_invtry_strm_cn)), lit(0))) \
                    .cast(DecimalType(9, 2)).alias("ship_ocpncy_pc"), \
                    when(age_res_baseln_metrics_df.gtr_am == 0, 0) \
                    .otherwise((age_res_baseln_metrics_df.comm_am * 100.00) \
                               / (when(age_res_baseln_metrics_df.gtr_am == 0, None) \
                                  .otherwise(age_res_baseln_metrics_df.gtr_am))) \
                    .cast(DecimalType(7, 2)).alias("comm_pc"), \
                    coalesce((age_res_baseln_metrics_df.oh_bkng_gst_cn \
                              * final_driver_df2.vyge_drtn_nght_cn), lit(0)).alias("psng_crus_dy_cn"), \
                    "fcst_vyge_grs_rev_am", \
                    (vyge_fnc_fcst_metrics_df.fcst_vyge_grs_rev_am \
                     - age_res_baseln_metrics_df.gtr_am) \
                    .alias("fcst_vyge_grs_rev_remn_am"), \
                    "fcst_vyge_net_rev_am", \
                    (vyge_fnc_fcst_metrics_df.fcst_vyge_net_rev_am \
                     - age_res_baseln_metrics_df.ntr_am).alias("fcst_vyge_net_rev_remn_am"), \
                    "fcst_comm_pc", \
                    "fcst_vyge_avg_price_per_dy_am", \
                    "fcst_vyge_net_price_per_dy_am", \
                    "fcst_gst_per_strm_cn", \
                    "fcst_ooo_gst_per_strm_cn", \
                    "fcst_ship_ocpncy_pc")

        sub_merge_1_df.cache()
        print
        "sub_merge_1_df count is %s" % sub_merge_1_df.count()
        sub_merge_1_df.createOrReplaceTempView("sub_merge_1")
        # debug = 1
        if debug == 1:
            DebugCount.count_check(sub_merge_1_df, "sub_merge_1_df")
        # print "sub_merge_1_df count is %s" %sub_merge_1_df.count()

        sub_merge_2_df = final_driver_df2 \
            .join(vyge_baseln_strm_typ_prevl_df, ["vyge_id", "version_start_date"], "left") \
            .join(mstr_vyge_drvr_df, ["vyge_id", "version_start_date"], "left") \
            .join(dt_dprt_df, ["vyge_id", "version_start_date"], "left") \
            .join(dt_arvl_df, ["vyge_id", "version_start_date"], "left") \
            .join(dt_prev_df, ["vyge_id", "version_start_date"], "left") \
            .join(expect_rev_metrics_df, ["vyge_id", "version_start_date"], "left") \
            .join(est_opn_vyge_strm_typ_voyage_df, ["vyge_id", "version_start_date"], "left") \
            .join(res_baseln_curr_wk_driver_df, ["vyge_id", "version_start_date"], "left") \
            .select(final_driver_df2.vyge_id, \
                    final_driver_df2.version_start_date, \
                    final_driver_df2.ship_cd, \
                    "vyge_opn_dt", \
                    "vyge_dprt_dt", \
                    "vyge_drtn_nght_cn", \
                    "vyge_arvl_dt", \
                    "vyge_itnry_nm", \
                    "orig_vyge_itnry_nm", \
                    final_driver_df2.app_vyge_id, \
                    "vyge_dprt_seapt_cd", \
                    "ship_nm", \
                    "ship_short_nm", \
                    "ship_cls_nm", \
                    "ship_lfboat_cpcty_cn", \
                    "ship_max_chld_cn", \
                    "curr_wk_promo_oh_bkng_cn", \
                    "curr_wk_other_oh_bkng_cn", \
                    "curr_wk_dvc_oh_bkng_cn", \
                    "curr_wk_obo_oh_bkng_cn", \
                    "curr_wk_prevl_oh_bkng_cn", \
                    "strm_typ_prevl_price_diff_am", \
                    "fnl_pmt_dt", \
                    "vyge_fscl_yr_nb", \
                    "vyge_dprt_qtr_nb", \
                    "curr_yr_fscl_wk_nb", \
                    "curr_yr_fscl_wk_strt_dt", \
                    "curr_yr_fscl_wk_end_dt", \
                    "vyge_fscl_mo_nb", \
                    "dprt_dt_wk_dy_nb", \
                    "arvl_dt_wk_dy_nb", \
                    "prev_yr_fscl_wk_nb", \
                    "prev_yr_fscl_wk_strt_dt", \
                    "prev_yr_fscl_wk_end_dt", \
                    "est_ooo_strm_cn", \
                    "expect_rev_am", \
                    "expect_rev_run_dts")

        sub_merge_2_df.cache()
        # print "sub_merge_2_df count is %s" %sub_merge_2_df.count()
        sub_merge_2_df.createOrReplaceTempView("sub_merge_2")
        if debug == 1:
            DebugCount.count_check(sub_merge_2_df, "sub_merge_2_df")
        # print "sub_merge_2_df count is %s" %sub_merge_2_df.count()

        sub_merge_3_df = final_driver_df2.join(udf_final_df2, ["vyge_id", "version_start_date"], "left") \
            .join(price_md_dt_tbl_df, ["vyge_id", "version_start_date"], "left") \
            .join(gtr_ntr_amts_df, ["vyge_id", "version_start_date"], "left") \
            .join(opn_gtr_ntr_amts_df, ["vyge_id", "version_start_date"], "left") \
            .join(rcmd_vyge_ntr_am_df, ["vyge_id", "version_start_date"], "left") \
            .select(final_driver_df2.version_start_date \
                    , final_driver_df2.vyge_id \
                    , "price_mod_dt" \
                    , "est_ship_ocpncy_pc" \
                    , "udf_curr_price_am" \
                    , "udf_as_of_dt_rcmd_price_am" \
                    , "udf_rcmd_price_am" \
                    , "udf_as_of_dt_rcmd_price_pc" \
                    , "udf_curr_price_pc" \
                    , "udf_rcmd_price_pc" \
                    , "udf_curr_price_chng_am" \
                    , "btwn_uncnstrn_bkng_run_dy_cn" \
                    , "gtr_price_pd_am" \
                    , "ntr_price_pd_am" \
                    , "opn_gtr_price_pd_am" \
                    , "opn_ntr_price_pd_am" \
                    , "rcmd_vyge_ntr_price_pd_am" \
                    , (rcmd_vyge_ntr_am_df.rcmd_vyge_ntr_price_pd_am \
                       - gtr_ntr_amts_df.ntr_price_pd_am).alias("ntr_price_pd_chng_am"))

        sub_merge_3_df.cache()
        print
        "sub_merge_3_df count is %s" % sub_merge_3_df.count()
        sub_merge_3_df.createOrReplaceTempView("sub_merge_3")
        if debug == 1:
            DebugCount.count_check(sub_merge_3_df, "sub_merge_3_df")
        # print "sub_merge_3_df count is %s" %sub_merge_3_df.count()

        """Final TD Export"""
        final_export_df = sub_merge_1_df.join(sub_merge_2_df, ["version_start_date", "vyge_id"]) \
            .join(sub_merge_3_df, ["version_start_date", "vyge_id"]) \
            .join(vyge_est_rev_metrics_df, ["version_start_date", "vyge_id"]) \
            .select(sub_merge_1_df.vyge_id, \
                    concat(sub_merge_1_df.version_start_date, lit(' 04:00:00')).cast("timestamp").alias(
                        "vrsn_strt_dts"), \
                    lit('9999-12-31 04:00:00.000000').cast("timestamp").alias("vrsn_end_dts"), \
                    "ship_nm", \
                    "ship_cd", \
                    "ship_short_nm", \
                    "ship_cls_nm", \
                    "vyge_dprt_dt", \
                    "vyge_arvl_dt", \
                    "vyge_drtn_nght_cn", \
                    "vyge_dprt_seapt_cd", \
                    "vyge_itnry_nm", \
                    "vyge_opn_dt", \
                    "fnl_pmt_dt", \
                    "price_mod_dt", \
                    "ship_lfboat_cpcty_cn", \
                    "vyge_fscl_yr_nb", \
                    "vyge_dprt_qtr_nb", \
                    "curr_yr_fscl_wk_nb", \
                    "prev_yr_fscl_wk_nb", \
                    "curr_yr_fscl_wk_strt_dt", \
                    "curr_yr_fscl_wk_end_dt", \
                    "prev_yr_fscl_wk_strt_dt", \
                    "prev_yr_fscl_wk_end_dt", \
                    "dprt_dt_wk_dy_nb", \
                    "arvl_dt_wk_dy_nb", \
                    "phys_invtry_strm_cn", \
                    "ooo_strm_cn", \
                    "avail_strm_cn", \
                    "ship_ocpncy_pc", \
                    vyge_est_rev_metrics_df.est_psng_crus_dy_cn, \
                    "pu_bkng_cn", \
                    "asgn_bkng_cn", \
                    "cncl_bkng_cn", \
                    "paid_bkng_cn", \
                    "grs_paid_bkng_cn", \
                    "oh_bkng_cn", \
                    "oh_asgn_bkng_cn", \
                    "promo_oh_bkng_pc", \
                    "alloc_grp_bkng_cn", \
                    "unalloc_grp_bkng_cn", \
                    "oh_asgn_bkng_gst_cn", \
                    "alloc_grp_gst_cn", \
                    "unalloc_grp_gst_cn", \
                    "asgn_bkng_gst_cn", \
                    "oh_bkng_gst_cn", \
                    "oh_bkng_adlt_gst_cn", \
                    "oh_bkng_chld_gst_cn", \
                    "oh_bkng_ifnt_gst_cn", \
                    "pu_bkng_adlt_gst_cn", \
                    "pu_bkng_chld_gst_cn", \
                    "pu_bkng_ifnt_gst_cn", \
                    "cncl_bkng_adlt_gst_cn", \
                    "cncl_bkng_chld_gst_cn", \
                    "cncl_bkng_ifnt_gst_cn", \
                    "oh_bkng_avg_gps_vl", \
                    when(sub_merge_1_df.psng_crus_dy_cn == 0, 0) \
                    .otherwise(sub_merge_1_df.gtr_am / (when(sub_merge_1_df.psng_crus_dy_cn == 0, None) \
                                                        .otherwise(sub_merge_1_df.psng_crus_dy_cn))) \
                    .cast(DecimalType(12, 2)).alias("gtr_pd_am"), \
                    when(sub_merge_1_df.psng_crus_dy_cn == 0, 0) \
                    .otherwise(sub_merge_1_df.ntr_am / (when(sub_merge_1_df.psng_crus_dy_cn == 0, None) \
                                                        .otherwise(sub_merge_1_df.psng_crus_dy_cn))) \
                    .cast(DecimalType(12, 2)).alias("ntr_pd_am"), \
                    when(sub_merge_1_df.avail_strm_cn == 0, 0) \
                    .otherwise(coalesce(((sub_merge_2_df.ship_lfboat_cpcty_cn \
                                          - sub_merge_1_df.oh_bkng_gst_cn - sub_merge_1_df.alloc_grp_gst_cn \
                                          - sub_merge_1_df.unalloc_grp_gst_cn) * 1.00000 \
                                         / (when(sub_merge_1_df.avail_strm_cn == 0, None).otherwise(
                                sub_merge_1_df.avail_strm_cn))) \
                                        , lit(0))).cast(DecimalType(12, 5)).alias("gps_remn_vl"), \
                    when(sub_merge_1_df.avail_strm_cn == 0, 0).otherwise(coalesce((( \
                                                                                               sub_merge_2_df.ship_max_chld_cn - sub_merge_1_df.oh_bkng_chld_gst_cn) \
                                                                                   * 1.00000 / (when(
                                sub_merge_1_df.avail_strm_cn == 0, None) \
                                                                                                .otherwise(
                                sub_merge_1_df.avail_strm_cn))), lit(0))) \
                    .cast(DecimalType(12, 5)).alias("kps_remn_vl"), \
                    "oh_bkng_mn_dng_gst_cn", \
                    "oh_bkng_sec_dng_gst_cn", \
                    "opn_gtr_price_pd_am", \
                    "opn_ntr_price_pd_am", \
                    "gtr_am", \
                    "gtr_price_pd_am", \
                    "ntr_am", \
                    "ntr_price_pd_am", \
                    "comm_am", \
                    "comm_pc", \
                    "non_comm_am", \
                    "fcst_vyge_grs_rev_am", \
                    "fcst_vyge_net_rev_am", \
                    "fcst_vyge_grs_rev_remn_am", \
                    "fcst_vyge_net_rev_remn_am", \
                    "fcst_comm_pc", \
                    "fcst_vyge_avg_price_per_dy_am", \
                    "fcst_vyge_net_price_per_dy_am", \
                    "fcst_gst_per_strm_cn", \
                    "fcst_ooo_gst_per_strm_cn", \
                    "fcst_ship_ocpncy_pc", \
                    vyge_est_rev_metrics_df.est_vyge_gtr_am, \
                    vyge_est_rev_metrics_df.est_vyge_gtr_remn_am, \
                    vyge_est_rev_metrics_df.est_vyge_grs_pd_am, \
                    vyge_est_rev_metrics_df.est_vyge_ntr_am, \
                    vyge_est_rev_metrics_df.est_vyge_ntr_remn_am, \
                    vyge_est_rev_metrics_df.est_vyge_net_pd_am, \
                    "vyge_lim_gst_cn", \
                    "vyge_lim_gst_pc", \
                    "vyge_chld_lim_gst_cn", \
                    "vyge_chld_lim_gst_pc", \
                    "vyge_ifnt_lim_gst_cn", \
                    "vyge_ifnt_lim_gst_pc", \
                    "vyge_mn_dng_sl_lim_gst_cn", \
                    "vyge_mn_dng_sl_lim_gst_pc", \
                    "vyge_sec_dng_sl_lim_gst_cn", \
                    "vyge_sec_dng_sl_lim_gst_pc", \
                    "dvc_oh_bkng_cn", \
                    "obo_oh_bkng_cn", \
                    "prevl_oh_bkng_cn", \
                    "promo_oh_bkng_cn", \
                    "irgs_oh_bkng_cn", \
                    "other_oh_bkng_cn", \
                    "app_vyge_id", \
                    "rcmd_vyge_ntr_price_pd_am", \
                    "ntr_price_pd_chng_am", \
                    when(sub_merge_3_df.ntr_price_pd_chng_am.isNull(), None) \
                    .when(sub_merge_3_df.ntr_price_pd_am == 0, 0) \
                    .otherwise((sub_merge_3_df.ntr_price_pd_chng_am * 100.00) / sub_merge_3_df.ntr_price_pd_am) \
                    .cast(DecimalType(12, 2)).alias("ntr_price_pd_chng_pc"), \
                    "est_ship_ocpncy_pc", \
                    "udf_curr_price_am", \
                    "udf_as_of_dt_rcmd_price_am", \
                    "udf_rcmd_price_am", \
                    "curr_wk_dvc_oh_bkng_cn", \
                    "curr_wk_irgs_oh_bkng_cn", \
                    "curr_wk_obo_oh_bkng_cn", \
                    "curr_wk_oh_bkng_gst_cn", \
                    "curr_wk_pu_ocpncy_pc", \
                    "curr_wk_pu_bkng_gst_cn", \
                    "curr_wk_pu_bkng_adlt_gst_cn", \
                    "curr_wk_pu_bkng_chld_gst_cn", \
                    "curr_wk_pu_bkng_ifnt_gst_cn", \
                    "curr_wk_pu_mn_dng_gst_cn", \
                    "curr_wk_pu_sec_dng_gst_cn", \
                    "curr_wk_pu_gtr_am", \
                    "curr_wk_pu_ntr_am", \
                    "curr_wk_pu_ntr_price_pd_am", \
                    "curr_wk_prevl_oh_bkng_cn", \
                    "curr_wk_promo_oh_bkng_cn", \
                    "curr_wk_other_oh_bkng_cn", \
                    "curr_wk_pu_bkng_cn", \
                    "psng_crus_dy_cn", \
                    "udf_as_of_dt_rcmd_price_pc", \
                    "udf_curr_price_pc", \
                    "udf_rcmd_price_pc", \
                    "vyge_avail_bkng_tot_gst_cn", \
                    "vyge_avail_bkng_chld_gst_cn", \
                    "vyge_avail_bkng_ifnt_gst_cn", \
                    "chld_min_age_nb", \
                    "chld_max_age_nb", \
                    "ifnt_min_age_nb", \
                    "ifnt_max_age_nb", \
                    "vyge_ifnt_stop_sl_in", \
                    "vyge_chld_stop_sl_in", \
                    "vyge_tot_stop_sl_in", \
                    "curr_wk_pu_gtr_price_pd_am", \
                    "strm_typ_prevl_price_diff_am", \
                    "vyge_fscl_mo_nb", \
                    "est_ooo_strm_cn", \
                    "orig_vyge_itnry_nm", \
                    "curr_wk_dvc_pu_bkng_cn", \
                    "curr_wk_obo_pu_bkng_cn", \
                    "curr_wk_prevl_pu_bkng_cn", \
                    "curr_wk_promo_pu_bkng_cn", \
                    "curr_wk_irgs_pu_bkng_cn", \
                    "curr_wk_other_pu_bkng_cn", \
                    "paid_bkng_gst_cn", \
                    "paid_adlt_gst_cn", \
                    "udf_curr_price_chng_am", \
                    "btwn_uncnstrn_bkng_run_dy_cn", \
                    "expect_rev_am", \
                    "expect_rev_run_dts")
        # final_export_df.show()
        if debug == 1:
            DebugCount.count_check(final_export_df, "final_export")
        folder_name = "%s%s" % ("vyge_baseln/partition_dt=", end_dt)
        data_loader.write_data("dm", folder_name, None, final_export_df)


import sys, os
from os import path

from pyspark import sql
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import col, asc
from pyspark.sql.functions import *

sys.path.append((path.dirname(path.dirname(path.abspath(__file__)))))

from framework.utils.DebugCount import *;
from vygestrmctgydly.VygeStrmCtgDlyNtrGTR import *;
from vygestrmctgydly.VygeStrmCtgDlyPriceModDt import *;
from vygestrmctgydly.VygeStrmCtgDlyResBaselnCons import *;
from vygestrmctgydly.VygeStrmCtgDlySlCounts import *;
class VygeStrmCtgyDlyDriver(object):


    #(self.start_date, self.end_date, self.spark, self.s3_root_bucket,self.data_loader,self.debug)
    @staticmethod
    def run_vyge_strm_ctgy_dly_Driver(start_dt, end_dt, sql_context, s3_bucket, data_loader,runType,debug):
        print("run_vyge_strm_ctgy_dly_Driver Process ")
        #VygeStrmCtgyDlyDriver.run_vyge_strm_ctgy_dly_Driver(self.start_date, self.end_date, self.spark, self.s3_root_bucket,self.data_loader,self.runType,self.debug)
        print("start_dt==>",start_dt)
        print("end_dt==>",end_dt )
        print("SparkContext==>",sql_context)
        print("s3_bucket==>",s3_bucket)
        print("data_laoder==>",data_loader)
        print("runtype===>",runType)
        print("debug==>",debug)
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################


        ################################################################################
        # Merge ship_strm_typ_df and ship_strm_typ_ext_df on ship_cd and typ_cd to     #
        # populate ship category names for the corresponding ship category type codes  #
        ################################################################################

        vyge_df = sql_context.sql("select * from vyge")
        vyge_attr_df = sql_context.sql("select * from vyge_attr") \
            .select(col("vyge_id").alias("vyge_id_tmp"),
                    "txn_dt",
                    "ship_cd",
                    "vyge_arvl_dt",
                    "vyge_opn_dt",
                    "vyge_dprt_dt",
                    "vyge_init_bkng_dt",
                    "vrsn_strt_dts",
                    "vrsn_end_dts").distinct()
        print("  vyge_attr_df count====>> ",vyge_attr_df.count());
        #
        # ('  vyge_attr_df count====>> ', 30040)
        # == == == == == == == = >> txn_driver_df <<= == == == == ==
        # ('count ==>', 30039)

        ship_feat_df = sql_context.sql("select * from ship_feat")
        app_vyge_xref_df = sql_context.sql("select * from app_vyge_xref")
        txn_driver_df = vyge_df.join(vyge_attr_df, (vyge_df.vyge_id == vyge_attr_df.vyge_id_tmp) \
                                     & (vyge_attr_df.txn_dt >= to_date(vyge_df.vrsn_strt_dts)) \
                                     & (vyge_attr_df.txn_dt < to_date(vyge_df.vrsn_end_dts))) \
            .join(ship_feat_df, (vyge_df.ship_cd == ship_feat_df.ship_cd)) \
            .join(app_vyge_xref_df, (vyge_df.vyge_id == app_vyge_xref_df.vyge_id)) \
            .select(vyge_df.vyge_id, \
                    vyge_attr_df.txn_dt, \
                    vyge_df.ship_cd, \
                    ship_feat_df.ship_nm, \
                    ship_feat_df.ship_short_nm, \
                    ship_feat_df.ship_cls_nm, \
                    vyge_df.vyge_dprt_dt, \
                    vyge_df.vyge_arvl_dt, \
                    vyge_df.vyge_drtn_nght_cn, \
                    vyge_df.vyge_dprt_seapt_cd, \
                    vyge_df.vyge_itnry_nm, \
                    app_vyge_xref_df.app_vyge_id, \
                    vyge_df.orig_vyge_itnry_nm) \
            .withColumn("dy_bef_vyge_cn", when((vyge_df.vyge_dprt_dt == "") | (vyge_attr_df.txn_dt == ""), lit("")) \
                        .otherwise(datediff(to_date(vyge_df.vyge_dprt_dt), vyge_attr_df.txn_dt))) \
            .dropDuplicates()
        print("===============>> txn_driver_df <<===========")
        print("count ==>",txn_driver_df.count())
        txn_driver_df.printSchema()
        txn_driver_df.cache()
        if debug == 1:
            DebugCount.debug_counts(txn_driver_df, "txn_driver")

        ship_strm_strm_typ1_df = sql_context.sql("select * from ship_strm_strm_typ1").distinct()
        ship_strm_typ_ext1_df = sql_context.sql("select * from ship_strm_typ_ext1").distinct()

        ship_strm_strm_typ_txn_df = ship_strm_strm_typ1_df.join(txn_driver_df,
                                                                (
                                                                            txn_driver_df.ship_cd == ship_strm_strm_typ1_df.ship_cd) \
                                                                & (txn_driver_df.txn_dt >= to_date(
                                                                    ship_strm_strm_typ1_df.shp_vrsn_strt_dts)) \
                                                                & (txn_driver_df.txn_dt < to_date(
                                                                    ship_strm_strm_typ1_df.shp_vrsn_end_dts))) \
            .select(ship_strm_strm_typ1_df.ship_cd, \
                    ship_strm_strm_typ1_df.ship_strm_strm_end_dts, \
                    ship_strm_strm_typ1_df.ship_strm_nb, \
                    ship_strm_strm_typ1_df.strm_typ_cd, \
                    txn_driver_df.txn_dt, \
                    ship_strm_strm_typ1_df.shp_vrsn_strt_dts.alias("vrsn_strt_dts"), \
                    ship_strm_strm_typ1_df.shp_vrsn_end_dts.alias("vrsn_end_dts"), \
                    ship_strm_strm_typ1_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ1_df.strm_cpcty_nb).distinct()
        ship_strm_strm_typ_txn_df.createOrReplaceTempView("ship_strm_strm_typ_vw")

        if debug == 1:
            DebugCount.debug_counts(ship_strm_strm_typ_txn_df, "ship_strm_strm_typ_txn")

        ship_strm_typ_ext_txn_df = ship_strm_typ_ext1_df.join(txn_driver_df,
                                                              (txn_driver_df.ship_cd == ship_strm_typ_ext1_df.ship_cd) \
                                                              & (txn_driver_df.txn_dt >= to_date(
                                                                  ship_strm_typ_ext1_df.ext_vrsn_strt_dts)) \
                                                              & (txn_driver_df.txn_dt < to_date(
                                                                  ship_strm_typ_ext1_df.ext_vrsn_end_dts)) \
                                                              & (ship_strm_typ_ext1_df.ship_ctgy_nm != "")) \
            .select(ship_strm_typ_ext1_df.ship_cd, \
                    ship_strm_typ_ext1_df.ship_strm_typ_cd, \
                    ship_strm_typ_ext1_df.ship_ctgy_nm, \
                    txn_driver_df.txn_dt, \
                    ship_strm_typ_ext1_df.ext_vrsn_strt_dts.alias("vrsn_strt_dts"), \
                    ship_strm_typ_ext1_df.ext_vrsn_end_dts.alias("vrsn_end_dts")).distinct()
        ship_strm_typ_ext_txn_df.createOrReplaceTempView("ship_strm_typ_ext_vw")

        if debug == 1:
            DebugCount.debug_counts(ship_strm_typ_ext_txn_df, "ship_strm_typ_ext_txn")


        ship_strm_strm_typ_ext_df = ship_strm_strm_typ_txn_df.join(ship_strm_typ_ext_txn_df, \
                                                                   (
                                                                           ship_strm_typ_ext_txn_df.ship_strm_typ_cd == ship_strm_strm_typ_txn_df.strm_typ_cd) \
                                                                   & (
                                                                           ship_strm_typ_ext_txn_df.ship_cd == ship_strm_strm_typ_txn_df.ship_cd) \
                                                                   & (
                                                                           ship_strm_typ_ext_txn_df.txn_dt == ship_strm_strm_typ_txn_df.txn_dt)) \
            .select(ship_strm_typ_ext_txn_df.ship_cd, \
                    ship_strm_typ_ext_txn_df.txn_dt, \
                    ship_strm_typ_ext_txn_df.ship_ctgy_nm, \
                    ship_strm_strm_typ_txn_df.strm_cpcty_nb, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_end_dts).distinct()

        if debug == 1:
            DebugCount.debug_counts(ship_strm_strm_typ_ext_df, "ship_strm_strm_typ_ext")

        vyge_attr_shp_ctgy_nm_df = ship_strm_strm_typ_ext_df.join(vyge_attr_df, \
                                                                  (
                                                                          vyge_attr_df.ship_cd == ship_strm_strm_typ_ext_df.ship_cd) \
                                                                  & (
                                                                          vyge_attr_df.txn_dt == ship_strm_strm_typ_ext_df.txn_dt) \
                                                                  & (vyge_attr_df.vyge_dprt_dt < to_date(
                                                                      ship_strm_strm_typ_ext_df.ship_strm_strm_end_dts)) \
                                                                  & (vyge_attr_df.vyge_dprt_dt >= to_date(
                                                                      ship_strm_strm_typ_ext_df.ship_strm_strm_strt_dts))) \
            .select(vyge_attr_df.vyge_id_tmp, \
                    vyge_attr_df.txn_dt, \
                    ship_strm_strm_typ_ext_df.strm_cpcty_nb, \
                    ship_strm_strm_typ_ext_df.ship_ctgy_nm, \
                    ship_strm_strm_typ_ext_df.ship_cd).distinct()

        if debug == 1:
            DebugCount.debug_counts(vyge_attr_shp_ctgy_nm_df, "vyge_attr_shp_ctgy_nm")

        price_rcmd_dtl_df = sql_context.sql("select * from price_rcmd_dtl ")
        uncnstrn_bkng_df = sql_context.sql("select * from uncnstrn_bkng ")

        price_rcmd_dtl_max_df = price_rcmd_dtl_df.groupBy("app_vyge_id").agg(
            max("price_rcmd_run_dts").alias("price_rcmd_run_dts_max")).distinct()

        if debug == 1:
            DebugCount.debug_counts(price_rcmd_dtl_max_df, "price_rcmd_dtl_max")

        uncnstrn_bkng_max_df = uncnstrn_bkng_df.groupBy("app_vyge_id").agg(
            max("uncnstrn_bkng_run_dts").alias("uncnstrn_bkng_run_dts_max")).distinct()

        if debug == 1:
            DebugCount.debug_counts(uncnstrn_bkng_max_df, "uncnstrn_bkng_max_df")

        vyge_strm_typ_drvr_temp_df = txn_driver_df.join(vyge_attr_shp_ctgy_nm_df,
                                                        (txn_driver_df.ship_cd == vyge_attr_shp_ctgy_nm_df.ship_cd) \
                                                        & (
                                                                    txn_driver_df.vyge_id == vyge_attr_shp_ctgy_nm_df.vyge_id_tmp) \
                                                        & (txn_driver_df.txn_dt == vyge_attr_shp_ctgy_nm_df.txn_dt)) \
            .select(txn_driver_df.vyge_id, \
                    vyge_attr_shp_ctgy_nm_df.ship_ctgy_nm, \
                    txn_driver_df.txn_dt, \
                    txn_driver_df.ship_cd, \
                    txn_driver_df.ship_nm, \
                    txn_driver_df.ship_short_nm, \
                    txn_driver_df.ship_cls_nm, \
                    txn_driver_df.vyge_dprt_dt, \
                    txn_driver_df.vyge_arvl_dt, \
                    txn_driver_df.vyge_drtn_nght_cn, \
                    txn_driver_df.dy_bef_vyge_cn, \
                    txn_driver_df.vyge_dprt_seapt_cd, \
                    txn_driver_df.vyge_itnry_nm, \
                    txn_driver_df.app_vyge_id, \
                    txn_driver_df.orig_vyge_itnry_nm).distinct()
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_temp_df, "vyge_strm_typ_drvr_temp")

        vyge_strm_typ_drvr_wk_txn_df = vyge_strm_typ_drvr_temp_df.join(price_rcmd_dtl_max_df, "app_vyge_id",
                                                                       "left_outer") \
            .join(uncnstrn_bkng_max_df, "app_vyge_id", "left_outer") \
            .select(vyge_strm_typ_drvr_temp_df.vyge_id, \
                    vyge_strm_typ_drvr_temp_df.ship_ctgy_nm, \
                    vyge_strm_typ_drvr_temp_df.txn_dt, \
                    vyge_strm_typ_drvr_temp_df.ship_cd, \
                    vyge_strm_typ_drvr_temp_df.ship_nm, \
                    vyge_strm_typ_drvr_temp_df.ship_short_nm, \
                    vyge_strm_typ_drvr_temp_df.ship_cls_nm, \
                    vyge_strm_typ_drvr_temp_df.vyge_dprt_dt, \
                    vyge_strm_typ_drvr_temp_df.vyge_arvl_dt, \
                    vyge_strm_typ_drvr_temp_df.vyge_drtn_nght_cn, \
                    vyge_strm_typ_drvr_temp_df.dy_bef_vyge_cn, \
                    vyge_strm_typ_drvr_temp_df.vyge_dprt_seapt_cd, \
                    vyge_strm_typ_drvr_temp_df.vyge_itnry_nm, \
                    vyge_strm_typ_drvr_temp_df.app_vyge_id, \
                    vyge_strm_typ_drvr_temp_df.orig_vyge_itnry_nm, \
                    price_rcmd_dtl_max_df.price_rcmd_run_dts_max, \
                    uncnstrn_bkng_max_df.uncnstrn_bkng_run_dts_max) \
            .dropDuplicates()
        vyge_strm_typ_drvr_wk_txn_df = vyge_strm_typ_drvr_wk_txn_df.withColumnRenamed("ship_ctgy_nm", "strm_ctgy_nm")
        vyge_strm_typ_drvr_wk_txn_df.createOrReplaceTempView("vyge_strm_typ_drvr_wk_txn_vw")

        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_wk_txn_df, "vyge_strm_typ_drvr_wk_txn_vw")
        # vyge_strm_typ_drvr_wk_txn_df.agg(min("txn_dt").alias("min_txn_dt"),max("txn_dt").alias("max_txn_dt")).show()
        cnt = vyge_strm_typ_drvr_wk_txn_df.count()
        print
        " count of records of vyge_strm_typ_drvr_wk_txn_df program : %s " % cnt

        filter_txn_clause = "txn_dt >= date('%s') and txn_dt <= date('%s')" % (start_dt, end_dt)

        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_wk_txn_df.filter(filter_txn_clause)
        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_df.withColumnRenamed("strm_ctgy_nm", "ship_strm_ctgy_nm")
        vyge_strm_typ_drvr_df.printSchema()
        vyge_strm_typ_drvr_df.show()
        vyge_strm_typ_drvr_df.createOrReplaceTempView("driver")
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_drvr_df, "driver")

        cnt = vyge_strm_typ_drvr_df.count()
        print(" count of records of driver program : %s " % cnt)

        folder_name = "%s%s" % ("vyge_strm_typ_drvr_df/partition_dt=", end_dt)
        print("******** floder_name=%s" % folder_name)
        data_loader.write_data("dm",folder_name,None,vyge_strm_typ_drvr_df)
        # vyge_strm_typ_drvr_df.agg(min("txn_dt").alias("min_txn_dt"),max("txn_dt").alias("max_txn_dt")).show()
        print("******** floder_name=%s" % folder_name)
        print(" ******************** Loading of vyge_strm_ctgy_dly into hdfs started ************************** ")
        #VygeStrmCtgDlyResBaselnCons.run_con_resbaseln(start_dt, end_dt, runType, sql_context, s3_bucket,data_loader,debug)
        opn_vyge_strm_typ_config_df = sql_context.read.format("orc").load(
            "/wdpr-apps-data/dclrms/works/opn_vyge_strm_typ_config/data/")
        opn_vyge_strm_typ_config_df.createOrReplaceTempView("opn_vyge_strm_typ_config")

        ship_strm_typ_ext_df = sql_context.sql("SELECT * FROM ship_strm_typ_ext")
        ship_strm_strm_typ_df1 = sql_context.sql("SELECT * FROM ship_strm_strm_typ1");

        vyge_strm_ctgy_dly_strm_typ = vyge_strm_typ_drvr_df.join(ship_strm_typ_ext_df, (
                vyge_strm_typ_drvr_df.ship_cd == ship_strm_typ_ext_df.ship_cd) \
                                                                 & (
                                                                         vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm) \
                                                                 & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
            ship_strm_typ_ext_df.ext_vrsn_strt_dts)) \
                                                                 & (vyge_strm_typ_drvr_df.txn_dt < to_date(
            ship_strm_typ_ext_df.ext_vrsn_end_dts))) \
            .join(ship_strm_strm_typ_df1, \
                  (ship_strm_strm_typ_df1.strm_typ_cd == ship_strm_typ_ext_df.ship_strm_typ_cd) \
                  & (vyge_strm_typ_drvr_df.ship_cd == ship_strm_strm_typ_df1.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(ship_strm_strm_typ_df1.ship_strm_strm_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(ship_strm_strm_typ_df1.ship_strm_strm_end_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                  ).join(opn_vyge_strm_typ_config_df, \
                         (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                             opn_vyge_strm_typ_config_df.vyge_strm_typ_config_strt_dts)) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                             opn_vyge_strm_typ_config_df.vyge_strm_typ_config_end_dts)) \
                         & (vyge_strm_typ_drvr_df.ship_cd == opn_vyge_strm_typ_config_df.ship_cd) \
                         & (ship_strm_strm_typ_df1.strm_typ_cd == opn_vyge_strm_typ_config_df.strm_typ_cd) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                         , "leftouter").select(vyge_strm_typ_drvr_df.vyge_id, ship_strm_typ_ext_df.ship_strm_typ_cd, \
                                               vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, vyge_strm_typ_drvr_df.txn_dt,
                                               opn_vyge_strm_typ_config_df.strm_typ_cd,
                                               opn_vyge_strm_typ_config_df.ooo_strm_cn)

        vyge_strm_ctgy_dly_strm_typ_driver = vyge_strm_ctgy_dly_strm_typ.select("vyge_id", "ship_strm_typ_cd",
                                                                                "ship_strm_ctgy_nm", "txn_dt",
                                                                                "ooo_strm_cn").groupBy("vyge_id",
                                                                                                       "ship_strm_typ_cd",
                                                                                                       "ship_strm_ctgy_nm",
                                                                                                       "txn_dt").agg(
            (sum("ooo_strm_cn").alias("ooo_strm_cn_sum")))

        vyge_strm_ctgy_dly_strm_typ_driver.createOrReplaceTempView("vyge_strm_ctgy_strm_typ_cd_driver")

        expect_oh_bkng_vw_df = sql_context.sql("select * from expect_oh_bkng_vw")

        # expect_oh_bkng_cn_df = vyge_strm_typ_drvr_df.join(expect_oh_bkng_vw_df, \
        #                                                   (
        #                                                           vyge_strm_typ_drvr_df.app_vyge_id == expect_oh_bkng_vw_df.app_vyge_id) \
        #                                                   & (
        #                                                           vyge_strm_typ_drvr_df.strm_typ_cd == expect_oh_bkng_vw_df.strm_typ_cd) \
        #                                                   & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
        #                                                       expect_oh_bkng_vw_df.expect_oh_bkng_run_dts)) \
        #                                                   & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
        #                                                       expect_oh_bkng_vw_df.asofdate)), "left_outer") \
        #     .select(vyge_strm_typ_drvr_df.vyge_id, \
        #             vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
        #             vyge_strm_typ_drvr_df.txn_dt, \
        #             expect_oh_bkng_vw_df.expect_oh_bkng_cn) \
        #     .groupBy("vyge_id", \
        #              "ship_strm_ctgy_nm", \
        #              "txn_dt") \
        #     .agg(sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn")) \
        #     .dropDuplicates()
        #
        # expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_vw")


        # expect_oh_bkng_cn_df = sql_context.sql("""
        #     			select distinct
        #     			drvr.vyge_id,
        #     			drvr.ship_strm_ctgy_nm,
        #     			drvr.txn_dt,
        #     			sum(oh_bkng_vw.expect_oh_bkng_cn) as expect_oh_bkng_cn
        #     			from driver drvr
        #     			left join expect_oh_bkng_vw oh_bkng_vw
        #     			on drvr.app_vyge_id = oh_bkng_vw.app_vyge_id
        #     			and drvr.txn_dt >= date(oh_bkng_vw.expect_oh_bkng_run_dts)
        #     			and drvr.txn_dt >= date(oh_bkng_vw.asofdate)
        #     			group by 1,2,3
        #     			""")
        # expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_vw")
        # if debug == 1:
        #     DebugCount.debug_counts(expect_oh_bkng_cn_df, "expect_oh_bkng_cn_vw")

        # udf_price_am_df = sql_context.sql(
        #     """
        #             SELECT driver.vyge_id,
        #                 driver.ship_strm_ctgy_nm,
        #                 driver.txn_dt,
        #                 SUM(uncnstrn_bkng.udf_curr_price_am) as udf_curr_price_am,
        #                 SUM(uncnstrn_bkng.udf_as_of_dt_rcmd_price_am) as udf_as_of_dt_rcmd_price_am,
        #                 SUM(uncnstrn_bkng.udf_rcmd_price_am) as udf_rcmd_price_am
        #             FROM driver driver LEFT JOIN uncnstrn_bkng uncnstrn_bkng
        #             ON driver.txn_dt >= date(driver.uncnstrn_bkng_run_dts_max)
        #                 AND driver.uncnstrn_bkng_run_dts_max = uncnstrn_bkng.uncnstrn_bkng_run_dts
        #                 AND  driver.app_vyge_id = uncnstrn_bkng.app_vyge_id
        #                 AND  driver.strm_typ_cd = uncnstrn_bkng.strm_typ_cd
        #                 AND  uncnstrn_bkng.dy_bef_vyge_cn = 1
        #             GROUP BY 1,2,3
        #                  """).dropDuplicates()
        # udf_price_am_df.createOrReplaceTempView("udf_price_am_vw")

        ##########################################################
        #              UDF CALCULATION METRCIS STARTED           #
        ##########################################################

        # udf_price_am_df = vyge_strm_typ_drvr_df.join(uncnstrn_bkng_df, \
        #                                              (vyge_strm_typ_drvr_df.app_vyge_id == uncnstrn_bkng_df.app_vyge_id) \
        #                                              & (
        #                                                          vyge_strm_typ_drvr_df.strm_typ_cd == uncnstrn_bkng_df.strm_typ_cd) \
        #                                              & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
        #                                                  vyge_strm_typ_drvr_df.uncnstrn_bkng_run_dts_max)) \
        #                                              & (
        #                                                      vyge_strm_typ_drvr_df.uncnstrn_bkng_run_dts_max == uncnstrn_bkng_df.uncnstrn_bkng_run_dts) \
        #                                              & (uncnstrn_bkng_df.dy_bef_vyge_cn == 1), "left_outer") \
        #     .select(vyge_strm_typ_drvr_df.vyge_id, \
        #             vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
        #             vyge_strm_typ_drvr_df.txn_dt, \
        #             uncnstrn_bkng_df.udf_curr_price_am, \
        #             uncnstrn_bkng_df.udf_as_of_dt_rcmd_price_am, \
        #             uncnstrn_bkng_df.udf_rcmd_price_am) \
        #     .groupBy("vyge_id", "ship_strm_ctgy_nm", "txn_dt") \
        #     .agg(sum("udf_curr_price_am") \
        #          .alias("udf_curr_price_am"), sum("udf_as_of_dt_rcmd_price_am") \
        #          .alias("udf_as_of_dt_rcmd_price_am"), sum("udf_rcmd_price_am") \
        #          .alias("udf_rcmd_price_am"))
        # udf_price_am_df.createOrReplaceTempView("udf_price_am_vw")
        # if debug == 1:
        #     DebugCount.debug_counts(udf_price_am_df, "udf_price_am_vw")

        strm_typ_nest_config_df = sql_context.sql(" select * from strm_typ_nest_config ")
        filter_clause = " UPPER(strm_typ_nest_grp_nm) = 'SHIPSCI' \
        					AND UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM') "
        strm_typ_nest_confg_df = strm_typ_nest_config_df.filter(filter_clause) \
            .select("ship_cd", \
                    "strm_typ_nest_grp_nm", \
                    "src_sys_strm_typ_nm") \
            .dropDuplicates()

        strm_typ_nest_config_split_df = strm_typ_nest_confg_df.withColumn("strm_typ_cd", explode(
            split(strm_typ_nest_confg_df.src_sys_strm_typ_nm, "[;]"))) \
            .select("ship_cd", "strm_typ_nest_grp_nm", "strm_typ_cd").distinct()

        if debug == 1:
            #debug_counts(strm_typ_nest_config_split_df, "strm_typ_nest_config_split_vw")

        ship_strm_nest_config_temp_df = ship_strm_strm_typ_txn_df.join(strm_typ_nest_config_split_df,
                                                                       ["ship_cd", "strm_typ_cd"]) \
            .select(ship_strm_strm_typ_txn_df.ship_cd, \
                    ship_strm_strm_typ_txn_df.strm_typ_cd.alias("strm_typ_cd_alias"), \
                    ship_strm_strm_typ_txn_df.txn_dt, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_strt_dts, \
                    ship_strm_strm_typ_txn_df.ship_strm_strm_end_dts, \
                    ship_strm_strm_typ_txn_df.strm_cpcty_nb) \
            .dropDuplicates()

        strm_cpcty_nb_df = vyge_strm_typ_drvr_df.join(vyge_strm_ctgy_dly_strm_typ_driver, \
                                                      (
                                                              vyge_strm_ctgy_dly_strm_typ_driver.SHIP_STRM_CTGY_NM == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                                                      & (vyge_strm_ctgy_dly_strm_typ_driver.TXN_DT == vyge_strm_typ_drvr_df.txn_dt) \
                                                      ).join(ship_strm_nest_config_temp_df, \
                                                             (vyge_strm_typ_drvr_df.ship_cd == ship_strm_nest_config_temp_df.ship_cd) \
                                                             & (vyge_strm_ctgy_dly_strm_typ_driver.strm_typ_cd == ship_strm_nest_config_temp_df.strm_typ_cd_alias) \
                                                             & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(
                                                                 ship_strm_nest_config_temp_df.ship_strm_strm_strt_dts)) \
                                                             & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(
                                                                 ship_strm_nest_config_temp_df.ship_strm_strm_end_dts)),
                                                             "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.ship_cd, \
                    ship_strm_nest_config_temp_df.strm_cpcty_nb) \
            .groupBy("vyge_id", \
                     "ship_strm_ctgy_nm", \
                     "ship_cd",\
                     "txn_dt") \
            .agg(sum("strm_cpcty_nb").alias("strm_cpcty_nb_sum")) \
            .dropDuplicates()

        strm_cpcty_nb_df.createOrReplaceTempView("strm_cpcty_nb_vw")

        if debug == 1:
            #debug_counts(strm_cpcty_nb_df, "strm_cpcty_nb_vw")


        # strm_typ_nest_confg_df = sql_context.sql("""
        #     						SELECT ship_cd,
        #     							strm_typ_nest_grp_nm,
        #     							src_sys_strm_typ_nm
        #     						FROM strm_typ_nest_config
        #     						WHERE UPPER(strm_typ_nest_grp_nm) = 'SHIPSCI'
        #     						AND UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM')
        #     						""").dropDuplicates()
        # strm_typ_nest_confg_df.printSchema();
        # strm_typ_nest_confg_df.show();
        #
        # strm_typ_nest_config_split_df = strm_typ_nest_confg_df.withColumn("strm_typ_cd", explode(
        #     split(strm_typ_nest_confg_df.src_sys_strm_typ_nm, "[;]"))) \
        #     .select("ship_cd", "strm_typ_nest_grp_nm", "strm_typ_cd").dropDuplicates()
        #
        # strm_typ_nest_config_split_df.createOrReplaceTempView("strm_typ_nest_config_split_vw")
        #
        # if debug == 1:
        #     DebugCount.debug_counts(strm_typ_nest_config_split_df, "strm_typ_nest_config_split_vw")
        #
        # strm_cpcty_nb_df = sql_context.sql("""
        #     			SELECT
        #     				driver.vyge_id,
        #     				driver.ship_strm_ctgy_nm,
        #     				driver.txn_dt,
        #                     SUM(ship_strm_strm_typ.strm_cpcty_nb) as strm_cpcty_nb_sum
        #                     FROM strm_typ_nest_config_split_vw strm_nst_confg_vw inner join ship_strm_strm_typ1 ship_strm_strm_typ
        #                     ON ship_strm_strm_typ.ship_cd = strm_nst_confg_vw.ship_cd
        #                     AND  ship_strm_strm_typ.strm_typ_cd = strm_nst_confg_vw.strm_typ_cd
        #                     inner join driver
        #                     ON driver.ship_cd=ship_strm_strm_typ.ship_cd
        #                     and driver.vyge_dprt_dt >= date(ship_strm_strm_typ.ship_strm_strm_strt_dts)
        #                     and driver.vyge_dprt_dt < date(ship_strm_strm_typ.ship_strm_strm_end_dts)
        #                     and driver.txn_dt  >= ship_strm_strm_typ.shp_vrsn_strt_dts
        #                     and driver.txn_dt < ship_strm_strm_typ.shp_vrsn_end_dts
        #                     GROUP BY driver.vyge_id,
        #                              driver.ship_strm_ctgy_nm,
        #                              driver.txn_dt
        #
        #                     """).dropDuplicates()
        #
        # strm_cpcty_nb_df.createOrReplaceTempView("strm_cpcty_nb_vw")
        # strm_cpcty_nb_df.printSchema();
        # strm_cpcty_nb_df.show();
        #
        # if debug == 1:
        #     DebugCount.debug_counts(strm_cpcty_nb_df, "strm_cpcty_nb_vw")

        # udf_price_am_pc_df = sql_context.sql("""
        #
        #     		SELECT distinct
        #     			driver.vyge_id,
        #     			driver.ship_strm_ctgy_nm,
        #     			driver.txn_dt as txn_date,
        #     			udf_price_am_vw.udf_curr_price_am,
        #     			udf_price_am_vw.udf_as_of_dt_rcmd_price_am,
        #     			udf_price_am_vw.udf_rcmd_price_am,
        #     			ROUND((udf_price_am_vw.udf_curr_price_am / strm_cpcty_nb_vw.strm_cpcty_nb_sum) * 100,2)  as udf_curr_price_pc ,
        #     			ROUND((udf_price_am_vw.udf_as_of_dt_rcmd_price_am / strm_cpcty_nb_vw.strm_cpcty_nb_sum) * 100,2) as udf_as_of_dt_rcmd_price_pc,
        #     			ROUND((udf_price_am_vw.udf_rcmd_price_am / strm_cpcty_nb_vw.strm_cpcty_nb_sum) * 100,2) as udf_rcmd_price_pc
        #     		FROM driver LEFT JOIN udf_price_am_vw
        #     		ON 	driver.vyge_id = udf_price_am_vw.vyge_id
        #     		AND 	driver.ship_strm_ctgy_nm = udf_price_am_vw.ship_strm_ctgy_nm
        #     		AND	driver.txn_dt = udf_price_am_vw.txn_dt
        #     		LEFT JOIN strm_cpcty_nb_vw
        #     		ON 	driver.vyge_id = strm_cpcty_nb_vw.vyge_id
        #     		AND	driver.ship_strm_ctgy_nm = strm_cpcty_nb_vw.ship_strm_ctgy_nm
        #     		AND	driver.txn_dt = strm_cpcty_nb_vw.txn_dt
        #     		""")

        # udf_price_am_pc_df.createOrReplaceTempView("udf_price_am_pc_vw")
        # udf_price_am_pc_df.printSchema();
        # udf_price_am_pc_df.show();

        #if debug == 1:
            #DebugCount.debug_counts(udf_price_am_pc_df, "udf_price_am_pc_vw")
        # udf_price_am_pc_df.select("udf_curr_price_am","udf_as_of_dt_rcmd_price_am","udf_rcmd_price_am","udf_curr_price_pc",
        # "udf_as_of_dt_rcmd_price_pc","udf_rcmd_price_pc ").distinct().show()
        # udf_price_am_pc_df.filter("vyge_id = 147006 and strm_typ_cd = '10A'").show()
        ###################################################
        #        UDF CALCULATION METRICS ENDED            #
        ###################################################

        print(" END OF DRIVER ")

        vyge_strm_typ_dly_sci_rcmd_df = sql_context.sql(""" 
                		select 
                			scl_rcmd_vw.vyge_id,
                			scl_rcmd_vw.ship_strm_ctgy_nm,
                			scl_rcmd_vw.txn_dt,   
                			case
                				when max_price_rcmd_run_dts is null and max_sl_lim_rcmd_run_dts is null then null  
                				when max_price_rcmd_run_dts is null and max_sl_lim_rcmd_run_dts is not null then 'Selling Limit'  
                				when max_price_rcmd_run_dts is not null and  max_sl_lim_rcmd_run_dts is null then 'Pricing' 
                				when max_price_rcmd_run_dts >= max_sl_lim_rcmd_run_dts then 'Pricing'
                				when max_price_rcmd_run_dts < max_sl_lim_rcmd_run_dts then 'Selling Limit'
                			end as sci_rcmd_typ_nm
                		from 	
                			(select 
                				drvr.vyge_id,
                				drvr.app_vyge_id,
                				drvr.ship_strm_ctgy_nm,
                				drvr.txn_dt,
                				max(prc.price_rcmd_run_dts) as max_price_rcmd_run_dts,
                				max(sl_lm.sl_lim_rcmd_run_dts) as max_sl_lim_rcmd_run_dts		
                			from driver drvr
                			left join (select distinct 
                						app_vyge_id,
                						price_rcmd_run_dts,
                						asofdate from  price_rcmd_dtl) prc
                			on drvr.app_vyge_id = prc.app_vyge_id 
                			and drvr.txn_dt >=  prc.price_rcmd_run_dts 
                			and drvr.txn_dt >= prc.asofdate 	
                			left join (select distinct 
                						app_vyge_id,
                						sl_lim_rcmd_run_dts, 
                						asofdate from  sl_lim_rcmd) sl_lm
                			on drvr.app_vyge_id = sl_lm.app_vyge_id
                			and drvr.txn_dt >= sl_lm.sl_lim_rcmd_run_dts
                			and drvr.txn_dt >= sl_lm.asofdate
                			group by 1,2,3,4) scl_rcmd_vw
                			""").dropDuplicates()

        vyge_strm_typ_dly_sci_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_sci_rcmd_vw")
        vyge_strm_typ_dly_sci_rcmd_df.printSchema();
        vyge_strm_typ_dly_sci_rcmd_df.show();

        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_sci_rcmd_df, "vyge_strm_typ_dly_sci_rcmd_vw")

        ship_filter = " strm_typ_cd NOT IN ( 'IGT', 'OGT', 'VGT', 'XAM','GTY', 'IRG' ) and UPPER(instnc_st_nm) = 'STANDARD' "
        print("ship_strm_typ_filter", ship_filter)
        ship_strm_strm_df = data_loader.read_data("dm", "SHIP_STRM_STRM_TYP").filter(ship_filter)
        # ship_strm_strm_df.printSchema();
        ship_strm_strm_df.createOrReplaceTempView("ship_strm_strm_typ")

        # print("Done Before ops")
        vyge_txn_dt_df = sql_context.sql(""" select distinct driver.vyge_id,driver.ship_strm_ctgy_nm,driver.ship_cd ,driver.vyge_dprt_dt,driver.txn_dt
                        FROM driver as driver        """)

        vyge_txn_dt_df.createOrReplaceTempView("vyge_txn_dt_df");



        # wrk_vyge_strm_ctgy_dly_strm_df = sql_context.sql(
        #     """
        #         SELECT
        #                 VYGE_ID,
        #                 SHIP_STRM_CTGY_NM,
        #                 SHIP_STRM_TYP_CD,
        #                 TXN_DT,
        #                 SUM(COALESCE(OOO_STRM_CN,0)) over (partition by VYGE_ID,SHIP_STRM_CTGY_NM,txn_dt ) AS OOO_STRM_CN,
        #                 SUM(COALESCE(OOO_STRM_CN,0)) over (partition by VYGE_ID,SHIP_STRM_TYP_CD,txn_dt ) AS OOO_STRM_CN_STRM
        #                 FROM (
        #                 SELECT
        #                 DRV.VYGE_ID
        #                 ,DRV.SHIP_STRM_CTGY_NM
        #                 ,DRV.TXN_DT
        #                 ,STRM.SHIP_STRM_TYP_CD
        #                 ,OVSTC.STRM_TYP_CD
        #                 ,OOO_STRM_CN
        #                 FROM driver as DRV
        #                 INNER JOIN
        #                 (
        #                 SELECT
        #                 SHIP_CD,
        #                 SHIP_STRM_TYP_CD,
        #                 CASE WHEN SHIP_STRM_TYP_CD ='GTY' THEN 'Guaranteed'
        #                 WHEN SHIP_STRM_TYP_CD IN ( 'XAM', 'IRG') THEN 'Other'
        #                 ELSE SHIP_CTGY_NM   END AS SHIP_CTGY_NM_DRV,
        #                 ext_vrsn_strt_dts,
        #                 ext_vrsn_end_dts
        #                 FROM  ship_strm_typ_ext1
        #
        #                 ) STRM
        #                 ON DRV.SHIP_CD = STRM.SHIP_CD
        #                 AND DRV.SHIP_STRM_CTGY_NM = STRM.SHIP_CTGY_NM_DRV
        #                 AND DRV.txn_dt >=STRM.ext_vrsn_strt_dts
        #                 AND DRV.txn_dt < STRM.ext_vrsn_end_dts
        #
        #
        #                 INNER JOIN ship_strm_strm_typ1 STRM_TYP
        #                 ON DRV.SHIP_CD=STRM_TYP.SHIP_CD
        #                 AND STRM.SHIP_STRM_TYP_CD = STRM_TYP.STRM_TYP_CD
        #                 AND DRV.VYGE_DPRT_DT >= CAST(STRM_TYP.SHIP_STRM_STRM_STRT_DTS AS DATE)
        #                 AND DRV.VYGE_DPRT_DT < CAST(STRM_TYP.SHIP_STRM_STRM_END_DTS AS DATE)
        #                 AND DRV.txn_dt>=STRM_TYP.shp_vrsn_strt_dts
        #                 AND DRV.txn_dt<STRM_TYP.shp_vrsn_end_dts
        #
        #                 LEFT JOIN  opn_vyge_strm_typ_config OVSTC
        #                 ON   DRV.txn_dt >= OVSTC.VYGE_STRM_TYP_CONFIG_STRT_DTS
        #                 AND DRV.txn_dt < OVSTC.VYGE_STRM_TYP_CONFIG_END_DTS
        #                 AND DRV.SHIP_CD = OVSTC.SHIP_CD
        #                 AND STRM.SHIP_STRM_TYP_CD = OVSTC.STRM_TYP_CD
        #                 AND DRV.VYGE_DPRT_DT >= OVSTC.VYGE_DPRT_DT
        #                 AND DRV.VYGE_DPRT_DT < OVSTC.VYGE_ARVL_DT
        #                 AND OVSTC.LGCL_DEL_IN = 'N'
        #                 WHERE STRM.SHIP_CTGY_NM_DRV IS NOT NULL
        #                 GROUP BY DRV.VYGE_ID
        #                 ,DRV.SHIP_STRM_CTGY_NM
        #                 ,DRV.TXN_DT
        #                 ,STRM.SHIP_STRM_TYP_CD
        #                 ,OVSTC.STRM_TYP_CD
        #                 ,OOO_STRM_CN
        #                 ) RS
        #
        # """).dropDuplicates();
        folder_name = "%s%s" % ("vyge_ship_driver_strm_typ_cd/partition_dt=", end_dt)
        # print("******** floder_name=%s" % folder_name)
        data_loader.write_data("dm", folder_name, None, vyge_strm_ctgy_dly_strm_typ_driver)
        #
        # print("wrk_vyge_strm_ctgy_dly_strm_df  & Count ",wrk_vyge_strm_ctgy_dly_strm_df.count());
        #
        # wrk_vyge_strm_ctgy_dly_strm_df.createOrReplaceTempView("vyge_strm_ctgy_strm_typ_cd_driver")
        vyge_strm_ctgy_dly_strm_typ_driver.printSchema()
        vyge_strm_ctgy_dly_strm_typ_driver.show(10)

        ship_strm_typ_ext_df=ship_strm_typ_ext_df.filter("SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')" )

        phys_invtry_strm_cn_df = vyge_strm_typ_drvr_df.join(ship_strm_typ_ext_df, (
                    vyge_strm_typ_drvr_df.ship_cd == ship_strm_typ_ext_df.ship_cd) \
                                                                & (
                                                                            vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm) \
                                                                & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
            ship_strm_typ_ext_df.ext_vrsn_strt_dts)) \
                                                                & (vyge_strm_typ_drvr_df.txn_dt < to_date(
            ship_strm_typ_ext_df.ext_vrsn_end_dts))) \
            .join(ship_strm_strm_typ_df1, \
                  (ship_strm_strm_typ_df1.strm_typ_cd == ship_strm_typ_ext_df.ship_strm_typ_cd) \
                  & (vyge_strm_typ_drvr_df.ship_cd == ship_strm_strm_typ_df1.ship_cd) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt >= to_date(ship_strm_strm_typ_df1.ship_strm_strm_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.vyge_dprt_dt < to_date(ship_strm_strm_typ_df1.ship_strm_strm_end_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_strm_strm_typ_df1.shp_vrsn_strt_dts)) \
                  & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_strm_strm_typ_df1.shp_vrsn_end_dts)) \
                  ).select(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                           vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, ship_strm_strm_typ_df1.ship_strm_nb).groupBy(
            vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt, vyge_strm_typ_drvr_df.ship_strm_ctgy_nm).agg(
            (count(ship_strm_strm_typ_df1.ship_strm_nb).alias("phys_invtry_strm_cn"))).dropDuplicates()


        # phys_invtry_strm_cn_df = sql_context.sql(""" select driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm,
        #                  COUNT(DISTINCT type.ship_strm_nb) as phys_invtry_strm_cn
        #                     from Driver as driver INNER JOIN ship_strm_strm_typ as type
        #                     ON driver.ship_cd=type.ship_cd
        #                     AND driver.vyge_dprt_dt >= date(type.ship_strm_strm_strt_dts)
        #                     AND driver.vyge_dprt_dt < date(type.ship_strm_strm_end_dts)
        #                     AND driver.txn_dt >= date(type.vrsn_strt_dts)
        #                     AND driver.txn_dt < date(type.vrsn_end_dts)
        #                     INNER JOIN ship_strm_typ_ext1 as ext
        #                     ON driver.ship_cd=ext.ship_cd
        #                     AND ext.ship_strm_typ_cd=type.strm_typ_cd
        #                     AND driver.ship_strm_ctgy_nm = ext.SHIP_CTGY_NM
        #                     AND driver.txn_dt >= date(ext.ext_vrsn_strt_dts)
        #                     AND driver.txn_dt < date(ext.ext_vrsn_end_dts)
        #                     where  SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')  and type.ship_cd!='XP' and ext.ship_cd!='XP'
        #                     group by driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm
        #                     """).dropDuplicates()
        # print("================>> phys_invtry_strm_cn_df ===>>")
        phys_invtry_strm_cn_df.createOrReplaceTempView("phys_invtry_strm_cn_df");

        phys_invtry_strm_cn_df_ntr = sql_context.sql(""" select driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm as ship_strm_ctgy_nm_new
        ,ext.SHIP_STRM_TYP_CD,     
                                 COUNT(DISTINCT type.ship_strm_nb) as phys_invtry_strm_cn
                                    from Driver as driver INNER JOIN ship_strm_strm_typ as type
                                    ON driver.ship_cd=type.ship_cd 
                                    AND driver.vyge_dprt_dt >= date(type.ship_strm_strm_strt_dts)
                                    AND driver.vyge_dprt_dt < date(type.ship_strm_strm_end_dts)
                                    AND driver.txn_dt >= date(type.vrsn_strt_dts)
                                    AND driver.txn_dt < date(type.vrsn_end_dts)
                                    INNER JOIN ship_strm_typ_ext1 as ext
                                    ON driver.ship_cd=ext.ship_cd 
                                    AND ext.ship_strm_typ_cd=type.strm_typ_cd
                                    AND driver.ship_strm_ctgy_nm = ext.SHIP_CTGY_NM
                                    AND driver.txn_dt >= date(ext.ext_vrsn_strt_dts)
                                    AND driver.txn_dt < date(ext.ext_vrsn_end_dts)
                                    where  SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')  and type.ship_cd!='XP' and ext.ship_cd!='XP'
                                    group by driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm,ext.SHIP_STRM_TYP_CD
                                    """).dropDuplicates()
        print("================>> phys_invtry_strm_cn_df ===>>")
        phys_invtry_strm_cn_df_ntr.createOrReplaceTempView("phys_invtry_strm_cn_df_ntr");
        folder_name = "%s%s" % ("phys_invtry_strm_cn/partition_dt=", end_dt)
        print("******** floder_name=%s" % folder_name)
        data_loader.write_data("dm", folder_name, None, phys_invtry_strm_cn_df_ntr)

        ooo_vyg_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "
        ooo_vyg_consolidated_df = data_loader.read_data("dm", "vygestatrmtypinventory").filter(ooo_vyg_filter)
        ooo_vyg_consolidated_df.createOrReplaceTempView("ooo_vyg_consoloidated")

        ooo_vyg_consolidated_sql = """
                                              select 
                                              sum(vyge_strm_ooo_strm_cn) as ooo_strm_cn
                                              ,sum(vyge_strm_phys_invtry_strm_cn) as phys_invtry_strm_cn 
                                              ,ooo.txn_dt as txn_dt
                                              ,ooo.vyge_id as vyge_id 
                                              from ooo_vyg_consoloidated ooo 
                                              group by 
                                                ooo.vyge_id
                                               ,ooo.txn_dt
                                            """
        ooo_vyg_inventory_cnt_driver_df = sql_context.sql(ooo_vyg_consolidated_sql).dropDuplicates()
        ooo_vyg_inventory_cnt_driver_df.createOrReplaceTempView("ooo_consolidated_vw");
        if debug == 1:
            DebugCount.debug_counts(ooo_vyg_inventory_cnt_driver_df, "ooo_vyg_inventory_cnt_driver_df")

        ooo_filter = " src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') "

        ooo_consolidated_df = spark.read.format("orc").load(
            "/wdpr-apps-data/dclrms/stg/dm/vygestatrmtypinventory").filter(ooo_filter)
        ooo_consolidated_df.createOrReplaceTempView("ooo_consoloidated")

        ooo_vyg_inventory_cnt_driver_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df,
                                            (vyge_strm_typ_drvr_df.txn_dt == ooo_consolidated_df.txn_dt) \
                                            & (vyge_strm_typ_drvr_df.vyge_id == ooo_consolidated_df.vyge_id) \
                                            ).select(vyge_strm_typ_drvr_df.txn_dt, vyge_strm_typ_drvr_df.vyge_id,
                                                     vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                                                     ooo_consolidated_df.vyge_strm_ooo_strm_cn).groupBy(
            vyge_strm_typ_drvr_df.txn_dt, vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.ship_strm_ctgy_nm).agg(
            (sum(ooo_consolidated_df.vyge_strm_ooo_strm_cn).alias("ooo_strm_cn")))



        # ooo_vyg_inventory_cnt_driver_df = sql_context.sql("""  SELECT driver.vyge_id,driver.txn_dt
        #                 ,driver.ship_strm_ctgy_nm
        #                 ,COUNT(CASE
        #                     WHEN type.ship_strm_nb IS NOT NULL 	AND RESERVETYPE = 'OUT OF ORDER'	THEN NULL
        #                     WHEN RESERVETYPE = 'OUT OF ORDER'	THEN CABINNUMBER ELSE  NULL
        #                   END) AS ooo_strm_cn
        #                 ,
        #                 COUNT(DISTINCT type.ship_strm_nb) as phys_invtry_strm_cn
        #
        #                 from Driver as driver INNER JOIN ship_strm_strm_typ as type
        #                 ON driver.ship_cd=type.ship_cd
        #                 AND driver.vyge_dprt_dt >= date(type.ship_strm_strm_strt_dts)
        #                 AND driver.vyge_dprt_dt < date(type.ship_strm_strm_end_dts)
        #                 AND driver.txn_dt >= date(type.vrsn_strt_dts)
        #                 AND driver.txn_dt < date(type.vrsn_end_dts)
        #
        #                 INNER JOIN ship_strm_typ_ext1 as ext
        #                 ON driver.ship_cd=ext.ship_cd
        #                 AND ext.ship_strm_typ_cd=type.strm_typ_cd
        #                 AND driver.ship_strm_ctgy_nm = ext.SHIP_CTGY_NM
        #                 AND driver.txn_dt >= date(ext.ext_vrsn_strt_dts)
        #                 AND driver.txn_dt < date(ext.ext_vrsn_end_dts)
        #
        #                 LEFT OUTER JOIN shipcabinreserved SP_RES
        #                 ON driver.SHIP_CD = SP_RES.CODE
        #                 AND driver.vyge_dprt_dt >= SP_RES.SAILDATEFROM
        #                 AND driver.vyge_dprt_dt < SP_RES.SAILDATETO
        #                 AND driver.txn_dt >= SP_RES.VRSN_STRT_DTS
        #                 AND driver.txn_dt < SP_RES.VRSN_END_DTS
        #                 AND type.ship_strm_nb = SP_RES.CABINNUMBER
        #                 AND SP_RES.Instnc_St_Nm='Standard'
        #                 WHERE  SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')  and type.ship_cd!='XP' and ext.ship_cd!='XP'
        #                 GROUP BY driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm
        #                 """).dropDuplicates();
        ooo_vyg_inventory_cnt_driver_df.createOrReplaceTempView("ooo_consolidated_vw");
        if debug == 1:
            DebugCount.debug_counts(ooo_vyg_inventory_cnt_driver_df, "ooo_vyg_inventory_cnt_driver_df")


        ooo_vyg_inventory_cnt_driver_df_ntr_gtr = sql_context.sql("""  SELECT driver.vyge_id,driver.txn_dt
                                ,driver.ship_strm_ctgy_nm as ship_strm_ctgy_nm_new,ext.SHIP_STRM_TYP_CD
                                ,COUNT(CASE	 
                                    WHEN type.ship_strm_nb IS NOT NULL 	AND RESERVETYPE = 'OUT OF ORDER'	THEN NULL
                                    WHEN RESERVETYPE = 'OUT OF ORDER'	THEN CABINNUMBER ELSE  NULL 
                                  END) AS ooo_strm_cn
                                ,
                                COUNT(DISTINCT type.ship_strm_nb) as phys_invtry_strm_cn

                                from Driver as driver INNER JOIN ship_strm_strm_typ as type
                                ON driver.ship_cd=type.ship_cd 
                                AND driver.vyge_dprt_dt >= date(type.ship_strm_strm_strt_dts)
                                AND driver.vyge_dprt_dt < date(type.ship_strm_strm_end_dts)
                                AND driver.txn_dt >= date(type.vrsn_strt_dts)
                                AND driver.txn_dt < date(type.vrsn_end_dts)

                                INNER JOIN ship_strm_typ_ext1 as ext
                                ON driver.ship_cd=ext.ship_cd 
                                AND ext.ship_strm_typ_cd=type.strm_typ_cd
                                AND driver.ship_strm_ctgy_nm = ext.SHIP_CTGY_NM
                                AND driver.txn_dt >= date(ext.ext_vrsn_strt_dts)
                                AND driver.txn_dt < date(ext.ext_vrsn_end_dts)

                                LEFT OUTER JOIN shipcabinreserved SP_RES
                                ON driver.SHIP_CD = SP_RES.CODE
                                AND driver.vyge_dprt_dt >= SP_RES.SAILDATEFROM
                                AND driver.vyge_dprt_dt < SP_RES.SAILDATETO 
                                AND driver.txn_dt >= SP_RES.VRSN_STRT_DTS
                                AND driver.txn_dt < SP_RES.VRSN_END_DTS
                                AND type.ship_strm_nb = SP_RES.CABINNUMBER
                                AND SP_RES.Instnc_St_Nm='Standard'
                                WHERE  SHIP_STRM_TYP_CD NOT IN ('GTY','VGT','XAM','IRG','IGT','OGT')  and type.ship_cd!='XP' and ext.ship_cd!='XP'
                                GROUP BY driver.vyge_id,driver.txn_dt,driver.ship_strm_ctgy_nm,ext.SHIP_STRM_TYP_CD
                                """).dropDuplicates();
        folder_name = "%s%s" % ("ooo_vyg_inventory_cnt_driver/partition_dt=", end_dt)
        print("******** floder_name=%s" % folder_name)
        data_loader.write_data("dm", folder_name, None, ooo_vyg_inventory_cnt_driver_df_ntr_gtr)

        ooo_vyg_inventory_cnt_driver_df_ntr_gtr.createOrReplaceTempView("ooo_vyg_inventory_cnt_driver_df_ntr_gtr");
        VygeStrmCtgDlyNtrGTR.run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader, debug)
        strm_df=vyge_strm_ctgy_dly_strm_typ_driver;
        expect_oh_bkng_cn_df = expect_oh_bkng_vw_df.join(vyge_strm_typ_drvr_df, \
                                                         (
                                                                     vyge_strm_typ_drvr_df.app_vyge_id == expect_oh_bkng_vw_df.app_vyge_id) \
                                                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                             expect_oh_bkng_vw_df.expect_oh_bkng_run_dts)) \
                                                         & (vyge_strm_typ_drvr_df.txn_dt >= to_date(
                                                             expect_oh_bkng_vw_df.asofdate))).join(strm_df, \
                                                                                                   (
                                                                                                               strm_df.SHIP_STRM_TYP_CD == expect_oh_bkng_vw_df.strm_typ_cd) \
                                                                                                   & (
                                                                                                               strm_df.TXN_DT >= to_date(
                                                                                                           expect_oh_bkng_vw_df.expect_oh_bkng_run_dts)) \
                                                                                                   & (
                                                                                                               strm_df.TXN_DT >= to_date(
                                                                                                           expect_oh_bkng_vw_df.asofdate)) \
                                                                                                   & (
                                                                                                               strm_df.SHIP_STRM_CTGY_NM == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                                                                                                   & (
                                                                                                               strm_df.VYGE_ID == vyge_strm_typ_drvr_df.vyge_id) \
                                                                                                   ) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    expect_oh_bkng_vw_df.expect_oh_bkng_cn, \
                    strm_df.SHIP_STRM_TYP_CD)
        expect_oh_bkng_cn_df.createOrReplaceTempView("expect_oh_bkng_cn_df")

        expect_oh_bkng_cn_final_df = expect_oh_bkng_cn_df.select("vyge_id", "ship_strm_ctgy_nm", "txn_dt",
                                                               "expect_oh_bkng_cn").groupBy("vyge_id",
                                                                                            "ship_strm_ctgy_nm",
                                                                                            "txn_dt").agg(
            sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn")).dropDuplicates()

        expect_oh_bkng_cn_final_df.createOrReplaceTempView("expect_oh_bkng_cn_vw")
        #expect_oh_bkng_cn_final_df=sql_context.sql("""  select vyge_id,ship_strm_ctgy_nm,txn_dt,sum(expect_oh_bkng_cn) from expect_oh_bkng_cn_df group by vyge_id,ship_strm_ctgy_nm,txn_dt """)
        #expect_oh_bkng_cn_final_df.createOrReplaceTempView("expect_oh_bkng_cn_vw")
        # expect_oh_bkng_cn_new_df = expect_oh_bkng_cn_df.select("vyge_id", "ship_strm_ctgy_nm", "txn_dt").groupBy(
        #     "vyge_id", "ship_strm_ctgy_nm", "txn_dt").agg(
        #     sum("expect_oh_bkng_cn").alias("expect_oh_bkng_cn")).dropDuplicates()



        #VygeStrmCtgDlySlCounts.run_viz_vyge_count_calc(start_dt, end_dt, runType, sql_context, s3_bucket,data_loader, debug)
        #run_viz_vyge_count_calc(start_dt, end_dt, runType, sql_context, s3_bucket,data_loader,debug)
        print("Start Calling to run_viz_ppp_metrics ")
        #VygeStrmCtgDlyPriceModDt.run_viz_ppp_metrics(start_dt, end_dt, runType, sql_context, s3_bucket,data_loader, debug)
        print("End  Calling to run_viz_ppp_metrics ")
        print("Start Calling to run_viz_vyge_gtr_ntr_calc ===>")
        #VygeStrmCtgDlyNtrGTR.run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, sql_context, s3_bucket,data_loader, debug)
        print("End Calling to run_viz_vyge_gtr_ntr_calc ===>")
        print("gtr_ntr_Cal completed & Driver process completed ")

        udf_price_am_pc_df=sql_context.sql("select * from uncnstrn_bkng");

        udf_price_am_pc_pre_df = vyge_strm_typ_drvr_df.join(udf_price_am_pc_df, \
                                                            (vyge_strm_typ_drvr_df.app_vyge_id == udf_price_am_pc_df.app_vyge_id) \
                                                            & (vyge_strm_typ_drvr_df.txn_dt >= to_date(udf_price_am_pc_df.uncnstrn_bkng_run_dts_max)) \
                                                            & (vyge_strm_typ_drvr_df.uncnstrn_bkng_run_dts_max  == udf_price_am_pc_df.uncnstrn_bkng_run_dts)) \
            .join(strm_df, (strm_df.SHIP_STRM_TYP_CD == expect_oh_bkng_vw_df.strm_typ_cd) \
                  & (strm_df.TXN_DT >= to_date(udf_price_am_pc_df.uncnstrn_bkng_run_dts_max)) \
                  & (strm_df.TXN_DT >= vyge_strm_typ_drvr_df.txn_dt) \
                  & (strm_df.SHIP_STRM_CTGY_NM == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                  & (strm_df.VYGE_ID == vyge_strm_typ_drvr_df.vyge_id) \
                  & (udf_price_am_pc_df.dy_bef_vyge_cn == 1) \
                  ).select(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                           vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                           udf_price_am_pc_df.udf_curr_price_am, udf_price_am_pc_df.udf_as_of_dt_rcmd_price_am,
                           udf_price_am_pc_df.udf_rcmd_price_am) \
            .groupBy(vyge_strm_typ_drvr_df.vyge_id, vyge_strm_typ_drvr_df.txn_dt,
                     vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
            .agg((sum(udf_price_am_pc_df.udf_curr_price_am).alias("udf_curr_price_am")),
                 (sum(udf_price_am_pc_df.udf_as_of_dt_rcmd_price_am).alias("udf_as_of_dt_rcmd_price_am")) \
                     (sum(udf_price_am_pc_df.udf_rcmd_price_am).alias("udf_rcmd_price_am")))

        udf_price_am_pc_df = vyge_strm_typ_drvr_df.join(udf_price_am_pc_pre_df,
                                                        ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"], "left_outer") \
            .join(strm_cpcty_nb_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"], "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt.alias("txn_date"), \
                    udf_price_am_pc_pre_df.udf_curr_price_am, \
                    udf_price_am_pc_pre_df.udf_as_of_dt_rcmd_price_am, \
                    udf_price_am_pc_pre_df.udf_rcmd_price_am, \
                    strm_cpcty_nb_df.strm_cpcty_nb_sum) \
            .withColumn("udf_curr_price_pc",
                        ((udf_price_am_pc_pre_df.udf_curr_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)")) \
            .withColumn("udf_as_of_dt_rcmd_price_pc",
                        ((udf_price_am_pc_pre_df.udf_as_of_dt_rcmd_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)")) \
            .withColumn("udf_rcmd_price_pc",
                        ((udf_price_am_pc_pre_df.udf_rcmd_price_am / strm_cpcty_nb_df.strm_cpcty_nb_sum) * 100) \
                        .cast("decimal(12,2)"))

        udf_price_am_pc_df.createOrReplaceTempView("udf_price_am_pc_vw")

        sl_lim_rcmd_df = sql_context.sql(
            " select distinct app_vyge_id,	sl_lim_rcmd_run_dts,asofdate from sl_lim_rcmd ")
        price_rcmd_dtl_df = sql_context.sql(
            "select distinct app_vyge_id,price_rcmd_run_dts,asofdate from price_rcmd_dtl")

        # debug=1
        vyge_strm_typ_dly_sci_rcmd_temp_df = vyge_strm_typ_drvr_df.join(price_rcmd_dtl_df, \
                                                                    (vyge_strm_typ_drvr_df.app_vyge_id == price_rcmd_dtl_df.app_vyge_id) \
                                                                & (vyge_strm_typ_drvr_df.txn_dt >= to_date(price_rcmd_dtl_df.price_rcmd_run_dts)) \
                                                                & (vyge_strm_typ_drvr_df.txn_dt >= to_date(price_rcmd_dtl_df.asofdate)), "left_outer") \
                                                .join(sl_lim_rcmd_df, \
                                                (vyge_strm_typ_drvr_df.app_vyge_id == sl_lim_rcmd_df.app_vyge_id) \
                                                & (vyge_strm_typ_drvr_df.txn_dt >= to_date(sl_lim_rcmd_df.sl_lim_rcmd_run_dts)) \
                                                & (vyge_strm_typ_drvr_df.txn_dt >= to_date(sl_lim_rcmd_df.asofdate)), "left_outer") \
                                        .select(vyge_strm_typ_drvr_df.vyge_id, \
                                                vyge_strm_typ_drvr_df.app_vyge_id, \
                                                vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                                                vyge_strm_typ_drvr_df.txn_dt, \
                                                price_rcmd_dtl_df.price_rcmd_run_dts, \
                                                sl_lim_rcmd_df.sl_lim_rcmd_run_dts) \
                                        .groupBy("vyge_id", "app_vyge_id", "ship_strm_ctgy_nm", "txn_dt") \
                                        .agg(max("price_rcmd_run_dts").alias("max_price_rcmd_run_dts") \
                                             , max("sl_lim_rcmd_run_dts").alias("max_sl_lim_rcmd_run_dts"))

        vyge_strm_typ_dly_sci_rcmd_df = vyge_strm_typ_dly_sci_rcmd_temp_df.withColumn("sci_rcmd_typ_nm", \
                                                                                      when((
                                                                                               vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNull()) \
                                                                                           & (
                                                                                               vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNull()), \
                                                                                           vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts) \
                                                                                      .otherwise(when((
                                                                                                          vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNull()) \
                                                                                                      & (
                                                                                                          vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNotNull()),
                                                                                                      lit(
                                                                                                          "Selling Limit")) \
                                                                                          .otherwise(when((
                                                                                                              vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts.isNotNull()) \
                                                                                                          & (
                                                                                                              vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts.isNull()),
                                                                                                          lit(
                                                                                                              "Pricing")) \
                                                                                          .otherwise(when(
                                                                                          (
                                                                                                  vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts \
                                                                                                  >= vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts),
                                                                                          lit("Pricing")) \
                                                                                          .otherwise(
                                                                                          when((
                                                                                                  vyge_strm_typ_dly_sci_rcmd_temp_df.max_price_rcmd_run_dts \
                                                                                                  < vyge_strm_typ_dly_sci_rcmd_temp_df.max_sl_lim_rcmd_run_dts),
                                                                                              lit("Selling Limit"))))))) \
            .select("vyge_id", \
                    "ship_strm_ctgy_nm", \
                    "txn_dt", \
                    "sci_rcmd_typ_nm") \
            .dropDuplicates()
        vyge_strm_typ_dly_sci_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_sci_rcmd_vw")
        if debug == 1:
            #debug_counts(vyge_strm_typ_dly_sci_rcmd_df, "vyge_strm_typ_dly_sci_rcmd_vw")









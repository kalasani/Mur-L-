##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : NTR & GTR Call
# Author            : Anjaiah  M                                                          #
# Date created      : 2018-08-26                                                         #
# Purpose           : To build the driver program                                        #
# Revision History  :                                                                    #
# Date           Author     Ref    Revision (Date in YYYYMMDD format)                    #
# 2018-08-26    kowshik Y   Chris                                                        #
#                                                                                        #
##########################################################################################


#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.DebugCount import *;
from pyspark.sql.types import *
import os, sys


class VygeStrmCtgDlyNtrGTR(object):

    @staticmethod
    def populate_ppp_metrics(rows):
        last_vyge_id = -1
        last_version_start_date = None
        last_strm_typ_cd = -1
        last_metric = -1.0
        first_rec = 1
        vyge_drtn_nght_cn = None
        vfd_am = None
        vfa_extra_am = None
        vfc_extra_am = None
        vfi_extra_am = None
        non_comm_am = None
        ppm_metric_list = []
        for row in rows:
            if (
                    last_vyge_id != row.vyge_id or last_version_start_date != row.txn_dt or last_strm_typ_cd != row.strm_typ_cd) and first_rec != 1:
                # this is the first one
                ppm_metric_list.append(
                    Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am,
                        vfa_extra_am, vfc_extra_am, vfi_extra_am, non_comm_am))
                vyge_drtn_nght_cn = None
                vfd_am = None
                vfa_extra_am = None
                vfc_extra_am = None
                vfi_extra_am = None
                non_comm_am = None

            first_rec = 0
            if row.vyge_drtn_nght_cn != None and row.vfd_am != None and row.vfa_extra_am != None and row.vfc_extra_am != None and row.vfi_extra_am != None and row.non_comm_am != None:
                # assuming that we re processing price first and then cabing
                vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
                vfd_am = row.vfd_am
                vfa_extra_am = row.vfa_extra_am
                vfc_extra_am = row.vfc_extra_am
                vfi_extra_am = row.vfi_extra_am
                non_comm_am = row.non_comm_am

            last_vyge_id = row.vyge_id
            last_version_start_date = row.txn_dt
            last_strm_typ_cd = row.strm_typ_cd
            vyge_drtn_nght_cn = row.vyge_drtn_nght_cn
            vfd_am = row.vfd_am
            vfa_extra_am = row.vfa_extra_am
            vfc_extra_am = row.vfc_extra_am
            vfi_extra_am = row.vfi_extra_am
            non_comm_am = row.non_comm_am
        if last_vyge_id != -1 and vfd_am != None and vfa_extra_am != None and vfc_extra_am != None and vfi_extra_am != None and non_comm_am != None:
            ppm_metric_list.append(
                Row(last_vyge_id, last_version_start_date, last_strm_typ_cd, vyge_drtn_nght_cn, vfd_am, vfa_extra_am,
                    vfc_extra_am,
                    vfi_extra_am, non_comm_am))
        return iter(ppm_metric_list)

    @staticmethod
    def run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, spark, s3_bucket, data_loader,debug):
        vyge_strm_typ_drvr_df1 = spark.sql("select * from driver ");

        ship_strm_typ_ext_df = spark.sql("select * from ship_strm_typ_ext1");

        vyge_attr_df = spark.sql("select * from vyge_attr")

        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_df1.join(ship_strm_typ_ext_df, \
                                                            (
                                                                        vyge_strm_typ_drvr_df1.ship_cd == ship_strm_typ_ext_df.ship_cd)
                                                            & (
                                                                        vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm)
                                                            & (
                                                                        vyge_strm_typ_drvr_df1.txn_dt >= ship_strm_typ_ext_df.ext_vrsn_strt_dts)
                                                            & (
                                                                        vyge_strm_typ_drvr_df1.txn_dt < ship_strm_typ_ext_df.ext_vrsn_end_dts)) \
            .select(vyge_strm_typ_drvr_df1.vyge_id,
                    ship_strm_typ_ext_df.ship_strm_typ_cd.alias("strm_typ_cd"),
                    vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm,
                    vyge_strm_typ_drvr_df1.txn_dt,
                    vyge_strm_typ_drvr_df1.ship_cd,
                    vyge_strm_typ_drvr_df1.vyge_dprt_dt,
                    vyge_strm_typ_drvr_df1.app_vyge_id,
                    vyge_strm_typ_drvr_df1.dy_bef_vyge_cn,
                    vyge_strm_typ_drvr_df1.vyge_drtn_nght_cn).distinct()

        vyge_strm_typ_drvr_df.createOrReplaceTempView("driver_strm")

        ooo_filter_clause = """ src_sys_strm_typ_cd not in ('IGT','OGT','VGT','XAM','GTY') """
        ooo_consolidated_df = spark.read.format("orc").load(
            "/wdpr-apps-data/dclrms/stg/dm/vygestatrmtypinventory/data").filter(ooo_filter_clause)

        ooo_inventory_cnt_df = vyge_strm_typ_drvr_df.join(ooo_consolidated_df, \
                                                          (vyge_strm_typ_drvr_df.vyge_id == ooo_consolidated_df.vyge_id) \
                                                          & (
                                                                      vyge_strm_typ_drvr_df.strm_typ_cd == ooo_consolidated_df.src_sys_strm_typ_cd) \
                                                          & (
                                                                      vyge_strm_typ_drvr_df.txn_dt == ooo_consolidated_df.txn_dt),
                                                          "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    ooo_consolidated_df.vyge_strm_ooo_strm_cn, \
                    ooo_consolidated_df.vyge_strm_phys_invtry_strm_cn) \
            .groupBy("vyge_id", "strm_typ_cd", "txn_dt") \
            .agg(sum("vyge_strm_ooo_strm_cn").alias("ooo_strm_cn"),
                 sum("vyge_strm_phys_invtry_strm_cn").alias("phys_invtry_strm_cn"))
        ooo_inventory_cnt_df.createOrReplaceTempView("ooo_consolidated_vw")
        print("Completed: ooo_inventory_cnt_df")


        proc_price_pt_vw_df = spark.sql("""select * from PROC_PRICE_PT """)

        vyge_fnc_fcst_var_temp_df = spark.sql("""
        select *,
        coalesce(max(data_ld_dts) over(partition by ship_cd,vyge_strt_dt order by data_ld_dts 
        asc rows between 1 following and 1 following
        ),
        CAST('9999-12-31 00:00:00.000000' as timestamp)) as vrsn_end_dts
        from vyge_fnc_fcst_var_vw 
        """)
        print("Completed: vyge_fnc_fcst_var_temp_df")
        vyge_fnc_fcst_var_temp_df.createOrReplaceTempView("vyge_fnc_fcst_var_temp_vw")

        vyge_ship_fnc_dflt_fcst_df = spark.sql(""" select
        drvr.vyge_id
        ,drvr.strm_typ_cd
        ,drvr.txn_dt
        ,drvr.ship_cd
        ,coalesce(vffc.fcst_ship_ocpncy_pc,dflt.fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc
        ,coalesce(vffc.fcst_comm_pc,dflt.fcst_comm_pc) as fcst_comm_pc
        ,coalesce(vffc.fcst_gst_per_strm_cn,dflt.fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn
        ,coalesce(vffc.fcst_ooo_gst_per_strm_cn, dflt.fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn
        ,coalesce(vffc.vyge_adlt_split_pc,dflt.vyge_adlt_split_pc) as adlt_split
        ,coalesce(vffc.vyge_chld_split_pc,dflt.vyge_chld_split_pc) as chld_split		
        from driver_strm drvr	
        inner join dflt_ship_fnc_fcst_vw dflt				
        on dflt.ship_cd = drvr.ship_cd
        and dflt.dflt_ship_fnc_fcst_strt_dts <= drvr.txn_dt
        and dflt.dflt_ship_fnc_fcst_end_dts > drvr.txn_dt
        and dflt.lgcl_del_in = 'N' 				
        left outer join vyge_fnc_fcst_var_temp_vw vffc
        on drvr.ship_cd = vffc.ship_cd
        and drvr.vyge_dprt_dt = vffc.vyge_strt_dt
        and vffc.vrsn_end_dts = '9999-12-31 00:00:00.000000'  """)

        vyge_ship_fnc_dflt_fcst_df.createOrReplaceTempView("vyge_ship_fnc_dflt_fcst_vw")
        print("Completed: vyge_ship_fnc_dflt_fcst_df")

        voyages_only_df = vyge_strm_typ_drvr_df.join(vyge_attr_df, ["vyge_id", "txn_dt"]) \
            .select("vyge_id", "txn_dt", vyge_strm_typ_drvr_df.strm_typ_cd, "vyge_init_bkng_dt")

        proc_price_pt_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                         (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                         & (voyages_only_df.txn_dt == proc_price_pt_vw_df.txn_dt) \
                                                         & (
                                                                     proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, proc_price_pt_vw_df.strm_typ_cd, voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm")
        print("Completed: proc_price_pt_calc_df")

        proc_price_pt_price_calc_df = proc_price_pt_calc_df.select("vyge_id", "vyge_drtn_nght_cn", "txn_dt",
                                                                   "strm_typ_cd", "vfd_am", "vfa_extra_am",
                                                                   "vfc_extra_am", \
                                                                   "vfi_extra_am", "non_comm_am",
                                                                   "proc_price_src_sys_nm") \
            .filter("proc_price_src_sys_nm = 'Pricing Extract'")
        proc_price_pt_price_calc_df.createOrReplaceTempView("proc_price_pt_price_calc_vw")
        print("Completed: proc_price_pt_price_calc_df")

        proc_price_pt_cabin_calc_df = proc_price_pt_calc_df.select("vyge_id", "vyge_drtn_nght_cn", "txn_dt",
                                                                   "strm_typ_cd", "vfd_am", "vfa_extra_am",
                                                                   "vfc_extra_am", "vfi_extra_am", \
                                                                   "non_comm_am", "proc_price_src_sys_nm") \
            .filter("proc_price_src_sys_nm = 'Cabin Cat'")
        proc_price_pt_cabin_calc_df.createOrReplaceTempView("proc_price_pt_cabin_calc_vw")
        print("Completed: proc_price_pt_cabin_calc_df")

        proc_price_pt_ntr_gtr_calc_df = spark.sql("""
        SELECT main.*
                from (
                
                select coalesce(proc_price_pt_price.vyge_id,proc_price_pt_cabin.vyge_id) as vyge_id
                ,coalesce(proc_price_pt_price.vyge_drtn_nght_cn,proc_price_pt_cabin.vyge_drtn_nght_cn) as vyge_drtn_nght_cn
                ,coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt) as txn_dt
                ,coalesce(proc_price_pt_price.strm_typ_cd,proc_price_pt_cabin.strm_typ_cd) as strm_typ_cd
                ,coalesce(proc_price_pt_price.vfd_am,proc_price_pt_cabin.vfd_am) as vfd_am
                ,coalesce(proc_price_pt_price.vfa_extra_am,proc_price_pt_cabin.vfa_extra_am) as vfa_extra_am
                ,coalesce(proc_price_pt_price.vfc_extra_am,proc_price_pt_cabin.vfc_extra_am) as vfc_extra_am
                ,coalesce(proc_price_pt_price.vfi_extra_am,proc_price_pt_cabin.vfi_extra_am) as vfi_extra_am
                ,coalesce(proc_price_pt_price.non_comm_am,proc_price_pt_cabin.non_comm_am) as non_comm_am
                ,coalesce(proc_price_pt_price.proc_price_src_sys_nm,proc_price_pt_cabin.proc_price_src_sys_nm) as proc_price_src_sys_nm
                ,row_number() over(
                partition by coalesce(proc_price_pt_price.vyge_id,proc_price_pt_cabin.vyge_id)\
                ,coalesce(proc_price_pt_price.strm_typ_cd,proc_price_pt_cabin.strm_typ_cd)\
                ,coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt)
                order by  coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt) desc
                ) as rank_num
                from driver_strm drvr
                left JOIN proc_price_pt_price_calc_vw proc_price_pt_price
                on drvr.vyge_id = proc_price_pt_price.vyge_id
                and drvr.strm_typ_cd  = proc_price_pt_price.strm_typ_cd
                and drvr.txn_dt = proc_price_pt_price.txn_dt
        
                left JOIN proc_price_pt_cabin_calc_vw proc_price_pt_cabin
                ON drvr.vyge_id = proc_price_pt_cabin.vyge_id
                and drvr.strm_typ_cd  = proc_price_pt_cabin.strm_typ_cd
                and drvr.txn_dt = proc_price_pt_cabin.txn_dt ) as main
                where main.rank_num = 1
                """)
        print("Completed: proc_price_pt_ntr_gtr_calc_df")

        proc_price_pt_ntr_gtr_calc_df.createOrReplaceTempView("proc_price_pt_ntr_gtr_calc_vw")

        proc_price_pt_gtr_tmp_df = spark.sql(""" 
        SELECT
        drvr.vyge_id,
        drvr.strm_typ_cd,
        drvr.ship_strm_ctgy_nm as ship_strm_ctgy_nm_tempNew ,
        drvr.txn_dt,
        min(fcst.fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc,
        min(fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn,
        min(fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn,
        min(fcst.fcst_comm_pc) as fcst_comm_pc,


        sum((((ppp.vfd_am+ppp.non_comm_am)*2)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn)) +
        (((ppp.vfa_extra_am+ppp.non_comm_am)*fcst.adlt_split)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn) *(fcst.fcst_gst_per_strm_cn - 2))+
        (((ppp.vfc_extra_am+ppp.non_comm_am)*fcst.chld_split)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn) *(fcst.fcst_gst_per_strm_cn - 2))) as grs_revenue,

        sum((strm.phys_invtry_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ship_ocpncy_pc-drvr.vyge_drtn_nght_cn*strm.ooo_strm_cn)*fcst.fcst_gst_per_strm_cn +
        (strm.ooo_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ooo_gst_per_strm_cn)) as grs_pcd


        from driver_strm drvr
        
        inner join  ooo_consolidated_vw strm
        on drvr.vyge_id = strm.vyge_id
        and drvr.strm_typ_cd = strm.strm_typ_cd
        and drvr.txn_dt = strm.txn_dt
        and drvr.strm_typ_cd not in ('IRG','XAM')

        inner join  proc_price_pt_ntr_gtr_calc_vw ppp
        on drvr.vyge_id = ppp.vyge_id
        and drvr.strm_typ_cd = ppp.strm_typ_cd
        and drvr.txn_dt = ppp.txn_dt

        left outer join vyge_ship_fnc_dflt_fcst_vw fcst
        on drvr.vyge_id = fcst.vyge_id
        and drvr.strm_typ_cd = fcst.strm_typ_cd
        and drvr.txn_dt = fcst.txn_dt
        group by drvr.vyge_id,
        drvr.strm_typ_cd,
        drvr.ship_strm_ctgy_nm,
        drvr.txn_dt
        """).distinct()

        proc_price_pt_gtr_tmp_df.createOrReplaceTempView("proc_price_pt_gtr_tmp_vw")
        print("Completed: proc_price_pt_gtr_tmp_df")

        proc_price_pt_gtr_df = spark.sql(""" select vyge_id,
        ship_strm_ctgy_nm_tempNew as ship_strm_ctgy_nm_temp ,
        txn_dt,
        cast(sum(grs_revenue)/sum(grs_pcd) as decimal(12,2)) as gtr_price_pd_am

        from proc_price_pt_gtr_tmp_vw 
        group by vyge_id,
        ship_strm_ctgy_nm_tempNew,
        txn_dt """)
        proc_price_pt_gtr_df.createOrReplaceTempView("proc_price_pt_gtr_vw")
        print("Completed: proc_price_pt_gtr_df")

        proc_price_pt_ntr_gtr_df = spark.sql("""
        SELECT proc_price_pt_gtr_vw.vyge_id,
        proc_price_pt_gtr_tmp_vw.ship_strm_ctgy_nm_tempNew as ship_strm_ctgy_nm_temp ,
        proc_price_pt_gtr_vw.txn_dt as txn_date,
        proc_price_pt_gtr_vw.gtr_price_pd_am,
        cast(proc_price_pt_gtr_vw.gtr_price_pd_am * (1- (proc_price_pt_gtr_tmp_vw.fcst_comm_pc)) as decimal(12,2)) as ntr_price_pd_am
        FROM proc_price_pt_gtr_vw join proc_price_pt_gtr_tmp_vw
        on proc_price_pt_gtr_vw.vyge_id = proc_price_pt_gtr_tmp_vw.vyge_id 
        and proc_price_pt_gtr_vw.ship_strm_ctgy_nm_temp = proc_price_pt_gtr_tmp_vw.ship_strm_ctgy_nm_tempNew
        and proc_price_pt_gtr_vw.txn_dt = proc_price_pt_gtr_tmp_vw.txn_dt
        """).distinct()
        print("Completed: proc_price_pt_ntr_gtr_df")

        proc_price_pt_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_ntr_gtr_vw")

        #XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        #OPN_GTR_NTR
        #XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        proc_price_pt_opn_calc_df = proc_price_pt_vw_df.join(voyages_only_df, \
                                                             (voyages_only_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                             & (coalesce(voyages_only_df.vyge_init_bkng_dt, \
                                                                         date_add(voyages_only_df.vyge_init_bkng_dt,
                                                                                  1)) == proc_price_pt_vw_df.txn_dt) \
                                                             & (
                                                                         proc_price_pt_vw_df.strm_typ_cd == voyages_only_df.strm_typ_cd)) \
            .select(proc_price_pt_vw_df.vyge_id, \
                    proc_price_pt_vw_df.strm_typ_cd, \
                    voyages_only_df.txn_dt \
                    , "vyge_drtn_nght_cn", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm")
        print("Completed: proc_price_pt_opn_calc_df")

        proc_price_pt_opn_price_calc_df = proc_price_pt_opn_calc_df \
            .select("vyge_id", "vyge_drtn_nght_cn", "txn_dt",
                    "strm_typ_cd", "vfd_am", "vfa_extra_am", "vfc_extra_am", \
                    "vfi_extra_am", "non_comm_am", "proc_price_src_sys_nm") \
            .filter("proc_price_src_sys_nm = 'Pricing Extract'")
        proc_price_pt_opn_price_calc_df.createOrReplaceTempView("proc_price_pt_opn_price_calc_vw")

        proc_price_pt_opn_cabin_calc_df = proc_price_pt_opn_calc_df \
            .select("vyge_id", "vyge_drtn_nght_cn", "txn_dt",
                    "strm_typ_cd", "vfd_am", "vfa_extra_am", "vfc_extra_am", "vfi_extra_am", \
                    "non_comm_am", "proc_price_src_sys_nm") \
            .filter("proc_price_src_sys_nm = 'Cabin Cat'")
        proc_price_pt_opn_cabin_calc_df.createOrReplaceTempView("proc_price_pt_opn_cabin_calc_vw")
        print("Completed: proc_price_pt_opn_cabin_calc_df")
        proc_price_pt_opn_ntr_gtr_calc_df = spark.sql("""
        select main.*
        from (
        select coalesce(proc_price_pt_price.vyge_id,proc_price_pt_cabin.vyge_id) as vyge_id
        ,coalesce(proc_price_pt_price.vyge_drtn_nght_cn,proc_price_pt_cabin.vyge_drtn_nght_cn) as vyge_drtn_nght_cn
        ,coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt) as txn_dt
        ,coalesce(proc_price_pt_price.strm_typ_cd,proc_price_pt_cabin.strm_typ_cd) as strm_typ_cd
        ,coalesce(proc_price_pt_price.vfd_am,proc_price_pt_cabin.vfd_am) as vfd_am
        ,coalesce(proc_price_pt_price.vfa_extra_am,proc_price_pt_cabin.vfa_extra_am) as vfa_extra_am
        ,coalesce(proc_price_pt_price.vfc_extra_am,proc_price_pt_cabin.vfc_extra_am) as vfc_extra_am
        ,coalesce(proc_price_pt_price.vfi_extra_am,proc_price_pt_cabin.vfi_extra_am) as vfi_extra_am
        ,coalesce(proc_price_pt_price.non_comm_am,proc_price_pt_cabin.non_comm_am) as non_comm_am
        ,coalesce(proc_price_pt_price.proc_price_src_sys_nm,proc_price_pt_cabin.proc_price_src_sys_nm) as proc_price_src_sys_nm
        ,row_number() over(partition by coalesce(proc_price_pt_price.vyge_id,proc_price_pt_cabin.vyge_id)\
        ,coalesce(proc_price_pt_price.strm_typ_cd,proc_price_pt_cabin.strm_typ_cd)\
        ,coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt)
        order by  coalesce(proc_price_pt_price.txn_dt,proc_price_pt_cabin.txn_dt) desc
        ) as rank_num
        from driver_strm drvr
        left JOIN proc_price_pt_opn_price_calc_vw proc_price_pt_price
        on drvr.vyge_id = proc_price_pt_price.vyge_id
        and drvr.strm_typ_cd  = proc_price_pt_price.strm_typ_cd
        and drvr.txn_dt = proc_price_pt_price.txn_dt

        left JOIN proc_price_pt_opn_cabin_calc_vw proc_price_pt_cabin
        ON drvr.vyge_id = proc_price_pt_cabin.vyge_id
        and drvr.strm_typ_cd  = proc_price_pt_cabin.strm_typ_cd
        and drvr.txn_dt = proc_price_pt_cabin.txn_dt ) as main
        where main.rank_num = 1
        """)

        proc_price_pt_opn_ntr_gtr_calc_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_calc_vw")
        print("Completed: proc_price_pt_opn_ntr_gtr_calc_df")

        proc_price_pt_opn_gtr_tmp_df = spark.sql("""
                    SELECT
                    drvr.vyge_id,
                    drvr.strm_typ_cd,
                    drvr.ship_strm_ctgy_nm as ship_strm_ctgy_nm_temp_new,
                    drvr.txn_dt,
                    min(fcst.fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc,
                    min(fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn,
                    min(fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn,
                    min(fcst.fcst_comm_pc) as fcst_comm_pc,
                    sum((((ppp.vfd_am+ppp.non_comm_am)*2)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn)) +
                    (((ppp.vfa_extra_am+ppp.non_comm_am)*fcst.adlt_split)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn) *(fcst.fcst_gst_per_strm_cn - 2))+
                    (((ppp.vfc_extra_am+ppp.non_comm_am)*fcst.chld_split)*((strm.phys_invtry_strm_cn*fcst.fcst_ship_ocpncy_pc)-strm.ooo_strm_cn) *(fcst.fcst_gst_per_strm_cn - 2))) as grs_revenue,
                    sum((strm.phys_invtry_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ship_ocpncy_pc-drvr.vyge_drtn_nght_cn*strm.ooo_strm_cn)*fcst.fcst_gst_per_strm_cn +
                    (strm.ooo_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ooo_gst_per_strm_cn)) as grs_pcd
                    FROM driver_strm drvr 
                    inner join  ooo_consolidated_vw strm
                    on drvr.vyge_id = strm.vyge_id
                    AND drvr.strm_typ_cd = strm.strm_typ_cd
                    AND drvr.txn_dt = strm.txn_dt
                    AND upper(drvr.strm_typ_cd) not in ('IRG','XAM')
                    inner join  proc_price_pt_opn_ntr_gtr_calc_vw ppp
                    on drvr.vyge_id = ppp.vyge_id
                    AND drvr.strm_typ_cd = ppp.strm_typ_cd
                    AND drvr.txn_dt = ppp.txn_dt 
                    left outer join vyge_ship_fnc_dflt_fcst_vw fcst
                    on drvr.vyge_id = fcst.vyge_id
                    AND drvr.strm_typ_cd = fcst.strm_typ_cd
                    AND drvr.txn_dt = fcst.txn_dt 
                    group by drvr.vyge_id,
                    drvr.strm_typ_cd,
                    drvr.ship_strm_ctgy_nm,
                    drvr.txn_dt 
        
        """)

        proc_price_pt_opn_gtr_tmp_df.createOrReplaceTempView("proc_price_pt_opn_gtr_tmp_vw")
        print("Completed: proc_price_pt_opn_gtr_tmp_df")

        proc_price_pt_opn_gtr_df = spark.sql(""" select vyge_id,
        ship_strm_ctgy_nm_temp_new as ship_strm_ctgy_nm_temp,
        txn_dt,
        cast(sum(grs_revenue)/sum(grs_pcd) as decimal(12,2)) as opn_gtr_price_pd_am

        from proc_price_pt_opn_gtr_tmp_vw 
        group by vyge_id,
        ship_strm_ctgy_nm_temp_new,
        txn_dt 
        """)
        proc_price_pt_opn_gtr_df.createOrReplaceTempView("proc_price_pt_opn_gtr_vw")
        print("Completed: proc_price_pt_opn_gtr_df")

        proc_price_pt_opn_ntr_gtr_df = spark.sql("""
        SELECT proc_price_pt_opn_gtr_vw.vyge_id,
        proc_price_pt_opn_gtr_vw.ship_strm_ctgy_nm_temp as ship_strm_ctgy_nm_temp ,
        proc_price_pt_opn_gtr_vw.txn_dt as txn_date,
        proc_price_pt_opn_gtr_vw.opn_gtr_price_pd_am,
        cast(proc_price_pt_opn_gtr_vw.opn_gtr_price_pd_am * (1- (proc_price_pt_opn_gtr_tmp_vw.fcst_comm_pc)) as decimal(12,2)) as opn_ntr_price_pd_am
        FROM proc_price_pt_opn_gtr_vw join proc_price_pt_opn_gtr_tmp_vw
        on proc_price_pt_opn_gtr_vw.vyge_id = proc_price_pt_opn_gtr_tmp_vw.vyge_id 
        and proc_price_pt_opn_gtr_vw.ship_strm_ctgy_nm_temp = proc_price_pt_opn_gtr_tmp_vw.ship_strm_ctgy_nm_temp_new
        and proc_price_pt_opn_gtr_vw.txn_dt = proc_price_pt_opn_gtr_tmp_vw.txn_dt
        """).distinct()

        proc_price_pt_opn_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_vw")
        print("Completed: proc_price_pt_opn_ntr_gtr_df")

        #XXXXXXXXXXXXXXXXXXXXXXXXXX
        #RCMD_GTR_NTR
        #XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        vyge_strm_ctgy_dly_rcmd_df = spark.sql(""" 
        select distinct 
        inn.vyge_id
        ,inn.strm_typ_cd
        ,inn.txn_dt
        ,sum(inn.plan_cfdnc_lvl_am) as plan_cfdnc_lvl_am
        ,sum(inn.price_impct_lvl_am) as price_impct_lvl_am
        ,sum(inn.vfd_pd_am + non_comm_fare_am) as rcmd_vyge_gtr_pd_am
        ,sum(inn.vfa_pd_am + non_comm_fare_am) as rcmd_vyge_adlt_gtr_pd_am
        ,sum(inn.vfc_pd_am + non_comm_fare_am) as rcmd_vyge_chld_gtr_pd_am
        FROM(SELECT DISTINCT
        drvr.vyge_id
        ,drvr.app_vyge_id
        ,drvr.strm_typ_cd
        ,drvr.txn_dt 
        ,drvr.dy_bef_vyge_cn
        ,rcmd_dtl.dy_bef_vyge_rnge_strt_cn
        ,rcmd_dtl.dy_bef_vyge_rnge_end_cn
        ,rcmd_dtl.price_rcmd_run_dts
        ,rcmd_dtl.non_comm_fare_am
        ,rcmd_dtl.plan_cfdnc_lvl_am
        ,rcmd_dtl.price_impct_lvl_am
        ,rcmd_dtl.vfd_pd_am
        ,rcmd_dtl.vfa_pd_am
        ,rcmd_dtl.vfc_pd_am
        ,rank() over(partition by drvr.vyge_id, rcmd_dtl.strm_typ_cd, drvr.txn_dt order by rcmd_dtl.price_rcmd_run_dts desc) as strm_rank
        ,rank() over(partition by drvr.vyge_id, drvr.txn_dt order by rcmd_dtl.asofdate desc,rcmd_dtl.price_rcmd_run_dts desc) as txn_rank
        FROM driver_strm drvr INNER JOIN price_rcmd_dtl rcmd_dtl 
        ON drvr.app_vyge_id = rcmd_dtl.app_vyge_id
        AND drvr.strm_typ_cd = rcmd_dtl.strm_typ_cd
        AND drvr.txn_dt >= rcmd_dtl.asofdate 
        AND (dy_bef_vyge_cn between rcmd_dtl.dy_bef_vyge_rnge_strt_cn AND rcmd_dtl.dy_bef_vyge_rnge_end_cn)
        ) inn 
        WHERE inn.strm_rank = 1 AND inn.txn_rank = 1
        GROUP BY 1,2,3
        """)

        print("Completed: vyge_strm_ctgy_dly_rcmd_df")

        vyge_strm_ctgy_dly_rcmd_df.createOrReplaceTempView("vyge_strm_ctgy_dly_rcmd_vw")

        vyge_strm_ctgy_dly_rcmd_gtr_temp_df = spark.sql(""" 
        select distinct 
        drvr.vyge_id,
        drvr.strm_typ_cd,
        drvr.ship_strm_ctgy_nm as ship_strm_ctgy_nm_temp_new ,
        drvr.txn_dt,
        min(fcst.fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc,
        min(fcst.fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn,
        min(fcst.fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn,
        min(fcst.fcst_comm_pc) as fcst_comm_pc,
        sum((coalesce(rcmd.rcmd_vyge_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * 2 * ((strm.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn))
        +
        (coalesce(rcmd.rcmd_vyge_adlt_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * fcst.adlt_split * ((strm.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  * (fcst.fcst_gst_per_strm_cn  - 2)) 
        +
        (coalesce(rcmd.rcmd_vyge_chld_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * fcst.chld_split * ((strm.phys_invtry_strm_cn* fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  * (fcst.fcst_gst_per_strm_cn - 2))) as grs_rcmd_revenue, 

        sum((strm.phys_invtry_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ship_ocpncy_pc - drvr.vyge_drtn_nght_cn*strm.ooo_strm_cn)*fcst.fcst_gst_per_strm_cn +
        (strm.ooo_strm_cn*drvr.vyge_drtn_nght_cn*fcst.fcst_ooo_gst_per_strm_cn)) as grs_rcmd_pcd

        from driver_strm drvr 
        inner join ooo_consolidated_vw  strm
        on drvr.vyge_id = strm.vyge_id
        and drvr.strm_typ_cd = strm.strm_typ_cd
        and drvr.txn_dt = strm.txn_dt
        and upper(drvr.strm_typ_cd) not in ('IRG','XAM')

        inner join vyge_strm_ctgy_dly_rcmd_vw rcmd
        on drvr.vyge_id = rcmd.vyge_id
        and drvr.strm_typ_cd = rcmd.strm_typ_cd
        and drvr.txn_dt = rcmd.txn_dt

        left outer join vyge_ship_fnc_dflt_fcst_vw fcst
        on drvr.vyge_id = fcst.vyge_id
        and drvr.strm_typ_cd = fcst.strm_typ_cd
        and drvr.txn_dt = fcst.txn_dt 
        group by drvr.vyge_id,
        drvr.strm_typ_cd,
        drvr.ship_strm_ctgy_nm,
        drvr.txn_dt """)

        vyge_strm_ctgy_dly_rcmd_gtr_temp_df.createOrReplaceTempView("vyge_strm_ctgy_dly_rcmd_gtr_temp_vw")
        print("Completed: vyge_strm_ctgy_dly_rcmd_gtr_temp_df")

        proc_price_pt_rcmd_gtr_df = spark.sql(""" select vyge_id,
        ship_strm_ctgy_nm_temp_new as ship_strm_ctgy_nm_temp,
        txn_dt,
        cast(sum(grs_rcmd_revenue)/sum(grs_rcmd_pcd) as decimal(12,2)) as rcmd_gtr_price_pd_am

        from vyge_strm_ctgy_dly_rcmd_gtr_temp_vw 
        group by vyge_id,
        ship_strm_ctgy_nm_temp_new,
        txn_dt """)
        proc_price_pt_rcmd_gtr_df.createOrReplaceTempView("proc_price_pt_rcmd_gtr_vw")
        print("Completed: proc_price_pt_rcmd_gtr_df")
        vyge_strm_ctgy_dly_rcmd_ntr_gtr_df = spark.sql("""
        SELECT proc_price_pt_rcmd_gtr_vw.vyge_id,
        proc_price_pt_rcmd_gtr_vw.ship_strm_ctgy_nm_temp  as ship_strm_ctgy_nm_temp,
        proc_price_pt_rcmd_gtr_vw.txn_dt as txn_date,
        proc_price_pt_rcmd_gtr_vw.rcmd_gtr_price_pd_am as rcmd_vyge_gtr_price_pd_am,
        cast(proc_price_pt_rcmd_gtr_vw.rcmd_gtr_price_pd_am * (1- (vyge_strm_ctgy_dly_rcmd_gtr_temp_vw.fcst_comm_pc)) as decimal(12,2)) as rcmd_vyge_ntr_price_pd_am
        FROM proc_price_pt_rcmd_gtr_vw join vyge_strm_ctgy_dly_rcmd_gtr_temp_vw
        on proc_price_pt_rcmd_gtr_vw.vyge_id = vyge_strm_ctgy_dly_rcmd_gtr_temp_vw.vyge_id 
        and proc_price_pt_rcmd_gtr_vw.ship_strm_ctgy_nm_temp = vyge_strm_ctgy_dly_rcmd_gtr_temp_vw.ship_strm_ctgy_nm_temp_new
        and proc_price_pt_rcmd_gtr_vw.txn_dt = vyge_strm_ctgy_dly_rcmd_gtr_temp_vw.txn_dt
        """).distinct()

        vyge_strm_ctgy_dly_rcmd_ntr_gtr_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_ntr_gtr_vw")
        print("Completed: vyge_strm_ctgy_dly_rcmd_ntr_gtr_df")

        vyge_strm_typ_dly_rcmd_df = spark.sql("""
                                select
                                        inn.vyge_id
                                        ,inn.ship_strm_ctgy_nm
                                        ,inn.txn_dt
                                        ,sum(DISTINCT inn.plan_cfdnc_lvl_am) as plan_cfdnc_lvl_am
                                        ,sum( inn.price_impct_lvl_am) as price_impct_lvl_am
                                        ,sum(inn.vfd_pd_am + non_comm_fare_am) as rcmd_vyge_gtr_pd_am
                                        ,sum(inn.vfa_pd_am + non_comm_fare_am) as rcmd_vyge_adlt_gtr_pd_am
                                        ,sum(inn.vfc_pd_am + non_comm_fare_am) as rcmd_vyge_chld_gtr_pd_am
                                FROM(SELECT     DISTINCT
                                                drvr.vyge_id
                                                ,drvr.app_vyge_id
                                                ,drvr.ship_strm_ctgy_nm
                                                ,drvr.txn_dt
                                                ,drvr.dy_bef_vyge_cn
                                                ,rcmd_dtl.dy_bef_vyge_rnge_strt_cn
                                                ,rcmd_dtl.dy_bef_vyge_rnge_end_cn
                                                ,rcmd_dtl.price_rcmd_run_dts
                                                ,rcmd_dtl.non_comm_fare_am
                                                ,rcmd_dtl.plan_cfdnc_lvl_am
                                                ,rcmd_dtl.price_impct_lvl_am
                                                ,rcmd_dtl.vfd_pd_am
                                                ,rcmd_dtl.vfa_pd_am
                                                ,rcmd_dtl.vfc_pd_am
                                                ,rank() over(partition by drvr.vyge_id, drvr.txn_dt order by rcmd_dtl.price_rcmd_run_dts desc) as strm_rank
                                                ,rank() over(partition by drvr.vyge_id, drvr.txn_dt order by rcmd_dtl.asofdate desc,rcmd_dtl.price_rcmd_run_dts desc) as txn_rank
        
                                        FROM driver_strm drvr  inner join price_rcmd_dtl rcmd_dtl
                                        ON drvr.app_vyge_id = rcmd_dtl.app_vyge_id
                                        AND drvr.strm_typ_cd = rcmd_dtl.strm_typ_cd
                                        AND drvr.txn_dt >= rcmd_dtl.asofdate
                                        AND upper(drvr.strm_typ_cd) not in ('IRG','XAM')
                                        AND (dy_bef_vyge_cn between rcmd_dtl.dy_bef_vyge_rnge_strt_cn AND rcmd_dtl.dy_bef_vyge_rnge_end_cn)
                                        ) inn
                                WHERE inn.strm_rank = 1 AND inn.txn_rank = 1
                                GROUP BY 1,2,3
                                """).dropDuplicates()
        vyge_strm_typ_dly_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_vw")
        print("Completed: vyge_strm_typ_dly_rcmd_df")








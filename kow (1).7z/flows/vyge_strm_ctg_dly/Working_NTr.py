##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : Voyage StateRoom Type                                              #
# Author            : Kowshik Y                                                          #
# Date created      : 2018-08-26                                                         #
# Purpose           : To build the driver program                                        #
# Revision History  :                                                                    #
# Date           Author     Ref    Revision (Date in YYYYMMDD format)                    #
# 2018-08-26    kowshik Y   Chris                                                        #
#                                                                                        #
##########################################################################################


#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.DebugCount import *;
from pyspark.sql.types import *
import os, sys


class VygeStrmCtgDlyNtrGTR(object):

    @staticmethod
    def run_viz_vyge_gtr_ntr_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader, debug):
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################

        #############################################################################################
        #   Calculating Physical inventory counts by joining with driver on vyge_id, strm_typ_cd    #
        #############################################################################################

        # proc_price_pt_src_syn_nm_df = sql_context.sql(""" SELECT
        # 		PPP.VYGE_ID,
        # 		PPP.STRM_TYP_CD,
        # 		PPP.TXN_DT,
        # 		MIN(CASE
        # 		WHEN UPPER(PPP.PROC_PRICE_SRC_SYS_NM) = 'PRICING EXTRACT' THEN 1
        # 		WHEN UPPER(PPP.PROC_PRICE_SRC_SYS_NM) = 'CABIN CAT' THEN 2
        # 		END
        # 		) AS proc_price_src_sys_nb
        # 		FROM  PROC_PRICE_PT PPP  INNER JOIN vyge_strm_ctgy_strm_typ_cd_driver as strm_typ_driver
        # 			ON  strm_typ_driver.vyge_id = PPP.vyge_id
        # 			AND strm_typ_driver.SHIP_STRM_TYP_CD=PPP.STRM_TYP_CD
        # 			AND UPPER(PPP.PROC_PRICE_SRC_SYS_NM) IN ('PRICING EXTRACT','CABIN CAT')
        # 			AND PPP.TXN_DT >= strm_typ_driver.txn_dt
        # 			AND UPPER(PPP.SFB_NM) = 'PREVAIL'
        # 		GROUP BY  PPP.VYGE_ID,
        # 		PPP.STRM_TYP_CD,
        # 		PPP.TXN_DT """).dropDuplicates()
        proc_price_pt_src_syn_nm_df = sql_context.sql(""" SELECT
                                    PPP.VYGE_ID,
                                    PPP.STRM_TYP_CD,
                                    PPP.TXN_DT,
                                    MIN(CASE
                                    WHEN UPPER(PPP.PROC_PRICE_SRC_SYS_NM) = 'PRICING EXTRACT' THEN 1
                                    WHEN UPPER(PPP.PROC_PRICE_SRC_SYS_NM) = 'CABIN CAT' THEN 2
                                    END
                                    ) AS proc_price_src_sys_nb
                                    FROM  PROC_PRICE_PT PPP
                                    WHERE
                                    UPPER(PPP.PROC_PRICE_SRC_SYS_NM) IN ('PRICING EXTRACT','CABIN CAT')
                                    AND UPPER(PPP.SFB_NM) IN ('PREVAIL','GTY')
                                    GROUP BY  PPP.VYGE_ID,
                                    PPP.STRM_TYP_CD,
                                    PPP.TXN_DT """).distinct()
        proc_price_pt_src_syn_nm_df.createOrReplaceTempView("proc_price_pt_src_syn_nm_vw")
        print("Input Data ==> proc_price_pt_src_syn_nm_df & Count ==>", proc_price_pt_src_syn_nm_df.count())
        proc_price_pt_src_syn_nm_df.printSchema();
        proc_price_pt_src_syn_nm_df.show();
        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_src_syn_nm_df, "proc_price_pt_src_syn_nm")

        vyge_fnc_fcst_var_temp_df = sql_context.sql("""
    		select *,
    			coalesce(max(data_ld_dts) over(partition by ship_cd,vyge_strt_dt order by data_ld_dts 
    		asc rows between 1 following and 1 following
    		),
    		CAST('9999-12-31 00:00:00.000000' as timestamp)) as vrsn_end_dts
    		from vyge_fnc_fcst_var_vw 
    		""").dropDuplicates()

        vyge_fnc_fcst_var_temp_df.createOrReplaceTempView("vyge_fnc_fcst_var_temp_vw")

        if debug == 1:
            DebugCount.debug_counts(vyge_fnc_fcst_var_temp_df, "vyge_fnc_fcst_var_temp_vw")

        vyge_ship_fnc_dflt_fcst_df = sql_context.sql(""" select
    		drvr.vyge_id
    		,drvr.txn_dt
    		,drvr.ship_cd
    		,drvr.ship_strm_ctgy_nm as ship_strm_ctgy_nm_new
    		,strm_typ_driver.SHIP_STRM_TYP_CD
    		,coalesce(vffc.fcst_ship_ocpncy_pc,dflt.fcst_ship_ocpncy_pc) as fcst_ship_ocpncy_pc
    		,coalesce(vffc.fcst_comm_pc,dflt.fcst_comm_pc) as fcst_comm_pc
    		,coalesce(vffc.fcst_gst_per_strm_cn,dflt.fcst_gst_per_strm_cn) as fcst_gst_per_strm_cn
    		,coalesce(vffc.fcst_ooo_gst_per_strm_cn, dflt.fcst_ooo_gst_per_strm_cn) as fcst_ooo_gst_per_strm_cn
    		,coalesce(vffc.vyge_adlt_split_pc,dflt.vyge_adlt_split_pc) as adlt_split
    		,coalesce(vffc.vyge_chld_split_pc,dflt.vyge_chld_split_pc) as chld_split		

    	    from driver drvr INNER JOIN vyge_strm_ctgy_strm_typ_cd_driver as strm_typ_driver
    			ON  drvr.vyge_id = strm_typ_driver.vyge_id
    			and drvr.ship_strm_ctgy_nm = strm_typ_driver.SHIP_STRM_CTGY_NM
    			and drvr.txn_dt = strm_typ_driver.txn_dt

    	inner join dflt_ship_fnc_fcst_vw dflt				
    		on dflt.ship_cd = drvr.ship_cd
    		and dflt.dflt_ship_fnc_fcst_strt_dts <= drvr.txn_dt
    		and dflt.dflt_ship_fnc_fcst_end_dts > drvr.txn_dt
    		and dflt.lgcl_del_in = 'N' 				
    	left outer join vyge_fnc_fcst_var_temp_vw vffc
    		on drvr.ship_cd = vffc.ship_cd
    		and drvr.vyge_dprt_dt = vffc.vyge_strt_dt
    		and vffc.vrsn_end_dts = '9999-12-31 00:00:00.000000'  """).dropDuplicates()

        vyge_ship_fnc_dflt_fcst_df.createOrReplaceTempView("vyge_ship_fnc_dflt_fcst_vw")
        print("vyge_ship_fnc_dflt_fcst_df & Count ()", vyge_ship_fnc_dflt_fcst_df.count())
        vyge_ship_fnc_dflt_fcst_df.printSchema()
        vyge_ship_fnc_dflt_fcst_df.show()

        if debug == 1:
            DebugCount.debug_counts(vyge_ship_fnc_dflt_fcst_df, "vyge_ship_fnc_dflt_fcst_vw")

        #########################################################
        #  CALCULATE GTR_PRICE_PD_AM & NTR_PRICE_PD_AM METRICS  #
        #########################################################

        proc_price_pt_dates_df = sql_context.sql(""" 
    		select
    			ppp_in.vyge_id
    			,ppp_in.strm_typ_cd
    			,ppp_in.txn_dt
    			,mn_txn_dt_ppp
    			,mx_txn_dt_ppp
    			,atr.vyge_init_bkng_dt as init_bkng_dt
    		from
    			(
    			select 
    				drvr.vyge_id
    				,drvr.txn_dt
    				,drvr.SHIP_STRM_TYP_CD as strm_typ_cd
    				,min(ppp.txn_dt) as mn_txn_dt_ppp
    				,max(ppp.txn_dt) as mx_txn_dt_ppp			
    			from vyge_strm_ctgy_strm_typ_cd_driver drvr inner join 
    				( select
    				sub_ppp1.vyge_id
    				,sub_ppp1.strm_typ_cd
    				,sub_ppp1.pp_src_sys_nm as proc_price_src_sys_nm
    				,sub_ppp1.txn_dt			
    				from 
    			(
    			select
    			sub_ppp.vyge_id,
    			sub_ppp.strm_typ_cd,
    			sub_ppp.txn_dt as txn_dt, 
    			case
    			when UPPER(sub_ppp.proc_price_src_sys_nb) = 1 then 'PRICING EXTRACT'
    			when UPPER(sub_ppp.proc_price_src_sys_nb) = 2 then 'CABIN CAT'
    			end as pp_src_sys_nm
    			from proc_price_pt_src_syn_nm_vw sub_ppp) sub_ppp1
    			inner join proc_price_pt ppp
    			on ppp.vyge_id = sub_ppp1.vyge_id
    			and ppp.strm_typ_cd = sub_ppp1.strm_typ_cd
    			and ppp.txn_dt = sub_ppp1.txn_dt
    			and UPPER(ppp.proc_price_src_sys_nm) = UPPER(sub_ppp1.pp_src_sys_nm)

    			) ppp

    			on drvr.vyge_id = ppp.vyge_id
    			and drvr.SHIP_STRM_TYP_CD = ppp.strm_typ_cd
    			and drvr.txn_dt >= ppp.txn_dt
    			group by 1,2,3
    			) ppp_in
    			left outer join vyge_attr atr
    			on ppp_in.vyge_id = atr.vyge_id
    			and ppp_in.txn_dt >= atr.vrsn_strt_dts
    			and ppp_in.txn_dt < atr.vrsn_end_dts
    			 """).dropDuplicates()

        proc_price_pt_dates_df.createOrReplaceTempView("proc_price_pt_dates_vw")
        print("proc_price_pt_dates_df & count ", proc_price_pt_dates_df.count())
        proc_price_pt_dates_df.printSchema();
        proc_price_pt_dates_df.show();

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_dates_df, "proc_price_pt_dates_vw")

        proc_price_pt_mtrics_max_df = sql_context.sql("""
    		select 
    		drvr.vyge_id
    		,drvr.SHIP_STRM_TYP_CD as strm_typ_cd
    		,drvr.txn_dt
    		,max(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfd_am else null end) as mx_vfd_am
    		,max(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfa_extra_am else null end) as mx_vfa_extra_am
    		,max(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfc_extra_am else null end) as mx_vfc_extra_am
    		,max(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.non_comm_am else null end) as mx_non_comm_am

    		,max(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfd_am else null end) as mn_vfd_am
    		,max(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfa_extra_am else null end) as mn_vfa_extra_am
    		,max(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfc_extra_am else null end) as mn_vfc_extra_am
    		,max(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.non_comm_am else null end) as mn_non_comm_am

    		,max(case when init_bkng_dt = ppp.txn_dt then ppp.vfd_am else null end) as init_vfd_am
    		,max(case when init_bkng_dt = ppp.txn_dt then ppp.vfa_extra_am else null end) as init_vfa_extra_am
    		,max(case when init_bkng_dt = ppp.txn_dt then ppp.vfc_extra_am else null end) as init_vfc_extra_am
    		,max(case when init_bkng_dt = ppp.txn_dt then ppp.non_comm_am else null end) as init_non_comm_am

    		from vyge_strm_ctgy_strm_typ_cd_driver drvr
    		inner join proc_price_pt_dates_vw ppp_dates
    		on drvr.vyge_id = ppp_dates.vyge_id
    		and drvr.SHIP_STRM_TYP_CD = ppp_dates.strm_typ_cd
    		and drvr.txn_dt = ppp_dates.txn_dt
    		inner join 
    		( select
    		sub_ppp1.vyge_id
    		,sub_ppp1.strm_typ_cd
    		,sub_ppp1.pp_src_sys_nm as proc_price_src_sys_nm
    		,sub_ppp1.txn_dt
    		,sub_ppp1.vfd_am
    		,sub_ppp1.vfa_extra_am
    		,sub_ppp1.vfc_extra_am
    		,sub_ppp1.non_comm_am
    		from 
    		(
    		select
    		sub_ppp.vyge_id,
    		sub_ppp.strm_typ_cd,
    		sub_ppp.txn_dt as txn_dt,
    		sub_ppp.vfd_am,
    		sub_ppp.vfa_extra_am,
    		sub_ppp.vfc_extra_am,
    		sub_ppp.non_comm_am,
    		case
    		when sub_ppp.proc_price_src_sys_nb = 1 then 'PRICING EXTRACT'
    		when sub_ppp.proc_price_src_sys_nb = 2 then 'CABIN CAT'
    		end as pp_src_sys_nm
    		from(
    		select
    		ppp.vyge_id
    		,ppp.strm_typ_cd
    		,min( case
    		when upper(ppp.proc_price_src_sys_nm) = 'PRICING EXTRACT' then 1
    		when upper(ppp.proc_price_src_sys_nm) = 'CABIN CAT' then 2
    		end) as proc_price_src_sys_nb
    		,ppp.txn_dt
    		,vfd_am
    		,vfa_extra_am
    		,vfc_extra_am
    		,non_comm_am
    		from PROC_PRICE_PT ppp
    		where upper(ppp.proc_price_src_sys_nm) in ('PRICING EXTRACT','CABIN CAT')
    		and upper(ppp.sfb_nm) = 'PREVAIL'
    		and upper(ppp.strm_typ_cd) not in ('XAM','IRG') 
    		group by 1,2,4,5,6,7,8
    		)sub_ppp
    		)sub_ppp1
    		inner join proc_price_pt ppp
    		on ppp.vyge_id = sub_ppp1.vyge_id
    		and ppp.strm_typ_cd = sub_ppp1.strm_typ_cd
    		and ppp.txn_dt = sub_ppp1.txn_dt
    		and UPPER(ppp.proc_price_src_sys_nm) = UPPER(sub_ppp1.pp_src_sys_nm)
    		group by 1,2,3,4,5,6,7,8
    		) ppp
    		on drvr.vyge_id = ppp.vyge_id
    		and drvr.SHIP_STRM_TYP_CD = ppp.strm_typ_cd
    		and drvr.txn_dt >= ppp.txn_dt
    		GROUP BY 1,2,3
    		""").dropDuplicates()
        proc_price_pt_mtrics_max_df.createOrReplaceTempView("proc_price_pt_mtrics_max_vw")
        print("proc_price_pt_mtrics_max_df &count ==>", proc_price_pt_mtrics_max_df.count())
        proc_price_pt_mtrics_max_df.show()
        proc_price_pt_mtrics_max_df.printSchema();

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_mtrics_max_df, "proc_price_pt_mtrics_max_vw")

        proc_price_pt_gtr_df = sql_context.sql(""" 
    		SELECT
    			gtr_calc.vyge_id,
    			gtr_calc.ship_strm_ctgy_nm,
    			gtr_calc.txn_dt,
    			gtr_calc.vfd_temp * gtr_calc.vfd_helper as vfd,
    			gtr_calc.vf3_8_adlt_temp * gtr_calc.vf3_8_adlt_helper as vf3_8_adlt,
    			gtr_calc.vf3_8_chld_temp * gtr_calc.vf3_8_chld_helper as vf3_8_chld,
    			gtr_calc.pcd,	
    			ntr_price_pd_am_temp,
    			gtr_calc.phys_invtry_strm_cn,
    			 gtr_calc.fcst_ship_ocpncy_pc,
    			 gtr_calc.ooo_strm_cn,
    			 gtr_calc.vyge_drtn_nght_cn,
    			cast(cast((gtr_calc.vfd_temp * gtr_calc.vfd_helper) + (gtr_calc.vf3_8_adlt_temp * gtr_calc.vf3_8_adlt_helper) +
    			 (gtr_calc.vf3_8_chld_temp * gtr_calc.vf3_8_chld_helper) as decimal(25,8)) / coalesce(gtr_calc.pcd,0.0) as decimal(12,2)) 
    			as gtr_price_pd_am
    		FROM 
    			(SELECT
    			drvr.vyge_id,
    			drvr.ship_strm_ctgy_nm,
    			drvr.txn_dt,
    			phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn,
    			 fcst.fcst_ship_ocpncy_pc,
    			 strm.ooo_strm_cn,
    			 drvr.vyge_drtn_nght_cn,
    			2 * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn) as vfd_helper,
    			fcst.adlt_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn) *
    			 (fcst.fcst_gst_per_strm_cn - 2) as vf3_8_adlt_helper,
    			(coalesce(ppp.mx_vfd_am,0.0) + coalesce(ppp.mx_non_comm_am,0.0)) as vfd_temp,
    			(coalesce(ppp.mx_vfa_extra_am,0.0) + coalesce(ppp.mx_non_comm_am,0.0)) as vf3_8_adlt_temp,
    			(coalesce(ppp.mx_vfc_extra_am,0.0) + coalesce(ppp.mx_non_comm_am,0.0)) as vf3_8_chld_temp,
    			fcst.chld_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc)- strm.ooo_strm_cn) *
    			(fcst.fcst_gst_per_strm_cn - 2) as vf3_8_chld_helper,
    			(
    			(
    			(
    			cast(phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn as decimal(15,8)) * cast(fcst.fcst_ship_ocpncy_pc as decimal(15,8))
    			) - strm.ooo_strm_cn
    			)
    			*
    			drvr.vyge_drtn_nght_cn
    			*
    			cast(fcst.fcst_gst_per_strm_cn as decimal(15,8))
    			)
    			+
    			(
    			strm.ooo_strm_cn
    			*
    			drvr.vyge_drtn_nght_cn
    			*
    			cast(fcst.fcst_ooo_gst_per_strm_cn as decimal(15,8))
    			) as pcd,
    			(1 - fcst.fcst_comm_pc) as ntr_price_pd_am_temp

    			from driver drvr inner join ship_strm_typ_ext1 strm_ext
                    on driver.ship_cd = strm_ext.ship_cd
                     AND driver.SHIP_STRM_CTGY_NM= SHIP_CTGY_NM
                    and driver.txn_dt >=strm_ext.vrsn_strt_dts
                    and driver.txn_dt < strm_ext.vrsn_end_dts

    			inner join  ooo_vyg_inventory_cnt_driver_df_ntr_gtr strm
    			on drvr.vyge_id = strm.vyge_id
    			and drvr.ship_strm_ctgy_nm = strm.ship_strm_ctgy_nm_new
    			and strm_ext.SHIP_STRM_TYP_CD = strm.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = strm.txn_dt
    			and strm_ext.SHIP_STRM_TYP_CD NOT IN ('XAM','IRG')

    			inner join  phys_invtry_strm_cn_df_ntr as phys_invtry_strm_cn_df_ntr
    			on drvr.vyge_id = phys_invtry_strm_cn_df_ntr.vyge_id
    			and drvr.ship_strm_ctgy_nm = phys_invtry_strm_cn_df_ntr.ship_strm_ctgy_nm_new
    			and strm_ext.SHIP_STRM_TYP_CD = phys_invtry_strm_cn_df_ntr.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = phys_invtry_strm_cn_df_ntr.txn_dt

    			inner join  proc_price_pt_mtrics_max_vw ppp
    			on drvr.vyge_id = ppp.vyge_id
    			and strm_ext.SHIP_STRM_TYP_CD = ppp.strm_typ_cd
    			and drvr.txn_dt = ppp.txn_dt

    			inner join vyge_ship_fnc_dflt_fcst_vw fcst
    			on drvr.vyge_id = fcst.vyge_id
    			and drvr.txn_dt = fcst.txn_dt
    			and drvr.ship_strm_ctgy_nm = fcst.ship_strm_ctgy_nm_new
    			and strm_ext.SHIP_STRM_TYP_CD = fcst.SHIP_STRM_TYP_CD
    			) gtr_calc

    			""").dropDuplicates()
        proc_price_pt_gtr_df.createOrReplaceTempView("proc_price_pt_gtr_vw")
        print("proc_price_pt_gtr_df count is ==>", proc_price_pt_gtr_df.count())
        proc_price_pt_gtr_df.printSchema();
        proc_price_pt_gtr_df.show();

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_gtr_df, "proc_price_pt_gtr_vw")

        proc_price_pt_ntr_gtr_df = sql_context.sql("""
    				SELECT vyge_id,
    				ship_strm_ctgy_nm ,
    				txn_dt as txn_dt,
    				gtr_price_pd_am,
    				cast(gtr_price_pd_am * ntr_price_pd_am_temp  as decimal(12,2)) as ntr_price_pd_am
    				FROM proc_price_pt_gtr_vw
    				""").dropDuplicates()

        proc_price_pt_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_ntr_gtr_vw")
        folder_name = "%s%s" % ("gtr_ntr_df/partition_dt=", end_dt)
        data_loader.write_data("dm", folder_name, None, proc_price_pt_ntr_gtr_df)
        print("proc_price_pt_ntr_gtr_df ==DF & Final Count () ", proc_price_pt_ntr_gtr_df.count())
        proc_price_pt_ntr_gtr_df.printSchema()
        proc_price_pt_ntr_gtr_df.show()

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_ntr_gtr_df, "proc_price_pt_ntr_gtr_vw")

        #################################################################
        #  CALCULATE OPN_GTR_PRICE_PD_AM & OPN_NTR_PRICE_PD_AM METRICS  #
        #################################################################

        proc_price_pt_opn_ntr_gtr_calc_df = sql_context.sql("""
    		SELECT DISTINCT 
    			opn_gtr_ntr_calc.*
    		FROM (
    			SELECT 
    			drvr.vyge_id
    			,ppp.strm_typ_cd
    			,drvr.ship_strm_ctgy_nm
    			,ppp.txn_dt as txn_dt_ppt
    			,drvr.txn_dt as txn_dt
    			,ppp.vfd_am
    			,ppp.vfa_extra_am
    			,ppp.vfc_extra_am
    			,ppp.non_comm_am
    			,vatt.vyge_init_bkng_dt
    			,vatt.vyge_dprt_dt
    			,datediff(ppp.txn_dt,vatt.vyge_init_bkng_dt) as diff
    			,CASE WHEN vatt.vyge_init_bkng_dt = ppp.txn_dt THEN 0 
    			WHEN date_add(vatt.vyge_init_bkng_dt, 1) = ppp.txn_dt THEN 0
    			ELSE 1 END as ind,
    			row_number() over(partition by drvr.vyge_id, ppp.strm_typ_cd, drvr.txn_dt order by ppp.txn_dt asc) as rank_asc
    			FROM 
    			(
    			SELECT
    			sub_ppp1.vyge_id
    			,sub_ppp1.strm_typ_cd
    			,sub_ppp1.pp_src_sys_nm as proc_price_src_sys_nb
    			,sub_ppp1.txn_dt
    			,ppp.vfd_am
    			,ppp.vfa_extra_am
    			,ppp.vfc_extra_am
    			,ppp.non_comm_am
    			FROM 
    			(
    			SELECT
    			sub_ppp.vyge_id,
    			sub_ppp.strm_typ_cd,
    			sub_ppp.txn_dt as txn_dt, 
    			CASE
    			WHEN sub_ppp.proc_price_src_sys_nb = 1 THEN 'PRICING EXTRACT'
    			WHEN sub_ppp.proc_price_src_sys_nb = 2 THEN 'CABIN CAT'
    			END as pp_src_sys_nm
    			FROM proc_price_pt_src_syn_nm_vw sub_ppp
    			)sub_ppp1
    			INNER JOIN PROC_PRICE_PT ppp
    			on ppp.vyge_id = sub_ppp1.vyge_id
    			AND ppp.strm_typ_cd = sub_ppp1.strm_typ_cd
    			AND ppp.txn_dt = sub_ppp1.txn_dt
    			AND upper(ppp.proc_price_src_sys_nm) = upper(sub_ppp1.pp_src_sys_nm)
    			group by 1,2,3,4,5,6,7,8
    			) ppp 
    		INNER JOIN  vyge_strm_ctgy_strm_typ_cd_driver drvr
    			on ppp.vyge_id = drvr.vyge_id
    			AND ppp.strm_typ_cd = drvr.SHIP_STRM_TYP_CD
    			AND drvr.txn_dt >= ppp.txn_dt
    		INNER JOIN vyge_attr vatt
    			on vatt.vyge_id = drvr.vyge_id
    			AND drvr.txn_dt >= date(vatt.vrsn_strt_dts)
    			AND drvr.txn_dt < date(vatt.vrsn_end_dts)) opn_gtr_ntr_calc
    		WHERE opn_gtr_ntr_calc.ind = 0
    		AND opn_gtr_ntr_calc.rank_asc = 1 
    		""").dropDuplicates()

        print(" ===>proc_price_pt_opn_ntr_gtr_calc_df & count () <<===", proc_price_pt_opn_ntr_gtr_calc_df.count());
        proc_price_pt_opn_ntr_gtr_calc_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_calc_vw")
        proc_price_pt_opn_ntr_gtr_calc_df.printSchema();
        proc_price_pt_opn_ntr_gtr_calc_df.show();

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_opn_ntr_gtr_calc_df, "proc_price_pt_opn_ntr_gtr_calc_vw")

        # proc_price_pt_opn_ntr_gtr_sbset_df = sql_context.sql("""
        #
        # SELECT DISTINCT
        # 	drvr.vyge_id,
        # 	drvr.strm_typ_cd,
        # 	drvr.txn_dt,
        # 	MAX(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfd_am else null end) as mx_vfd_am,
        # 	MAX(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfa_extra_am else null end) as mx_vfa_extra_am,
        # 	MAX(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.vfc_extra_am else null end) as mx_vfc_extra_am,
        # 	MAX(case when mx_txn_dt_ppp = ppp.txn_dt then ppp.non_comm_am else null end) as mx_non_comm_am,
        #
        # 	MAX(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfd_am else null end) as mn_vfd_am,
        # 	MAX(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfa_extra_am else null end) as mn_vfa_extra_am,
        # 	MAX(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.vfc_extra_am else null end) as mn_vfc_extra_am,
        # 	MAX(case when mn_txn_dt_ppp = ppp.txn_dt then ppp.non_comm_am else null end) as mn_non_comm_am,
        #
        # 	MAX(case when init_bkng_dt = ppp.txn_dt then ppp.vfd_am else null end) as init_vfd_am,
        # 	MAX(case when init_bkng_dt = ppp.txn_dt then ppp.vfa_extra_am else null end) as init_vfa_extra_am,
        # 	MAX(case when init_bkng_dt = ppp.txn_dt then ppp.vfc_extra_am else null end) as init_vfc_extra_am,
        # 	MAX(case when init_bkng_dt = ppp.txn_dt then ppp.non_comm_am else null end) as init_non_comm_am
        # FROM driver drvr
        # INNER JOIN proc_price_pt_dates_vw ppp_dates
        # 	on drvr.vyge_id = ppp_dates.vyge_id
        # 	AND drvr.strm_typ_cd = ppp_dates.strm_typ_cd
        # 	AND drvr.txn_dt = ppp_dates.txn_dt
        # INNER JOIN proc_price_pt_opn_ntr_gtr_calc_vw ppp
        # 	on  ppp_dates.vyge_id = ppp.vyge_id
        # 	AND drvr.strm_typ_cd = ppp.strm_typ_cd
        # 	AND ppp_dates.txn_dt >= ppp.txn_dt
        # group by 1,2,3	""").dropDuplicates()
        # print("===>proc_price_pt_opn_ntr_gtr_sbset_df<<===")
        # proc_price_pt_opn_ntr_gtr_sbset_df.printSchema();
        # proc_price_pt_opn_ntr_gtr_sbset_df.show();
        #
        # proc_price_pt_opn_ntr_gtr_sbset_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_sbset_vw")
        # if debug == 1:
        #     DebugCount.debug_counts(proc_price_pt_opn_ntr_gtr_sbset_df, "proc_price_pt_opn_ntr_gtr_sbset_vw")

        proc_price_pt_opn_gtr_df = sql_context.sql("""
    		SELECT DISTINCT  
    			opn_gtr_calc.vyge_id,
    			opn_gtr_calc.ship_strm_ctgy_nm,
    			opn_gtr_calc.txn_dt,
    			opn_gtr_calc.opn_ntr_price_pd_am_temp,
    			opn_gtr_calc.opn_vfd_temp * opn_gtr_calc.vfd_helper as opn_vfd,
    			opn_gtr_calc.opn_vf3_8_adlt_temp * opn_gtr_calc.vf3_8_adlt_helper as opn_vf3_8_adlt,
    			opn_gtr_calc.opn_vf3_8_chld_temp * opn_gtr_calc.vf3_8_chld_helper as opn_vf3_8_chld,
    			cast(cast(((opn_gtr_calc.opn_vfd_temp * opn_gtr_calc.vfd_helper) + (opn_gtr_calc.opn_vf3_8_adlt_temp * 
    			opn_gtr_calc.vf3_8_adlt_helper) + (opn_gtr_calc.opn_vf3_8_chld_temp * opn_gtr_calc.vf3_8_chld_helper)) 
    			as decimal(25,8)) / coalesce(opn_gtr_calc.pcd,0.0) as decimal(12,2)) as opn_gtr_price_pd_am
    		FROM
    			(SELECT
    				drvr.vyge_id,
    				drvr.ship_strm_ctgy_nm,
    				drvr.txn_dt,
    				2 * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - STRM.ooo_strm_cn) as vfd_helper, 
    				fcst.adlt_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  
    				* (fcst.fcst_gst_per_strm_cn - 2) as vf3_8_adlt_helper, 
    				fcst.chld_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc)- strm.ooo_strm_cn)  
    				* (fcst.fcst_gst_per_strm_cn - 2) as vf3_8_chld_helper, 
    				(coalesce(ppp.vfd_am,0.0) + coalesce(ppp.non_comm_am, 0.0)) as opn_vfd_temp ,
    				(coalesce(ppp.vfa_extra_am,0.0) + coalesce(ppp.non_comm_am,0.0))  as opn_vf3_8_adlt_temp,
    				(coalesce(ppp.vfc_extra_am,0.0) + coalesce(ppp.non_comm_am,0.0))  as opn_vf3_8_chld_temp,
    				(
    				(
    				(
    				cast(phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn as decimal(15,8)) * cast(fcst.fcst_ship_ocpncy_pc as decimal(15,8))
    				) - strm.ooo_strm_cn
    				) 
    				* 
    				drvr.vyge_drtn_nght_cn 
    				* 
    				cast(fcst.fcst_gst_per_strm_cn as decimal(15,8))
    				)
    				+ 
    				(
    				strm.ooo_strm_cn
    				*
    				drvr.vyge_drtn_nght_cn
    				*
    				cast(fcst.fcst_ooo_gst_per_strm_cn as decimal(15,8))
    				) as pcd ,
    				(1 - fcst.fcst_comm_pc) as opn_ntr_price_pd_am_temp

    			from driver drvr inner join ship_strm_typ_ext1 strm_ext
                    on driver.ship_cd = strm_ext.ship_cd
                     AND driver.SHIP_STRM_CTGY_NM= SHIP_CTGY_NM
                    and driver.txn_dt >=strm_ext.vrsn_strt_dts
                    and driver.txn_dt < strm_ext.vrsn_end_dts



    			inner join  ooo_vyg_inventory_cnt_driver_df_ntr_gtr strm
    			on drvr.vyge_id = strm.vyge_id
    			and drvr.ship_strm_ctgy_nm = strm.ship_strm_ctgy_nm_new
    			and strm_ext.SHIP_STRM_TYP_CD = strm.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = strm.txn_dt

    			inner join  phys_invtry_strm_cn_df_ntr as phys_invtry_strm_cn_df_ntr
    			on drvr.vyge_id = phys_invtry_strm_cn_df_ntr.vyge_id
    			and drvr.ship_strm_ctgy_nm = phys_invtry_strm_cn_df_ntr.ship_strm_ctgy_nm_new
    			and strm_ext.SHIP_STRM_TYP_CD = phys_invtry_strm_cn_df_ntr.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = phys_invtry_strm_cn_df_ntr.txn_dt

    			inner join  proc_price_pt_opn_ntr_gtr_calc_vw ppp
    				on drvr.vyge_id = ppp.vyge_id
                    and strm_ext.SHIP_STRM_TYP_CD = ppp.strm_typ_cd
    				AND drvr.txn_dt = ppp.txn_dt 

    			inner join vyge_ship_fnc_dflt_fcst_vw fcst
    				on drvr.vyge_id = fcst.vyge_id
    				AND drvr.txn_dt = fcst.txn_dt 
    				and drvr.ship_strm_ctgy_nm = fcst.ship_strm_ctgy_nm_new
    			    and strm_ext.SHIP_STRM_TYP_CD = fcst.SHIP_STRM_TYP_CD
    				) 
    		opn_gtr_calc 
    		""").dropDuplicates()

        proc_price_pt_opn_gtr_df.createOrReplaceTempView("proc_price_pt_opn_gtr_vw")
        print("proc_price_pt_opn_gtr_df  count ===>", proc_price_pt_opn_gtr_df.count())
        proc_price_pt_opn_gtr_df.printSchema();
        proc_price_pt_opn_gtr_df.show();

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_opn_gtr_df, "proc_price_pt_opn_gtr_vw")

        proc_price_pt_opn_ntr_gtr_df = sql_context.sql("""
    		SELECT DISTINCT 
    			vyge_id,
    			ship_strm_ctgy_nm,
    			txn_dt,
    			opn_gtr_price_pd_am,
    			cast(opn_gtr_price_pd_am * opn_ntr_price_pd_am_temp  as decimal(12,2)) as opn_ntr_price_pd_am
    		FROM proc_price_pt_opn_gtr_vw
    		""").dropDuplicates()
        print("===>> proc_price_pt_opn_ntr_gtr_df &count  <<<", proc_price_pt_opn_ntr_gtr_df.count())
        proc_price_pt_opn_ntr_gtr_df.printSchema()
        proc_price_pt_opn_ntr_gtr_df.show();
        folder_name = "%s%s" % ("opngtr_opnntr_df/partition_dt=", end_dt)
        data_loader.write_data("dm", folder_name, None, proc_price_pt_opn_ntr_gtr_df)
        proc_price_pt_opn_ntr_gtr_df.createOrReplaceTempView("proc_price_pt_opn_ntr_gtr_vw")

        if debug == 1:
            DebugCount.debug_counts(proc_price_pt_opn_ntr_gtr_df, "proc_price_pt_opn_ntr_gtr_vw")
        vyge_strm_typ_dly_rcmd_df = sql_context.sql(""" 
                    		select 
                    			inn.vyge_id
                    			,inn.strm_typ_cd
                    			,inn.txn_dt
                    			,sum(DISTINCT inn.plan_cfdnc_lvl_am) as plan_cfdnc_lvl_am
                    			,sum( inn.price_impct_lvl_am) as price_impct_lvl_am
                    			,sum(inn.vfd_pd_am + non_comm_fare_am) as rcmd_vyge_gtr_pd_am
                    			,sum(inn.vfa_pd_am + non_comm_fare_am) as rcmd_vyge_adlt_gtr_pd_am
                    			,sum(inn.vfc_pd_am + non_comm_fare_am) as rcmd_vyge_chld_gtr_pd_am
                    		FROM(SELECT	DISTINCT
                    				drvr.vyge_id
                    				,drvr.app_vyge_id
                    				,drvr.ship_strm_ctgy_nm
                    				,rcmd_dtl.strm_typ_cd
                    				,drvr.txn_dt 
                    				,drvr.dy_bef_vyge_cn
                    				,rcmd_dtl.dy_bef_vyge_rnge_strt_cn
                    				,rcmd_dtl.dy_bef_vyge_rnge_end_cn
                    				,rcmd_dtl.price_rcmd_run_dts
                    				,rcmd_dtl.non_comm_fare_am
                    				,rcmd_dtl.plan_cfdnc_lvl_am
                    				,rcmd_dtl.price_impct_lvl_am
                    				,rcmd_dtl.vfd_pd_am
                    				,rcmd_dtl.vfa_pd_am
                    				,rcmd_dtl.vfc_pd_am
                    				,rank() over(partition by drvr.vyge_id, drvr.txn_dt order by rcmd_dtl.price_rcmd_run_dts desc) as strm_rank
                    				,rank() over(partition by drvr.vyge_id, drvr.txn_dt order by rcmd_dtl.asofdate desc,rcmd_dtl.price_rcmd_run_dts desc) as txn_rank

                    			FROM driver drvr INNER JOIN vyge_strm_ctgy_strm_typ_cd_driver as strm_typ_driver
                                ON  drvr.vyge_id = strm_typ_driver.vyge_id
                                and drvr.ship_strm_ctgy_nm = strm_typ_driver.SHIP_STRM_CTGY_NM
                                and drvr.txn_dt = strm_typ_driver.txn_dt

                    			INNER JOIN price_rcmd_dtl rcmd_dtl 
                    			ON drvr.app_vyge_id = rcmd_dtl.app_vyge_id
                    			AND strm_typ_driver.SHIP_STRM_TYP_CD = rcmd_dtl.strm_typ_cd
                    			AND drvr.txn_dt >= rcmd_dtl.asofdate 
                    			AND (dy_bef_vyge_cn between rcmd_dtl.dy_bef_vyge_rnge_strt_cn AND rcmd_dtl.dy_bef_vyge_rnge_end_cn)
                    			) inn 
                    		WHERE inn.strm_rank = 1 AND inn.txn_rank = 1
                    		GROUP BY 1,2,3
                    		""").dropDuplicates()

        vyge_strm_typ_dly_rcmd_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_vw")
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_rcmd_df, "vyge_strm_typ_dly_rcmd_vw")

        vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df = sql_context.sql(""" 

    		select distinct
    			rcmd_temp.vyge_id,
    			rcmd_temp.strm_typ_cd,
    			rcmd_temp.ship_strm_ctgy_nm,
    			rcmd_temp.txn_dt,
    			rcmd_temp.fcst_comm_pc,
    			case when rcmd_temp.pcd is null then null when  rcmd_temp.pcd = 0 then 0.0 
    			else cast(cast((rcmd_temp.vfd + rcmd_temp.vf3_8_adlt + rcmd_temp.vf3_8_chld) as decimal(12,2)) /coalesce(rcmd_temp.pcd,0.0) 
    			as decimal(12,2)) end as rcmd_vyge_gtr_price_pd_am 
    		from (select distinct 
    				drvr.vyge_id,
    				drvr.ship_strm_ctgy_nm,
    				drvr.txn_dt,
    				fcst.fcst_comm_pc,
    				coalesce(rcmd.rcmd_vyge_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * 2 * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn * fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  as vfd, 
    				coalesce(rcmd.rcmd_vyge_adlt_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * fcst.adlt_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn 
    				* fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  * (fcst.fcst_gst_per_strm_cn  - 2) as vf3_8_adlt, 
    				coalesce(rcmd.rcmd_vyge_chld_gtr_pd_am,0.0) * drvr.vyge_drtn_nght_cn * fcst.chld_split * ((phys_invtry_strm_cn_df_ntr.phys_invtry_strm_cn
    				* fcst.fcst_ship_ocpncy_pc) - strm.ooo_strm_cn)  * (fcst.fcst_gst_per_strm_cn - 2) as vf3_8_chld, 
    				(
    				(
    				(
    				cast(strm.phys_invtry_strm_cn as decimal(15,8)) * cast(fcst.fcst_ship_ocpncy_pc as decimal(15,8))
    				) - strm.ooo_strm_cn
    				) 
    				* 
    				drvr.vyge_drtn_nght_cn 
    				* 
    				cast(fcst.fcst_gst_per_strm_cn as decimal(15,8))
    				)
    				+ 
    				(
    				strm.ooo_strm_cn
    				*
    				drvr.vyge_drtn_nght_cn
    				*
    				cast(fcst.fcst_ooo_gst_per_strm_cn as decimal(15,8))
    				) as pcd 

    			from driver drvr INNER JOIN vyge_strm_ctgy_strm_typ_cd_driver as strm_typ_driver
    			ON  drvr.vyge_id = strm_typ_driver.vyge_id
    			and drvr.ship_strm_ctgy_nm = strm_typ_driver.SHIP_STRM_CTGY_NM
    			and drvr.txn_dt = strm_typ_driver.txn_dt
    			AND strm_typ_driver.SHIP_STRM_TYP_CD NOT IN ('XAM','IRG')

    			inner join  ooo_vyg_inventory_cnt_driver_df_ntr_gtr strm
    			on drvr.vyge_id = strm.vyge_id
    			and drvr.ship_strm_ctgy_nm = strm.ship_strm_ctgy_nm_new
    			and strm_typ_driver.SHIP_STRM_TYP_CD = strm.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = strm.txn_dt
    			and strm_typ_driver.SHIP_STRM_TYP_CD NOT IN ('XAM','IRG')

    			inner join  phys_invtry_strm_cn_df_ntr as phys_invtry_strm_cn_df_ntr
    			on drvr.vyge_id = phys_invtry_strm_cn_df_ntr.vyge_id
    			and drvr.ship_strm_ctgy_nm = phys_invtry_strm_cn_df_ntr.ship_strm_ctgy_nm_new
    			and strm_typ_driver.SHIP_STRM_TYP_CD = phys_invtry_strm_cn_df_ntr.SHIP_STRM_TYP_CD
    			and drvr.txn_dt = phys_invtry_strm_cn_df_ntr.txn_dt

                inner join vyge_strm_typ_dly_rcmd_vw rcmd
                on drvr.vyge_id = rcmd.vyge_id
                and strm_typ_driver.SHIP_STRM_TYP_CD = rcmd.strm_typ_cd
                and drvr.txn_dt = rcmd.txn_dt


    			left outer join vyge_ship_fnc_dflt_fcst_vw fcst
                on drvr.vyge_id = fcst.vyge_id
                AND drvr.txn_dt = fcst.txn_dt 
                and drvr.ship_strm_ctgy_nm = fcst.ship_strm_ctgy_nm_new
                and strm_typ_driver.SHIP_STRM_TYP_CD = fcst.SHIP_STRM_TYP_CD

                 ) 
            rcmd_temp """).dropDuplicates()

        vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_ntr_gtr_temp_vw")
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_rcmd_ntr_gtr_temp_df, "vyge_strm_typ_dly_rcmd_ntr_gtr_temp_vw")

        vyge_strm_typ_dly_rcmd_ntr_gtr_df = sql_context.sql("""
    				select distinct 
    					vyge_id,
    					strm_typ_cd,
    					ship_strm_ctgy_nm,
    					txn_dt,
    					rcmd_vyge_gtr_price_pd_am,
    					cast(rcmd_vyge_gtr_price_pd_am * (1 - fcst_comm_pc) as decimal(12,2))  as rcmd_vyge_ntr_price_pd_am
    				FROM vyge_strm_typ_dly_rcmd_ntr_gtr_temp_vw 
    				""").dropDuplicates()

        vyge_strm_typ_dly_rcmd_ntr_gtr_df.createOrReplaceTempView("vyge_strm_typ_dly_rcmd_ntr_gtr_vw")
        print("vyge_strm_typ_dly_rcmd_ntr_gtr_df===DF")
        vyge_strm_typ_dly_rcmd_ntr_gtr_df.printSchema();
        vyge_strm_typ_dly_rcmd_ntr_gtr_df.show();
        if debug == 1:
            DebugCount.debug_counts(vyge_strm_typ_dly_rcmd_ntr_gtr_df, "vyge_strm_typ_dly_rcmd_ntr_gtr_vw")

        rcmd_gtr_pd_chng_df = sql_context.sql("""
                            SELECT  distinct
                                    prc_rcmd_gtr_pd_am.vyge_id,
                                    prc_rcmd_gtr_pd_am.ship_strm_ctgy_nm,
                                    prc_rcmd_gtr_pd_am.txn_dt ,
                                    prc_rcmd_gtr_pd_am.rcmd_vyge_gtr_pd_am,
                                    (prc_rcmd_gtr_pd_am.rcmd_vyge_gtr_pd_am - proc_price_pt_vw.gtr_pd_am) as gtr_pd_chng_am,
                                    ROUND((prc_rcmd_gtr_pd_am.rcmd_vyge_gtr_pd_am - proc_price_pt_vw.gtr_pd_am) / gtr_pd_am , 2)
                                    as gtr_pd_chng_pc
                            FROM vyge_strm_typ_dly_rcmd_vw prc_rcmd_gtr_pd_am left join proc_price_pt_vw proc_price_pt_vw
                            ON proc_price_pt_vw.vyge_id = prc_rcmd_gtr_pd_am.vyge_id
                                    AND proc_price_pt_vw.ship_strm_ctgy_nm = prc_rcmd_gtr_pd_am.ship_strm_ctgy_nm
                                    AND proc_price_pt_vw.txn_dt = prc_rcmd_gtr_pd_am.txn_dt
                                    """).dropDuplicates()
        rcmd_gtr_pd_chng_df.createOrReplaceTempView("rcmd_gtr_pd_chng_vw")
        print("rcmd_gtr_pd_chng_vw  ==DF")
        rcmd_gtr_pd_chng_df.printSchema();
        rcmd_gtr_pd_chng_df.show();
        if debug == 1:
            DebugCount.debug_counts(rcmd_gtr_pd_chng_df, "rcmd_gtr_pd_chng_vw")

        print
        " END OF GTR NTR "





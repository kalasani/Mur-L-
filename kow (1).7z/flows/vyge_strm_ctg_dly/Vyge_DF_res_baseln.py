# #####################################################################################
# # Project           : DCL RM - Disney Cruise Line Revenue Management                #
# # Program name      : Promotional pricing - Con_resbaseln                           #
# # Author            : Kowshik Y                                                     #
# # Date created      : 20180619                                                      #
# # Purpose           : To fetch VF metrices from raw resbaseln data                  #
# # Revision History  :                                                               #
# #   Date        Author     Ref    Revision (Date in YYYYMMDD format)                #
# # 20180620    kowshik Y   Chris                                                     #
# #                                                                                   #
# #####################################################################################
#
# #################################################################################
# # STEP 1: Initializing SPARK variable and importing dependent functions/objects #
# #################################################################################
#
# from datetime import datetime
# from datetime import timedelta
# from pyspark.sql import SparkSession
# from pyspark.sql.window import Window
# from pyspark import SparkContext
# from pyspark import SQLContext
# from pyspark.sql.functions import *
# from framework.utils.DebugCount import *;
# import sys, traceback
# from pyspark.sql.types import *
# import os, sys
#
# class VygeStrmCtgDlyResBaselnCons(object):
#
#     @staticmethod
#     def run_con_resbaseln(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,debug):
#         ##################################################################
#         # Driver program to run promotional_price dm main process method #
#         # Attributes                                                     #
#         # start_dt    : the time slice that is being executed            #
#         # sql_context : the spark sql context                            #
#         # s3_bucket   : the s3 bucket that identifies the data source    #
#         # debug       :  debugging the counts                            #
#         ##################################################################
#
#
#         ##################################################################################################################
#         # Populate consolidated resbaseln by merging with driver program to fetch OnHand paid booking counts along       #
#         # with guest counts metrices grouped by primary key of driver program(i.e, vyge_id, ship_strm_typ_cd and txn_dt) #
#         ##################################################################################################################
#
#         # res_baseln_strm_level_df = data_loader.read_data_from_path("con/res_baseln_vyge_strm_only")
#         # res_baseln_strm_level_df.createOrReplaceTempView("res_baseln_strm_level_vw")
#         #
#         res_baseln_strm_level_df = sql_context.read.format("orc").load("/wdpr-apps-data/dclrms/test/stage/con/res_baseln_vyge_strm_ctgy_only/data")
#         res_baseln_strm_level_df.createOrReplaceTempView("res_baseln_strm_level_vw")
#         res_baseln_strm_level_df.printSchema();
#         res_baseln_strm_level_df.show();
#         vyge_strm_typ_drvr_df = sql_context.sql(" select * from driver ")
#         res_baseln_con_unasgn_temp_df = vyge_strm_typ_drvr_df.join(res_baseln_strm_level_df,["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer")
#
#         \
#                 res_baseln_con_unasgn_df = sql_context.sql("""
#     		select
#     			vw.vyge_id,
#     			vw.ship_strm_ctgy_nm,
#     			vw.txn_dt,
#     			vw.pu_bkng_cn,
#     			vw.cncl_bkng_cn,
#     			vw.oh_paid_bkng_cn,
#     			vw.grs_paid_bkng_cn,
#     			vw.oh_bkng_gst_cn,
#     			(vw.oh_paid_bkng_cn - vw.oh_asgn_bkng_cn) as oh_unasgn_bkng_cn,
#     			(vw.oh_bkng_gst_cn - vw.oh_asgn_bkng_gst_cn) as oh_unasgn_bkng_gst_cn
#     		from (
#     				SELECT
#     				drvr.vyge_id,
#     				drvr.ship_strm_ctgy_nm,
#     				drvr.txn_dt,
#
#
#     				res_baseln.pu_bkng_cn as pu_bkng_cn,
#     				res_baseln.cncl_bkng_cn as cncl_bkng_cn,
#     				res_baseln.oh_bkng_cn as oh_paid_bkng_cn,
#     				res_baseln.grs_paid_bkng_cn as grs_paid_bkng_cn,
#     				res_baseln.oh_bkng_gst_cn as oh_bkng_gst_cn,
#     				res_baseln.oh_asgn_bkng_cn as oh_asgn_bkng_cn,
#     				res_baseln.oh_asgn_bkng_gst_cn as oh_asgn_bkng_gst_cn
#
#
#     				FROM driver drvr LEFT JOIN res_baseln_strm_level_vw res_baseln
#     				ON drvr.vyge_id = res_baseln.vyge_id
#     				and drvr.ship_strm_ctgy_nm = res_baseln.strm_ctgy_nm
#     				and date(drvr.txn_dt) = date(res_baseln.txn_dt)
#
#
#     				) vw
#     			""")
#         res_baseln_con_unasgn_df.createOrReplaceTempView("res_baseln_con_unasgn_vw")
#         res_baseln_con_unasgn_df.printSchema();
#         res_baseln_con_unasgn_df.show();
#
#         res_baseln_con_asgn_df = sql_context.sql("""
#     		select
#     			drvr.vyge_id,
#     			drvr.ship_strm_ctgy_nm,
#     			drvr.txn_dt,
#     			SUM(case when res_baseln.res_sts_cd in ('OF','CL','BK','TM') and res_baseln.price_strm_typ_cd not in ('IRG','XAM')  then 1
#     			else 0 end) as oh_asgn_bkng_cn,
#     			SUM(case when res_baseln.res_sts_cd in ('OF','CL','BK','TM')  and res_baseln.price_strm_typ_cd not in ('IRG','XAM')  then tot_gst_cn
#     			else 0 end) as oh_asgn_bkng_gst_cn
#
#     		FROM driver drvr LEFT  JOIN res_baseln res_baseln
#     			ON drvr.vyge_id = res_baseln.vyge_id
#     			and drvr.strm_typ_cd = res_baseln.asgn_strm_typ_cd
#     			and drvr.txn_dt>= date(res_baseln.vrsn_strt_dts)
#     			and drvr.txn_dt< date(res_baseln.vrsn_end_dts)
#
#     		GROUP BY drvr.vyge_id,
#     				drvr.ship_strm_ctgy_nm,
#     				drvr.txn_dt
#     		""").dropDuplicates();
#         res_baseln_con_asgn_df.createOrReplaceTempView("res_baseln_con_asgn_vw")
#         res_baseln_con_asgn_df.printSchema();
#         res_baseln_con_asgn_df.show();
#
#         res_baseln_asgn_unasgn_df = sql_context.sql("""
#     			select
#     			con_unasgn_vw.vyge_id,
#     			con_unasgn_vw.ship_strm_ctgy_nm,
#     			con_unasgn_vw.txn_dt,
#
#     			con_unasgn_vw.pu_bkng_cn,
#
#     			con_unasgn_vw.cncl_bkng_cn,
#     			con_unasgn_vw.oh_paid_bkng_cn,
#     			con_unasgn_vw.grs_paid_bkng_cn,
#
#     			con_unasgn_vw.oh_bkng_gst_cn,
#     			con_unasgn_vw.oh_unasgn_bkng_cn,
#     			con_unasgn_vw.oh_unasgn_bkng_gst_cn,
#
#     			con_asgn_vw.oh_asgn_bkng_cn,
#     			con_asgn_vw.oh_asgn_bkng_gst_cn
#
#     		FROM res_baseln_con_unasgn_vw con_unasgn_vw join res_baseln_con_asgn_vw con_asgn_vw
#
#     		ON con_unasgn_vw.vyge_id = con_asgn_vw.vyge_id
#     		AND con_unasgn_vw.ship_strm_ctgy_nm = con_asgn_vw.ship_strm_ctgy_nm
#     		AND con_unasgn_vw.txn_dt = con_asgn_vw.txn_dt
#     		""").dropDuplicates();
#         res_baseln_asgn_unasgn_df.printSchema();
#         res_baseln_asgn_unasgn_df.show();
#
#         res_baseln_asgn_unasgn_df.createOrReplaceTempView("res_baseln_asgn_unasgn_vw")
#
#         res_baseln_con_df = sql_context.sql("""
#     			SELECT DISTINCT
#     			drv.vyge_id,
#     			drv.ship_strm_ctgy_nm,
#     			drv.txn_dt,
#     			asgn_unasgn_vw.pu_bkng_cn,
#     			asgn_unasgn_vw.cncl_bkng_cn,
#     			asgn_unasgn_vw.oh_paid_bkng_cn,
#     			asgn_unasgn_vw.grs_paid_bkng_cn,
#     			asgn_unasgn_vw.oh_bkng_gst_cn,
#     			asgn_unasgn_vw.oh_unasgn_bkng_cn,
#     			asgn_unasgn_vw.oh_unasgn_bkng_gst_cn,
#     			asgn_unasgn_vw.oh_asgn_bkng_cn,
#     			asgn_unasgn_vw.oh_asgn_bkng_gst_cn
#     		FROM driver drv LEFT JOIN res_baseln_asgn_unasgn_vw asgn_unasgn_vw
#     		ON drv.vyge_id = asgn_unasgn_vw.vyge_id
#     		AND drv.ship_strm_ctgy_nm = asgn_unasgn_vw.ship_strm_ctgy_nm
#     		AND drv.txn_dt = asgn_unasgn_vw.txn_dt
#     			""").dropDuplicates();
#         res_baseln_con_df.createOrReplaceTempView("res_baseln_con_vw")
#         res_baseln_con_df.printSchema();
#         res_baseln_con_df.show();
#
#         opn_vyge_strm_typ_config_df = sql_context.read.format("orc").load(
#             "/wdpr-apps-data/dclrms/works/opn_vyge_strm_typ_config/data/")
#         opn_vyge_strm_typ_config_df.createOrReplaceTempView("opn_vyge_strm_typ_config")
#
#         ship_inventory_alloc_unalloc_df = sql_context.sql(
#             """
#                     SELECT
#                         drv_alloc.vyge_id as vyge_id,
#                         drv_alloc.ship_strm_ctgy_nm as ship_strm_ctgy_nm,
#                         drv_alloc.txn_dt as txn_dt,
#
#                         SUM(CASE WHEN drv_alloc.dlgt_res_id IS NULL AND drv_alloc.cabin_number IS  NOT NULL
#                             THEN 1 ELSE 0
#                         END) AS alloc_grp_bkng_cn,
#
#                         SUM(CASE WHEN drv_alloc.dlgt_res_id IS NULL AND drv_alloc.cabin_number IS  NULL
#                             THEN 1 ELSE 0
#                         END) AS unalloc_grp_bkng_cn,
#
#                         SUM(CASE WHEN drv_alloc.DLGT_RES_ID IS NULL AND drv_alloc.cabin_number IS  NOT NULL
#                             THEN drv_alloc.occupancy ELSE 0
#                         END) AS alloc_grp_gst_cn,
#
#                         SUM(CASE WHEN drv_alloc.DLGT_RES_ID IS NULL AND drv_alloc.cabin_number IS  NULL
#                             THEN drv_alloc.occupancy ELSE 0
#                         END) AS unalloc_grp_gst_cn
#                     ,
#                       SUM(case WHEN drv_alloc.CABIN_NUMBER IS NOT NULL	AND drv_alloc.DLGT_RES_ID IS NOT NULL                THEN 1 ELSE 0 END) as dlgt_grp_bkng_cn
#                     FROM (
#                        select distinct
#                         driver.vyge_id,
#                         driver.ship_strm_ctgy_nm,
#                         driver.txn_dt,
#                         alloc.cabin_number,
#                         alloc.occupancy,
#                         alloc.dlgt_res_id
#                         from
#                         driver driver join ship_inventory_alloc alloc
#                         ON driver.ship_cd = alloc.ship_code
#                          AND driver.strm_typ_cd = alloc.cabin_category
#                         AND driver.vyge_dprt_dt = alloc.sail_date_from
#                         WHERE UPPER(alloc.allocation_owner_type) = 'GROUP') drv_alloc
#                         GROUP BY drv_alloc.vyge_id,
#                         drv_alloc.ship_strm_ctgy_nm,
#                         drv_alloc.txn_dt
#             """).dropDuplicates()
#         #                AND driver.strm_typ_cd = alloc.cabin_category
#
#         ship_inventory_alloc_unalloc_df.createOrReplaceTempView("ship_inventory_alloc_unalloc_vw")
#         ship_inventory_alloc_unalloc_df.printSchema()
#         ship_inventory_alloc_unalloc_df.show(10);
#         if debug == 1:
#             DebugCount.debug_counts(ship_inventory_alloc_unalloc_df, "ship_inventory_alloc_unalloc_df")
#
#         con_res_df = res_baseln_con_df.join(ship_inventory_alloc_unalloc_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"],
#                                             "left_outer") \
#             .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", res_baseln_con_df.pu_bkng_cn,
#                     res_baseln_con_df.cncl_bkng_cn \
#                     , res_baseln_con_df.grs_paid_bkng_cn, res_baseln_con_df.oh_bkng_gst_cn \
#                     , res_baseln_con_df.oh_unasgn_bkng_gst_cn, res_baseln_con_df.oh_asgn_bkng_gst_cn \
#                     , coalesce(res_baseln_con_df.oh_paid_bkng_cn, lit("0")).alias("oh_paid_bkng_cn") \
#                     , coalesce(res_baseln_con_df.oh_asgn_bkng_cn, lit("0")).alias("oh_asgn_bkng_cn") \
#                     , coalesce(res_baseln_con_df.oh_unasgn_bkng_cn, lit("0")).alias("oh_unasgn_bkng_cn") \
#                     , coalesce(ship_inventory_alloc_unalloc_df.dlgt_grp_bkng_cn, lit("0")).alias(
#                 "dlgt_grp_bkng_cn")).distinct()
#
#         con_res_df.createOrReplaceTempView("con_res_vw")
#         con_res_df.printSchema();
#         con_res_df.show();
#
#         print("1oth,4th Cal Start Here ")
#         txn_dt_week_num_vw_df = sql_context.sql(" select * from txn_dt_week_num")
#         txn_dt_week_num_vw_df.printSchema();
#         txn_dt_week_num_vw_df.show();
#         print("txn_dt_week_num_vw_df====>", txn_dt_week_num_vw_df)
#         vyge_strm_typ_drvr_wk_txn_df = sql_context.sql(" select * from vyge_strm_typ_drvr_wk_txn_vw ")
#         vyge_strm_typ_drvr_wk_txn_df = vyge_strm_typ_drvr_wk_txn_df.withColumnRenamed("ship_ctgy_nm", "strm_ctgy_nm")
#         print("vyge_strm_typ_drvr_wk_txn_df====>", vyge_strm_typ_drvr_wk_txn_df)
#         vyge_strm_typ_drvr_wk_txn_df.printSchema();
#         vyge_strm_typ_drvr_wk_txn_df.show();
#         res_baseln_week_num_df = res_baseln_strm_level_df.join(txn_dt_week_num_vw_df, \
#                                                                (
#                                                                        res_baseln_strm_level_df.txn_dt == txn_dt_week_num_vw_df.txn_date)) \
#             .select("vyge_id", \
#                     "strm_ctgy_nm", \
#                     "txn_dt", \
#                     "pu_bkng_cn", \
#                     "cncl_bkng_cn", \
#                     "week_num").distinct()
#
#         driver_week_num_df = vyge_strm_typ_drvr_wk_txn_df.join(txn_dt_week_num_vw_df, \
#                                                                (
#                                                                        vyge_strm_typ_drvr_wk_txn_df.txn_dt == txn_dt_week_num_vw_df.txn_date)) \
#             .select("vyge_id", \
#                     "strm_ctgy_nm", \
#                     "txn_dt", \
#                     "week_num").distinct()
#
#         window_four_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm").orderBy("week_num").rowsBetween(-4, -1)
#         window_ten_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm") \
#             .orderBy("week_num") \
#             .rowsBetween(-10, -1)
#         window_prev_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm") \
#             .orderBy("week_num") \
#             .rowsBetween(-1, -1)
#
#         week_num_group_sum_temp_df = driver_week_num_df.join(res_baseln_week_num_df, \
#                                                              ["vyge_id", "strm_ctgy_nm", "txn_dt", "week_num"]) \
#             .groupBy("vyge_id", "strm_ctgy_nm", "week_num") \
#             .agg(sum("pu_bkng_cn").alias("pu_bkng_cn_sum"), \
#                  sum("cncl_bkng_cn").alias("cncl_bkng_cn_sum")) \
#             .select("vyge_id", \
#                     "strm_ctgy_nm", \
#                     "week_num", \
#                     "pu_bkng_cn_sum", \
#                     "cncl_bkng_cn_sum") \
#             .withColumn("pu_cncl_bkng_cn_sum", (col("pu_bkng_cn_sum") - col("cncl_bkng_cn_sum"))) \
#             .drop(col("pu_bkng_cn_sum")) \
#             .drop(col("cncl_bkng_cn_sum"))
#
#         week_num_group_sum_df = week_num_group_sum_temp_df \
#             .withColumn("four_wk_pu_bkng_cn_tmp", \
#                         sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
#                         .over(window_four_wk)) \
#             .withColumn("ten_wk_pkup_bkng_cn_tmp", \
#                         sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
#                         .over(window_ten_wk)) \
#             .withColumn("prev_wk_pu_bkng_cn_tmp", \
#                         sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
#                         .over(window_prev_wk))
#
#         if debug == 1:
#             DebugCount.debug_counts(week_num_group_sum_df, "week_num_group_sum_vw")
#
#         ten_four_wk_metrics_temp_df = driver_week_num_df.join(week_num_group_sum_df, \
#                                                               ["vyge_id", "strm_ctgy_nm", "week_num"], "left_outer") \
#             .select("vyge_id", \
#                     "strm_ctgy_nm", \
#                     "txn_dt", \
#                     "week_num", \
#                     when(col("four_wk_pu_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
#                     .otherwise(col("four_wk_pu_bkng_cn_tmp")).alias("four_wk_pu_bkng_cn_tmp"), \
#                     when(col("ten_wk_pkup_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
#                     .otherwise(col("ten_wk_pkup_bkng_cn_tmp")).alias("ten_wk_pkup_bkng_cn_tmp"), \
#                     when(col("prev_wk_pu_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
#                     .otherwise(col("prev_wk_pu_bkng_cn_tmp")).alias("prev_wk_pu_bkng_cn_tmp"))
#
#         if debug == 1:
#             DebugCount.debug_counts(ten_four_wk_metrics_temp_df, "ten_four_wk_metrics_temp_vw")
#
#         res_baseln_strm_level_tmp_df = vyge_strm_typ_drvr_wk_txn_df.join(res_baseln_strm_level_df \
#                                                                          .select("vyge_id", "strm_ctgy_nm", "txn_dt",
#                                                                                  "curr_wk_pu_bkng_cn"), \
#                                                                          ["vyge_id", "strm_ctgy_nm", "txn_dt"],
#                                                                          "left_outer") \
#             .select("vyge_id", \
#                     "strm_ctgy_nm", \
#                     "txn_dt", \
#                     res_baseln_strm_level_df.curr_wk_pu_bkng_cn) \
#             .groupBy("vyge_id", "strm_ctgy_nm", "txn_dt") \
#             .agg(sum("curr_wk_pu_bkng_cn").alias("curr_wk_pu_bkng_cn_sum")) \
#             .distinct()
#         # debug=1
#
#         ten_four_prev_wk_metrics_temp_df = ten_four_wk_metrics_temp_df.join(res_baseln_strm_level_tmp_df, \
#                                                                             ["vyge_id", "strm_ctgy_nm", "txn_dt"]). \
#             select("vyge_id", \
#                    "strm_ctgy_nm", \
#                    "txn_dt", \
#                    col("four_wk_pu_bkng_cn_tmp").alias("four_wk_pu_bkng_cn") \
#                    , col("ten_wk_pkup_bkng_cn_tmp").alias("ten_wk_pkup_bkng_cn") \
#                    , col("prev_wk_pu_bkng_cn_tmp").alias("prev_wk_pu_bkng_cn") \
#                    , when(res_baseln_strm_level_tmp_df.curr_wk_pu_bkng_cn_sum.isNull(), lit("0").cast("integer")) \
#                    .otherwise(res_baseln_strm_level_tmp_df.curr_wk_pu_bkng_cn_sum).alias("curr_wk_pu_bkng_cn_tmp"))
#         ten_four_prev_wk_metrics_temp_df = ten_four_prev_wk_metrics_temp_df.withColumnRenamed("strm_ctgy_nm",
#                                                                                               "ship_strm_ctgy_nm")
#         ten_four_prev_wk_metrics_temp_df.printSchema();
#         ten_four_prev_wk_metrics_temp_df.show()
#         if debug == 1:
#             DebugCount.debug_counts(ten_four_prev_wk_metrics_temp_df, "ten_four_prev_wk_metrics_temp_vw")
#         # ten_four_prev_wk_metrics_temp_df.agg(min("txn_dt").alias("min_txn_dt"), max("txn_dt").alias("max_txn_dt")).show()
#
#         filter_txn_wk_clause = "txn_dt >= date('%s') and txn_dt <= date('%s')" % (start_dt, end_dt)
#
#         ten_four_prev_wk_metrics_df = ten_four_prev_wk_metrics_temp_df \
#             .withColumn("four_wk_pu_avg_bkng_cn", \
#                         (ten_four_prev_wk_metrics_temp_df.four_wk_pu_bkng_cn / 4.00) \
#                         .cast("decimal(8,2)")) \
#             .withColumn("ten_wk_pu_avg_bkng_cn", \
#                         (ten_four_prev_wk_metrics_temp_df.ten_wk_pkup_bkng_cn / 10.00) \
#                         .cast("decimal(8,2)")).filter(filter_txn_wk_clause)
#
#         ten_four_prev_wk_metrics_df.printSchema()
#         ten_four_prev_wk_metrics_df.show();
#         if debug == 1:
#             DebugCount.debug_counts(ten_four_prev_wk_metrics_df, "ten_four_prev_wk_metrics_vw")
#
#         ten_four_prev_wk_metrics_df.printSchema()
#         ten_four_prev_wk_metrics_df.createOrReplaceTempView("ten_four_prev_wk_metrics_vw")
#         # ten_four_prev_wk_metrics_df.agg(min("txn_dt").alias("min_txn_dt"), max("txn_dt").alias("max_txn_dt")).show()
#         print
#         " END OF CONSOLIADTED RESBASELN "
#
#         print(" END OF CONSOLIADTED RESBASELN ")
#
#

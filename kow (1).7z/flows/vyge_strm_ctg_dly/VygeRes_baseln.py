#####################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                #
# Program name      :  Con_resbaseln                           #
# Author            : Anjaiah M                                                     #
# Date created      : 20180619                                                      #
# Purpose           : To fetch VF metrices from raw resbaseln data                  #
# Revision History  :                                                               #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                #
# 20180620    Sumanth Y   Chris                                                     #
#                                                                                   #
#####################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/objects #
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
from framework.utils.DebugCount import *;
import sys, traceback
from pyspark.sql.types import *
import os, sys

class VygeStrmCtgDlyResBaselnCons(object):

    @staticmethod
    def run_con_resbaseln(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,debug):
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################


        ##################################################################################################################
        # Populate consolidated resbaseln by merging with driver program to fetch OnHand paid booking counts along       #
        # with guest counts metrices grouped by primary key of driver program(i.e, vyge_id, ship_strm_typ_cd and txn_dt) #
        ##################################################################################################################

        # res_baseln_strm_level_df = data_loader.read_data_from_path("con/res_baseln_vyge_strm_only")
        # res_baseln_strm_level_df.createOrReplaceTempView("res_baseln_strm_level_vw")
        #
        #res_baseln_strm_level_df = sql_context.read.format("orc").load("/wdpr-apps-data/dclrms/test/stage/con/res_baseln_vyge_strm_ctgy_only/data")
        res_baseln_strm_level_df = data_loader.read_data_from_path("con/res_baseln_vyge_strm_ctgy")
        res_baseln_strm_level_df.createOrReplaceTempView("res_baseln_strm_level_vw")
        res_baseln_filter_df = sql_context.sql(""" select * from res_baseln """)
        vyge_strm_typ_drvr_df = sql_context.sql(" select * from driver ")
        vyge_strm_ctgy_dly_strm_typ_driver = sql_context.sql(" select * from vyge_strm_ctgy_strm_typ_cd_driver ")
        ship_inventory_alloc_df = sql_context.sql(
            """ select * from ship_inventory_alloc 	where UPPER(allocation_owner_type) = 'GROUP' """)

        # res_baseln_con_unasgn_temp_df = vyge_strm_ctgy_dly_strm_typ_driver.join(res_baseln_strm_level_df, \
        #                                                                         (vyge_strm_ctgy_dly_strm_typ_driver.vyge_id == res_baseln_strm_level_df.vyge_id) \
        #                                                                         &(vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm == res_baseln_strm_level_df.strm_ctgy_nm) \
        #                                                                         & (to_date(res_baseln_strm_level_df.txn_dt) == vyge_strm_ctgy_dly_strm_typ_driver.txn_dt)) \
        #     .select(vyge_strm_ctgy_dly_strm_typ_driver.vyge_id, \
        #             vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm, \
        #             vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd.alias("strm_typ_cd"), \
        #             vyge_strm_ctgy_dly_strm_typ_driver.txn_dt, \
        #             res_baseln_strm_level_df.pu_bkng_cn, \
        #             res_baseln_strm_level_df.cncl_bkng_cn, \
        #             res_baseln_strm_level_df.oh_bkng_cn, \
        #             res_baseln_strm_level_df.grs_paid_bkng_cn, \
        #             res_baseln_strm_level_df.oh_bkng_gst_cn, \
        #             res_baseln_strm_level_df.oh_asgn_bkng_cn, \
        #             res_baseln_strm_level_df.oh_asgn_bkng_gst_cn).distinct()
        #
        # res_baseln_con_unasgn_agg_df = res_baseln_con_unasgn_temp_df \
        #     .withColumn("pu_bkng_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.pu_bkng_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("cncl_bkng_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.cncl_bkng_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("oh_paid_bkng_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.oh_bkng_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("grs_paid_bkng_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.grs_paid_bkng_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("oh_bkng_gst_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.oh_bkng_gst_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("oh_asgn_bkng_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.oh_asgn_bkng_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .withColumn("oh_asgn_bkng_gst_cn", \
        #                 when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
        #                         res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
        #                      res_baseln_con_unasgn_temp_df.oh_asgn_bkng_gst_cn) \
        #                 .otherwise(lit("0").cast("integer"))) \
        #     .groupBy(res_baseln_con_unasgn_temp_df.vyge_id, \
        #              res_baseln_con_unasgn_temp_df.ship_strm_ctgy_nm, \
        #              res_baseln_con_unasgn_temp_df.strm_typ_cd, \
        #              res_baseln_con_unasgn_temp_df.txn_dt) \
        #     .agg(sum("pu_bkng_cn").alias("pu_bkng_cn"), \
        #          sum("cncl_bkng_cn").alias("cncl_bkng_cn"), \
        #          sum("oh_paid_bkng_cn").alias("oh_paid_bkng_cn"), \
        #          sum("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
        #          sum("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
        #          sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
        #          sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"))
        #
        # res_baseln_con_unasgn_agg_df_new = res_baseln_con_unasgn_agg_df.select("vyge_id", "ship_strm_ctgy_nm", "txn_dt",
        #                                                                        "pu_bkng_cn", "cncl_bkng_cn",
        #                                                                        "oh_paid_bkng_cn", "grs_paid_bkng_cn",
        #                                                                        "oh_bkng_gst_cn", \
        #                                                                        "oh_asgn_bkng_cn",
        #                                                                        "oh_asgn_bkng_gst_cn").groupBy("vyge_id",
        #                                                                                                       "ship_strm_ctgy_nm",
        #                                                                                                       "txn_dt") \
        #                                                                 .agg(max("pu_bkng_cn").alias("pu_bkng_cn"), \
        #                                                                      max("cncl_bkng_cn").alias("cncl_bkng_cn"), \
        #                                                                      max("oh_paid_bkng_cn").alias("oh_paid_bkng_cn"), \
        #                                                                      max("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
        #                                                                      max("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
        #                                                                      max("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
        #                                                                      max("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"))

        vyge_strm_typ_drvr_df1 = sql_context.sql(" select * from driver ")
        #spark.read.format("orc").load("/wdpr-apps-data/dclrms/dev/dm/vyge_strm_typ_drvr_df_new/partition_dt=2018-01-07/data")
        # res_baseln_strm_level_df = spark.read.format("orc").load(
        #     "/wdpr-apps-data/dclrms/dev/con/res_baseln_vyge_strm_only/data")

        # ship_strm_typ_ext_df = spark.read.format("orc").load("/wdpr-apps-data/dclrms/stg/dm/SHIP_STRM_TYP_EXT/data")
        # ship_strm_typ_ext_df.createOrReplaceTempView("ship_strm_typ_ext")

        ship_strm_typ_ext_filter_clause1 = " UPPER(ship_strm_typ_cd) NOT IN('IRG','XAM') \
                                    and UPPER(instnc_st_nm)='STANDARD' and ship_cd != 'XP'"

        ship_strm_typ_ext_df = data_loader.read_data("dm", "SHIP_STRM_TYP_EXT")
        res_baseln_strm_typ_cd_level_df = data_loader.read_data_from_path("con/res_baseln_vyge_strm_only")
        vyge_strm_typ_drvr_df = vyge_strm_typ_drvr_df1.join(ship_strm_typ_ext_df, \
                                                            (vyge_strm_typ_drvr_df1.ship_cd == ship_strm_typ_ext_df.ship_cd)
                                                            &(vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm)
                                                            &(vyge_strm_typ_drvr_df1.txn_dt >= ship_strm_typ_ext_df.vrsn_strt_dts)
                                                            &(vyge_strm_typ_drvr_df1.txn_dt < ship_strm_typ_ext_df.vrsn_end_dts)) \
            .select(vyge_strm_typ_drvr_df1.vyge_id,
                    ship_strm_typ_ext_df.ship_strm_typ_cd.alias("strm_typ_cd"),
                    vyge_strm_typ_drvr_df1.ship_strm_ctgy_nm,
                    vyge_strm_typ_drvr_df1.txn_dt,
                    vyge_strm_typ_drvr_df1.ship_cd,
                    vyge_strm_typ_drvr_df1.vyge_dprt_dt,
                    vyge_strm_typ_drvr_df1.app_vyge_id,
                    vyge_strm_typ_drvr_df1.dy_bef_vyge_cn,
                    vyge_strm_typ_drvr_df1.vyge_drtn_nght_cn).distinct()


        res_baseln_con_unasgn_temp_df = vyge_strm_typ_drvr_df.join(res_baseln_strm_typ_cd_level_df, \
                                                                   ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.strm_typ_cd, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm,
                    res_baseln_strm_typ_cd_level_df.pu_bkng_cn, \
                    res_baseln_strm_typ_cd_level_df.cncl_bkng_cn, \
                    res_baseln_strm_typ_cd_level_df.oh_bkng_cn, \
                    res_baseln_strm_typ_cd_level_df.grs_paid_bkng_cn, \
                    res_baseln_strm_typ_cd_level_df.oh_bkng_gst_cn, \
                    res_baseln_strm_typ_cd_level_df.oh_asgn_bkng_cn, \
                    res_baseln_strm_typ_cd_level_df.oh_asgn_bkng_gst_cn).distinct()

        res_baseln_con_unasgn_agg_df = res_baseln_con_unasgn_temp_df \
            .withColumn("pu_bkng_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.pu_bkng_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("cncl_bkng_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.cncl_bkng_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("oh_paid_bkng_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.oh_bkng_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("grs_paid_bkng_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.grs_paid_bkng_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("oh_bkng_gst_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.oh_bkng_gst_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("oh_asgn_bkng_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.oh_asgn_bkng_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("oh_asgn_bkng_gst_cn", \
                        when(((res_baseln_con_unasgn_temp_df.strm_typ_cd != 'IRG') | (
                                res_baseln_con_unasgn_temp_df.strm_typ_cd != 'XAM')), \
                             res_baseln_con_unasgn_temp_df.oh_asgn_bkng_gst_cn) \
                        .otherwise(lit("0").cast("integer"))) \
            .groupBy(res_baseln_con_unasgn_temp_df.vyge_id, \
                     res_baseln_con_unasgn_temp_df.strm_typ_cd, \
                     res_baseln_con_unasgn_temp_df.ship_strm_ctgy_nm,
                     res_baseln_con_unasgn_temp_df.txn_dt) \
            .agg(sum("pu_bkng_cn").alias("pu_bkng_cn"), \
                 sum("cncl_bkng_cn").alias("cncl_bkng_cn"), \
                 sum("oh_paid_bkng_cn").alias("oh_paid_bkng_cn"), \
                 sum("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
                 sum("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
                 sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
                 sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"))

        res_baseln_con_unasgn_agg_df_new = vyge_strm_typ_drvr_df1.join(res_baseln_con_unasgn_agg_df,
                                                                       ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", "pu_bkng_cn", "cncl_bkng_cn", "oh_paid_bkng_cn",
                    "grs_paid_bkng_cn", "oh_bkng_gst_cn", "oh_asgn_bkng_cn", "oh_asgn_bkng_gst_cn") \
            .groupBy("vyge_id", "ship_strm_ctgy_nm", "txn_dt") \
            .agg(sum("pu_bkng_cn").alias("pu_bkng_cn"), \
                 sum("cncl_bkng_cn").alias("cncl_bkng_cn"), \
                 sum("oh_paid_bkng_cn").alias("oh_paid_bkng_cn"), \
                 sum("grs_paid_bkng_cn").alias("grs_paid_bkng_cn"), \
                 sum("oh_bkng_gst_cn").alias("oh_bkng_gst_cn"), \
                 sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
                 sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn"))

        res_baseln_con_unasgn_df = res_baseln_con_unasgn_agg_df_new.select(res_baseln_con_unasgn_agg_df_new.vyge_id, \
                                                                           res_baseln_con_unasgn_agg_df_new.ship_strm_ctgy_nm, \
                                                                           res_baseln_con_unasgn_agg_df_new.txn_dt, \
                                                                           res_baseln_con_unasgn_agg_df_new.pu_bkng_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.cncl_bkng_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.oh_paid_bkng_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.grs_paid_bkng_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.oh_bkng_gst_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.oh_asgn_bkng_cn, \
                                                                           res_baseln_con_unasgn_agg_df_new.oh_asgn_bkng_gst_cn, \
                                                                           (res_baseln_con_unasgn_agg_df_new.oh_paid_bkng_cn - res_baseln_con_unasgn_agg_df_new.oh_asgn_bkng_cn).alias("oh_unasgn_bkng_cn"), \
                    (res_baseln_con_unasgn_agg_df_new.oh_bkng_gst_cn - res_baseln_con_unasgn_agg_df_new.oh_asgn_bkng_gst_cn).alias("oh_unasgn_bkng_gst_cn"), \
                    ).distinct()


        res_baseln_con_unasgn_df.createOrReplaceTempView("res_baseln_con_unasgn_vw")
        res_baseln_con_unasgn_df.filter("vyge_id=178007 and ship_strm_ctgy_nm='Oceanview' and txn_dt='2018-01-07'").show(10)


        # filtr_clause = "res_sts_cd in ('OF','CL','BK','TM') and price_strm_typ_cd not in ('IRG','XAM')"
        #
        # res_baseln_con_asgn_temp_df = vyge_strm_typ_drvr_df.join(vyge_strm_ctgy_dly_strm_typ_driver, \
        #                                                     (vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
        #                                                     &(vyge_strm_ctgy_dly_strm_typ_driver.txn_dt == vyge_strm_typ_drvr_df.txn_dt) \
        #                                                     & (vyge_strm_ctgy_dly_strm_typ_driver.vyge_id == vyge_strm_typ_drvr_df.vyge_id) \
        #                                                 ).join(res_baseln_filter_df.filter(filtr_clause), \
        #                                                  (vyge_strm_typ_drvr_df.vyge_id == res_baseln_filter_df.vyge_id) \
        #                                                  & (vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd == res_baseln_filter_df.asgn_strm_typ_cd) \
        #                                                 & (vyge_strm_typ_drvr_df.txn_dt >= to_date(res_baseln_filter_df.vrsn_strt_dts)) \
        #                                                 & (vyge_strm_typ_drvr_df.txn_dt < to_date(res_baseln_filter_df.vrsn_end_dts)), "left_outer") \
        #     .select(vyge_strm_typ_drvr_df.vyge_id, \
        #             vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
        #             vyge_strm_typ_drvr_df.txn_dt, \
        #             vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd, \
        #             res_baseln_filter_df.tot_gst_cn).distinct()
        #
        #
        # res_baseln_con_asgn_df = res_baseln_con_asgn_temp_df \
        #     .withColumn("oh_asgn_bkng_cn", when(res_baseln_con_asgn_temp_df.tot_gst_cn.isNull(), \
        #                                         lit("0").cast("integer")) \
        #                 .otherwise(lit("1").cast("integer"))) \
        #     .withColumn("oh_asgn_bkng_gst_cn", when(res_baseln_con_asgn_temp_df.tot_gst_cn.isNull(), \
        #                                             lit("0").cast("integer")) \
        #                 .otherwise(res_baseln_con_asgn_temp_df.tot_gst_cn)) \
        #     .groupBy("vyge_id", "ship_strm_ctgy_nm","ship_strm_typ_cd" "txn_dt") \
        #     .agg(sum("oh_asgn_bkng_cn").alias("oh_asgn_bkng_cn"), \
        #          sum("oh_asgn_bkng_gst_cn").alias("oh_asgn_bkng_gst_cn")).distinct()
        #
        # res_baseln_con_asgn_df.createOrReplaceTempView("res_baseln_con_asgn_vw")

        # res_baseln_asgn_unasgn_df = sql_context.sql("""
    		# 	select
    		# 	con_unasgn_vw.vyge_id,
    		# 	con_unasgn_vw.ship_strm_ctgy_nm,
    		# 	con_unasgn_vw.txn_dt,
        #
    		# 	con_unasgn_vw.pu_bkng_cn,
        #
    		# 	con_unasgn_vw.cncl_bkng_cn,
    		# 	con_unasgn_vw.oh_paid_bkng_cn,
    		# 	con_unasgn_vw.grs_paid_bkng_cn,
        #
    		# 	con_unasgn_vw.oh_bkng_gst_cn,
    		# 	con_unasgn_vw.oh_unasgn_bkng_cn,
    		# 	con_unasgn_vw.oh_unasgn_bkng_gst_cn,
        #
    		# 	con_asgn_vw.oh_asgn_bkng_cn,
    		# 	con_asgn_vw.oh_asgn_bkng_gst_cn
        #
    		# FROM res_baseln_con_unasgn_vw con_unasgn_vw join res_baseln_con_asgn_vw con_asgn_vw
        #
    		# ON con_unasgn_vw.vyge_id = con_asgn_vw.vyge_id
    		# AND con_unasgn_vw.ship_strm_ctgy_nm = con_asgn_vw.ship_strm_ctgy_nm
    		# AND con_unasgn_vw.txn_dt = con_asgn_vw.txn_dt
    		# """).dropDuplicates();
        #
        # res_baseln_asgn_unasgn_df = res_baseln_con_unasgn_df.join(res_baseln_con_asgn_df, \
        #                                                           ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
        #     .select(res_baseln_con_unasgn_df.vyge_id, \
        #             res_baseln_con_unasgn_df.ship_strm_ctgy_nm, \
        #             res_baseln_con_unasgn_df.txn_dt, \
        #             res_baseln_con_unasgn_df.pu_bkng_cn, \
        #             res_baseln_con_unasgn_df.cncl_bkng_cn, \
        #             res_baseln_con_unasgn_df.oh_paid_bkng_cn, \
        #             res_baseln_con_unasgn_df.grs_paid_bkng_cn, \
        #             res_baseln_con_unasgn_df.oh_bkng_gst_cn, \
        #             res_baseln_con_unasgn_df.oh_unasgn_bkng_cn, \
        #             res_baseln_con_unasgn_df.oh_unasgn_bkng_gst_cn, \
        #             res_baseln_con_asgn_df.oh_asgn_bkng_cn, \
        #             res_baseln_con_asgn_df.oh_asgn_bkng_gst_cn)
        # res_baseln_asgn_unasgn_df.createOrReplaceTempView("res_baseln_asgn_unasgn_vw")

        res_baseln_asgn_unasgn_df = res_baseln_con_unasgn_df.select(res_baseln_con_unasgn_df.vyge_id, \
                    res_baseln_con_unasgn_df.ship_strm_ctgy_nm, \
                    res_baseln_con_unasgn_df.txn_dt, \
                    res_baseln_con_unasgn_df.pu_bkng_cn, \
                    res_baseln_con_unasgn_df.cncl_bkng_cn, \
                    res_baseln_con_unasgn_df.oh_paid_bkng_cn, \
                    res_baseln_con_unasgn_df.grs_paid_bkng_cn, \
                    res_baseln_con_unasgn_df.oh_bkng_gst_cn, \
                    res_baseln_con_unasgn_df.oh_unasgn_bkng_cn, \
                    res_baseln_con_unasgn_df.oh_unasgn_bkng_gst_cn, \
                   res_baseln_con_unasgn_df.oh_asgn_bkng_cn, \
                   res_baseln_con_unasgn_df.oh_asgn_bkng_gst_cn)
        res_baseln_asgn_unasgn_df.createOrReplaceTempView("res_baseln_asgn_unasgn_vw")
        # res_baseln_con_df = sql_context.sql("""
    		# 	SELECT DISTINCT
    		# 	drv.vyge_id,
    		# 	drv.ship_strm_ctgy_nm,
    		# 	drv.txn_dt,
    		# 	asgn_unasgn_vw.pu_bkng_cn,
    		# 	asgn_unasgn_vw.cncl_bkng_cn,
    		# 	asgn_unasgn_vw.oh_paid_bkng_cn,
    		# 	asgn_unasgn_vw.grs_paid_bkng_cn,
    		# 	asgn_unasgn_vw.oh_bkng_gst_cn,
    		# 	asgn_unasgn_vw.oh_unasgn_bkng_cn,
    		# 	asgn_unasgn_vw.oh_unasgn_bkng_gst_cn,
    		# 	asgn_unasgn_vw.oh_asgn_bkng_cn,
    		# 	asgn_unasgn_vw.oh_asgn_bkng_gst_cn
    		# FROM driver drv LEFT JOIN res_baseln_asgn_unasgn_vw asgn_unasgn_vw
    		# ON drv.vyge_id = asgn_unasgn_vw.vyge_id
    		# AND drv.ship_strm_ctgy_nm = asgn_unasgn_vw.ship_strm_ctgy_nm
    		# AND drv.txn_dt = asgn_unasgn_vw.txn_dt
    		# 	""").dropDuplicates();

        res_baseln_con_df = vyge_strm_typ_drvr_df.join(res_baseln_asgn_unasgn_df, \
                                                       ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"], "left_outer") \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    when(res_baseln_asgn_unasgn_df.pu_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.pu_bkng_cn).alias("pu_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.cncl_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.cncl_bkng_cn).alias("cncl_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_paid_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_paid_bkng_cn).alias("oh_paid_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.grs_paid_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.grs_paid_bkng_cn).alias("grs_paid_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_bkng_gst_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_bkng_gst_cn).alias("oh_bkng_gst_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_unasgn_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_unasgn_bkng_cn).alias("oh_unasgn_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_unasgn_bkng_gst_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_unasgn_bkng_gst_cn).alias("oh_unasgn_bkng_gst_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_asgn_bkng_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_asgn_bkng_cn).alias("oh_asgn_bkng_cn"), \
                    when(res_baseln_asgn_unasgn_df.oh_asgn_bkng_gst_cn.isNull(), \
                         lit("0").cast("integer")) \
                    .otherwise(res_baseln_asgn_unasgn_df.oh_asgn_bkng_gst_cn).alias("oh_asgn_bkng_gst_cn"))

        res_baseln_con_df.createOrReplaceTempView("res_baseln_con_vw")

        # opn_vyge_strm_typ_config_df = sql_context.read.format("orc").load("/wdpr-apps-data/dclrms/works/opn_vyge_strm_typ_config/data/")
        # opn_vyge_strm_typ_config_df.createOrReplaceTempView("opn_vyge_strm_typ_config")

        vyge_strm_typ_drvr_df = sql_context.sql(" select * from driver ")
        ship_inventory_alloc_unalloc_tmp_df = vyge_strm_typ_drvr_df.join(vyge_strm_ctgy_dly_strm_typ_driver, \
                                                                         (vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_ctgy_nm == vyge_strm_typ_drvr_df.ship_strm_ctgy_nm) \
                                                                         & (vyge_strm_ctgy_dly_strm_typ_driver.txn_dt == vyge_strm_typ_drvr_df.txn_dt) \
                                                                         & (vyge_strm_ctgy_dly_strm_typ_driver.vyge_id == vyge_strm_typ_drvr_df.vyge_id) \
                                                                         ).join(ship_inventory_alloc_df, \
                                                                                ( vyge_strm_typ_drvr_df.ship_cd == ship_inventory_alloc_df.SHIP_CODE) \
                                                                                & (vyge_strm_ctgy_dly_strm_typ_driver.ship_strm_typ_cd == ship_inventory_alloc_df.CABIN_CATEGORY) \
                                                                                & ( vyge_strm_typ_drvr_df.vyge_dprt_dt == ship_inventory_alloc_df.SAIL_DATE_FROM) \
                                                                                & (vyge_strm_typ_drvr_df.vyge_arvl_dt == ship_inventory_alloc_df.SAIL_DATE_TO) \
                                                                                & ( vyge_strm_typ_drvr_df.txn_dt >= to_date(ship_inventory_alloc_df.vrsn_strt_dts)) \
                                                                                & (vyge_strm_typ_drvr_df.txn_dt < to_date(ship_inventory_alloc_df.vrsn_end_dts)) \
                                                                                & (ship_inventory_alloc_df.ALLOCATION_OWNER_TYPE == 'GROUP')) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    vyge_strm_typ_drvr_df.txn_dt, \
                    ship_inventory_alloc_df.CABIN_NUMBER, \
                    ship_inventory_alloc_df.OCCUPANCY, \
                    ship_inventory_alloc_df.DLGT_RES_ID) \
            .withColumn("alloc_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
                                                  & (ship_inventory_alloc_df.CABIN_NUMBER.isNotNull()),
                                                  lit("1").cast("integer")) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("unalloc_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
                                                    & (ship_inventory_alloc_df.CABIN_NUMBER.isNull()),
                                                    lit("1").cast("integer")) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("alloc_grp_gst_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
                                                 & (ship_inventory_alloc_df.CABIN_NUMBER.isNotNull()),
                                                 ship_inventory_alloc_df.OCCUPANCY) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("unalloc_grp_gst_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNull()) \
                                                   & (ship_inventory_alloc_df.CABIN_NUMBER.isNull()),
                                                   ship_inventory_alloc_df.OCCUPANCY) \
                        .otherwise(lit("0").cast("integer"))) \
            .withColumn("dlgt_grp_bkng_cn", when((ship_inventory_alloc_df.DLGT_RES_ID.isNotNull()), lit("1") \
                                                 .cast("integer")).otherwise(lit("0").cast("integer"))) \
            .groupBy("vyge_id", \
                     "ship_strm_ctgy_nm", \
                     "txn_dt") \
            .agg(sum("alloc_grp_bkng_cn").alias("alloc_grp_bkng_cn"), \
                 sum("unalloc_grp_bkng_cn").alias("unalloc_grp_bkng_cn"), \
                 sum("alloc_grp_gst_cn").alias("alloc_grp_gst_cn"), \
                 sum("unalloc_grp_gst_cn").alias("unalloc_grp_gst_cn"), \
                 sum("dlgt_grp_bkng_cn").alias("dlgt_grp_bkng_cn")).distinct()

        ship_inventory_alloc_unalloc_df = vyge_strm_typ_drvr_df.join(ship_inventory_alloc_unalloc_tmp_df, \
                                                                     ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"],
                                                                     "left_outer") \
            .select("vyge_id", \
                    "ship_strm_ctgy_nm", \
                    "txn_dt", \
                    when(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_bkng_cn.isNull(), lit("0") \
                         .cast("integer")).alias("alloc_grp_bkng_cn"), \
                    when(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_bkng_cn.isNull(), lit("0") \
                         .cast("integer")).alias("unalloc_grp_bkng_cn"), \
                    when(ship_inventory_alloc_unalloc_tmp_df.alloc_grp_gst_cn.isNull(), lit("0") \
                         .cast("integer")).alias("alloc_grp_gst_cn"), \
                    when(ship_inventory_alloc_unalloc_tmp_df.unalloc_grp_gst_cn.isNull(), lit("0") \
                         .cast("integer")).alias("unalloc_grp_gst_cn"), \
                    when(ship_inventory_alloc_unalloc_tmp_df.dlgt_grp_bkng_cn.isNull(), lit("0") \
                         .cast("integer")).alias("dlgt_grp_bkng_cn")).distinct()


        ship_inventory_alloc_unalloc_df.createOrReplaceTempView("ship_inventory_alloc_unalloc_vw")
        if debug == 1:
            DebugCount.debug_counts(ship_inventory_alloc_unalloc_df, "ship_inventory_alloc_unalloc_df")
        print(" Completed : ship_inventory_alloc_unalloc_df Operation Here ")
        con_res_df = res_baseln_con_df.join(ship_inventory_alloc_unalloc_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"],
                                            "left_outer") \
            .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", res_baseln_con_df.pu_bkng_cn,
                    res_baseln_con_df.cncl_bkng_cn \
                    , res_baseln_con_df.grs_paid_bkng_cn, res_baseln_con_df.oh_bkng_gst_cn \
                    , res_baseln_con_df.oh_unasgn_bkng_gst_cn, res_baseln_con_df.oh_asgn_bkng_gst_cn \
                    , coalesce(res_baseln_con_df.oh_paid_bkng_cn, lit("0")).alias("oh_paid_bkng_cn") \
                    , coalesce(res_baseln_con_df.oh_asgn_bkng_cn, lit("0")).alias("oh_asgn_bkng_cn") \
                    , coalesce(res_baseln_con_df.oh_unasgn_bkng_cn, lit("0")).alias("oh_unasgn_bkng_cn") \
                    , coalesce(ship_inventory_alloc_unalloc_df.dlgt_grp_bkng_cn, lit("0")).alias(
                "dlgt_grp_bkng_cn")).distinct()

        con_res_df.createOrReplaceTempView("con_res_vw")

        print("1oth,4th Cal Start Here ")
        txn_dt_week_num_vw_df = sql_context.sql(" select * from txn_dt_week_num")
        print("txn_dt_week_num_vw_df====>", txn_dt_week_num_vw_df)
        vyge_strm_typ_drvr_wk_txn_df = sql_context.sql(" select * from vyge_strm_typ_drvr_wk_txn_vw ")

        vyge_strm_typ_drvr_wk_txn_weeks_df = vyge_strm_typ_drvr_wk_txn_df.join(ship_strm_typ_ext_df, \
                                                            (vyge_strm_typ_drvr_wk_txn_df.ship_cd == ship_strm_typ_ext_df.ship_cd)
                                                            & (vyge_strm_typ_drvr_wk_txn_df.ship_strm_ctgy_nm == ship_strm_typ_ext_df.ship_ctgy_nm)
                                                            & (vyge_strm_typ_drvr_wk_txn_df.txn_dt >= ship_strm_typ_ext_df.vrsn_strt_dts)
                                                            & (vyge_strm_typ_drvr_wk_txn_df.txn_dt < ship_strm_typ_ext_df.vrsn_end_dts)) \
            .select(vyge_strm_typ_drvr_wk_txn_df.vyge_id,
                    ship_strm_typ_ext_df.ship_strm_typ_cd.alias("strm_typ_cd"),
                    vyge_strm_typ_drvr_wk_txn_df.ship_strm_ctgy_nm,
                    vyge_strm_typ_drvr_wk_txn_df.txn_dt,
                    vyge_strm_typ_drvr_wk_txn_df.ship_cd,
                    vyge_strm_typ_drvr_wk_txn_df.vyge_dprt_dt,
                    vyge_strm_typ_drvr_wk_txn_df.app_vyge_id,
                    vyge_strm_typ_drvr_wk_txn_df.dy_bef_vyge_cn,
                    vyge_strm_typ_drvr_wk_txn_df.vyge_drtn_nght_cn).distinct()
        print("Need to Check vyge_strm_typ_drvr_wk_txn_df")


        vyge_strm_typ_drvr_wk_txn_df = vyge_strm_typ_drvr_wk_txn_df.withColumnRenamed("ship_ctgy_nm", "strm_ctgy_nm")
        print("vyge_strm_typ_drvr_wk_txn_df====>", vyge_strm_typ_drvr_wk_txn_df)
        res_baseln_week_num_df = res_baseln_strm_level_df.join(txn_dt_week_num_vw_df, \
                                                               (res_baseln_strm_level_df.txn_dt == txn_dt_week_num_vw_df.txn_date)) \
            .select("vyge_id", \
                    "strm_ctgy_nm", \
                    "txn_dt", \
                    "pu_bkng_cn", \
                    "cncl_bkng_cn", \
                    "week_num").distinct()

        driver_week_num_df = vyge_strm_typ_drvr_wk_txn_weeks_df.join(txn_dt_week_num_vw_df, \
                                                               (vyge_strm_typ_drvr_wk_txn_weeks_df.txn_dt == txn_dt_week_num_vw_df.txn_date)) \
            .select("vyge_id", \
                    "strm_ctgy_nm", \
                    "txn_dt", \
                    "week_num").distinct()

        window_four_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm").orderBy("week_num").rowsBetween(-4, -1)
        window_ten_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm") \
            .orderBy("week_num") \
            .rowsBetween(-10, -1)
        window_prev_wk = Window.partitionBy("vyge_id", "strm_ctgy_nm") \
            .orderBy("week_num") \
            .rowsBetween(-1, -1)

        week_num_group_sum_temp_df = driver_week_num_df.join(res_baseln_week_num_df, \
                                                             ["vyge_id", "strm_ctgy_nm", "txn_dt", "week_num"]) \
            .groupBy("vyge_id", "strm_ctgy_nm", "week_num") \
            .agg(sum("pu_bkng_cn").alias("pu_bkng_cn_sum"), \
                 sum("cncl_bkng_cn").alias("cncl_bkng_cn_sum")) \
            .select("vyge_id", \
                    "strm_ctgy_nm", \
                    "week_num", \
                    "pu_bkng_cn_sum", \
                    "cncl_bkng_cn_sum") \
            .withColumn("pu_cncl_bkng_cn_sum", (col("pu_bkng_cn_sum") - col("cncl_bkng_cn_sum"))) \
            .drop(col("pu_bkng_cn_sum")) \
            .drop(col("cncl_bkng_cn_sum"))
        week_num_group_sum_temp_df=week_num_group_sum_temp_df.distinct()
        week_num_group_sum_df = week_num_group_sum_temp_df \
            .withColumn("four_wk_pu_bkng_cn_tmp", \
                        sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
                        .over(window_four_wk)) \
            .withColumn("ten_wk_pkup_bkng_cn_tmp", \
                        sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
                        .over(window_ten_wk)) \
            .withColumn("prev_wk_pu_bkng_cn_tmp", \
                        sum(week_num_group_sum_temp_df.pu_cncl_bkng_cn_sum) \
                        .over(window_prev_wk))

        if debug == 1:
            DebugCount.debug_counts(week_num_group_sum_df, "week_num_group_sum_vw")

        ten_four_wk_metrics_temp_df = driver_week_num_df.join(week_num_group_sum_df, \
                                                              ["vyge_id", "strm_ctgy_nm", "week_num"], "left_outer") \
            .select("vyge_id", \
                    "strm_ctgy_nm", \
                    "txn_dt", \
                    "week_num", \
                    when(col("four_wk_pu_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
                    .otherwise(col("four_wk_pu_bkng_cn_tmp")).alias("four_wk_pu_bkng_cn_tmp"), \
                    when(col("ten_wk_pkup_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
                    .otherwise(col("ten_wk_pkup_bkng_cn_tmp")).alias("ten_wk_pkup_bkng_cn_tmp"), \
                    when(col("prev_wk_pu_bkng_cn_tmp").isNull(), lit("0").cast("integer")) \
                    .otherwise(col("prev_wk_pu_bkng_cn_tmp")).alias("prev_wk_pu_bkng_cn_tmp")).distinct()

        if debug == 1:
            DebugCount.debug_counts(ten_four_wk_metrics_temp_df, "ten_four_wk_metrics_temp_vw")

        res_baseln_strm_level_tmp_df = vyge_strm_typ_drvr_wk_txn_df.join(res_baseln_strm_level_df \
                                                                         .select("vyge_id", "strm_ctgy_nm", "txn_dt",
                                                                                 "curr_wk_pu_bkng_cn"), \
                                                                         ["vyge_id", "strm_ctgy_nm", "txn_dt"],
                                                                         "left_outer") \
            .select("vyge_id", \
                    "strm_ctgy_nm", \
                    "txn_dt", \
                    res_baseln_strm_level_df.curr_wk_pu_bkng_cn) \
            .groupBy("vyge_id", "strm_ctgy_nm", "txn_dt") \
            .agg(sum("curr_wk_pu_bkng_cn").alias("curr_wk_pu_bkng_cn_sum")) \
            .distinct()
        # debug=1

        ten_four_prev_wk_metrics_temp_df = ten_four_wk_metrics_temp_df.join(res_baseln_strm_level_tmp_df, \
                                                                            ["vyge_id", "strm_ctgy_nm", "txn_dt"]). \
            select("vyge_id", \
                   "strm_ctgy_nm", \
                   "txn_dt", \
                   col("four_wk_pu_bkng_cn_tmp").alias("four_wk_pu_bkng_cn") \
                   , col("ten_wk_pkup_bkng_cn_tmp").alias("ten_wk_pkup_bkng_cn") \
                   , col("prev_wk_pu_bkng_cn_tmp").alias("prev_wk_pu_bkng_cn") \
                   , when(res_baseln_strm_level_tmp_df.curr_wk_pu_bkng_cn_sum.isNull(), lit("0").cast("integer")) \
                   .otherwise(res_baseln_strm_level_tmp_df.curr_wk_pu_bkng_cn_sum).alias("curr_wk_pu_bkng_cn_tmp")).distinct()
        ten_four_prev_wk_metrics_temp_df = ten_four_prev_wk_metrics_temp_df.withColumnRenamed("strm_ctgy_nm",
                                                                                              "ship_strm_ctgy_nm")
        if debug == 1:
            DebugCount.debug_counts(ten_four_prev_wk_metrics_temp_df, "ten_four_prev_wk_metrics_temp_vw")
        # ten_four_prev_wk_metrics_temp_df.agg(min("txn_dt").alias("min_txn_dt"), max("txn_dt").alias("max_txn_dt")).show()

        filter_txn_wk_clause = "txn_dt >= date('%s') and txn_dt <= date('%s')" % (start_dt, end_dt)

        ten_four_prev_wk_metrics_df = ten_four_prev_wk_metrics_temp_df \
            .withColumn("four_wk_pu_avg_bkng_cn", \
                        (ten_four_prev_wk_metrics_temp_df.four_wk_pu_bkng_cn / 4.00) \
                        .cast("decimal(8,2)")) \
            .withColumn("ten_wk_pu_avg_bkng_cn", \
                        (ten_four_prev_wk_metrics_temp_df.ten_wk_pkup_bkng_cn / 10.00) \
                        .cast("decimal(8,2)")).filter(filter_txn_wk_clause)

        if debug == 1:
            DebugCount.debug_counts(ten_four_prev_wk_metrics_df, "ten_four_prev_wk_metrics_vw")

        ten_four_prev_wk_metrics_df.createOrReplaceTempView("ten_four_prev_wk_metrics_vw")
        # ten_four_prev_wk_metrics_df.agg(min("txn_dt").alias("min_txn_dt"), max("txn_dt").alias("max_txn_dt")).show()
        print(" END OF CONSOLIADTED RESBASELN ")



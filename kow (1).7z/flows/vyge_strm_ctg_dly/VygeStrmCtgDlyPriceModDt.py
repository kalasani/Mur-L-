#####################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                #
# Program name      : Promotional pricing - Con_resbaseln                           #
# Author            : Kowshik Y                                                     #
# Date created      : 20180619                                                      #
# Purpose           : To fetch VF metrices from raw resbaseln data                  #
# Revision History  :                                                               #
#   Date        Author     Ref    Revision (Date in YYYYMMDD format)                #
# 20180620    kowshik Y   Chris                                                     #
#                                                                                   #
#####################################################################################

#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/objects #
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.DebugCount import *;
from pyspark.sql.types import *
import os, sys

class VygeStrmCtgDlyPriceModDt(object):
    @staticmethod
    def run_viz_ppp_metrics(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,debug):

            ##################################################################
            # Driver program to run promotional_price dm main process method #
            # Attributes                                                     #
            # start_dt    : the time slice that is being executed            #
            # sql_context : the spark sql context                            #
            # s3_bucket   : the s3 bucket that identifies the data source    #
            # debug       :  debugging the counts                            #
            ##################################################################


            ######################################################################################################
            # Populate PPP grs pd amount metrics by merging with driver program to fetch grs per dimension       #
            ######################################################################################################

            vyge_strm_typ_drvr_df = sql_context.sql(" select * from driver")

            proc_price_pt_vw_df = sql_context.sql(""" 
                                select vyge_id,
                                    strm_typ_cd,
                                    txn_dt, 
                                    ship_cd,
                                    non_comm_am,
                                    vyge_drtn_nght_cn,
                                    upper(sfb_nm) as sfb_nm,
                                    vfd_am,
                                    vfa_extra_am,
                                    vfc_extra_am,
                                    vfi_extra_am,
                                    vfs_am, 
                                    upper(proc_price_src_sys_nm) as proc_price_src_sys_nm  
                                from proc_price_pt """).distinct()

            filter_clause = """ proc_price_src_sys_nm in ('PRICING EXTRACT','CABIN CAT') 
                                and sfb_nm in ('PREVAIL','GTY') """

            proc_price_pt_src_syn_nm_df = proc_price_pt_vw_df.filter(filter_clause) \
                .select("vyge_id", \
                        "strm_typ_cd", \
                        "txn_dt", \
                        "proc_price_src_sys_nm") \
                .withColumn("proc_price_src_sys_min", \
                            when(col("proc_price_src_sys_nm") == 'PRICING EXTRACT', \
                                 lit("1").cast("integer")) \
                            .otherwise(when(col("proc_price_src_sys_nm") == 'CABIN CAT', \
                                            lit("2").cast("integer")))) \
                .groupBy("vyge_id", \
                         "strm_typ_cd", \
                         "txn_dt") \
                .agg(min("proc_price_src_sys_min").alias("proc_price_src_sys_nb"))

            vyge_strm_typ_drvr_max_txn_df = vyge_strm_typ_drvr_df.groupBy("vyge_id", "strm_typ_cd") \
                .agg(max("txn_dt") \
                     .alias("max_txn_dt")).distinct()

            proc_price_pt_max_df = proc_price_pt_src_syn_nm_df.join(vyge_strm_typ_drvr_max_txn_df, \
                                                                    (
                                                                                vyge_strm_typ_drvr_max_txn_df.vyge_id == proc_price_pt_src_syn_nm_df.vyge_id) \
                                                                    & (
                                                                                vyge_strm_typ_drvr_max_txn_df.strm_typ_cd == proc_price_pt_src_syn_nm_df.strm_typ_cd) \
                                                                    & (
                                                                                vyge_strm_typ_drvr_max_txn_df.max_txn_dt == proc_price_pt_src_syn_nm_df.txn_dt)) \
                .select(vyge_strm_typ_drvr_max_txn_df.vyge_id, \
                        vyge_strm_typ_drvr_max_txn_df.strm_typ_cd, \
                        proc_price_pt_src_syn_nm_df.txn_dt, \
                        proc_price_pt_src_syn_nm_df.proc_price_src_sys_nb) \
                .withColumn("pp_src_sys_nm", \
                            when(col("proc_price_src_sys_nb") == 1, \
                                 lit("PRICING EXTRACT")) \
                            .otherwise(when(col("proc_price_src_sys_nb") == 2, \
                                            lit("CABIN CAT")))) \
                .groupBy("vyge_id", "strm_typ_cd", "pp_src_sys_nm") \
                .agg(max("txn_dt").alias("txn_dt"))

            proc_price_pt_mod_dt_temp_df = proc_price_pt_max_df.join(proc_price_pt_vw_df, \
                                                                     (
                                                                                 proc_price_pt_max_df.vyge_id == proc_price_pt_vw_df.vyge_id) \
                                                                     & (
                                                                                 proc_price_pt_max_df.strm_typ_cd == proc_price_pt_vw_df.strm_typ_cd) \
                                                                     & (
                                                                                 proc_price_pt_max_df.pp_src_sys_nm == proc_price_pt_vw_df.proc_price_src_sys_nm) \
                                                                     & (
                                                                                 proc_price_pt_max_df.txn_dt == proc_price_pt_vw_df.txn_dt)) \
                .select(proc_price_pt_vw_df.vyge_id, \
                        proc_price_pt_vw_df.strm_typ_cd, \
                        proc_price_pt_max_df.txn_dt, \
                        proc_price_pt_vw_df.sfb_nm, \
                        proc_price_pt_max_df.pp_src_sys_nm, \
                        proc_price_pt_vw_df.non_comm_am, \
                        proc_price_pt_vw_df.vyge_drtn_nght_cn, \
                        proc_price_pt_vw_df.sfb_nm, \
                        proc_price_pt_vw_df.vfd_am, \
                        proc_price_pt_vw_df.vfa_extra_am, \
                        proc_price_pt_vw_df.vfc_extra_am, \
                        proc_price_pt_vw_df.vfi_extra_am, \
                        proc_price_pt_vw_df.vfs_am).distinct()

            window_non_comm = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)
            window_vfd_am = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)
            window_vfa_extra_am = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)
            window_vfc_extra_am = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)
            window_vfi_extra_am = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)
            window_vfs_am = Window.partitionBy("vyge_id", "strm_typ_cd").orderBy("txn_dt").rowsBetween(-1, -1)

            proc_price_pt_mod_dt_max_df = proc_price_pt_mod_dt_temp_df \
                .withColumn("prev_non_comm_am", max(col("non_comm_am")).over(window_non_comm)) \
                .withColumn("prev_vfd_am", max(col("vfd_am")).over(window_vfd_am)) \
                .withColumn("prev_vfa_extra_am", max(col("vfa_extra_am")).over(window_vfa_extra_am)) \
                .withColumn("prev_vfc_extra_am", max(col("vfc_extra_am")).over(window_vfc_extra_am)) \
                .withColumn("prev_vfi_extra_am", max(col("vfi_extra_am")).over(window_vfi_extra_am)) \
                .withColumn("prev_vfs_am", max(col("vfs_am")).over(window_vfs_am))

            proc_price_pt_mod_dt_df = proc_price_pt_mod_dt_max_df \
                .withColumn("flg_non_comm_am", \
                            when(proc_price_pt_mod_dt_max_df.non_comm_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_non_comm_am.isNull(), lit("0").cast("integer")) \
                            .otherwise(
                                when((proc_price_pt_mod_dt_max_df.non_comm_am == proc_price_pt_mod_dt_max_df.prev_non_comm_am) \
                                     , lit("0").cast("integer")) \
                                .otherwise(lit("1").cast("integer")))) \
                .withColumn("flg_vfd", \
                            when(proc_price_pt_mod_dt_max_df.vfd_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_vfd_am.isNull(), lit("0").cast("integer")) \
                            .otherwise(when((proc_price_pt_mod_dt_max_df.vfd_am == proc_price_pt_mod_dt_max_df.prev_vfd_am), \
                                            lit("0").cast("integer")) \
                                       .otherwise(lit("1").cast("integer")))) \
                .withColumn("flg_vfa", \
                            when(proc_price_pt_mod_dt_max_df.vfa_extra_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_vfa_extra_am.isNull(), lit("0").cast("integer")) \
                            .otherwise(when(
                                (proc_price_pt_mod_dt_max_df.vfa_extra_am == proc_price_pt_mod_dt_max_df.prev_vfa_extra_am), \
                                lit("0").cast("integer")) \
                                       .otherwise(lit("1").cast("integer")))) \
                .withColumn("flg_vfc", \
                            when(proc_price_pt_mod_dt_max_df.vfc_extra_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_vfc_extra_am.isNull(), lit("0").cast("integer")) \
                            .otherwise(when(
                                (proc_price_pt_mod_dt_max_df.vfc_extra_am == proc_price_pt_mod_dt_max_df.prev_vfc_extra_am), \
                                lit("0").cast("integer")) \
                                       .otherwise(lit("1").cast("integer")))) \
                .withColumn("flg_vfi", \
                            when(proc_price_pt_mod_dt_max_df.vfi_extra_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_vfi_extra_am.isNull(), lit("0").cast("integer")) \
                            .otherwise( \
                                when(
                                    (proc_price_pt_mod_dt_max_df.vfi_extra_am == proc_price_pt_mod_dt_max_df.prev_vfi_extra_am), \
                                    lit("0").cast("integer")) \
                                    .otherwise(lit("1").cast("integer")))) \
                .withColumn("flg_vfs", \
                            when(proc_price_pt_mod_dt_max_df.vfs_am.isNull() \
                                 | proc_price_pt_mod_dt_max_df.prev_vfs_am.isNull(), lit("0").cast("integer")) \
                            .otherwise( \
                                when((proc_price_pt_mod_dt_max_df.vfs_am == proc_price_pt_mod_dt_max_df.prev_vfs_am), \
                                     lit("0").cast("integer")) \
                                    .otherwise(lit("1").cast("integer")))) \
                .drop(col("prev_non_comm_am")) \
                .drop(col("prev_vfd_am")) \
                .drop(col("prev_vfa_extra_am")) \
                .drop(col("prev_vfc_extra_am")) \
                .drop(col("prev_vfi_extra_am")) \
                .drop(col("prev_vfs_am"))

            proc_price_pt_src_df = proc_price_pt_mod_dt_df \
                .withColumn("max_chg_dt", \
                            when((col("flg_vfd") == 1) \
                                 | (col("flg_vfs") == 1) \
                                 | (col("flg_vfa") == 1) \
                                 | (col("flg_vfc") == 1) \
                                 | (col("flg_vfi") == 1) \
                                 | (col("flg_non_comm_am") == 1), col("txn_dt")) \
                            .otherwise(lit(""))) \
                .drop(col("flg_vfd")) \
                .drop(col("flg_vfs")) \
                .drop(col("flg_vfa")) \
                .drop(col("flg_vfc")) \
                .drop(col("flg_vfi")) \
                .drop(col("flg_non_comm_am"))
            proc_price_pt_src_df.createOrReplaceTempView("proc_price_pt_src")

            proc_price_grs_pd_am_temp_df = proc_price_pt_src_df.filter("max_chg_dt is not null") \
                .select("vyge_id", \
                        "strm_typ_cd", \
                        "sfb_nm", \
                        "txn_dt", \
                        "pp_src_sys_nm", \
                        "non_comm_am", \
                        "vyge_drtn_nght_cn", \
                        "vfd_am", \
                        "vfa_extra_am", \
                        "vfc_extra_am", \
                        "vfi_extra_am", \
                        "vfs_am", \
                        col("max_chg_dt").alias("price_mod_dt")) \
                .withColumn("vfd_prevl_grs_pd_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfd_am") < 1000000)), \
                                 ((col("vfd_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                 .cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfd_am") < 1000000)), \
                                            ((col("vfd_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                            .cast("decimal(12,2)")))) \
         \
                .withColumn("vfa_extra_prevl_grs_pd_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfa_extra_am") < 1000000)), \
                                 ((col("vfa_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                 .cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfa_extra_am") < 1000000)), \
                                            ((col("vfa_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                            .cast("decimal(12,2)")))) \
         \
                .withColumn("vfc_extra_prevl_grs_pd_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfc_extra_am") < 1000000)), \
                                 ((col("vfc_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                 .cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfc_extra_am") < 1000000)), \
                                            ((col("vfc_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                            .cast("decimal(12,2)")))) \
         \
                .withColumn("vfi_extra_prevl_grs_pd_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfi_extra_am") < 1000000)), \
                                 ((col("vfi_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                 .cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfi_extra_am") < 1000000)), \
                                            ((col("vfi_extra_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                            .cast("decimal(12,2)")))) \
         \
                .withColumn("vfs_prevl_grs_pd_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfs_am") < 1000000)), \
                                 ((col("vfs_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")) \
                                 .cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfs_am") < 1000000)), \
                                            ((col("vfs_am") + col("non_comm_am")) / col("vyge_drtn_nght_cn")).cast(
                                                "decimal(12,2)")))) \
         \
                .withColumn("vfd_prevl_rt_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfd_am") < 1000000)), \
                                 (col("vfd_am") + col("non_comm_am")).cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfd_am") < 1000000)), \
                                            (col("vfd_am") + col("non_comm_am")).cast("decimal(12,2)")))) \
         \
                .withColumn("vfa_extra_prevl_rt_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfa_extra_am") < 1000000)), \
                                 (col("vfa_extra_am") + col("non_comm_am")).cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfa_extra_am") < 1000000)), \
                                            (col("vfa_extra_am") + col("non_comm_am")).cast("decimal(12,2)")))) \
         \
                .withColumn("vfc_extra_prevl_rt_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfc_extra_am") < 1000000)), \
                                 (col("vfc_extra_am") + col("non_comm_am")).cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfc_extra_am") < 1000000)), \
                                            (col("vfc_extra_am") + col("non_comm_am")).cast("decimal(12,2)")))) \
         \
                .withColumn("vfi_extra_prevl_rt_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfi_extra_am") < 1000000)), \
                                 (col("vfi_extra_am") + col("non_comm_am")).cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfi_extra_am") < 1000000)), \
                                            (col("vfi_extra_am") + col("non_comm_am")).cast("decimal(12,2)")))) \
         \
                .withColumn("vfs_prevl_rt_am", \
                            when((((col("strm_typ_cd") == 'IGT') \
                                   | (col("strm_typ_cd") == 'OGT') \
                                   | (col("strm_typ_cd") == 'VGT')) \
                                  & (col("sfb_nm") == 'GTY') & (col("vfs_am") < 1000000)), \
                                 (col("vfs_am") + col("non_comm_am")).cast("decimal(12,2)")) \
                            .otherwise(when((((col("strm_typ_cd") != 'IGT') \
                                              | (col("strm_typ_cd") != 'OGT') \
                                              | (col("strm_typ_cd") != 'VGT')) \
                                             & (col("sfb_nm") == 'PREVAIL') & (col("vfs_am") < 1000000)), \
                                            (col("vfs_am") + col("non_comm_am")).cast("decimal(12,2)"))))

            proc_price_grs_pd_am_df = proc_price_grs_pd_am_temp_df \
                .withColumn("vfa_config_pc", \
                            ((proc_price_grs_pd_am_temp_df.vfa_extra_prevl_grs_pd_am) \
                             / proc_price_grs_pd_am_temp_df.vfd_prevl_grs_pd_am) * 100) \
                .withColumn("vfc_config_pc", \
                            ((proc_price_grs_pd_am_temp_df.vfc_extra_prevl_grs_pd_am) \
                             / proc_price_grs_pd_am_temp_df.vfa_extra_prevl_grs_pd_am) * 100) \
                .withColumn("vfi_config_pc", \
                            ((proc_price_grs_pd_am_temp_df.vfi_extra_prevl_grs_pd_am) \
                             / proc_price_grs_pd_am_temp_df.vfc_extra_prevl_grs_pd_am) * 100) \
                .withColumn("gtr_pd_am", \
                            (proc_price_grs_pd_am_temp_df.vfd_prevl_rt_am \
                             / proc_price_grs_pd_am_temp_df.vyge_drtn_nght_cn)).distinct()

            proc_price_pt_metrics_vw_df = vyge_strm_typ_drvr_df.join(proc_price_grs_pd_am_df, \
                                                                     ["vyge_id", "strm_typ_cd", "txn_dt"], "left_outer") \
                .select(vyge_strm_typ_drvr_df.vyge_id,
                        vyge_strm_typ_drvr_df.strm_typ_cd,
                        vyge_strm_typ_drvr_df.txn_dt,
                        vyge_strm_typ_drvr_df.ship_strm_ctgy_nm,
                        proc_price_grs_pd_am_df.price_mod_dt,
                        proc_price_grs_pd_am_df.vfd_prevl_grs_pd_am,
                        proc_price_grs_pd_am_df.vfa_extra_prevl_grs_pd_am,
                        proc_price_grs_pd_am_df.vfc_extra_prevl_grs_pd_am,
                        proc_price_grs_pd_am_df.vfi_extra_prevl_grs_pd_am,
                        proc_price_grs_pd_am_df.vfs_prevl_grs_pd_am,
                        proc_price_grs_pd_am_df.vfd_prevl_rt_am,
                        proc_price_grs_pd_am_df.vfa_extra_prevl_rt_am,
                        proc_price_grs_pd_am_df.vfc_extra_prevl_rt_am,
                        proc_price_grs_pd_am_df.vfi_extra_prevl_rt_am,
                        proc_price_grs_pd_am_df.vfs_prevl_rt_am,
                        proc_price_grs_pd_am_df.vfa_config_pc.cast("decimal(12,2)"),
                        proc_price_grs_pd_am_df.vfc_config_pc.cast("decimal(12,2)"),
                        proc_price_grs_pd_am_df.vfi_config_pc.cast("decimal(12,2)"),
                        proc_price_grs_pd_am_df.gtr_pd_am.cast("decimal(12,2)"))

            if debug == 1:
                DebugCount.debug_counts(proc_price_pt_metrics_vw_df, "proc_price_pt_metrics_vw")
            proc_price_pt_metrics_vw_df.createOrReplaceTempView("proc_price_pt_vw")
            print("Final In PPPT Metics here ===>Proc_price_pt")
            proc_price_pt_metrics_vw_df.printSchema()
            proc_price_pt_metrics_vw_df.show();
            print
            " END OF PPP METRICS "

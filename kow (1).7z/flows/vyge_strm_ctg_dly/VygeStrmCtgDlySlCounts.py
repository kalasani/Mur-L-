##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : Voyage StateRoom Type                                              #
# Author            : Anjaiah M                                                          #
# Date created      : 2018-08-26                                                         #
# Purpose           : To build the driver program                                        #
# Revision History  :                                                                    #
# Date           Author     Ref    Revision (Date in YYYYMMDD format)                    #
# 2018-08-26    kowshik Y   Chris                                                        #
#                                                                                        #
##########################################################################################


#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from framework.utils.DebugCount import *;
from pyspark.sql.functions import *
import sys, traceback
from pyspark.sql.types import *
import os, sys

class VygeStrmCtgDlySlCounts(object):
    @staticmethod
    def run_viz_vyge_count_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader,debug):
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################


        #######################################################################
        #  Calculating max of absolute_lim_nb from sl_lim_vyge_sum dataset    #
        #######################################################################
        proc_price_pt_diff_df = data_loader.read_data_from_path("con/PROC_PRICE_PT_DIFF")
        vyge_strm_typ_drvr_df = sql_context.sql("select * from Driver ");
        proc_price_pt_diff_df.createOrReplaceTempView("proc_price_pt_diff_tmp_vw")

        price_mod_date_temp_df = vyge_strm_typ_drvr_df.join(proc_price_pt_diff_df, \
                                                            (
                                                                        vyge_strm_typ_drvr_df.vyge_id == proc_price_pt_diff_df.vyge_id) \
                                                            & (
                                                                        vyge_strm_typ_drvr_df.strm_typ_cd == proc_price_pt_diff_df.strm_typ_cd) \
                                                            & (
                                                                        proc_price_pt_diff_df.txn_dt <= vyge_strm_typ_drvr_df.txn_dt)) \
            .select(vyge_strm_typ_drvr_df.vyge_id, \
                    vyge_strm_typ_drvr_df.ship_strm_ctgy_nm, \
                    proc_price_pt_diff_df.txn_dt) \
            .groupBy("vyge_id", "ship_strm_ctgy_nm") \
            .agg(max("txn_dt").alias("price_mod_dt")) \
            .select(col("vyge_id").alias("vyge_id_tmp"), \
                    col("strm_typ_cd").alias("strm_typ_cd_tmp"), "price_mod_dt")

        price_mod_date_df = vyge_strm_typ_drvr_df.join(price_mod_date_temp_df, \
                                                       (
                                                                   vyge_strm_typ_drvr_df.vyge_id == price_mod_date_temp_df.vyge_id_tmp) \
                                                       & (
                                                                   vyge_strm_typ_drvr_df.ship_strm_ctgy_nm == price_mod_date_temp_df.ship_strm_ctgy_nm),
                                                       "left_outer") \
            .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", price_mod_date_temp_df.price_mod_dt)
        price_mod_date_df.createOrReplaceTempView("price_mod_date_vw")

        sl_lim_strm_typ_cn_df = sql_context.sql(""" 
    			select driver.vyge_id,
    			driver.ship_strm_ctgy_nm,
    			driver.txn_dt,
    			Max(sl_lim_vyge_sum.absolute_lim_nb) as sl_lim_strm_typ_cn
    			from driver driver,sl_lim_vyge_sum sl_lim_vyge_sum
    			where driver.vyge_id = sl_lim_vyge_sum.sail_id
    			and driver.strm_typ_cd=sl_lim_vyge_sum.cbn_ctgy_cd
    			and driver.txn_dt >= date(sl_lim_vyge_sum.vrsn_strt_dts)
    			and driver.txn_dt < date(sl_lim_vyge_sum.vrsn_end_dts)
    			group by driver.vyge_id,
    			driver.ship_strm_ctgy_nm,
    			driver.txn_dt 
    			""").dropDuplicates()

        sl_lim_strm_typ_cn_df.createOrReplaceTempView("sl_lim_strm_typ_cn_vw")
        sl_lim_strm_typ_cn_df.printSchema();
        sl_lim_strm_typ_cn_df.show();
        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_cn_df, "sl_lim_strm_typ_cn_df")

        strm_typ_nest_confg_temp_df1 = sql_context.sql("""
    		SELECT ship_cd,
    		strm_ctgy_nm,
    		src_sys_strm_typ_nm,
    		sci_rcmd_excl_in,
    		STRM_TYP_NEST_CONFIG_STRT_DTS as vrsn_strt_dts
    		FROM strm_typ_nest_config
    		WHERE UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM')
    		""").dropDuplicates()

        strm_typ_nest_confg_temp_df1.createOrReplaceTempView("strm_typ_nest_confg_temp_vw")

        strm_typ_nest_confg_df1 = sql_context.sql(""" 
    			select *, 
         		    		COALESCE(MAX(VRSN_STRT_DTS) 
             			OVER(PARTITION BY SHIP_CD,strm_ctgy_nm ORDER BY VRSN_STRT_DTS ASC ROWS BETWEEN 1 FOLLOWING AND 1 FOLLOWING),
             			CAST('9999-12-31 00:00:00.000000' AS TIMESTAMP)) AS VRSN_END_DTS
    			FROM strm_typ_nest_confg_temp_vw """).dropDuplicates()

        strm_typ_nest_confg_df1.createOrReplaceTempView("strm_typ_nest_confg_vw")
        strm_typ_nest_config_split_df1 = strm_typ_nest_confg_df1.withColumn("strm_typ_cd", \
                                                                            explode(split(
                                                                                strm_typ_nest_confg_df1.src_sys_strm_typ_nm,
                                                                                "[;]"))) \
            .select("ship_cd", "sci_rcmd_excl_in", "strm_ctgy_nm", "strm_typ_cd", "vrsn_strt_dts",
                    "vrsn_end_dts").distinct()

        strm_typ_nest_config_split_df1.createOrReplaceTempView("strm_typ_nest_config_split_vw1")

        sl_lim_rcmd_lim_df = sql_context.sql("""
    	select 
    	    drvr.vyge_id,
    		drvr.ship_strm_ctgy_nm,
    		drvr.txn_dt as txn_dt, 
    		SUM(drvr.rcmd_lim) as sl_lim_strm_cn
    	FROM (SELECT 
    		driver.vyge_id,
    		driver.ship_strm_ctgy_nm,
    		driver.txn_dt ,
    		strm_typ_nest_config.src_sys_strm_typ_nm,
    		MAX(absolute_lim_nb) as rcmd_lim
    	FROM driver join strm_typ_nest_confg_vw strm_typ_nest_config 
    	ON driver.ship_cd = strm_typ_nest_config.ship_cd
    	    AND strm_typ_nest_config.STRM_CTGY_NM =driver.ship_strm_ctgy_nm
    		AND (UPPER(strm_typ_nest_config.strm_ctgy_nm) = 'SHIPSCI'
    		OR UPPER(strm_typ_nest_config.sci_rcmd_excl_in) = 'Y')
    		and date(strm_typ_nest_config.vrsn_strt_dts) <= driver.txn_dt
    		and date(strm_typ_nest_config.vrsn_end_dts) > driver.txn_dt

        JOIN sl_lim_vyge_sum   ON 	 
    		sl_lim_vyge_sum.sail_id = driver.vyge_id
    		and strm_typ_nest_config.src_sys_strm_typ_nm = sl_lim_vyge_sum.cbn_ctgy_cd
    		and date(sl_lim_vyge_sum.vrsn_strt_dts) <= driver.txn_dt
    		and date(sl_lim_vyge_sum.vrsn_end_dts) > driver.txn_dt
    		and UPPER(sl_lim_vyge_sum.instnc_st_nm) = 'STANDARD'

    	WHERE sl_lim_vyge_sum.cbn_ctgy_cd is not null
    			and sl_lim_vyge_sum.promo_cd is null
    			and sl_lim_vyge_sum.prod_typ_cd is null
    			and sl_lim_vyge_sum.pkg_typ_cd is null
    			and sl_lim_vyge_sum.age_ctgy_cd is null
    			and sl_lim_vyge_sum.ocpncy_cn is null
    			and sl_lim_vyge_sum.ref_src_nm is null
    			and sl_lim_vyge_sum.res_typ_cd is null
    			and sl_lim_vyge_sum.agcy_id is null
    			and sl_lim_vyge_sum.grp_typ_cd is null
    			and sl_lim_vyge_sum.dng_tm is null
    			and sl_lim_vyge_sum.age_fr_nb is null
    			and sl_lim_vyge_sum.age_to_nb is null
    			and sl_lim_vyge_sum.gst_seq_fr_nb is null
    			and sl_lim_vyge_sum.gst_seq_to_nb is null
    			and sl_lim_vyge_sum.conditiontext is null
    			and sl_lim_vyge_sum.auth_cd is null		
    	GROUP BY driver.vyge_id,
    		driver.ship_strm_ctgy_nm,
    		driver.txn_dt,
    		strm_typ_nest_config.src_sys_strm_typ_nm) drvr
    	GROUP BY  drvr.vyge_id,
                    drvr.ship_strm_ctgy_nm,
                    drvr.txn_dt
        		""").dropDuplicates()

        sl_lim_rcmd_lim_df.createOrReplaceTempView("sl_lim_rcmd_lim_vw")
        sl_lim_rcmd_lim_df.printSchema();
        sl_lim_rcmd_lim_df.show();

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_lim_df, "sl_lim_rcmd_lim_vw")

        driver_df = sql_context.sql(""" select driver.*,
        			vw.oh_paid_bkng_cn,
        			vw.oh_asgn_bkng_cn,
        			vw.oh_unasgn_bkng_cn,
        			vw.dlgt_grp_bkng_cn
        			from driver join con_res_vw vw
        			ON driver.vyge_id = vw.vyge_id
        			AND driver.ship_strm_ctgy_nm = vw.ship_strm_ctgy_nm 
        			AND driver.txn_dt = vw.txn_dt
        			""").dropDuplicates()
        driver_df.createOrReplaceTempView("driver_subset")
        if debug == 1:
            DebugCount.debug_counts(driver_df, "driver_df")

        pd_asn_bkng_cn_df = sql_context.sql(""" 
    			select ds.vyge_id,
    			ds.ship_strm_ctgy_nm,
    			ds.txn_dt,
    			(ds.oh_paid_bkng_cn + sisu.alloc_grp_bkng_cn + sisu.unalloc_grp_bkng_cn) as paid_bkng_cn,
    			(ds.oh_asgn_bkng_cn + sisu.alloc_grp_bkng_cn + sisu.unalloc_grp_bkng_cn) as asgn_bkng_cn
    			FROM driver_subset ds join ship_inventory_alloc_unalloc_vw sisu
    			ON ds.vyge_id = sisu.vyge_id
    			AND ds.ship_strm_ctgy_nm = sisu.ship_strm_ctgy_nm
    			AND ds.txn_dt = sisu.txn_dt
    			 """).dropDuplicates()
        pd_asn_bkng_cn_df.createOrReplaceTempView("pd_asn_bkng_cn_vw")
        pd_asn_bkng_cn_df.printSchema();
        pd_asn_bkng_cn_df.show();

        if debug == 1:
            DebugCount.debug_counts(pd_asn_bkng_cn_df, "pd_asn_bkng_cn_df")

        sl_lim_strm_typ_pc_df = sql_context.sql(""" 
    			select 
    			sl_vw.vyge_id,
    			sl_vw.ship_strm_ctgy_nm,
    			sl_vw.txn_dt,
    			sl_vw.sl_lim_strm_typ_cn,
    			(pd_asn_vw.paid_bkng_cn/sl_vw.sl_lim_strm_typ_cn)*100 as sl_lim_strm_typ_pc,
    			(sl_vw.sl_lim_strm_typ_cn - pd_asn_vw.paid_bkng_cn) as sl_strm_cn
    			from
    			sl_lim_strm_typ_cn_vw sl_vw,pd_asn_bkng_cn_vw pd_asn_vw
    			where sl_vw.vyge_id = pd_asn_vw.vyge_id
    			AND sl_vw.ship_strm_ctgy_nm = pd_asn_vw.ship_strm_ctgy_nm
    			AND sl_vw.txn_dt = pd_asn_vw.txn_dt 
    			""").dropDuplicates()

        sl_lim_strm_typ_pc_df.createOrReplaceTempView("sl_lim_strm_typ_pc_vw")
        sl_lim_strm_typ_pc_df.printSchema();
        sl_lim_strm_typ_pc_df.show();

        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_pc_df, "sl_lim_strm_typ_pc_df")

        count_metrics_df = sql_context.sql(""" 

    		select 

    		    ds.vyge_id,
    			ds.ship_strm_ctgy_nm as strm_ctg_nm_new,
    			ds.txn_dt as txn_dt,

    			(phys_invtry_strm_cn_df.phys_invtry_strm_cn - ooo_vw.ooo_strm_cn - pd_asn_vw.asgn_bkng_cn - ds.oh_unasgn_bkng_cn - sisu.alloc_grp_bkng_cn - sisu.unalloc_grp_bkng_cn) as avail_strm_ctgy_cn,

    			ROUND(((ds.oh_asgn_bkng_cn + ds.oh_unasgn_bkng_cn+ sisu.alloc_grp_bkng_cn +sisu.unalloc_grp_bkng_cn + ooo_vw.ooo_strm_cn) / phys_invtry_strm_cn_df.phys_invtry_strm_cn )*100, 2) as strm_ctgy_ocpncy_pc,

    			ROUND(((phys_invtry_strm_cn_df.phys_invtry_strm_cn - (phys_invtry_strm_cn_df.phys_invtry_strm_cn - ooo_vw.ooo_strm_cn - pd_asn_vw.asgn_bkng_cn - ds.oh_unasgn_bkng_cn- sisu.alloc_grp_bkng_cn - sisu.unalloc_grp_bkng_cn)) / phys_invtry_strm_cn_df.phys_invtry_strm_cn)*100,2) as strm_ctgy_utlz_pc,


    			sl_lim_typ.sl_lim_strm_typ_cn as sl_lim_strm_ctgy_cn ,

    			Round(sl_lim_typ.sl_lim_strm_typ_pc,2) as sl_lim_strm_ctgy_pc,

    		    sl_lim_typ.sl_strm_cn,

    			pd_asn_vw.paid_bkng_cn,

    			pd_asn_vw.asgn_bkng_cn,



    			(ds.dlgt_grp_bkng_cn + sisu.alloc_grp_bkng_cn + sisu.unalloc_grp_bkng_cn) as grp_bkng_cn

    			FROM
    			driver_subset ds,
    			ooo_consolidated_vw ooo_vw,
    			pd_asn_bkng_cn_vw pd_asn_vw, 
    			ship_inventory_alloc_unalloc_vw sisu,
    			phys_invtry_strm_cn_df as phys_invtry_strm_cn_df,
    			sl_lim_strm_typ_pc_vw sl_lim_typ

    			where 
    			ds.vyge_id = ooo_vw.vyge_id
    			and ds.txn_dt = ooo_vw.txn_dt

    			and ds.vyge_id = pd_asn_vw.vyge_id
    			and ds.ship_strm_ctgy_nm = pd_asn_vw.ship_strm_ctgy_nm
    			and ds.txn_dt = pd_asn_vw.txn_dt

    			and ds.vyge_id = phys_invtry_strm_cn_df.vyge_id
    			and ds.ship_strm_ctgy_nm = phys_invtry_strm_cn_df.ship_strm_ctgy_nm
    			and ds.txn_dt = phys_invtry_strm_cn_df.txn_dt


    			and ds.vyge_id = sisu.vyge_id
    			and ds.ship_strm_ctgy_nm = sisu.ship_strm_ctgy_nm
    			and ds.txn_dt = sisu.txn_dt

    			and ds.vyge_id = sl_lim_typ.vyge_id
    			and ds.ship_strm_ctgy_nm = sl_lim_typ.ship_strm_ctgy_nm
    			and ds.txn_dt = sl_lim_typ.txn_dt 

    			""").dropDuplicates()
        count_metrics_df.createOrReplaceTempView("count_metrics_vw")
        count_metrics_df.printSchema();
        count_metrics_df.show();
        if debug == 1:
            DebugCount.debug_counts(count_metrics_df, "count_metrics_df")

        print(" END OF COUNT CALC ")



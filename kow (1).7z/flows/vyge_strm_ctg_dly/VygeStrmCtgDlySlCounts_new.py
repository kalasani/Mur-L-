##########################################################################################
# Project           : DCL RM - Disney Cruise Line Revenue Management                     #
# Program name      : Counts info                                             #
# Author            : Anjaiah M                                                          #
# Date created      : 2018-08-26                                                         #
# Purpose           : To build the driver program                                        #
# Revision History  :                                                                    #
# Date           Author     Ref    Revision (Date in YYYYMMDD format)                    #
# 2018-08-26    kowshik Y   Chris                                                        #
#                                                                                        #
##########################################################################################


#################################################################################
# STEP 1: Initializing SPARK variable and importing dependent functions/packages#
#################################################################################

from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from framework.utils.DebugCount import *;
from pyspark.sql.functions import *
import sys, traceback
from pyspark.sql.types import *
import os, sys
class VygeStrmCtgDlySlCounts(object):


    @staticmethod
    def run_viz_vyge_count_calc(start_dt, end_dt, runType, sql_context, s3_bucket, data_loader, debug):
        ##################################################################
        # Driver program to run promotional_price dm main process method #
        # Attributes                                                     #
        # start_dt    : the time slice that is being executed            #
        # sql_context : the spark sql context                            #
        # s3_bucket   : the s3 bucket that identifies the data source    #
        # debug       :  debugging the counts                            #
        ##################################################################

        sl_lim_vyge_sum_df = sql_context.sql(" select * from sl_lim_vyge_sum ").distinct()
        strm_typ_nest_config_df = sql_context.sql(" select * from strm_typ_nest_config ").distinct()
        strm_typ_cd_driver_df=sql_context.sql(" select * from vyge_strm_ctgy_strm_typ_cd_driver ").distinct()
        ship_inventory_alloc_unalloc_df=sql_context.sql(" select * from ship_inventory_alloc_unalloc_vw ").distinct()
        res_baseln_con_vw_df = sql_context.sql(" select * from res_baseln_con_vw ").distinct()
        ooo_inventory_cnt_df = sql_context.sql(" select * from ooo_consolidated_vw_ship_strm_ctgy ").distinct()
        phy_inventory_df=sql_context.sql(" select * from phys_invtry_strm_cn_df ").distinct()
        proc_price_pt_diff_df = data_loader.read_data_from_path("con/PROC_PRICE_PT_DIFF")
        driver_df = sql_context.sql("select * from driver ").distinct();
        proc_price_pt_diff_df.createOrReplaceTempView("proc_price_pt_diff_tmp_vw")

        price_mod_date_tmp_df = strm_typ_cd_driver_df.join(proc_price_pt_diff_df, \
                                                                        (strm_typ_cd_driver_df.vyge_id == proc_price_pt_diff_df.vyge_id) \
                                                                        &(strm_typ_cd_driver_df.ship_strm_typ_cd == proc_price_pt_diff_df.strm_typ_cd) \
                                                                        &(proc_price_pt_diff_df.txn_dt <= strm_typ_cd_driver_df.txn_dt)) \
            .select(strm_typ_cd_driver_df.vyge_id, strm_typ_cd_driver_df.ship_strm_ctgy_nm,
                    proc_price_pt_diff_df.txn_dt) \
            .groupBy("vyge_id", "ship_strm_ctgy_nm") \
            .agg(max("txn_dt").alias("price_mod_dt")).distinct()

        price_mod_date_df = driver_df.join(price_mod_date_tmp_df, ["vyge_id", "ship_strm_ctgy_nm"]) \
            .select(driver_df.vyge_id, \
                    driver_df.ship_strm_ctgy_nm, \
                    driver_df.txn_dt, \
                    price_mod_date_tmp_df.price_mod_dt).distinct()

        print("Completed:: price_mod_date_df")
        price_mod_date_df.createOrReplaceTempView("price_mod_date_vw")

        #######################################################################
        #  Calculating max of absolute_lim_nb from sl_lim_vyge_sum dataset    #
        #######################################################################

        # sl_lim_strm_typ_cn_df = driver_df.join(strm_typ_cd_driver_df, \
        #                                                    (strm_typ_cd_driver_df.ship_strm_ctgy_nm == driver_df.ship_strm_ctgy_nm) \
        #                                                    &( strm_typ_cd_driver_df.txn_dt == driver_df.txn_dt) \
        #                                                    & (strm_typ_cd_driver_df.vyge_id == driver_df.vyge_id) \
        #                                                    ).join(sl_lim_vyge_sum_df, \
        #                                                    (driver_df.vyge_id == sl_lim_vyge_sum_df.Sail_id) \
        #                                                     & (strm_typ_cd_driver_df.ship_strm_typ_cd == sl_lim_vyge_sum_df.cbn_ctgy_cd) \
        #                                                     & (driver_df.txn_dt >= to_date(sl_lim_vyge_sum_df.vrsn_strt_dts)) \
        #                                                     & (driver_df.txn_dt < to_date(sl_lim_vyge_sum_df.vrsn_end_dts)), "left_outer") \
        #     .select(strm_typ_cd_driver_df.vyge_id, strm_typ_cd_driver_df.ship_strm_ctgy_nm, strm_typ_cd_driver_df.txn_dt, "absolute_lim_nb") \
        #     .groupBy(strm_typ_cd_driver_df.vyge_id, strm_typ_cd_driver_df.ship_strm_ctgy_nm, strm_typ_cd_driver_df.txn_dt) \
        #     .agg(max("absolute_lim_nb").alias("sl_lim_strm_typ_cn")).distinct()
        # print("Completed: sl_lim_strm_typ_cn_df")

        sl_lim_strm_typ_cn_tmp_df = strm_typ_cd_driver_df.join(sl_lim_vyge_sum_df, \
                                                                            (strm_typ_cd_driver_df.vyge_id == sl_lim_vyge_sum_df.Sail_id) \
                                                                            & ( strm_typ_cd_driver_df.ship_strm_typ_cd == sl_lim_vyge_sum_df.cbn_ctgy_cd) \
                                                                            & ( strm_typ_cd_driver_df.txn_dt >= to_date(sl_lim_vyge_sum_df.vrsn_strt_dts)) \
                                                                            & ( strm_typ_cd_driver_df.txn_dt < to_date(
                                                                                    sl_lim_vyge_sum_df.vrsn_end_dts)),
                                                                            "left_outer") \
            .select("vyge_id", "ship_strm_typ_cd", "ship_strm_ctgy_nm", "txn_dt", "absolute_lim_nb") \
            .groupBy("vyge_id", "ship_strm_typ_cd", "ship_strm_ctgy_nm", "txn_dt") \
            .agg(max("absolute_lim_nb").alias("sl_lim_strm_typ_cn"))

        sl_lim_strm_typ_cn_df = driver_df.join(sl_lim_strm_typ_cn_tmp_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", "sl_lim_strm_typ_cn"). \
            groupBy("vyge_id", "ship_strm_ctgy_nm", "txn_dt") \
            .agg(sum("sl_lim_strm_typ_cn").alias("sl_lim_strm_typ_cn"))

        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_cn_df, "sl_lim_strm_typ_cn_vw")

        window_vrsn_end_dts_nxt = Window.partitionBy("ship_cd").orderBy("strm_typ_nest_config_strt_dts") \
            .rowsBetween(-1, -1)
        filter_clause = "UPPER(src_sys_strm_typ_nm) NOT IN ('IRG','XAM') and UPPER(strm_typ_nest_grp_nm) = 'SHIPSCI' and lgcl_del_in = 'N'"
        window_vrsn_end_dts = Window.partitionBy("ship_cd", "src_sys_strm_typ_nm").orderBy("strm_typ_nest_config_strt_dts") \
            .rowsBetween(1, 1)

        strm_typ_nest_confg_temp_df1 = strm_typ_nest_config_df.filter(filter_clause) \
            .select("ship_cd", \
                    "strm_ctgy_nm", \
                    "src_sys_strm_typ_nm", \
                    "sci_rcmd_excl_in", \
                    "strm_typ_nest_config_strt_dts", \
                    col("strm_typ_nest_config_strt_dts").alias("vrsn_strt_dts_est"), \
                    max("strm_typ_nest_config_strt_dts") \
                    .over(window_vrsn_end_dts_nxt).alias("vrsn_strt_dts_nxt")) \
            .withColumn("vrsn_end_dts_est", when(col("vrsn_strt_dts_nxt").isNull(), \
                                                 lit("9999-12-31 00:00:00.000000").cast("timestamp")) \
                        .otherwise(col("vrsn_strt_dts_nxt"))).drop(col("vrsn_strt_dts_nxt"))

        strm_typ_nest_confg_temp_df1=strm_typ_nest_confg_temp_df1.distinct()
        if debug == 1:
            DebugCount.debug_counts(strm_typ_nest_confg_temp_df1, "strm_typ_nest_confg_temp_vw")

        strm_typ_nest_confg_vw_df = strm_typ_nest_confg_temp_df1.select("ship_cd", \
                                                                        "strm_ctgy_nm", \
                                                                        "src_sys_strm_typ_nm", \
                                                                        "sci_rcmd_excl_in", \
                                                                        "strm_typ_nest_config_strt_dts", \
                                                                        col("strm_typ_nest_config_strt_dts").alias( "vrsn_strt_dts"), \
                                                                        max("strm_typ_nest_config_strt_dts") \
                                                                        .over(window_vrsn_end_dts).alias("vrsn_end_dts_tmp")) \
                                                                        .withColumn("vrsn_end_dts", when(col("vrsn_end_dts_tmp").isNull(), \
                                                                                    lit("9999-12-31 00:00:00.000000").cast("timestamp")) \
                                                                                    .otherwise(col("vrsn_end_dts_tmp")))
        strm_typ_nest_confg_vw_df=strm_typ_nest_confg_vw_df.distinct()

        # print("Completed :: strm_typ_nest_confg_vw_df")
        # folder_name = "%s%s" % ("strm_typ_nest_confg_vw_df/partition_dt=", end_dt)
        #
        # print("******** floder_name=%s" % folder_name)
        # data_loader.write_data("dm", folder_name, None, strm_typ_nest_confg_vw_df)
        # strm_typ_nest_confg_vw_df.printSchema();
        # strm_typ_nest_confg_vw_df.show(10)
        if debug == 1:
            DebugCount.debug_counts(strm_typ_nest_confg_vw_df, "strm_typ_nest_confg_vw_df")

        sl_lim_rcmd_lim_temp_df = driver_df.join(strm_typ_nest_confg_vw_df, \
                                                             (driver_df.ship_cd == strm_typ_nest_confg_vw_df.ship_cd) \
                                                             &(driver_df.txn_dt >= to_date( strm_typ_nest_confg_vw_df.vrsn_strt_dts)) \
                                                             & (driver_df.txn_dt < to_date(strm_typ_nest_confg_vw_df.vrsn_end_dts))) \
            .join(sl_lim_vyge_sum_df, (sl_lim_vyge_sum_df.Sail_id == driver_df.vyge_id) \
                  & (strm_typ_nest_confg_vw_df.src_sys_strm_typ_nm == sl_lim_vyge_sum_df.cbn_ctgy_cd) \
                  & (driver_df.txn_dt >= to_date(sl_lim_vyge_sum_df.vrsn_strt_dts)) \
                  & (driver_df.txn_dt < to_date(sl_lim_vyge_sum_df.vrsn_end_dts))) \
            .select("vyge_id", \
                    "ship_strm_ctgy_nm", \
                    "txn_dt", \
                    "src_sys_strm_typ_nm", \
                    "absolute_lim_nb") \
            .groupBy("vyge_id", "ship_strm_ctgy_nm", "txn_dt", "src_sys_strm_typ_nm") \
            .agg(max("absolute_lim_nb").alias("rcmd_lim")).distinct()
        print("Completed:: sl_lim_rcmd_lim_temp_df")

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_lim_temp_df, "sl_lim_rcmd_lim_temp_vw")

        sl_lim_rcmd_lim_df = sl_lim_rcmd_lim_temp_df \
            .groupBy("vyge_id", \
                     "ship_strm_ctgy_nm", \
                     col("txn_dt").alias("txn_date")) \
            .agg(sum("rcmd_lim").alias("sl_lim_strm_cn")).distinct()
        sl_lim_rcmd_lim_df.createOrReplaceTempView("sl_lim_rcmd_lim_vw")
        print("Completed: sl_lim_rcmd_lim_df")

        if debug == 1:
            DebugCount.debug_counts(sl_lim_rcmd_lim_df, "sl_lim_rcmd_lim_vw")



        driver_subset_df = driver_df.join(res_baseln_con_vw_df, \
                                                      ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .select(driver_df.vyge_id, \
                    driver_df.ship_strm_ctgy_nm, \
                    driver_df.txn_dt, \
                    res_baseln_con_vw_df.oh_paid_bkng_cn, \
                    res_baseln_con_vw_df.oh_asgn_bkng_cn, \
                    res_baseln_con_vw_df.oh_unasgn_bkng_cn).distinct()
        print("Completed:: driver_subset_df")

        if debug == 1:
            DebugCount.debug_counts(driver_subset_df, "driver_subset_vw")

        pd_asn_bkng_cn_temp_df = driver_subset_df.join(ship_inventory_alloc_unalloc_df, \
                                                       ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .select(driver_subset_df.vyge_id, \
                    driver_subset_df.ship_strm_ctgy_nm, \
                    driver_subset_df.txn_dt, \
                    driver_subset_df.oh_paid_bkng_cn, \
                    driver_subset_df.oh_asgn_bkng_cn, \
                    ship_inventory_alloc_unalloc_df.unalloc_grp_bkng_cn.alias("unalloc_grp_bkng_cn1"), \
                    ship_inventory_alloc_unalloc_df.alloc_grp_bkng_cn.alias("alloc_grp_bkng_cn1")).distinct()
        print("Completed:: pd_asn_bkng_cn_temp_df")

        if debug == 1:
            DebugCount.debug_counts(pd_asn_bkng_cn_temp_df, "pd_asn_bkng_cn_temp_vw")

        pd_asn_bkng_cn_df = pd_asn_bkng_cn_temp_df \
            .withColumn("paid_bkng_cn", (pd_asn_bkng_cn_temp_df.oh_paid_bkng_cn + \
                                         pd_asn_bkng_cn_temp_df.alloc_grp_bkng_cn1 + \
                                         pd_asn_bkng_cn_temp_df.unalloc_grp_bkng_cn1)) \
            .withColumn("asgn_bkng_cn", (pd_asn_bkng_cn_temp_df.oh_asgn_bkng_cn + \
                                         pd_asn_bkng_cn_temp_df.alloc_grp_bkng_cn1 + \
                                         pd_asn_bkng_cn_temp_df.unalloc_grp_bkng_cn1)) \
            .select("vyge_id", "ship_strm_ctgy_nm", "txn_dt", "paid_bkng_cn", "asgn_bkng_cn").distinct()
        print("Compelted:: pd_asn_bkng_cn_df")

        if debug == 1:
            DebugCount.debug_counts(pd_asn_bkng_cn_df, "pd_asn_bkng_cn_vw")

        sl_lim_strm_typ_pc_temp_df = sl_lim_strm_typ_cn_df.join(pd_asn_bkng_cn_df, \
                                                                ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .select(sl_lim_strm_typ_cn_df.vyge_id, \
                    sl_lim_strm_typ_cn_df.ship_strm_ctgy_nm, \
                    sl_lim_strm_typ_cn_df.txn_dt, \
                    sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn, \
                    pd_asn_bkng_cn_df.paid_bkng_cn).distinct()
        print("Completed: sl_lim_strm_typ_pc_temp_df")

        sl_strm_cn_df = sl_lim_strm_typ_pc_temp_df.groupBy("vyge_id").agg(
            sum("sl_lim_strm_typ_cn").alias("sl_lim_strm_typ_cn"), \
            sum("paid_bkng_cn").alias("paid_bkng_cn")) \
            .withColumn("sl_strm_cn", (col("sl_lim_strm_typ_cn") - col("paid_bkng_cn"))) \
            .select("vyge_id", "sl_strm_cn").distinct()

        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_pc_temp_df, "sl_lim_strm_typ_pc_temp_vw")

        sl_lim_strm_typ_pc_df = sl_lim_strm_typ_pc_temp_df \
            .withColumn("sl_lim_strm_typ_pc", \
                        (pd_asn_bkng_cn_df.paid_bkng_cn / sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn) * 100) \
            .withColumn("sl_strm_ctgy_cn", \
                        (sl_lim_strm_typ_cn_df.sl_lim_strm_typ_cn - pd_asn_bkng_cn_df.paid_bkng_cn))

        if debug == 1:
            DebugCount.debug_counts(sl_lim_strm_typ_pc_df, "sl_lim_strm_typ_pc_vw")

        count_metrics_temp_df = driver_subset_df.join(ooo_inventory_cnt_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .join(pd_asn_bkng_cn_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .join(phy_inventory_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .join(ship_inventory_alloc_unalloc_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .join(sl_lim_strm_typ_pc_df, ["vyge_id", "ship_strm_ctgy_nm", "txn_dt"]) \
            .join(sl_strm_cn_df,"vyge_id")\
            .select(driver_subset_df.vyge_id, \
                    driver_subset_df.ship_strm_ctgy_nm, \
                    driver_subset_df.txn_dt,
                    phy_inventory_df.phys_invtry_strm_cn,
                    ooo_inventory_cnt_df.ooo_strm_cn,
                    pd_asn_bkng_cn_df.asgn_bkng_cn,
                    driver_subset_df.oh_unasgn_bkng_cn,
                    driver_subset_df.oh_asgn_bkng_cn,
                    ship_inventory_alloc_unalloc_df.alloc_grp_bkng_cn,
                    ship_inventory_alloc_unalloc_df.unalloc_grp_bkng_cn,
                    sl_lim_strm_typ_pc_df.sl_lim_strm_typ_cn,
                    sl_lim_strm_typ_pc_df.sl_lim_strm_typ_pc,
                    sl_lim_strm_typ_pc_df.sl_strm_ctgy_cn,
                    sl_strm_cn_df.sl_strm_cn,
                    pd_asn_bkng_cn_df.paid_bkng_cn,
                    ship_inventory_alloc_unalloc_df.dlgt_grp_bkng_cn
                    ).distinct()
        print("Completed::: count_metrics_temp_df")

        if debug == 1:
            DebugCount.debug_counts(count_metrics_temp_df, "count_metrics_temp_vw")

        count_metrics_df = count_metrics_temp_df \
            .withColumn("avail_strm_ctgy_cn", \
                        (count_metrics_temp_df.phys_invtry_strm_cn - \
                         count_metrics_temp_df.ooo_strm_cn - \
                         count_metrics_temp_df.asgn_bkng_cn - \
                         count_metrics_temp_df.oh_unasgn_bkng_cn - \
                         count_metrics_temp_df.alloc_grp_bkng_cn - \
                         count_metrics_temp_df.unalloc_grp_bkng_cn) ) \
            .withColumn("strm_ctgy_ocpncy_pc", \
                        ((count_metrics_temp_df.oh_asgn_bkng_cn + \
                          count_metrics_temp_df.oh_unasgn_bkng_cn + \
                          count_metrics_temp_df.alloc_grp_bkng_cn + \
                          count_metrics_temp_df.unalloc_grp_bkng_cn + \
                          count_metrics_temp_df.ooo_strm_cn) / \
                         count_metrics_temp_df.phys_invtry_strm_cn) * 100) \
            .withColumn("strm_ctgy_utlz_pc", \
                        ((count_metrics_temp_df.phys_invtry_strm_cn - \
                          (count_metrics_temp_df.phys_invtry_strm_cn - \
                           count_metrics_temp_df.ooo_strm_cn - \
                           count_metrics_temp_df.asgn_bkng_cn - \
                           count_metrics_temp_df.oh_unasgn_bkng_cn)) / \
                         count_metrics_temp_df.phys_invtry_strm_cn) * 100) \
            .withColumn("grp_bkng_cn", \
                        (count_metrics_temp_df.dlgt_grp_bkng_cn + \
                         count_metrics_temp_df.alloc_grp_bkng_cn + \
                         count_metrics_temp_df.unalloc_grp_bkng_cn)) \
            .select("vyge_id", \
                    col("ship_strm_ctgy_nm").alias("ship_strm_ctgy_nm_temp"), \
                    "txn_dt", \
                    "asgn_bkng_cn", \
                    col("sl_lim_strm_typ_cn").alias("sl_lim_strm_ctgy_cn"), \
                    col("sl_lim_strm_typ_pc").alias("sl_lim_strm_ctgy_pc").cast("decimal(12,2)"), \
                    "sl_strm_cn", \
                    "paid_bkng_cn", \
                    "dlgt_grp_bkng_cn", \
                    "avail_strm_ctgy_cn", \
                    "sl_strm_ctgy_cn",\
                    col("strm_ctgy_ocpncy_pc").alias("strm_ctgy_ocpncy_pc").cast("decimal(12,2)"), \
                    col("strm_ctgy_utlz_pc").alias("strm_ctgy_utlz_pc").cast("decimal(12,2)"), \
                    "grp_bkng_cn").distinct()
        count_metrics_df.createOrReplaceTempView("count_metrics_vw")
        print("Completed::: count_metrics_df")

        if debug == 1:
            DebugCount.debug_counts(count_metrics_df, "count_metrics_vw")
        print
        " END OF COUNT CALC "

import json


class ConfigReader:
    """This is a clss that has methods helping to load configuration properties

    """

    def __init__(self):
        """ Initialiation method for this class
        """
        self.resource_package = "framework/config"

    def read_json_as_string(self, json_name):
        """
             provide the name of the json file to be read
             reads the json and sends back a dictionary
        """
        location = "%s/%s/%s" % (self.resource_package, "json", json_name)
        f = open(location)
        str = f.read()
        f.close()
        return json.loads(str)
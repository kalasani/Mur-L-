from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
import sys, traceback
#from flows.utils.S3DataLoader import *
#from flows.jobs.con_resbaseln_cancellation_dm import *
#from flows.jobs.con_sl_lim_vyge_sum_cancellation_dm import *
#from flows.utils.DataFrameUtil import *
from framework.core.BaseJob_old import BaseJob
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from pyspark.sql.types import *

from time import time
import os, sys


class DebugCount(object):

    @staticmethod
    def count_check(dataframe, name):
        print(" Debug start ************************************************************************ %s %s" % (
            name, datetime.now()))
        cnt = dataframe.count()
        # dataframe.show()
        try:
            dataframe.show()
        except:
            print(" exception")
        print(" Debug counts ************************************************************************ %s " % cnt)
        print(" Debug end ************************************************************************ %s %s" % (
            name, datetime.now()))

import json
from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import col, asc
from pyspark.sql import Row
import os
import sys, traceback


class S3DataLoader:
    """This is a class that has methods helping to load data

       Attributes:
         sql_context: representing the spark sql context
         s3_bucket: the S3 bucket string example mybucket
         data_format: data format to be read - defaults to orc
    """

    def __init__(self, sql_context, s3_bucket, data_format="orc"):
        """ Initialiation method for this class
        """
        self.sql_context = sql_context
        self.s3_bucket = s3_bucket
        self.data_format = data_format
        self.reservation_record_dt = datetime.strptime("2016-01-11", "%Y-%m-%d").date()
        self.reservation_start_dt = datetime.strptime("1800-01-01", "%Y-%m-%d").date()

    def read_data_from_path(self, path):
        """ reads orc data from S3 based on partition filter conditrions and a custom filter clause

            Attributes:
               path - the actual path where the data is
            returns a data frame
        """
        s3_loc = "%s/%s/data" % (self.s3_bucket, path)
        print
        s3_loc
        return self.sql_context.read.format(self.data_format).load(s3_loc)

    def read_data_with_filter(self, folder, data_ref, partition_col, start_dt, end_dt, filter):
        """ reads orc data from S3 based on partition filter conditrions and a custom filter clause

            Attributes:
              folder: the location under the S3 bucket usually sha, dm or app
              data_ref:  the name of the data like RES_BASELN, VYGE etc..
              parititon_col: the name of the partition column
              filter: Additional filter criterion to filter data

            returns a data frame
        """

        ## special handling for res_baseln
        if data_ref.upper() == "RES_BASELN":
            if start_dt != None:
                start_dt_date = datetime.strptime(str(start_dt), "%Y-%m-%d").date()
                if start_dt_date < self.reservation_record_dt:
                    start_dt = "%s" % self.reservation_start_dt
                    print
                    "reservation start date modified to %s" % start_dt
        if partition_col == None:
            partition_col = "partition_dt"
        # start_dt=datetime.strptime(start_dt, "%Y-%m-%d").date()
        # end_dt=datetime.strptime(end_dt, "%Y-%m-%d").date()
        s3_loc = "%s/%s/%s/data" % (self.s3_bucket, folder, data_ref)
        filter_clause = "%s >= date('%s') and %s <= date('%s')" % (partition_col, start_dt, partition_col, end_dt)
        if filter != None:
            filter_clause = "%s and %s" % (filter_clause, filter)
        df_input = self.sql_context.read.format(self.data_format).load(s3_loc).filter(filter_clause)
        return df_input

    def read_all_data(self, data_ref, schema):
        """ reads data from HDFS root and path sent instead of dooing a union , it needs a schema """
        s3_loc = "%s/%s/data/*" % (self.s3_bucket, data_ref)
        df_input = self.sql_context.read.format(self.data_format).schema(schema).load(s3_loc)
        return df_input

    def read_data(self, folder, data_ref):
        """ reads data from S3 based on partition filter conditrions and a custom filter clause

            Attributes:
              folder: the location under the S3 bucket usually sha, dm or app
              data_ref:  the name of the data like RES_BASELN, VYGE etc..

            returns a data frame
        """
        s3_loc = "%s/%s/%s/data" % (self.s3_bucket, folder, data_ref)
        df_input = self.sql_context.read.format(self.data_format).load(s3_loc)
        return df_input

    def write_data_to_partition(self, folder, data_ref, partition_col, partition_val, data_frame, mode):
        """
           Used by consolidators to write data to a partition, in spark when we write in overwrite mode
           all partitions get overwriten hence we need to write to the specific partiion
            Attributes:
              folder: the location under the S3 bucket usually sha, dm or app
              data_ref:  the name of the data like RES_BASELN, VYGE etc..
              partition_col: the name of the partition col
              patition_val:  the vlaue of the partition col
              data_frame: the data frame identifying the data to be written
              mode: overwrite or append
        """
        s3loc = "%s/%s/%s/data/%s=%s" % (self.s3_bucket, folder, data_ref, partition_col, partition_val)
        data_frame.write.mode(mode).format("orc").save(s3loc)

    def check_parition_if_date_exists(self, folder, data_ref, dt_column, dt):
        """
            The purpose of this method is to develop a  way to check if data
            already exists for a particular date, if it exists - this indicates
            this is a potential corruption of data
            example: if txn_dt - july 1 2017 exists , we cannot append a new data
            for july 1, 2017 .. this indicates possible data corruption
             Attributes:
               folder: the location under the S3 bucket usually sha, dm or app
               data_ref:  the name of the data like RES_BASELN, VYGE etc..
               dt_column: the name of the date column where the filter is applied
               dt: the value of the date  that is existing or not in the data folder
        """
        s3loc = "%s/%s/%s/data" % (self.s3_bucket, folder, data_ref)
        print
        "checking %s" % s3loc
        exists = False
        try:
            filter = " %s >= date('%s')" % (dt_column, dt)
            print
            filter
            df_input = self.sql_context.read.format(self.data_format).load(s3loc).filter(filter).select(dt_column)
            if df_input != None:
                exists = not df_input.rdd.isEmpty()
        except:
            traceback.print_exc()
            exists = False
        print
        " data exists = %s " % exists
        return exists

    def write_data(self, folder, data_ref, partition_col, data_frame):
        s3loc = "%s/%s/%s/data" % (self.s3_bucket, folder, data_ref)
        if partition_col != None:
            data_frame.write.partitionBy(partition_col).mode("overwrite").format("orc").save(s3loc)
        else:
            print
            "%s" % s3loc
            data_frame.write.mode("overwrite").format("orc").save(s3loc)

    def write_data_with_mode(self, folder, data_ref, partition_col, data_frame, mode):
        s3loc = "%s/%s/%s/data" % (self.s3_bucket, folder, data_ref)
        if partition_col != None:
            data_frame.write.partitionBy(partition_col).mode(mode).format("orc").save(s3loc)
        else:
            data_frame.write.mode(mode).format("orc").save(s3loc)

    def write_data_to_path(self, path, df):
        s3loc = "%s/%s/data" % (self.s3_bucket, path)
        print
        "%s" % s3loc
        df.write.mode("overwrite").format("orc").option("header", "true").save(s3loc)

    def read_data_one_partition_handle_error(self, folder, data_ref, partition_col, partition_dt, filter):
        """
         Calls read_data_one_partition but returns None when the partition does not exist
        """
        try:
            partition_df = self.read_data_one_partition(folder, data_ref, partition_col, partition_dt, filter)
            return partition_df
        except:
            return None

    def read_data_one_partition(self, folder, data_ref, partition_col, partition_dt, filter):
        """ reads orc data from S3 based on partition filter conditrions and a custom filter clause
            This method is useful for an incremental mode where it needs to read only one partition

            Attributes:
              folder: the location under the S3 bucket usually sha, dm or app
              data_ref:  the name of the data like RES_BASELN, VYGE etc..
              parititon_col: the name of the partition column
              partition_dt : the exact partition date as a string in YYYY-MM-dd format
              filter: Additional filter criterion to filter data

              returns a data frame
        """
        if partition_col == None:
            partition_col = "partition_dt"
        s3_loc = "%s/%s/%s/data/%s=%s" % (self.s3_bucket, folder, data_ref, partition_col, partition_dt)
        if filter != None:
            return self.sql_context.read.format(self.data_format).load(s3_loc).filter(filter)
        else:
            return self.sql_context.read.format(self.data_format).load(s3_loc)

    def read_data_one_partitionVoygeStateROOM(self, folder, data_ref, partition_col, partition_dt, filter):
        """ reads orc data from S3 based on partition filter conditrions and a custom filter clause
            This method is useful for an incremental mode where it needs to read only one partition

            Attributes:
              folder: the location under the S3 bucket usually sha, dm or app
              data_ref:  the name of the data like RES_BASELN, VYGE etc..
              parititon_col: the name of the partition column
              partition_dt : the exact partition date as a string in YYYY-MM-dd format
              filter: Additional filter criterion to filter data

              returns a data frame
        """
        if partition_col == None:
            partition_col = "partition_dt"
        s3_loc = "%s/%s/%s/%s=%s/data" % (self.s3_bucket, folder, data_ref, partition_col, partition_dt)
        print(s3_loc)
        if filter != None:
            return self.sql_context.read.format(self.data_format).load(s3_loc).filter(filter)
        else:
            return self.sql_context.read.format(self.data_format).load(s3_loc)

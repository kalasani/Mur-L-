from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark import SQLContext


class DataFrameUtil:
    """This is a class that has methods helping to convert RDD to a dataframe using schema

       Attributes:
         sql_context: representing the spark sql context
    """

    def __init__(self, sql_context):
        """ Initialiation method for this class
        """
        self.sql_context = sql_context

    def convertRddToDataFrame(self, rdd, schema):
        """ reads orc data from S3 based on partition filter conditrions and a custom filter clause

            Attributes:
              rdd: input rdd
              schema:  rdd_schema
            returns a data frame
        """
        return self.sql_context.createDataFrame(rdd, schema)
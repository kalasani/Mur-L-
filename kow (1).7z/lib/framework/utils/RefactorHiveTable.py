import subprocess
from pyspark.sql import HiveContext


class RefactorHiveTable():
    def __init__(self, spark, hdfs_path, database, table):
        self.hive = HiveContext(spark.sparkContext)
        self.hdfs = hdfs_path
        self.hive_db = database
        self.hive_table = table
        self.refactor()


    def refactor(self):

        print
        print "Hive Table refactor Starts for " + self.hive_db + "." + self.hive_table
        hive_db = self.hive_db
        hive_table = self.hive_table
        alter_table_add_statement = None
        alter_table_drop_statement = None

        hdfs_partitions = set(self.get_hdfs_dirs(self.hdfs))
        # print "hdfs_partitions ", len(hdfs_partitions)
        hive_partitions = set(self.get_hive_partitions(hive_db, hive_table))
        # print "hive_partitions ", len(hive_partitions)
        add_partition_list = list(hdfs_partitions - hive_partitions)
        drop_partition_list = list(hive_partitions - hdfs_partitions)

        # print "###############add_partition_list################"
        # print add_partition_list
        # print "##############drop_partition_list################"
        # print drop_partition_list

        for partition in add_partition_list:
            date = partition.split('=')[1]
            partition_by = "partition_dt='"+date+"'"
            if add_partition_list.index(partition) == 0:
                alter_table_add_statement = "alter table " + hive_db + "." + hive_table + " add partition (" + partition_by + ")"
            else:
                alter_table_add_statement = alter_table_add_statement + " partition (" + partition_by + ")"

        if alter_table_add_statement is not None:
            print "###############add_partition_list################"
            print alter_table_add_statement
            query = alter_table_add_statement
            self.hive.sql(query)


        for partition in drop_partition_list:
            date = partition.split('=')[1]
            partition_by = "partition_dt='" + date + "'"
            if drop_partition_list.index(partition) == 0:
                alter_table_drop_statement = "alter table " + hive_db + "." + hive_table + " DROP IF EXISTS PARTITION (" + partition_by + ")"
            else:
                alter_table_drop_statement = alter_table_drop_statement + ", partition (" + partition_by + ")"

        if alter_table_drop_statement is not None:
            print "##############drop_partition_list################"
            print alter_table_drop_statement
            query = alter_table_drop_statement
            self.hive.sql(query)

        print
        print "Hive Table refactor Ends"

    def get_hive_partitions(self, src_database, table_name):
        query = "show partitions " + src_database + "." + table_name
        df = self.hive.sql(query)
        partition_list = df.select("partition").rdd.flatMap(lambda x: x).collect()
        print "no of partitions for hive table : ", len(partition_list)
        return partition_list

    @staticmethod
    def get_hdfs_dirs(hdfs_path):
        source_files_directories = subprocess.check_output(['hdfs', 'dfs', '-ls', '-r', hdfs_path])
        source_directories_splits = source_files_directories.splitlines()
        partition_list = []

        for source_path in source_directories_splits:
            print '--SOURCE PATH:<' + source_path + '>'
            if hdfs_path not in source_path:
                continue
            if "_SUCCESS" not in source_path:
                source_details = " ".join(source_path.split()[7:])
                # print "source_details "+source_details
                source_hdfs_path, partition = source_details.rsplit('/', 1)
                # print "source_hdfs_path " +source_hdfs_path
                if source_hdfs_path == hdfs_path:
                    partition_list.append(partition)

        print "no of partitions for hdfs path : ", len(partition_list)


        return partition_list
import time, os
from abc import ABCMeta, abstractmethod
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark import SparkConf
from datetime import datetime, timedelta
from framework.config.ConfigJsonImpl import ConfigJson
from framework.config.ConfigBase import ConfigBase
from framework.config.ConfigHbaseImpl import ConfigHbase
from framework.config import constant
from framework.core.Audit import *
from framework.utils.S3DataLoader import *
from framework.core.SparkSessionCreate import SparkSessionCreate


class BaseJob(object):
    _metaclass_ = ABCMeta
    ENVIRONMENT = None
    CONFIG_SOURCE = None
    FLOOR_DT = constant.floor_dt
    INIT_DT = constant.init_dt
    NUM_DAYS_AFTER_ARVL_DT = constant.num_days_after_arvl_dt

    def __init__(self, name):

        # variables
        self.name = name
        self.start_time = time.time()
        self.end_time = None
        self.last_activity = self.start_time
        self.load_type = None
        self.start_date = None
        self.end_date = None
        self.args = None
        self.max_dataload_dt = None
        self.debug = None
        self.publish_flag = None
        self.s3_root_bucket = None
        self.refresh = None
        self.num_days = None
        self.data_loader = None
        self.param_kv = None
        self.di_configuration = None
        self.hive_loc = None
        self.HWM = None
        self.metrics = JobResult()

        # Spark Session
        self.print_time_stats("Creating spark session...")
        self.spark = SparkSessionCreate(self.name).spark
        self.print_time_stats("Spark session created")
        self.sc = self.spark.sparkContext
        self.print_time_stats("Spark context created")
        self.sc.addPyFile(constant.pyFiles)
        self.sc.setLogLevel(constant.logLevel)
        self.sql = SQLContext(self.spark)
        self.print_time_stats("Sql context created")

        # Logger
        self.log4jLogger = self.spark._jvm.org.apache.log4j
        self.LOGGER = self.log4jLogger.LogManager.getLogger(__name__)

        # validate the environment
        self.validate_env()

        # Config
        self.print_time_stats("Creating configuration object...")
        if self.isHbase():
            self.config = ConfigHbase(self.spark, BaseJob.ENVIRONMENT, self.name, self.LOGGER)
        else:
            self.log_error("HBase configuration not found. Reading from Json...")
            self.config = ConfigJson(self.name, self.LOGGER)
        self.print_time_stats("Configuration object created")

        self.env = self.config.getEnvConfig()
        self.print_time_stats("Reading Env config completed")
        self.parameters = self.config.getJobConfig()
        self.print_time_stats("Reading Job config completed")

        if self.env is not None:
            self.s3_root_bucket = self.env.hdfs_root_directory
            self.data_loader = S3DataLoader(self.spark, self.s3_root_bucket,self.env.kv)

        if self.parameters != None:
            self.init_variables()
        else:
            self.log_warn("Job params not found, no job parameters initialized.")


    def validate_env(self):
        self.log_info("validating env...")
        curr_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        path = constant.json_path + "/environment.json"
        env_json = ConfigBase.readJson(path)
        value = env_json["env.name"]
        flag = (curr_path == value)
        if not flag:
            self.log_error("wrong environment. Please verify your configuration")
            # return -1
        BaseJob.ENVIRONMENT = value
        try:
            BaseJob.CONFIG_SOURCE = env_json["config"]
        except:
            pass

    def init_variables(self):
        self.load_type = self.parameters.load_type
        self.start_date = self.format_date(self.parameters.start_date)
        self.end_date = self.format_date(self.parameters.end_date)
        self.debug = self.parameters.debug
        self.publish_flag = self.parameters.td_publish_flag
        self.param_kv = self.parameters.kv
        self.di_configuration = self.parameters.kv
        self.hive_loc = self.parameters.hive_ref_write_loc

        if self.di_configuration.has_key("etl.run.max_dataload_dt"):
            self.max_dataload_dt = self.format_date(self.di_configuration["etl.run.max_dataload_dt"])

        if self.load_type != None and self.load_type.lower() == "refresh":
            self.refresh = 1
            self.log_info("Running job in refresh mode...")
        else:
            self.refresh = 0
            self.config.initHWMConfig()
            HWM = self.config.getHWMConfig()
            if HWM is not None:
                date_str = HWM.items["high.water.mark.dt"]

                if self.load_type.lower() == "intraday":
                    self.HWM = self.format_date_time(date_str)
                else:
                    self.HWM = self.format_date(date_str)
                    self.start_date = self.HWM + timedelta(days=1)
                    self.end_date = self.HWM + timedelta(days=1)
                    self.max_dataload_dt = self.HWM + timedelta(days=2)
            else:
                self.log_info("Running the job with the default Job config parameters...")


    def print_run_param(self):
        print
        print "#############Running job with the bellow parameters################"
        print "start_date       : ", self.start_date
        print "end_date         : ", self.end_date
        print "load_type        : ", self.load_type
        print "debug            : ", self.debug
        print "s3_root_bucket   : ", self.s3_root_bucket
        print "###################################################################"
        print

    def isHbase(self):
        if BaseJob.CONFIG_SOURCE is not None and BaseJob.CONFIG_SOURCE.lower() == "hbase":
            return True
        else:
            return False

    def get_start_date(self):
        return self.start_date

    def get_end_date(self):
        return self.end_date

    def isRefresh(self):
        return self.refresh

    def get_load_type(self):
        return self.load_type

    def get_s3_root_bucket(self):
        return self.s3_root_bucket

    def get_hive_loc(self):
        return self.hive_loc

    def print_time_stats(self, message):
        curr_time = time.time()
        total_time = curr_time - self.start_time
        last_activity = curr_time - self.last_activity
        print datetime.now().strftime("%y/%m/%d %H:%M:%S") + " INFO " + type(self).__name__ + ": " + \
              str(str(message) + ". Time taken from last activity : " + self.pretty_time(last_activity) +
                  " Total Duration : " + self.pretty_time(total_time)+"")
        self.last_activity = curr_time

    def set_result_count(self, count):
        self.metrics.result_count = count

    def update_HWM(self, date):
        sdate = str(date)
        print("updateHighWaterMark ===>")
        data = {"env.name": BaseJob.ENVIRONMENT,
                "job.name": self.name,
                "high.water.mark.dt": sdate
                }
        self.config.writeHWM(data)

    def collect_stats(self, status):
        self.end_time = time.time()
        self.metrics.start_date_timestamp = time.asctime(time.localtime(self.start_time))
        self.metrics.end_date_timestamp = time.asctime(time.localtime(self.end_time))
        self.metrics.duration = self.pretty_time(self.end_time - self.start_time)
        self.metrics.app_id = self.sc.applicationId
        self.metrics.app_name = self.sc.appName
        self.metrics.job_name = self.name
        self.metrics.env_name = BaseJob.ENVIRONMENT
        self.metrics.start_date = self.start_date
        self.metrics.end_date = self.end_date
        self.metrics.load_type = self.load_type
        self.metrics.args = self.args
        self.metrics.job_config = self.param_kv
        self.metrics.job_status = status
        self.metrics.publish_flag = self.publish_flag
        key = BaseJob.ENVIRONMENT + "_" + self.name + "_" + datetime.now().strftime("%Y-%m-%d_%H:%M")

        if self.isHbase():
            self.config.writeResult(key, self.metrics)
        else:
            self.metrics.display()

        print
        print "Job Status : " + status

    def execute(self):
        self.print_run_param()
        self.print_time_stats("Job execution starts now...")
        try:
            self.setUp()
            self.loadData()
            self.preProcess()
            self.createDriver()
            self.process()
            self.writeToHDFS()
            self.tearDown()
            self.print_time_stats("Job execution completed.")
            if self.load_type!=None and self.load_type.lower() != "intraday":
                self.update_HWM(self.end_date)
            self.collect_stats("success")

        except:
            self.print_time_stats("Job failed.")
            self.collect_stats("failed")
            raise

    def log_info(self, message):
        print datetime.now().strftime("%y/%m/%d %H:%M:%S") + " INFO " + type(self).__name__ + ": " + str(message)

    def log_debug(self, message):
        print datetime.now().strftime("%y/%m/%d %H:%M:%S") + " DEBUG " + type(self).__name__ + ": " + str(message)

    def log_warn(self, message):
        print datetime.now().strftime("%y/%m/%d %H:%M:%S") + " WARN " + type(self).__name__ + ": " + str(message)

    def log_error(self, message):
        print datetime.now().strftime("%y/%m/%d %H:%M:%S") + " ERROR " + type(self).__name__ + ": " + str(message)

    @staticmethod
    def pretty_time(val):
        hour, minutes, seconds = val // 3600, (val // 60) % 60, val % 60
        return str(int(round(hour, 0))) + "h:" + str(int(round(minutes, 0))) + "m:" + str(int(round(seconds, 0))) + "s"

    @staticmethod
    def format_date(sDate):
        return datetime.strptime(str(sDate), "%Y-%m-%d").date()

    @staticmethod
    def format_date_time(sDate):
        return datetime.strptime(str(sDate), "%Y-%m-%d %H:%M:%S")

    @abstractmethod
    def setUp(self):
        raise NotImplementedError

    @abstractmethod
    def loadData(self):
        raise NotImplementedError

    @abstractmethod
    def preProcess(self):
        raise NotImplementedError

    @abstractmethod
    def createDriver(self):
        raise NotImplementedError

    @abstractmethod
    def process(self):
        raise NotImplementedError

    @abstractmethod
    def writeToHDFS(self):
        raise NotImplementedError

    @abstractmethod
    def tearDown(self):
        raise NotImplementedError
from pyspark.sql import SparkSession


class SparkSessionCreate():
        def __init__(self, appName):
                self.appName = appName
                self.spark = self.getSparkSession(self.appName)

        def getSparkSession(self, appname):
                """
                This method used to create SparkSession object.
                :param appname:
                :return: spark
                """
                return SparkSession.builder.appName(appname).enableHiveSupport().getOrCreate()
import json

class JobConfig():
    def __init__(self):
        self.kv = {}
        self.env_name = None
        self.job_name = None
        self.load_type = None
        self.start_date = None
        self.end_date = None
        self.debug = None
        self.td_publish_flag = None
        self.data_download_refresh = None
        self.load_loop_counter = None
        self.load_delta_period = None
        self.load_post_arrival_day_count = None
        self.max_dataload_dt = None
        self.hive_ref_write_loc = None


    @classmethod
    def createJobConfig(cls, json_object):
        obj = JobConfig()
        kv_pair = {}
        if json_object is not None:
            print json_object
            obj.env_name = json_object["env.name"]
            obj.job_name = json_object["job.name"]
            try:
               obj.max_dataload_dt = json_object["etl.run.max_dataload_dt"]
            except:
               pass
            try:
               obj.debug = int(json_object["job.debug"])
            except:
               obj.debug = 0
            try:
                obj.hive_ref_write_loc = json_object["hive.ref.write.loc"]
            except:
                pass
            obj.load_type = json_object["etl.load.type"]
            obj.start_date = json_object["etl.run.bus.prd.start.timestamp"]
            obj.end_date = json_object["etl.run.bus.prd.end.timestamp"]
            obj.td_publish_flag = json_object["teradata.publish.flag"]
            obj.load_loop_counter = json_object["etl.load.loop.counter"]
            obj.load_delta_period = json_object["etl.load.delta.period"]
            obj.load_post_arrival_day_count = json_object["etl.load.post.arrival.day.count"]
            for key,value in json_object.iteritems():
               kv_pair[key]= value
            obj.kv = kv_pair
        return obj


class HWMConfig():
    def __init__(self):
        self.items = {}

    @classmethod
    def createHWMConfig(cls, json_object):
        obj = JobConfig()
        kv_pair = {}
        if json_object is not None:
            for key, value in json_object.iteritems():
                kv_pair[key] = value
            obj.items = kv_pair
        return obj


class JobResult():
    def __init__(self):
        self.app_id = None
        self.app_name = None
        self.job_name = None
        self.env_name = None

        self.start_date = None
        self.end_date = None
        self.load_type = None
        self.args = []

        self.start_date_timestamp = None
        self.end_date_timestamp = None
        self.duration = None
        self.result_count = None
        self.job_status = False
        self.publish_flag = False
        self.error = None

        self.job_config = None


    def display(self):
        print ""
        print "#########################Job Result Metrics#####################################"
        print "app_id                   ===> ", self.app_id
        print "app_name                 ===> ", self.app_name
        print "job_name                 ===> ", self.job_name
        print "env_name                 ===> ", self.env_name
        print "start_date               ===> ", self.start_date
        print "end_date                 ===> ", self.end_date
        print "load_type                ===> ", self.load_type
        print "args                     ===> ", self.args
        print "start_date_timestamp     ===> ", self.start_date_timestamp
        print "end_date_timestamp       ===> ", self.end_date_timestamp
        print "duration                 ===> ", self.duration
        print "result_count             ===> ", self.result_count
        print "job_status               ===> ", self.job_status
        print "error                    ===> ", self.error
        print "job_config               ===> ", json.dumps(self.job_config)

        print "################################################################################"


class EnvConfig():
    def __init__(self):
        self.kv = {}
        self.env_name = None
        self.linux_root_directory = None
        self.hdfs_root_directory = None
        self.hdfs_temp_root_directory = None
        self.hdfs_work_root_directory = None
        self.hdfs_sha_directory = None
        self.hdfs_dm_directory = None
        self.hdfs_app_directory = None
        self.hdfs_arch_directory = None
        self.hdfs_default_file_format = None
        self.kafka_enable_auto_commit = None
        self.kafka_bootstrap_servers = None
        self.kafka_group_id = None
        self.kafka_security_protocol = None
        self.kafka_truststore_location = None
        self.kafka_truststore_password = None
        self.kafka_keystore_location = None
        self.kafka_keystore_password = None
        self.kafka_kerberose = None
        self.teradata_dbc = None
        self.teradata_environment = None
        self.teradata_jdbc_url = None
        self.teradata_uid = None
        self.teradata_pwd = None
        self.teradata_jdbc_driver = None
        self.teradata_db_prefix = None
        self.teradata_dcl_sha_db = None
        self.teradata_dcl_sha_vmdb = None
        self.teradata_dcl_dm_db = None
        self.teradata_dcl_dm_vmdb = None
        self.teradata_dcl_app_db = None
        self.teradata_dcl_app_vmdb = None
        self.teradata_dcl_arch_db = None
        self.teradata_dcl_arch_vmdb = None
        self.teradata_blctl_db = None
        self.teradata_blctl_vmdb = None

    @classmethod
    def createEnvConfig(cls, json_object):
        obj = EnvConfig()
        kv_pair = {}
        if json_object is not None:
            obj.env_name = json_object["env.name"]
            obj.linux_root_directory = json_object["linux.root.directory"]
            obj.hdfs_root_directory = json_object["hdfs.root.directory"]
            obj.hdfs_temp_root_directory = json_object["hdfs.temp.root.directory"]
            obj.hdfs_work_root_directory = json_object["hdfs.work.root.directory"]
            obj.teradata_dbc = json_object["teradata.dbc"]
            obj.teradata_environment = json_object["teradata.environment"]
            obj.teradata_jdbc_url = json_object["teradata.jdbc.url"]
            obj.teradata_uid = json_object["teradata.uid"]
            obj.teradata_pwd = json_object["teradata.pwd"]
            obj.teradata_jdbc_driver = json_object["teradata.jdbc.driver"]
            for key,value in json_object.iteritems():
               kv_pair[key]= value
            obj.kv = kv_pair
        return obj


class IntradayJobParam():
    def __init__(self):
        self.env_name = None
        self.job_name = None

        self.load_type = None
        self.start_date = None
        self.end_date = None
        self.debug = None
        self.td_publish_flag = None
        self.data_download_refresh = None
        self.load_loop_counter = None
        self.load_delta_period = None
        self.load_post_arrival_day_count = None
        self.max_dataload_dt = None
        self.high_water_mark_dts = None

        self.price_config_high_water_mark_dts = None;
        self.sl_lim_config_high_water_mark_dts = None;
        self.sl_lim_rcmd_high_water_mark_dts = None;

        self.price_rcmd_dtl_high_water_mark_dts = None;
        self.expect_oh_bkng_high_water_mark_dts = None;
        self.uncnstrn_bkng_high_water_mark_dts = None;

        self.uncnstrn_dmnd_fcs_high_water_mark_dts = None;
    @classmethod
    def createIntradayJobParam(cls, json_object):
        obj = IntradayJobParam()

        if json_object is not None:
            obj.env_name = json_object["env.name"]
            obj.job_name = json_object["job.name"]


            obj.high_water_mark_dts = json_object["pdp.intraday.high.water.mark.dts"]
            obj.price_config_high_water_mark_dts = json_object["price_config.high.water.mark.dts"]
            obj.sl_lim_config_high_water_mark_dts = json_object["sl_lim_config.high.water.mark.dts"]
            obj.sl_lim_rcmd_high_water_mark_dts = json_object["sl_lim_rcmd.high.water.mark.dts"]

            obj.price_rcmd_dtl_high_water_mark_dts = json_object["price_rcmd_dtl.high.water.mark.dts"]
            obj.expect_oh_bkng_high_water_mark_dts = json_object["expect_oh_bkng.high.water.mark.dts"]
            obj.uncnstrn_bkng_high_water_mark_dts = json_object["uncnstrn_bkng.high.water.mark.dts"]

            obj.uncnstrn_dmnd_fcs_high_water_mark_dts = json_object["uncnstrn_dmnd_fcs.high.water.mark.dts"]

            obj.debug = int(json_object["job.debug"])
            obj.load_type = json_object["etl.load.type"]
            obj.start_date = json_object["etl.run.bus.prd.start.timestamp"]
            obj.end_date = json_object["etl.run.bus.prd.end.timestamp"]
            obj.td_publish_flag = json_object["teradata.publish.flag"]
            obj.load_loop_counter = json_object["etl.load.loop.counter"]
            obj.load_delta_period = json_object["etl.load.delta.period"]
            obj.load_post_arrival_day_count = json_object["etl.load.post.arrival.day.count"]
            obj.max_dataload_dt = json_object["etl.run.max_dataload_dt"]
        return obj;

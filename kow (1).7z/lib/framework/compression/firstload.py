from pyspark.sql import SparkSession
import datetime
import json
from datetime import timedelta , date
import sys,os

date1= sys.argv[1]
path= sys.argv[2]
#Read JSON

jfil = open(path);
d = json.load(jfil)
default_date = d["default_date"]
closeDate = d["closeDate"]
ck_list = d["change_key"]
pk_list = d["Primary_key"]
S3inputPath = d["S3inputPath"]
S3outputPath = d["S3outputPath"]
tableName = d["tableName"]
openDate = d["openDate"]
columnList = d["columnList"]


select_list = columnList + openDate + closeDate

file1=S3inputPath[0]+date1+"/data/"

outfile=S3outputPath[0]+tableName[0]+"_delta_"+date1



spark = SparkSession.builder.master("yarn").getOrCreate()


#Read the file from S3 bucket and create a dataframe

df1= spark.read.option("header","true").orc(file1);
df2=df1.drop('vyge_vrsn_strt_dts')
df2.printSchema()

final_dump = df2.drop_duplicates()

#Put the final dump in S3

#Validation Check
final_dump.printSchema()
final_dump.count()
final_dump.show(10)

final_dump.select(select_list).coalesce(1).write.option("header", "true").mode("overwrite").orc(outfile)
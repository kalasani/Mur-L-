"""Description : This code creates versions of the record based on the change tracking columns
SCD - TYP2 update
Developed by : Srikant Das ( dass030)
Modified Date : 21-06-2018
Modified by : dass030
Takes 3 inputs as arguments dates of the files to be compared and the path of the JSON file
date2 - past date , date1 current date"""

#Import the required modules
from pyspark.sql import SparkSession
import datetime
import json
from datetime import timedelta , date
from pyspark.sql.functions import col
import sys,os

#import the system arguments
date2 = sys.argv[1]
date1 = sys.argv[2]
path = sys.argv[3]

#Read JSON
jfil = open(path);
d = json.load(jfil)
default_date = d["default_date"]
closeDate = d["closeDate"]
ck_list = d["change_key"]
pk_list = d["Primary_key"]
S3inputPath = d["S3inputPath"]
S3outputPath = d["S3outputPath"]
tableName = d["tableName"]
openDate = d["openDate"]
columnList = d["columnList"]

select_list=columnList + openDate+closeDate

"""Read the current file and the past delta file"""
currentfile=S3inputPath[0]+date1+"/data/"
prevDatafile=S3outputPath[0]+tableName[0]+"_delta_"+date2+"/"
#prevDatafile=S3inputPath[0]+date2+"/data/"
#latestDeltaFile=S3outputPath[0]+tableName[0]+"_delta_"+date2+"/"

outfile=S3outputPath[0]+tableName[0]+"_delta_"+date1
spark = SparkSession.builder.master("local").getOrCreate()

#Read the file from S3 bucket and create a dataframe
prev_df=spark.read.option("header","true").orc(prevDatafile);
current_df= spark.read.option("header","true").orc(currentfile);
prev_df =prev_df.drop_duplicates()
current_df=current_df.drop_duplicates()

"""Below will be used for debugging"""
#delta_df=delta_df.drop_duplicates().filter("vyge_id = 166015 and price_mod_dt='2017-11-07'" )

prev_df.createOrReplaceTempView("vw_past")
current_df.createOrReplaceTempView("vw_current")

#Query Builder to find the new records from current data
qstr1 = "select a.* from vw_current a left join vw_past b on "
for i in range(0, len(pk_list)):
	qstr1 += "a." + str(pk_list[i]) + "="+ "b." + str(pk_list[i]) + " and "
qstr1 = qstr1[:-4]
qstr1 += " where "
qstr1 += "("
for j in range(0, len(ck_list)):
	qstr1 += "b." + str(ck_list[j]) + " is NULL and "
qstr1 = qstr1[:-4]
qstr1 += ")"

new_rec = spark.sql(qstr1)

#query Builder to find the newly updated records
qstr2 = "select a.* from vw_current a inner join vw_past b on "
for i in range(0,len(pk_list)):
	qstr2 += "a." + str(pk_list[i]) + "="+" b." + str(pk_list[i]) + " and "
qstr2 += "("
for j in range(0, len(ck_list)):
	qstr2 += "a." + str(ck_list[j]) + "!= b." + str(ck_list[j]) + " or "
qstr2 = qstr2[:-4]
qstr2 += ")"

old_rec_update = spark.sql(qstr2)
old_rec_update=old_rec_update.drop_duplicates()

#query Builder to find the unchanged records from prev file
qs_un_del = "select a.* from vw_current a inner join vw_past b on "
for i in range(0,len(pk_list)):
	qs_un_del += "a." + str(pk_list[i]) + "="+" b." + str(pk_list[i]) + " and "
qs_un_del += "("
for j in range(0, len(ck_list)):
	qs_un_del += "a." + str(ck_list[j]) + "= b." + str(ck_list[j]) + " or "
qs_un_del = qs_un_del[:-4]
qs_un_del += ")"

old_rec_unchange = spark.sql(qs_un_del)
old_rec_unchange=old_rec_unchange.drop_duplicates()
old_rec_unchange.createOrReplaceTempView("old_rec_unchange")

#query Builder to find the old records and update the end date
qstr3 = "select "
for i in range(0,len(columnList)):
	qstr3 += "b." + str(columnList[i]) + " ,"
qstr3 += "b."
qstr3 += openDate[0]
qstr3 += ",a."+openDate[0]
qstr3 += " as "+ closeDate[0]
qstr3 += " from vw_past b inner join vw_current a on "
for i in range(0,len(pk_list)):
	qstr3 += "a." + str(pk_list[i]) + "="+" b." + str(pk_list[i]) + " and "
qstr3 = qstr3[:-4]
qstr3 += " where "
qstr3 += "("
for j in range(0, len(ck_list)):
	qstr3 += "a." + str(ck_list[j]) + "!= b." + str(ck_list[j]) + " or "
qstr3 = qstr3[:-4]
qstr3 += ")"

closeRecords = spark.sql(qstr3)
closeRecords=closeRecords.drop_duplicates()

final_delta = new_rec.select(select_list).unionAll(old_rec_update.select(select_list)).unionAll(closeRecords.select(select_list))\
						.unionAll(old_rec_unchange.select(select_list)).drop_duplicates()

#Put the final dump in S3
#final_delta.show(5)
#print "The count of final dataset ",final_delta.count()

"""Activate the below code to do a Sanity check and debugging"""
#print("Count of last delta"),prev_df.count()
#print("Count of last file"),current_df.count()
#current_df.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'" ).show()
#prev_df.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'" ).show()
#print("Unchnaged records")
#old_rec_unchange.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'").show()
#closeRecords.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'").show()
#old_rec_update.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'").show()
#new_rec.filter("vyge_id = 166015 and price_mod_dt='2017-11-07'").show()
#print outfile

"""Write the final output to S3 as a delta file of the current date"""
final_delta.select(select_list).coalesce(1).write.option("header", "true").mode("overwrite").orc(outfile)
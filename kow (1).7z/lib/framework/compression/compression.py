import json
from datetime import datetime
from datetime import timedelta
from pyspark.sql import SparkSession
from pyspark import SparkConf
from pyspark.sql import Row
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys, traceback
from framework.utils.S3DataLoader import *
from framework.utils.DataFrameUtil import *
from framework.utils.ConfigReader import *
from itertools import chain
import time
import os


# createDeltafileNew.py  -1 2018-01-28 2018-01-29 hist_price_vyge_price_pd_baseln
# conf = SparkConf().setAppName('compression').setMaster('local[2]')
# spark = SparkContext(conf=conf)
# sql_context = SQLContext(spark)
# spark.setLogLevel("ERROR")
# s3_bucket = "s3a://wdpr-ia-dclrms/d3t"

def version_it(rows, change_keys, pkeys, start_dt, end_dt):
    """
     Attributes:
     rows: the partition block that is being processed
     change_keys: the keys that are going to compared for the versioning to happen list of strings
     pkeys: the columns list without the dates which form the primary key
     start_dt: the name of the column that identiifies the start date
     end_dt: th ename of the column that identifies the end date

     approach and flow of logic:
     creates two dynamic keys by concatenating columns
     primary key without the dates
     metrics - all metrics that need to be measured
     this data is sorted by pk and start_dt
     we discard the data when there is no change in metrics , for
     all other cases it is versioned by changing the dates
    """
    final_summary_list = []
    last_pk = "-1"
    last_metric = "-1"
    base_dt = None
    base_row = None
    pk_value = None
    metric_value = None
    for row in rows:
        vals = []
        pkey = []
        for x in change_keys:
            str = "%s" % row[x]
            vals.append(str)
        for x in pkeys:
            str = "%s" % row[x]
            pkey.append(str)
        pk_value = ",".join(pkey)
        metric_value = ",".join(vals)

        # all keys initializeda
        if base_row == None:
            base_row = row
            base_dt = row[end_dt]
        elif pk_value != last_pk:
            tp = base_row.asDict()
            tp["vrsn_end_dts"] = base_dt
            # output previous row as it is  a valid last record and not the very first record
            final_summary_list.append(Row(**tp))
            base_row = row
            base_dt = row[end_dt]
        elif pk_value == last_pk:
            if last_metric != metric_value:
                # pks are same but we need to version it
                tp = base_row.asDict()
                tp["vrsn_end_dts"] = row[start_dt]
                final_summary_list.append(Row(**tp))
                base_row = row
                base_dt = row[end_dt]

        # final_summary_list.append(Row(",".join(pkey),",".join(vals)))
        last_pk = pk_value
        last_metric = metric_value
    if base_row != None:
        tp = base_row.asDict()
        tp["vrsn_end_dts"] = base_dt
        final_summary_list.append(Row(**tp))
    return iter(final_summary_list)


def read_data_to_be_versioned(path, data_loader, start_dt, end_dt):
    dt = end_dt
    df_output_final = None
    schema = None
    while dt <= end_dt:
        new_path = path.replace("##DATE##", str(dt))
        print
        new_path
        df_output = data_loader.read_data_from_path(new_path)
        dt = dt + timedelta(1)
        if df_output_final == None:
            df_output_final = df_output
            schema = df_output_final.schema
            break
        else:
            df_output_final = df_output_final.union(df_output)
    new_path = path.replace("##DATE##", str(end_dt))
    filter_clause = "date(%s) >= date('%s') and date(%s) <= date('%s')" % (
    "vrsn_strt_dts", start_dt, "vrsn_strt_dts", end_dt)
    print
    filter_clause
    df_final = data_loader.read_all_data(new_path, schema).filter(filter_clause)
    count = df_final.count()
    print
    " count is %s " % count
    return df_final.withColumn("new_data", lit(1).cast("int"))


def version_data(ref_dt, start_dt, end_dt, table_name, sql_context, s3_bucket):
    """
       ref_dt will be refresh for an iniital load
       ref_dt can be set to "latest" inidcating regular incremental run
       ref_dt can be set to a date -- for catchup scenarios - assuming we have data available for txn_dt in delta files

       start_dt to end_dt data will loaded and versioned in comparison with data
    """
    data_loader = S3DataLoader(sql_context, s3_bucket)
    converter = DataFrameUtil(sql_context)
    config_reader = ConfigReader()
    table_list = config_reader.read_json_as_string("compressed_tables.json")
    # f=open("config/compressed_tables.json","r")
    # json_str = f.read()
    # f.close()
    selected_item = None
    for item in table_list:
        if item["table_name"] == table_name:
            selected_item = item
    f = lambda x: version_it(x, selected_item["change_key"], selected_item["primary_key_no_dt"],
                             selected_item["open_date"], selected_item["close_date"])
    if selected_item != None:
        schema = None
        select_list = selected_item["columnList"] + ["new_data"]
        ref_data_df = None
        versioned_data_df = read_data_to_be_versioned(selected_item["inputPath"], data_loader, start_dt, end_dt).select(
            select_list)
        if ref_dt.strip() != "refresh":
            ref_dt_is_date = 0
            reference_dt = None
            try:
                reference_dt = datetime.strptime(ref_dt, "%Y-%m-%d").date()
                ref_dt_is_date = 1
            except:
                pass
            if ref_dt_is_date == 1:
                ref_data_df = data_loader.read_data_from_path(
                    selected_item["latestDatePath"].replace("##DATE##", str(reference_dt))).withColumn("new_data",
                                                                                                       lit(0).cast(
                                                                                                           "int"))
            else:
                ref_data_df = data_loader.read_data_from_path(selected_item["latestPath"]).withColumn("new_data",
                                                                                                      lit(0).cast(
                                                                                                          "int"))
            # reference data we only need to load the ones which have 9999 as the end date as the other data is already versioned
            filter_clause = " date(%s) == date('9999-12-31') " % selected_item["close_date"]
            ref_data_df = ref_data_df.filter(filter_clause)
            versioned_data_df = versioned_data_df.union(ref_data_df.select(select_list))
        schema = versioned_data_df.schema
        exprs_partition = [col(x) for x in selected_item["primary_key_no_dt"]]
        sort_list = selected_item["primary_key_no_dt"][:]
        sort_list.append(selected_item["open_date"])
        exprs_sort = [col(x) for x in sort_list]
        final_versioned_rdd = versioned_data_df.repartition(*exprs_partition) \
            .sortWithinPartitions(*exprs_sort) \
            .rdd.mapPartitions(f, preservesPartitioning=True).toDF().select(select_list)
        final_versioned_df = converter.convertRddToDataFrame(final_versioned_rdd.rdd, schema)
        final_versioned_df.createOrReplaceTempView("final_versioned_df")

        # print final_versioned_df.schema
        # final_versioned_df.show()
        # sys.exit(1)
        # final_versioned_df.show()
        # new_data 1 needs to be put into teradata always
        # new data 0 only the ones whose end date is not 9999 - indicates it was versioned needs to be loaded to teradata
        final_versioned_df.cache()
        data_loader.write_data_to_path(selected_item["latestPath"], final_versioned_df)
        data_loader.write_data_to_path(selected_item["latestDatePath"].replace("##DATE##", str(end_dt)),
                                       final_versioned_df)
        # dfv=data_loader.read_data_from_path(selected_item["latestDatePath"].replace("##DATE##",str(end_dt)))
        # dfv.show()
        # final_versioned_df.unpersist()


def run_compression(reference_dt, start_dt_str, end_dt_str, table_name, sql_context, s3_bucket):
    start_dt = None
    end_dt = None
    try:
        ref_dt = reference_dt
        start_dt = datetime.strptime(start_dt_str, "%Y-%m-%d").date()
        end_dt = datetime.strptime(end_dt_str, "%Y-%m-%d").date()
    except:
        print
        "*****************************"
        "error in parsing input parameters"
        traceback.print_exc()
        sys.exit(-1)

    try:
        print
        "************START VERSIONING*****************"
        version_data(ref_dt, start_dt, end_dt, table_name, sql_context, s3_bucket)
        print
        "************END VERSIONING*******************"
    except:
        print
        "*****************************"
        traceback.print_exc()
        sys.exit(-1)

# driver("refresh","2018-01-27","2018-01-29","hist_price_vyge_price_pd_baseln")
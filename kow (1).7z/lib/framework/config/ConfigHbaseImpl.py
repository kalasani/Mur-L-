import json
import sys, os
from os import path
from pyspark.sql.types import *

sys.path.append(path.dirname(path.dirname(path.dirname(path.abspath(__file__)))))

from framework.config.ConfigBase import ConfigBase
#from framework.core.BaseJob import BaseJob
from ConfigBase import ConfigBase
from framework.core.Audit import JobConfig, EnvConfig, HWMConfig, IntradayJobParam


data_source_format = 'org.apache.spark.sql.execution.datasources.hbase'

config_table = "di_configuration"

result_table = "di_job_runs"

HWM_table = "di_high_water_mark"

job_catalog = ''.join(("""{
                    "table":{"namespace":"default", "name":\"""" + config_table + """\"},
                    "rowkey":"key",
                    "columns":{
                        "rowkey":{"cf":"rowkey", "col":"key", "type":"string"},
                        "value":{"cf":"configuration", "col":"value", "type":"string"}
                    }
                }""").split())


result_catalog = ''.join(("""{
                    "table":{"namespace":"default", "name":\"""" + result_table + """\"},
                    "rowkey":"key",
                    "columns":{
                        "rowkey":{"cf":"rowkey", "col":"key", "type":"string"},
                        "appId":{"cf":"metrics", "col":"appId", "type":"string"},
                        "appName":{"cf":"metrics", "col":"appName", "type":"string"},
                        "jobName":{"cf":"metrics", "col":"jobName", "type":"string"},
                        "envName":{"cf":"metrics", "col":"envName", "type":"string"},
                        "startDateTimestamp":{"cf":"metrics", "col":"startDateTimestamp", "type":"string"},
                        "endDateTimestamp":{"cf":"metrics", "col":"endDateTimestamp", "type":"string"},
                        "duration":{"cf":"metrics", "col":"duration", "type":"string"},
                        "resultCount":{"cf":"metrics", "col":"resultCount", "type":"string"},
                        "jobStatus":{"cf":"metrics", "col":"jobStatus", "type":"string"},
                        "error":{"cf":"metrics", "col":"error", "type":"string"},
                        "publishFlag":{"cf":"metrics", "col":"publishFlag", "type":"string"},
                        "args":{"cf":"metrics", "col":"args", "type":"string"},     
                        "startDate":{"cf":"metrics", "col":"startDate", "type":"string"},
                        "endDate":{"cf":"metrics", "col":"endDate", "type":"string"},
                        "LoadType":{"cf":"metrics", "col":"LoadType", "type":"string"},                                          
                        "inputParam":{"cf":"configuration", "col":"inputParam", "type":"string"}                        
                    }
                }""").split())


HWM_catalog = ''.join(("""{
                    "table":{"namespace":"default", "name":\"""" + HWM_table + """\"},
                    "rowkey":"key",
                    "columns":{
                        "rowkey":{"cf":"rowkey", "col":"key", "type":"string"},
                        "value":{"cf":"configuration", "col":"value", "type":"string"}
                    }
                }""").split())


class ConfigHbase(ConfigBase):
    def __init__(self, spark, env, job, LOGGER):
        self.spark = spark
        self.env = env # BaseJob.ENVIRONMENT
        self.df_di_configuration = self.spark.read.options(catalog=job_catalog).format(data_source_format).load()
        super(ConfigHbase, self).__init__(job, LOGGER)
        self.LOGGER.debug("catalog ==> " + job_catalog)

    def initJobConfig(self, isDownload=False):
        if self.JobConfig is None:
            job = self.env + "_" + self.job
            print "reading JobConfig from HBase --> Key : "+job.lower()
            res = self.df_di_configuration.filter(self.df_di_configuration.rowkey == job.lower()).select("value")

            if res.count() != 1:
                print "Job Parameter not found in HBase table."
                return None

            res_json = json.loads(res.toJSON().collect()[0])

            print "#########PARAM###########"
            print res_json["value"]
            print "#########################"

            self.JobConfig = JobConfig.createJobConfig(json.loads(res_json["value"]))

    def initEnvConfig(self):
        if self.EnvConfig is None:
            job = self.env
            print "reading EnvConfig from HBase --> Key : "+job.lower()
            res = self.df_di_configuration.filter(self.df_di_configuration.rowkey == job.lower()).select("value")

            if res.count() != 1:
                print "Environment Configuration not found in HBase table."
                sys.exit(-1)

            res_json = json.loads(res.toJSON().collect()[0])

            print "#########ENV###########"
            print res_json["value"]
            print "#######################"

            self.EnvConfig = EnvConfig.createEnvConfig(json.loads(res_json["value"]))

    def initHWMConfig(self):
        self.df_di_high_water_mark = self.spark.read.options(catalog=HWM_catalog).format(data_source_format).load()
        if self.HWMConfig is None:
            job = self.env + "_" + self.job
            print "reading HWMConfig from HBase --> Key : "+job.lower()
            res = self.df_di_high_water_mark.filter(self.df_di_high_water_mark.rowkey == job.lower()).select("value")

            if res.count() != 1:
                print "High water mark not found in HBase table for job " + self.job
                return None

            res_json = json.loads(res.toJSON().collect()[0])

            print "#########HWM###########"
            print res_json["value"]
            print "#######################"

            self.HWMConfig = HWMConfig.createHWMConfig(json.loads(res_json["value"]))


    def getTableConfig(self, table):
        table_name = self.env + "_" + table + "_tdi"
        print "reading TableConfig from HBase --> Key : " + table_name.lower()
        res = self.df_di_configuration.filter(self.df_di_configuration.rowkey == table_name.lower()).select("value")

        if res.count() != 1:
            print "Table metadata not found in HBase table."
            return None

        res_json = json.loads(res.toJSON().collect()[0])

        print "#########PARAM###########"
        print json.loads(res_json["value"])
        print "#########################"

        return json.loads(res_json["value"])

    def getMetaConfig(self):
        pass

    def readData(self, job):
        job = self.env + "_" + job
        print "reading data from HBase --> Key : " + job
        res = self.df_di_configuration.filter(self.df_di_configuration.rowkey == job.lower()).select("value")

        if res.count() != 1:
            print "Data not found in HBase table."
            sys.exit(-1)

        res_json = json.loads(res.toJSON().collect()[0])

        print "#########DATA###########"
        print res_json["value"]
        print "########################"

        return IntradayJobParam.createIntradayJobParam(json.loads(res_json["value"]))

    def writeData(self, job, data):
        #job means row_keyName
        job = self.env + "_" + job

        json_data = json.dumps(data)
        #jsonRDD = self.spark.sparkContext.parallelize(data1)
        key_val = [(job.lower(), json_data)]
        df = self.spark.createDataFrame(key_val, ['rowkey', 'value'])
        df.write.option("catalog", job_catalog).option("newtable", "5").format(data_source_format).save()


    def validate(self, value):
        if value is not None:
            return str(value)
        else:
            return "null"

    def writeResult(self, key, data):

        print ""
        print "Key :" +key
        print ""
        data.display()

        if key is not None:

            keys_schema = StructType([StructField("rowkey", StringType(), True),
                                      StructField("appId", StringType(), True),
                                      StructField("appName", StringType(), True),
                                      StructField("jobName", StringType(), True),
                                      StructField("envName", StringType(), True),
                                      StructField("startDateTimestamp", StringType(), True),
                                      StructField("endDateTimestamp", StringType(), True),
                                      StructField("duration", StringType(), True),
                                      StructField("resultCount", StringType(), True),
                                      StructField("jobStatus", StringType(), True),
                                      StructField("error", StringType(), True),
                                      StructField("publishFlag", StringType(), True),
                                      StructField("args", StringType(), True),
                                      StructField("startDate", StringType(), True),
                                      StructField("endDate", StringType(), True),
                                      StructField("LoadType", StringType(), True),
                                      StructField("inputParam", StringType(), True)
                                      ])

            val = [(key, self.validate(data.app_id), self.validate(data.app_name), self.validate(data.job_name),
                    self.validate(data.env_name), self.validate(data.start_date_timestamp),
                    self.validate(data.end_date_timestamp), self.validate(data.duration),
                    self.validate(data.result_count), self.validate(data.job_status), self.validate(data.error),
                    self.validate(data.publish_flag), self.validate(data.args), self.validate(data.start_date),
                    self.validate(data.end_date), self.validate(data.load_type),
                    self.validate(json.dumps(data.job_config)))]

            df = self.spark.createDataFrame(val, keys_schema)

            df.write.option("catalog", result_catalog).option("newtable", "5").format(data_source_format).save()

    def writeHWM(self, data):
        self.writeKeyHWM(self.job,data)

    def writeKeyHWM(self, key, data):

        key = self.env + "_" + key
        json_data = json.dumps(data)

        print json_data
        key_val = [(key.lower(), json_data)]
        df = self.spark.createDataFrame(key_val, ['rowkey', 'value'])
        df.write.option("catalog", HWM_catalog).option("newtable", "5").format(data_source_format).save()
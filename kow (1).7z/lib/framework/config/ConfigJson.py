from datetime import date, datetime, timedelta
import json
from ConfigBase import *
import os


class ConfigJson(ConfigBase):
    def __init__(self, job, LOGGER):
        path = "framework/config/json"
        # path = os.path.dirname(os.path.abspath(__file__)) + "/json"
        self.di_config_env = '%s/di_configuration_environment.json' % (path)
        self.di_config_job = '%s/di_configuration_job.json' % (path)
        self.TableInforamtionFileName = '%s/meta_data_config.json' % (path)
        self.di_config_meta = '%s/di_configuration_meta.json' % (path)
        super(ConfigJson, self).__init__(job, LOGGER)

    def initEnvConfig(self):
        if self.EnvConfig is None:
            self.EnvConfig = EnvConfig.createEnvConfig(self.readJson(self.di_config_env))

    def initJobConfig(self, isDownload=False):
        if self.JobConfig is None:
            param_info = self.readJson(self.di_config_job)
            job = self.job
            if isDownload:
                job = "download_" + self.job
            filter_output = [item for item in param_info if item['job.name'].lower() == job.lower()]
            if not filter_output:
                # self.logger.error("Table not found")
                print("Job Param not found")
                return None

            self.JobConfig = JobConfig.createJobConfig(filter_output[0])

    def initHWMConfig(self):
        self.HWMConfig = None

    def getTableConfig(self, table):
        tableinformation = self.readJson(self.TableInforamtionFileName)
        filter_output = [item for item in tableinformation if item['table_name'].lower() == table.lower()]
        if not filter_output:
            # self.logger.error("Table not found")
            print("Table not found")
            return -1
        return filter_output[0]

    def readData(self, job_name, isDownload=False):
        if self.IntradayJobParam is None:
            param_info = self.readJson(self.di_config_job)
            print("param_info==>",param_info)
            job = job_name
            #job=self.env + "_" + job_name
            print("Job ==>",job)
            if isDownload:
                job = "download_" + job_name
            filter_output = [item for item in param_info if item['job.name'].lower() == job.lower()]
            print("filter_output==>",filter_output)
            if not filter_output:
                # self.logger.error("Table not found")
                print("Job Param not found")
                return None

            self.IntradayJobParam = IntradayJobParam.createIntradayJobParam(filter_output[0])
            # self.JobConfigObj = self.createJobConfig(self.readJson(self.di_config_job))
        return self.IntradayJobParam

    def getMetaConfig(self):
        return self.readJson(self.di_config_meta)


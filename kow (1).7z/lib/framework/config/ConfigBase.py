import json
import sys, os
from os import path

sys.path.append(path.dirname(path.dirname(path.dirname(path.abspath(__file__)))))
from framework.core.Audit import *

class ConfigBase(object):
    def __init__(self, job, LOGGER):
        path = "framework/config/json"
        self.environment = '%s/environment.json' % (path)
        self.T2HConfig = None
        self.dmConfig = None
        self.EnvConfig = None
        self.JobConfig = None
        self.HWMConfig = None
        self.IntradayJobParam=None
        self.job = job
        self.LOGGER = LOGGER
        self.initEnvConfig()
        self.initJobConfig()



    def getEnvironment(self):
        return self.readJson(self.environment)

    def getEnvConfig(self):
        return self.EnvConfig

    def getJobConfig(self):
        return self.JobConfig

    def getHWMConfig(self):
        return self.HWMConfig


    @staticmethod
    def readJson(file_name):
        with open(file_name) as json_file:
            return (json.load(json_file))

    def initJobConfig(self, isDownload=False):
        raise NotImplementedError

    def initEnvConfig(self):
        raise NotImplementedError

    def initHWMConfig(self):
        raise NotImplementedError

    def getTableConfig(self, table):
        raise NotImplementedError

    def getMetaConfig(self):
        raise NotImplementedError

    def readData(self, key):
        pass

    def writeData(self, key, data):
        pass

    def writeResult(self, key, data):
        pass

    def update(self):
        pass